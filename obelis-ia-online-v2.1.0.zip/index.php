<?php
// define('DEBUG_MODE', true);
// index.php (Versión Final)

error_reporting(E_ALL);
ini_set('display_errors', '1');


session_start();
ob_start();

// Cargar configuración y clases principales
require_once __DIR__ . '/src/Config/config.php'; // Asegura que GEMINI_API_KEY esté disponible
require_once __DIR__ . '/vendor/autoload.php';


use ObelisIA\Router\MainRouter;
use ObelisIA\Database\Database;
use ObelisIA\Auth\Auth;
use ObelisIA\Services\MetaTagGenerator; // Para la generación de meta etiquetas con IA


$database = new Database();
$db = $database->getConnection();
$auth = new Auth($db);

// Registrar actividad de navegación en cada carga de página para usuarios autenticados
if (isset($_SESSION['user_id'])) {
    require_once __DIR__ . '/helpers/log_activity.php';
    $currentUrl = $_SERVER['REQUEST_URI'] ?? '';
    log_user_activity($db, $_SESSION['user_id'], 'Navegación', $currentUrl);
}

// Lógica para cerrar sesión
if (isset($_GET['logout'])) {
    // Borrar actividad reciente de este usuario (solo de hoy)
    if (isset($_SESSION['user_id'])) {
        $userId = $_SESSION['user_id'];
        require_once __DIR__ . '/src/Database/Database.php';
        $database = new Database();
        $db = $database->getConnection();
        $stmt = $db->prepare("DELETE FROM activity_logs WHERE user_id = ? AND DATE(created_at) = CURDATE()");
        $stmt->execute([$userId]);
    }
    $auth->logout();
    MainRouter::redirect('inicio');
}

// Resolver la ruta para obtener el archivo de contenido
$page_to_include = null;
$tool_slug = null;
// Obtener la ruta y excluir el panel admin del controlador principal
$requestUri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$route = trim(substr($requestUri, strlen(MainRouter::getBasePath())), '/');

// Si la ruta es admin o inicia con admin/, delegar al controlador propio y salir
if ($route === 'admin' || strpos($route, 'admin/') === 0) {
    require __DIR__ . '/admin/index.php';
    exit;
}

// Enrutamiento dinámico para el resto del sitio
if (strpos($route, 'herramientas') === 0) {
    $parts = explode('/', $route);
    if (isset($parts[1]) && !empty($parts[1])) {
        $tool_slug = $parts[1];
    }
    $page_to_include = __DIR__ . '/pages/tools_page.php';
} else {
    $page_to_include = MainRouter::resolve();
}

// --- NUEVO FLUJO OPTIMIZADO PARA META TAGS ---

// 1. Configurar meta tags por defecto
$default_title = 'ObelisIA - Herramientas de IA para creadores y empresas';
$default_description = 'ObelisIA ofrece un conjunto de herramientas de inteligencia artificial para edición de imágenes, generación de texto, composición musical y más. Impulsa tu creatividad con nuestras soluciones.';
$default_keywords = 'ObelisIA, IA, inteligencia artificial, herramientas IA, edición de imágenes, generador de imágenes, generador de texto, composición musical, herramientas para creadores, empresas IA';

$page_title = $default_title;
$page_description = $default_description;
$page_keywords = $default_keywords;

// 2. Consultar meta tags existentes en la base de datos PRIMERO
$stmt = $db->prepare("SELECT title, description, keywords FROM pages_meta WHERE route = :route");
$stmt->bindParam(':route', $route);
$stmt->execute();
$metaTags = $stmt->fetch(PDO::FETCH_ASSOC);

if ($metaTags && !empty($metaTags['title'])) {
    // Meta tags ya existen en DB - usarlas inmediatamente
    $page_title = $metaTags['title'];
    $page_description = $metaTags['description'];
    $page_keywords = $metaTags['keywords'];
} else {
    // Meta tags no existen - usar defaults y generar en background
    // (Las variables ya están configuradas con los valores por defecto)
}

// 3. Incluir header INMEDIATAMENTE con meta tags disponibles
include __DIR__ . '/src/Utils/header.php';

// 4. Mostrar contenido de la página
if (file_exists($page_to_include)) {
    include $page_to_include;
} else {
    include __DIR__ . '/pages/error/404.php';
}

// 5. Generar meta tags en BACKGROUND si no existían (para futuras visitas)
if (!$metaTags || empty($metaTags['title'])) {
    register_shutdown_function(function() use ($db, $route, $page_to_include) {
        try {
            // Capturar contenido para análisis de IA
            ob_start();
            if (file_exists($page_to_include)) {
                include $page_to_include;
            }
            $pageContent = ob_get_clean();
            
            // Generar meta tags con IA
            $metaGenerator = new MetaTagGenerator();
            $meta = $metaGenerator->generate($pageContent, $route);
            
            if (is_array($meta) && !empty($meta['title'])) {
                // Guardar en la base de datos para futuras visitas
                $stmt = $db->prepare("INSERT INTO pages_meta (route, title, description, keywords) VALUES (:route, :title, :description, :keywords)
                    ON DUPLICATE KEY UPDATE title=VALUES(title), description=VALUES(description), keywords=VALUES(keywords), last_updated=CURRENT_TIMESTAMP()");
                $stmt->execute([
                    ':route' => $route,
                    ':title' => $meta['title'],
                    ':description' => $meta['description'],
                    ':keywords' => $meta['keywords']
                ]);
            }
        } catch (\Throwable $e) {
            error_log('Background meta generation error: ' . $e->getMessage());
        }
    });
}

// 6. Incluir el pie de página
include __DIR__ . '/src/Utils/footer.php';