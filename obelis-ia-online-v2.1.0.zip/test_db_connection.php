<?php
/**
 * Test de conexión con variables de entorno
 * Verifica que la configuración de .env funcione correctamente
 */

require_once __DIR__ . '/helpers/db.php';

echo "🔧 Probando conexión a la base de datos con variables de entorno...\n\n";

// Mostrar variables cargadas (sin mostrar contraseña)
echo "📋 Variables de entorno cargadas:\n";
echo "   DB_HOST: " . ($_ENV['DB_HOST'] ?? 'no definido') . "\n";
echo "   DB_NAME: " . ($_ENV['DB_NAME'] ?? 'no definido') . "\n";
echo "   DB_USER: " . ($_ENV['DB_USER'] ?? 'no definido') . "\n";
echo "   DB_PASS: " . (isset($_ENV['DB_PASS']) ? '[definido]' : 'no definido') . "\n";
echo "   GEMINI_API_KEY: " . (isset($_ENV['GEMINI_API_KEY']) ? '[definido]' : 'no definido') . "\n\n";

// Probar conexión MySQLi
echo "🔗 Probando conexión MySQLi...\n";
try {
    $db = getDbConnection();
    if ($db) {
        echo "✅ Conexión MySQLi exitosa!\n";
        echo "   Charset: " . $db->character_set_name() . "\n";
        echo "   Versión del servidor: " . $db->server_info . "\n";
        $db->close();
    } else {
        echo "❌ Error en conexión MySQLi\n";
    }
} catch (Exception $e) {
    echo "❌ Error MySQLi: " . $e->getMessage() . "\n";
}

echo "\n";

// Probar conexión PDO
echo "🔗 Probando conexión PDO...\n";
try {
    $pdo = getPdoConnection();
    if ($pdo) {
        echo "✅ Conexión PDO exitosa!\n";
        $version = $pdo->query('SELECT VERSION()')->fetchColumn();
        echo "   Versión del servidor: " . $version . "\n";
        
        // Probar una consulta simple
        $stmt = $pdo->query('SELECT COUNT(*) as total FROM users');
        $result = $stmt->fetch();
        echo "   Total de usuarios: " . $result['total'] . "\n";
    } else {
        echo "❌ Error en conexión PDO\n";
    }
} catch (Exception $e) {
    echo "❌ Error PDO: " . $e->getMessage() . "\n";
}

echo "\n🎉 Prueba de conexión completada!\n";
?>
