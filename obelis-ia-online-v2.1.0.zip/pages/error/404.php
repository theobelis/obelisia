<?php
// pages/error/404.php
$page_title = "Página no encontrada - ObelisIA";
$body_class = "error-page";
?>

    <div class="error-container py-5">
        <!-- Elementos flotantes de fondo -->
        <div class="floating-elements">
            <div class="floating-element"></div>
            <div class="floating-element"></div>
            <div class="floating-element"></div>
            <div class="floating-element"></div>
        </div>
        
        <div class="error-card bg-light">
            <!-- Número de error -->
            <div class="error-number">404</div>
            
            <!-- Título -->
            <h1 class="error-title">¡Oops! Página no encontrada</h1>
            
            <!-- Descripción -->
            <p class="error-description">
                La página que estás buscando no existe o ha sido movida. 
                No te preocupes, te ayudamos a encontrar lo que necesitas.
            </p>
            
            <!-- Buscador -->
            <div class="search-box">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="¿Qué estás buscando?" id="errorSearch">
                    <button class="btn btn-primary-custom" type="button">
                        <i class="material-icons">search</i>
                    </button>
                </div>
            </div>
            
            <!-- Sugerencias -->
            <div class="search-suggestions">
                <h6 class="mb-3">¿Quizás estás buscando?</h6>
                <a href="/" class="suggestion-item">
                    <i class="material-icons">home</i>
                    <span>Página principal</span>
                </a>
                <a href="/panel" class="suggestion-item">
                    <i class="material-icons">dashboard</i>
                    <span>Mi Dashboard</span>
                </a>
                <a href="/acceso" class="suggestion-item">
                    <i class="material-icons">login</i>
                    <span>Iniciar sesión</span>
                </a>
                <a href="/contacto" class="suggestion-item">
                    <i class="material-icons">support_agent</i>
                    <span>Contacto y soporte</span>
                </a>
            </div>
            
            <!-- Botones de acción -->
            <div class="error-actions">
                <a href="/" class="btn btn-primary-custom">
                    <i class="material-icons me-2">home</i>
                    Ir al Inicio
                </a>
                <button onclick="history.back()" class="btn btn-outline-primary">
                    <i class="material-icons me-2">arrow_back</i>
                    Volver Atrás
                </button>
            </div>
        </div>
    </div>
    
    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Funcionalidad de búsqueda
        document.getElementById('errorSearch').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const searchTerm = this.value.trim();
                if (searchTerm) {
                    // Redirigir a la página principal con el término de búsqueda
                    window.location.href = '/?search=' + encodeURIComponent(searchTerm);
                }
            }
        });
        
        // Animación de entrada
        document.addEventListener('DOMContentLoaded', function() {
            const card = document.querySelector('.error-card');
            card.style.opacity = '0';
            card.style.transform = 'translateY(30px)';
            
            setTimeout(() => {
                card.style.transition = 'all 0.6s ease';
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, 100);
        });
        
        // Tracking de eventos (opcional)
        if (typeof gtag !== 'undefined') {
            gtag('event', 'page_view', {
                page_title: '404 Error',
                page_location: window.location.href
            });
        }
    </script>
</html>
