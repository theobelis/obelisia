<?php
/**
 * Página de Checkout Profesional - ObelisIA
 * Sistema completo de pagos con PayPal, Stripe y tarjetas de crédito/débito
 */

// Cargar configuración
require_once __DIR__ . '/../../src/Config/config.php';

// Verificar autenticación
if (!$auth->isLoggedIn()) {
    \ObelisIA\Router\MainRouter::redirect('acceso');
}

// Obtener parámetros del plan
$plan = $_GET['plan'] ?? 'premium';
$billing = $_GET['billing'] ?? 'monthly';

// Configuración de planes
$plans = [
    'premium' => [
        'name' => 'ObelisIA Premium',
        'monthly' => ['price' => 19.00, 'currency' => 'USD', 'period' => 'mes'],
        'yearly' => ['price' => 190.00, 'currency' => 'USD', 'period' => 'año', 'savings' => '2 meses gratis'],
        'features' => [
            'Generaciones ilimitadas sin anuncios',
            'Removedor de fondo avanzado',
            'Editor de imágenes profesional',
            'Videos IA sin límite',
            'Sin marca de agua',
            'Soporte prioritario 24/7',
            'Acceso completo a Obelis Studio',
            'Exportación en alta calidad'
        ]
    ]
];

// Validar plan y facturación
if (!isset($plans[$plan]) || !in_array($billing, ['monthly', 'yearly'])) {
    header('Location: /precios');
    exit;
}

$selected_plan = $plans[$plan];
$price_info = $selected_plan[$billing];
$user = $auth->getCurrentUser();

$page_title = "Checkout - " . $selected_plan['name'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - ObelisIA</title>
    
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        
        .checkout-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .checkout-header {
            text-align: center;
            margin-bottom: 40px;
        }
        
        .checkout-header h1 {
            background: var(--gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            font-weight: 700;
            font-size: 2.5rem;
            margin-bottom: 10px;
        }
        
        .checkout-card {
            background: white;
            border-radius: 20px;
            box-shadow: var(--shadow);
            padding: 30px;
            margin-bottom: 30px;
            transition: all 0.3s ease;
        }
        
        .checkout-card:hover {
            box-shadow: var(--shadow-hover);
            transform: translateY(-2px);
        }
        
        .plan-summary {
            background: var(--gradient);
            color: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
        }
        
        .plan-summary h3 {
            margin-bottom: 15px;
            font-weight: 600;
        }
        
        .price-display {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 10px;
        }
        
        .price-period {
            opacity: 0.8;
            font-size: 1rem;
        }
        
        .savings-badge {
            background: rgba(255, 255, 255, 0.2);
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9rem;
            display: inline-block;
            margin-top: 10px;
        }
        
        .features-list {
            list-style: none;
            padding: 0;
            margin-top: 20px;
        }
        
        .features-list li {
            padding: 8px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .features-list li:last-child {
            border-bottom: none;
        }
        
        .features-list i {
            margin-right: 10px;
            color: #4ade80;
        }
        
        .payment-method {
            border: 2px solid #e5e7eb;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .payment-method:hover,
        .payment-method.active {
            border-color: var(--primary-color);
            background: rgba(102, 126, 234, 0.05);
        }
        
        .payment-method-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .payment-method-info {
            display: flex;
            align-items: center;
        }
        
        .payment-method-icon {
            width: 50px;
            height: 50px;
            background: var(--gradient);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            margin-right: 15px;
            font-size: 1.2rem;
        }
        
        .payment-logos {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 10px;
        }
        
        .payment-logos img {
            height: 24px;
            opacity: 0.7;
        }
        
        .form-control {
            border: 2px solid #e5e7eb;
            border-radius: 10px;
            padding: 12px 15px;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .btn-checkout {
            background: var(--gradient);
            border: none;
            color: white;
            padding: 15px 30px;
            border-radius: 50px;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            width: 100%;
        }
        
        .btn-checkout:hover {
            background: var(--gradient-hover);
            transform: translateY(-2px);
            box-shadow: var(--shadow-hover);
            color: white;
        }
        
        .btn-checkout:disabled {
            opacity: 0.6;
            transform: none;
            cursor: not-allowed;
        }
        
        .security-info {
            text-align: center;
            margin-top: 20px;
            color: #6b7280;
            font-size: 0.9rem;
        }
        
        .security-info i {
            color: #10b981;
            margin-right: 5px;
        }
        
        .order-summary {
            background: #f8fafc;
            border-radius: 15px;
            padding: 20px;
            margin-top: 20px;
        }
        
        .order-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .order-row:last-child {
            border-bottom: none;
            font-weight: 600;
            font-size: 1.1rem;
            color: var(--primary-color);
        }
        
        .spinner {
            width: 20px;
            height: 20px;
            border: 2px solid #ffffff;
            border-top: 2px solid transparent;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .alert-custom {
            border: none;
            border-radius: 15px;
            padding: 15px 20px;
        }
        
        .breadcrumb-custom {
            background: white;
            border-radius: 50px;
            padding: 10px 20px;
            margin-bottom: 30px;
            box-shadow: var(--shadow);
        }
        
        @media (max-width: 768px) {
            .checkout-container {
                padding: 10px;
            }
            
            .checkout-header h1 {
                font-size: 2rem;
            }
            
            .checkout-card {
                padding: 20px;
            }
            
            .plan-summary {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="checkout-container">
        <!-- Breadcrumb -->
        <nav class="breadcrumb-custom">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                <li class="breadcrumb-item"><a href="/precios">Precios</a></li>
                <li class="breadcrumb-item active">Checkout</li>
            </ol>
        </nav>

        <!-- Header -->
        <div class="checkout-header">
            <h1><i class="fas fa-shopping-cart me-3"></i>Finalizar Compra</h1>
            <p class="text-muted">Completa tu compra de forma segura en pocos pasos</p>
        </div>

        <div class="row">
            <!-- Columna Principal - Métodos de Pago -->
            <div class="col-lg-8">
                <div class="checkout-card">
                    <h3 class="mb-4"><i class="fas fa-credit-card me-2"></i>Método de Pago</h3>
                    
                    <!-- Mensajes de Error -->
                    <div id="error-message" class="alert alert-danger alert-custom d-none"></div>
                    <div id="success-message" class="alert alert-success alert-custom d-none"></div>
                    
                    <!-- Método PayPal -->
                    <div class="payment-method" data-method="paypal">
                        <div class="payment-method-header">
                            <div class="payment-method-info">
                                <div class="payment-method-icon">
                                    <i class="fab fa-paypal"></i>
                                </div>
                                <div>
                                    <h5 class="mb-1">PayPal</h5>
                                    <small class="text-muted">Paga de forma segura con tu cuenta PayPal</small>
                                </div>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="payment_method" value="paypal" id="paypal">
                            </div>
                        </div>
                        <div class="payment-method-content mt-3" style="display: none;">
                            <div id="paypal-button-container"></div>
                        </div>
                    </div>

                    <!-- Método Tarjeta de Crédito/Débito -->
                    <div class="payment-method" data-method="card">
                        <div class="payment-method-header">
                            <div class="payment-method-info">
                                <div class="payment-method-icon">
                                    <i class="fas fa-credit-card"></i>
                                </div>
                                <div>
                                    <h5 class="mb-1">Tarjeta de Crédito/Débito</h5>
                                    <small class="text-muted">Visa, Mastercard, American Express</small>
                                    <div class="payment-logos">
                                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Visa_Inc._logo.svg/2560px-Visa_Inc._logo.svg.png" alt="Visa">
                                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Mastercard-logo.svg/1280px-Mastercard-logo.svg.png" alt="Mastercard">
                                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/American_Express_logo_%282018%29.svg/1200px-American_Express_logo_%282018%29.svg.png" alt="Amex">
                                    </div>
                                </div>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="payment_method" value="card" id="card" checked>
                            </div>
                        </div>
                        <div class="payment-method-content mt-4">
                            <form id="card-form">
                                <div class="row">
                                    <div class="col-12 mb-3">
                                        <label for="card_number" class="form-label">Número de Tarjeta</label>
                                        <div class="input-group">
                                            <input type="text" class="form-control" id="card_number" placeholder="1234 5678 9012 3456" maxlength="19" required>
                                            <span class="input-group-text"><i class="fas fa-credit-card"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="card_expiry" class="form-label">Fecha de Vencimiento</label>
                                        <input type="text" class="form-control" id="card_expiry" placeholder="MM/AA" maxlength="5" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="card_cvc" class="form-label">CVC</label>
                                        <input type="text" class="form-control" id="card_cvc" placeholder="123" maxlength="4" required>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12 mb-3">
                                        <label for="card_name" class="form-label">Nombre del Titular</label>
                                        <input type="text" class="form-control" id="card_name" placeholder="Nombre completo como aparece en la tarjeta" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Información de Facturación -->
                    <div class="checkout-card mt-4">
                        <h4 class="mb-3"><i class="fas fa-file-invoice me-2"></i>Información de Facturación</h4>
                        <form id="billing-form">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="billing_email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="billing_email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="billing_phone" class="form-label">Teléfono (Opcional)</label>
                                    <input type="tel" class="form-control" id="billing_phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-8 mb-3">
                                    <label for="billing_address" class="form-label">Dirección</label>
                                    <input type="text" class="form-control" id="billing_address" placeholder="Calle, número, piso, etc." required>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="billing_city" class="form-label">Ciudad</label>
                                    <input type="text" class="form-control" id="billing_city" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="billing_country" class="form-label">País</label>
                                    <select class="form-control" id="billing_country" required>
                                        <option value="">Seleccionar país</option>
                                        <option value="US">Estados Unidos</option>
                                        <option value="MX">México</option>
                                        <option value="ES">España</option>
                                        <option value="AR">Argentina</option>
                                        <option value="CO">Colombia</option>
                                        <option value="PE">Perú</option>
                                        <option value="CL">Chile</option>
                                        <option value="VE">Venezuela</option>
                                        <option value="EC">Ecuador</option>
                                        <option value="BO">Bolivia</option>
                                        <option value="UY">Uruguay</option>
                                        <option value="PY">Paraguay</option>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="billing_zip" class="form-label">Código Postal</label>
                                    <input type="text" class="form-control" id="billing_zip" required>
                                </div>
                            </div>
                        </form>
                    </div>

                    <!-- Botón de Pago -->
                    <button type="button" class="btn btn-checkout mt-4" id="process-payment" disabled>
                        <span id="payment-button-text">
                            <i class="fas fa-lock me-2"></i>
                            Procesar Pago Seguro - $<?php echo number_format($price_info['price'], 2); ?> <?php echo $price_info['currency']; ?>
                        </span>
                        <span id="payment-loading" style="display: none;">
                            <div class="spinner me-2"></div>Procesando...
                        </span>
                    </button>

                    <div class="security-info">
                        <i class="fas fa-shield-alt"></i>
                        <strong>Pago 100% Seguro:</strong> Utilizamos cifrado SSL de 256 bits para proteger tu información financiera.
                        <br>
                        <i class="fas fa-undo-alt"></i>
                        <strong>Garantía de 30 días:</strong> Si no estás satisfecho, te devolvemos tu dinero.
                    </div>
                </div>
            </div>

            <!-- Columna Derecha - Resumen del Pedido -->
            <div class="col-lg-4">
                <div class="checkout-card">
                    <div class="plan-summary">
                        <h3><?php echo $selected_plan['name']; ?></h3>
                        <div class="price-display">
                            $<?php echo number_format($price_info['price'], 0); ?>
                            <span class="price-period">/ <?php echo $price_info['period']; ?></span>
                        </div>
                        <?php if (isset($price_info['savings'])): ?>
                            <div class="savings-badge">
                                <i class="fas fa-tag me-1"></i><?php echo $price_info['savings']; ?>
                            </div>
                        <?php endif; ?>
                        
                        <ul class="features-list">
                            <?php foreach ($selected_plan['features'] as $feature): ?>
                                <li><i class="fas fa-check"></i> <?php echo $feature; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    
                    <div class="order-summary">
                        <h5 class="mb-3">Resumen del Pedido</h5>
                        <div class="order-row">
                            <span><?php echo $selected_plan['name']; ?> (<?php echo ucfirst($billing); ?>)</span>
                            <span>$<?php echo number_format($price_info['price'], 2); ?></span>
                        </div>
                        <div class="order-row">
                            <span>Descuentos</span>
                            <span>$0.00</span>
                        </div>
                        <div class="order-row">
                            <span>Impuestos</span>
                            <span>Incluidos</span>
                        </div>
                        <div class="order-row">
                            <strong>Total</strong>
                            <strong>$<?php echo number_format($price_info['price'], 2); ?> <?php echo $price_info['currency']; ?></strong>
                        </div>
                    </div>
                    
                    <div class="mt-3 text-center">
                        <small class="text-muted">
                            <i class="fas fa-info-circle me-1"></i>
                            La suscripción se renovará automáticamente. Puedes cancelar en cualquier momento.
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php if(defined('PAYPAL_CLIENT_ID') && PAYPAL_CLIENT_ID): ?>
    <script src="https://www.paypal.com/sdk/js?client-id=<?php echo PAYPAL_CLIENT_ID; ?>&currency=<?php echo $price_info['currency']; ?>"></script>
    <?php endif; ?>
    
    <script>
        // Configuración global
        const CHECKOUT_CONFIG = {
            plan: '<?php echo $plan; ?>',
            billing: '<?php echo $billing; ?>',
            amount: <?php echo $price_info['price']; ?>,
            currency: '<?php echo $price_info['currency']; ?>',
            user_id: <?php echo $user['id']; ?>
        };
    </script>
    
    <script src="/assets/js/checkout/checkout.js"></script>
</body>
</html>