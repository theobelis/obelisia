<?php
$page_title = "Checkout Créditos - Obelis";

// Verificar autenticación
if (!isset($_SESSION['user_id'])) {
    header('Location: /acceso');
    exit;
}

$package_id = $_GET['package'] ?? null;
if (!$package_id) {
    header('Location: ' . \ObelisIA\Router\MainRouter::url('creditos'));
    exit;
}

// Obtener información del paquete
try {
    $stmt = $db->prepare("SELECT * FROM credit_packages WHERE id = ? AND is_active = 1");
    $stmt->execute([$package_id]);
    $package = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$package) {
        header('Location: ' . \ObelisIA\Router\MainRouter::url('creditos'));
        exit;
    }
} catch (Exception $e) {
    header('Location: ' . \ObelisIA\Router\MainRouter::url('creditos'));
    exit;
}

// Obtener datos del usuario
try {
    $stmt = $db->prepare("SELECT username, email, credits FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $user = ['username' => '', 'email' => '', 'credits' => 0];
}

$total_credits = $package['credits_amount'] + $package['bonus_credits'];
$price_per_credit = $package['price'] / $total_credits;
?>

<style>
.checkout-container {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    padding: 40px 0;
}

.checkout-card {
    background: white;
    border-radius: 20px;
    box-shadow: 0 20px 60px rgba(0,0,0,0.1);
    overflow: hidden;
}

.checkout-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 30px;
    text-align: center;
}

.checkout-content {
    padding: 40px;
}

.package-summary {
    background: #f8f9fa;
    border-radius: 15px;
    padding: 30px;
    margin-bottom: 30px;
}

.package-icon {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
    font-size: 2rem;
}

.credits-display {
    font-size: 3rem;
    font-weight: bold;
    color: #667eea;
    text-align: center;
    margin: 20px 0;
}

.bonus-indicator {
    background: #d4edda;
    color: #155724;
    padding: 10px 20px;
    border-radius: 25px;
    text-align: center;
    margin-bottom: 20px;
    font-weight: bold;
}

.order-details {
    background: white;
    border: 2px solid #e9ecef;
    border-radius: 15px;
    padding: 25px;
    margin-bottom: 30px;
}

.detail-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 0;
    border-bottom: 1px solid #e9ecef;
}

.detail-row:last-child {
    border-bottom: none;
    font-weight: bold;
    color: #2d3748;
    font-size: 1.1rem;
}

.payment-methods {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    gap: 15px;
    margin-bottom: 30px;
}

.payment-method {
    border: 2px solid #e9ecef;
    border-radius: 15px;
    padding: 20px;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s ease;
    background: white;
}

.payment-method:hover {
    border-color: #667eea;
    background: #f8f9ff;
}

.payment-method.selected {
    border-color: #667eea;
    background: linear-gradient(135deg, #f8f9ff 0%, #ffffff 100%);
}

.payment-method i {
    font-size: 2rem;
    margin-bottom: 10px;
    color: #667eea;
}

.payment-method .method-name {
    font-weight: bold;
    color: #2d3748;
    font-size: 14px;
}

.checkout-btn {
    background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
    border: none;
    color: white;
    padding: 18px 40px;
    border-radius: 50px;
    font-weight: bold;
    font-size: 1.1rem;
    width: 100%;
    transition: all 0.3s ease;
}

.checkout-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(72, 187, 120, 0.3);
    color: white;
}

.checkout-btn:disabled {
    background: #cbd5e0;
    cursor: not-allowed;
    transform: none;
    box-shadow: none;
}

.security-badges {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 20px;
    margin-top: 20px;
    padding-top: 20px;
    border-top: 1px solid #e9ecef;
}

.security-badge {
    display: flex;
    align-items: center;
    color: #718096;
    font-size: 14px;
}

.security-badge i {
    margin-right: 5px;
    color: #48bb78;
}

.terms-checkbox {
    margin: 20px 0;
}

.terms-checkbox label {
    cursor: pointer;
    user-select: none;
}

.loading-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.8);
    z-index: 9999;
    align-items: center;
    justify-content: center;
    color: white;
}

.loading-content {
    text-align: center;
}

.spinner {
    width: 60px;
    height: 60px;
    border: 4px solid rgba(255,255,255,0.3);
    border-top: 4px solid white;
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin: 0 auto 20px;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

@media (max-width: 768px) {
    .checkout-content {
        padding: 30px 20px;
    }
    
    .payment-methods {
        grid-template-columns: repeat(2, 1fr);
    }
}
</style>

<div class="checkout-container">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 col-xl-6">
                <div class="checkout-card">
                    <div class="checkout-header">
                        <h2 class="mb-0">
                            <i class="fas fa-shopping-cart me-3"></i>
                            Finalizar Compra
                        </h2>
                    </div>
                    
                    <div class="checkout-content">
                        <!-- Resumen del paquete -->
                        <div class="package-summary">
                            <div class="package-icon">
                                <i class="fas fa-coins"></i>
                            </div>
                            
                            <h3 class="text-center"><?= htmlspecialchars($package['package_name']) ?></h3>
                            
                            <div class="credits-display">
                                <?= number_format($package['credits_amount']) ?>
                                <small style="font-size: 1rem;">créditos</small>
                            </div>
                            
                            <?php if ($package['bonus_credits'] > 0): ?>
                            <div class="bonus-indicator">
                                <i class="fas fa-gift me-2"></i>
                                + <?= number_format($package['bonus_credits']) ?> créditos de regalo
                            </div>
                            <?php endif; ?>
                            
                            <div class="text-center text-muted">
                                Total: <strong><?= number_format($total_credits) ?> créditos</strong>
                            </div>
                        </div>
                        
                        <!-- Detalles del pedido -->
                        <div class="order-details">
                            <h5 class="mb-3">
                                <i class="fas fa-receipt me-2"></i>
                                Detalles del Pedido
                            </h5>
                            
                            <div class="detail-row">
                                <span>Créditos base:</span>
                                <span><?= number_format($package['credits_amount']) ?></span>
                            </div>
                            
                            <?php if ($package['bonus_credits'] > 0): ?>
                            <div class="detail-row">
                                <span>Créditos bonus:</span>
                                <span class="text-success">+ <?= number_format($package['bonus_credits']) ?></span>
                            </div>
                            <?php endif; ?>
                            
                            <div class="detail-row">
                                <span>Precio por crédito:</span>
                                <span>$<?= number_format($price_per_credit, 4) ?></span>
                            </div>
                            
                            <div class="detail-row">
                                <span>Créditos actuales:</span>
                                <span><?= number_format($user['credits']) ?></span>
                            </div>
                            
                            <div class="detail-row">
                                <span>Créditos después de la compra:</span>
                                <span class="text-success"><?= number_format($user['credits'] + $total_credits) ?></span>
                            </div>
                            
                            <div class="detail-row">
                                <span><strong>Total a pagar:</strong></span>
                                <span><strong>$<?= number_format($package['price'], 2) ?> USD</strong></span>
                            </div>
                        </div>
                        
                        <!-- Métodos de pago -->
                        <h5 class="mb-3">
                            <i class="fas fa-credit-card me-2"></i>
                            Método de Pago
                        </h5>
                        
                        <div class="payment-methods">
                            <div class="payment-method selected" data-method="paypal">
                                <i class="fab fa-paypal"></i>
                                <div class="method-name">PayPal</div>
                            </div>
                            
                            <div class="payment-method" data-method="stripe">
                                <i class="far fa-credit-card"></i>
                                <div class="method-name">Tarjeta</div>
                            </div>
                            
                            <div class="payment-method" data-method="crypto">
                                <i class="fab fa-bitcoin"></i>
                                <div class="method-name">Crypto</div>
                            </div>
                        </div>
                        
                        <!-- Términos y condiciones -->
                        <div class="terms-checkbox">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="terms-agreement" required>
                                <label class="form-check-label" for="terms-agreement">
                                    Acepto los <a href="<?php echo \ObelisIA\Router\MainRouter::url('legal/terminos'); ?>" target="_blank">términos y condiciones</a> 
                                    y la <a href="<?php echo \ObelisIA\Router\MainRouter::url('legal/privacidad'); ?>" target="_blank">política de privacidad</a>
                                </label>
                            </div>
                        </div>
                        
                        <!-- Botón de compra -->
                        <button class="checkout-btn" id="checkout-button" disabled onclick="processPayment()">
                            <i class="fas fa-lock me-2"></i>
                            Pagar $<?= number_format($package['price'], 2) ?> - Compra Segura
                        </button>
                        
                        <!-- Badges de seguridad -->
                        <div class="security-badges">
                            <div class="security-badge">
                                <i class="fas fa-shield-alt"></i>
                                Pago Seguro
                            </div>
                            <div class="security-badge">
                                <i class="fas fa-lock"></i>
                                SSL 256-bit
                            </div>
                            <div class="security-badge">
                                <i class="fas fa-undo"></i>
                                Garantía 30 días
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Loading overlay -->
<div class="loading-overlay" id="loading-overlay">
    <div class="loading-content">
        <div class="spinner"></div>
        <h4>Procesando tu pago...</h4>
        <p>Por favor, no cierres esta ventana</p>
    </div>
</div>

<script>
let selectedPaymentMethod = 'paypal';

// Manejar selección de método de pago
document.querySelectorAll('.payment-method').forEach(method => {
    method.addEventListener('click', function() {
        document.querySelectorAll('.payment-method').forEach(m => m.classList.remove('selected'));
        this.classList.add('selected');
        selectedPaymentMethod = this.dataset.method;
    });
});

// Manejar checkbox de términos
document.getElementById('terms-agreement').addEventListener('change', function() {
    const checkoutBtn = document.getElementById('checkout-button');
    checkoutBtn.disabled = !this.checked;
});

// Función para procesar el pago
function processPayment() {
    const loadingOverlay = document.getElementById('loading-overlay');
    loadingOverlay.style.display = 'flex';
    
    // Datos de la compra
    const purchaseData = {
        package_id: <?= $package['id'] ?>,
        credits_amount: <?= $package['credits_amount'] ?>,
        bonus_credits: <?= $package['bonus_credits'] ?>,
        total_amount: <?= $package['price'] ?>,
        payment_method: selectedPaymentMethod,
        currency: 'USD'
    };
    
    // Simular procesamiento (aquí integrarías con PayPal, Stripe, etc.)
    setTimeout(() => {
        // En una implementación real, aquí harías la llamada a la API de pago
        simulatePaymentSuccess(purchaseData);
    }, 3000);
}

function simulatePaymentSuccess(purchaseData) {
    // Enviar datos al servidor para registrar la compra
    fetch('/api/checkout/process_credit_purchase.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(purchaseData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Redirigir a página de éxito
            window.location.href = '/checkout/success?type=credits&purchase_id=' + data.purchase_id;
        } else {
            alert('Error procesando el pago: ' + data.message);
            document.getElementById('loading-overlay').style.display = 'none';
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error de conexión. Por favor, intenta de nuevo.');
        document.getElementById('loading-overlay').style.display = 'none';
    });
}
</script>