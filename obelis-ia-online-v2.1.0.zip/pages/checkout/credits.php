<?php
$page_title = "Comprar Créditos - Obelis";

// Verificar autenticación
if (!isset($_SESSION['user_id'])) {
    header('Location: /acceso');
    exit;
}

// Obtener paquetes de créditos
try {
    $stmt = $db->prepare("
        SELECT * FROM credit_packages 
        WHERE is_active = 1 
        ORDER BY sort_order, credits_amount ASC
    ");
    $stmt->execute();
    $packages = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $packages = [];
}

// Obtener créditos actuales del usuario
try {
    $stmt = $db->prepare("SELECT credits, subscription_type FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user_data = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $user_data = ['credits' => 0, 'subscription_type' => 'free'];
}
?>

<style>
.credits-container {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    padding: 40px 0;
}

.credits-header {
    background: white;
    border-radius: 20px 20px 0 0;
    padding: 40px;
    text-align: center;
    box-shadow: 0 -5px 20px rgba(0,0,0,0.1);
}

.credits-content {
    background: white;
    border-radius: 0 0 20px 20px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.1);
    overflow: hidden;
}

.current-credits {
    background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
    color: white;
    padding: 30px;
    text-align: center;
    margin-bottom: 40px;
}

.credits-icon {
    width: 80px;
    height: 80px;
    background: rgba(255,255,255,0.2);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
    font-size: 2rem;
}

.package-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 25px;
    padding: 40px;
}

.package-card {
    background: white;
    border: 2px solid #e9ecef;
    border-radius: 15px;
    padding: 30px;
    text-align: center;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.package-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 20px 40px rgba(0,0,0,0.1);
    border-color: #667eea;
}

.package-card.popular {
    border-color: #667eea;
    background: linear-gradient(135deg, #f8f9ff 0%, #ffffff 100%);
}

.package-card.popular::before {
    content: "MÁS POPULAR";
    position: absolute;
    top: 15px;
    right: -25px;
    background: #667eea;
    color: white;
    padding: 5px 30px;
    font-size: 12px;
    font-weight: bold;
    transform: rotate(45deg);
}

.credits-amount {
    font-size: 3rem;
    font-weight: bold;
    color: #667eea;
    margin: 20px 0;
}

.bonus-credits {
    background: #f0fff4;
    color: #38a169;
    padding: 8px 15px;
    border-radius: 20px;
    font-size: 14px;
    font-weight: bold;
    display: inline-block;
    margin-bottom: 20px;
}

.package-price {
    font-size: 2rem;
    font-weight: bold;
    color: #2d3748;
    margin-bottom: 10px;
}

.price-per-credit {
    color: #718096;
    font-size: 14px;
    margin-bottom: 20px;
}

.package-features {
    text-align: left;
    margin: 20px 0;
}

.package-features li {
    margin-bottom: 8px;
    color: #4a5568;
}

.package-features i {
    color: #48bb78;
    margin-right: 8px;
}

.buy-btn {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border: none;
    color: white;
    padding: 15px 30px;
    border-radius: 50px;
    font-weight: bold;
    transition: all 0.3s ease;
    width: 100%;
}

.buy-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(102, 126, 234, 0.3);
    color: white;
}

.credits-info {
    background: #f8f9fa;
    padding: 40px;
    border-top: 1px solid #e9ecef;
}

.info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 30px;
}

.info-item {
    text-align: center;
}

.info-icon {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 15px;
    font-size: 1.5rem;
}

.tool-costs {
    background: white;
    border-radius: 15px;
    padding: 30px;
    margin-top: 40px;
}

.cost-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 0;
    border-bottom: 1px solid #e9ecef;
}

.cost-item:last-child {
    border-bottom: none;
}

.tool-info {
    display: flex;
    align-items: center;
}

.tool-info i {
    color: #667eea;
    margin-right: 10px;
    width: 20px;
}

.cost-amount {
    font-weight: bold;
    color: #2d3748;
}

@media (max-width: 768px) {
    .package-grid {
        grid-template-columns: 1fr;
        padding: 20px;
    }
    
    .credits-header {
        padding: 30px 20px;
    }
}
</style>

<div class="credits-container">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="credits-header">
                    <h1 class="mb-3">
                        <i class="fas fa-coins text-warning me-3"></i>
                        Comprar Créditos
                    </h1>
                    <p class="lead mb-0">Impulsa tu creatividad con créditos para usar todas las herramientas de IA</p>
                </div>
                
                <div class="credits-content">
                    <div class="current-credits">
                        <div class="credits-icon">
                            <i class="fas fa-wallet"></i>
                        </div>
                        <h3>Créditos Actuales</h3>
                        <div class="h2 mb-0">
                            <span id="current-credits"><?= number_format($user_data['credits']) ?></span>
                            <small>créditos</small>
                        </div>
                        <?php if ($user_data['subscription_type'] === 'premium'): ?>
                        <small class="opacity-75">+ 1,000 créditos mensuales con Premium</small>
                        <?php endif; ?>
                    </div>
                    
                    <div class="package-grid">
                        <?php foreach ($packages as $index => $package): ?>
                        <div class="package-card <?= $index === 2 ? 'popular' : '' ?>">
                            <h4><?= htmlspecialchars($package['package_name']) ?></h4>
                            
                            <div class="credits-amount">
                                <?= number_format($package['credits_amount']) ?>
                                <small style="font-size: 1rem;">créditos</small>
                            </div>
                            
                            <?php if ($package['bonus_credits'] > 0): ?>
                            <div class="bonus-credits">
                                + <?= number_format($package['bonus_credits']) ?> créditos bonus
                            </div>
                            <?php endif; ?>
                            
                            <div class="package-price">
                                $<?= number_format($package['price'], 2) ?>
                            </div>
                            
                            <div class="price-per-credit">
                                $<?= number_format($package['price'] / ($package['credits_amount'] + $package['bonus_credits']), 4) ?> por crédito
                            </div>
                            
                            <ul class="package-features list-unstyled">
                                <li><i class="fas fa-check"></i> Válidos para todas las herramientas</li>
                                <li><i class="fas fa-check"></i> No expiran nunca</li>
                                <li><i class="fas fa-check"></i> Acceso inmediato</li>
                                <?php if ($package['bonus_credits'] > 0): ?>
                                <li><i class="fas fa-gift"></i> <?= $package['bonus_credits'] ?> créditos de regalo</li>
                                <?php endif; ?>
                            </ul>
                            
                            <button class="buy-btn" onclick="purchaseCredits(<?= $package['id'] ?>)">
                                <i class="fas fa-shopping-cart me-2"></i>
                                Comprar Ahora
                            </button>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="credits-info">
                        <h3 class="text-center mb-4">¿Cómo funcionan los créditos?</h3>
                        
                        <div class="info-grid">
                            <div class="info-item">
                                <div class="info-icon">
                                    <i class="fas fa-bolt"></i>
                                </div>
                                <h5>Uso Inmediato</h5>
                                <p>Los créditos se aplican instantáneamente a tu cuenta para usar en cualquier herramienta.</p>
                            </div>
                            
                            <div class="info-item">
                                <div class="info-icon">
                                    <i class="fas fa-infinity"></i>
                                </div>
                                <h5>No Expiran</h5>
                                <p>Tus créditos no tienen fecha de vencimiento. Úsalos cuando quieras.</p>
                            </div>
                            
                            <div class="info-item">
                                <div class="info-icon">
                                    <i class="fas fa-tools"></i>
                                </div>
                                <h5>Todas las Herramientas</h5>
                                <p>Un solo tipo de crédito para acceder a todas nuestras herramientas de IA.</p>
                            </div>
                            
                            <div class="info-item">
                                <div class="info-icon">
                                    <i class="fas fa-shield-alt"></i>
                                </div>
                                <h5>Compra Segura</h5>
                                <p>Procesamos pagos de forma segura con encriptación de grado bancario.</p>
                            </div>
                        </div>
                        
                        <div class="tool-costs">
                            <h4 class="text-center mb-4">Costo por Herramienta</h4>
                            
                            <div class="cost-item">
                                <div class="tool-info">
                                    <i class="fas fa-pen-fancy"></i>
                                    <span>Generador de Texto</span>
                                </div>
                                <span class="cost-amount">1 crédito</span>
                            </div>
                            
                            <div class="cost-item">
                                <div class="tool-info">
                                    <i class="fas fa-language"></i>
                                    <span>Traductor IA</span>
                                </div>
                                <span class="cost-amount">1 crédito</span>
                            </div>
                            
                            <div class="cost-item">
                                <div class="tool-info">
                                    <i class="fas fa-spell-check"></i>
                                    <span>Mejorador de Texto</span>
                                </div>
                                <span class="cost-amount">2 créditos</span>
                            </div>
                            
                            <div class="cost-item">
                                <div class="tool-info">
                                    <i class="fas fa-search"></i>
                                    <span>Optimizador SEO</span>
                                </div>
                                <span class="cost-amount">2 créditos</span>
                            </div>
                            
                            <div class="cost-item">
                                <div class="tool-info">
                                    <i class="fas fa-image"></i>
                                    <span>Generador de Imágenes</span>
                                </div>
                                <span class="cost-amount">3 créditos</span>
                            </div>
                            
                            <div class="cost-item">
                                <div class="tool-info">
                                    <i class="fas fa-volume-up"></i>
                                    <span>Generador de Audio</span>
                                </div>
                                <span class="cost-amount">5 créditos</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function purchaseCredits(packageId) {
    // Aquí implementarías la lógica de compra
    // Por ahora, redirigir al checkout con el paquete seleccionado
    window.location.href = `/creditos/comprar?package=${packageId}`;
}

// Actualizar créditos en tiempo real
function updateCreditsDisplay() {
    fetch('/api/tools/get_user_stats.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('current-credits').textContent = 
                    new Intl.NumberFormat().format(data.credits);
            }
        })
        .catch(error => console.error('Error actualizando créditos:', error));
}

// Actualizar cada 30 segundos
setInterval(updateCreditsDisplay, 30000);
</script>

