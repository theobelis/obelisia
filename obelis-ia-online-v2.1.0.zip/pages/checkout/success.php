<?php
require_once __DIR__ . '/../../helpers/csrf.php';

// Verificar que el usuario esté autenticado
if (!isset($_SESSION['user_id'])) {
    header('Location: /acceso');
    exit;
}

$purchase_type = $_GET['type'] ?? 'subscription';
$purchase_id = $_GET['purchase_id'] ?? null;
$payment_id = $_GET['payment_id'] ?? null;

// Obtener información según el tipo de compra
$purchase_info = null;
$user_info = null;

if ($purchase_type === 'credits' && $purchase_id) {
    // Compra de créditos
    try {
        $stmt = $db->prepare("
            SELECT cp.*, pkg.package_name, pkg.credits_amount as package_credits, pkg.bonus_credits as package_bonus
            FROM credit_purchases cp 
            JOIN credit_packages pkg ON cp.package_id = pkg.id
            WHERE cp.id = ? AND cp.user_id = ?
        ");
        $stmt->execute([$purchase_id, $_SESSION['user_id']]);
        $purchase_info = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        error_log("Error obteniendo información de compra de créditos: " . $e->getMessage());
    }
} else {
    // Compra de suscripción (código original)
    if ($payment_id) {
        try {
            $stmt = $db->prepare("SELECT * FROM payments WHERE transaction_id = ? AND user_id = ? ORDER BY completed_at DESC LIMIT 1");
            $stmt->execute([$payment_id, $_SESSION['user_id']]);
            $purchase_info = $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error obteniendo información de pago: " . $e->getMessage());
        }
    }
}

// Obtener información actualizada del usuario
try {
    $stmt = $db->prepare("SELECT subscription_type, subscription_status, subscription_expires_at, credits FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user_info = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $user_info = null;
}

$page_title = $purchase_type === 'credits' ? "Créditos Comprados - Obelis" : "Confirmación de Pago - Obelis";
?>

<style>
.success-container {
    min-height: 80vh;
    display: flex;
    align-items: center;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.success-card {
    background: white;
    border-radius: 20px;
    box-shadow: 0 20px 60px rgba(0,0,0,0.1);
    overflow: hidden;
    max-width: 600px;
    width: 100%;
}

.success-header {
    background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
    color: white;
    padding: 40px 30px;
    text-align: center;
}

.success-icon {
    width: 80px;
    height: 80px;
    background: rgba(255,255,255,0.2);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
    font-size: 36px;
}

.success-content {
    padding: 40px 30px;
}

.payment-details {
    background: #f8f9fa;
    border-radius: 12px;
    padding: 25px;
    margin: 25px 0;
}

.detail-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 0;
    border-bottom: 1px solid #e2e8f0;
}

.detail-row:last-child {
    border-bottom: none;
}

.detail-label {
    font-weight: 600;
    color: #4a5568;
}

.detail-value {
    color: #2d3748;
    font-weight: 500;
}

.feature-list {
    background: #f0fff4;
    border: 1px solid #c6f6d5;
    border-radius: 8px;
    padding: 20px;
    margin: 25px 0;
}

.feature-list h5 {
    color: #2f855a;
    margin: 0 0 15px;
    font-weight: 600;
}

.feature-list ul {
    margin: 0;
    padding-left: 20px;
}

.feature-list li {
    color: #2d3748;
    margin-bottom: 8px;
}

.action-buttons {
    display: flex;
    gap: 15px;
    margin-top: 30px;
}

.btn-primary-gradient {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border: none;
    border-radius: 8px;
    color: white;
    padding: 12px 24px;
    font-weight: 600;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    transition: all 0.3s ease;
}

.btn-primary-gradient:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
    color: white;
    text-decoration: none;
}

.btn-outline {
    border: 2px solid #667eea;
    background: transparent;
    color: #667eea;
    border-radius: 8px;
    padding: 10px 24px;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s ease;
}

.btn-outline:hover {
    background: #667eea;
    color: white;
    text-decoration: none;
}

@media (max-width: 768px) {
    .success-container {
        padding: 20px;
    }
    
    .success-header {
        padding: 30px 20px;
    }
    
    .success-content {
        padding: 30px 20px;
    }
    
    .action-buttons {
        flex-direction: column;
    }
    
    .detail-row {
        flex-direction: column;
        align-items: flex-start;
        gap: 5px;
    }
}
</style>

<div class="success-container">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="success-card mx-auto">
                    <div class="success-header">
                        <div class="success-icon">
                            <i class="fas fa-<?= $purchase_type === 'credits' ? 'coins' : 'check' ?>"></i>
                        </div>
                        <h1 class="h2 mb-3">
                            <?= $purchase_type === 'credits' ? '¡Créditos Comprados!' : '¡Pago Exitoso!' ?>
                        </h1>
                        <p class="mb-0 opacity-90">
                            <?= $purchase_type === 'credits' ? 'Tus créditos han sido añadidos a tu cuenta' : 'Tu suscripción ha sido activada correctamente' ?>
                        </p>
                    </div>
                    
                    <div class="success-content">
                        <?php if ($purchase_type === 'credits' && $purchase_info): ?>
                        <!-- Contenido para compra de créditos -->
                        <div class="payment-details">
                            <h4 class="mb-3">
                                <i class="fas fa-coins text-warning me-2"></i>
                                Compra de Créditos
                            </h4>
                            
                            <div class="detail-row">
                                <span class="detail-label">Paquete</span>
                                <span class="detail-value">
                                    <span class="badge bg-warning text-dark"><?= htmlspecialchars($purchase_info['package_name']) ?></span>
                                </span>
                            </div>
                            
                            <div class="detail-row">
                                <span class="detail-label">Créditos Comprados</span>
                                <span class="detail-value fw-bold"><?= number_format($purchase_info['credits_purchased']) ?></span>
                            </div>
                            
                            <?php if ($purchase_info['bonus_credits'] > 0): ?>
                            <div class="detail-row">
                                <span class="detail-label">Créditos Bonus</span>
                                <span class="detail-value text-success">+ <?= number_format($purchase_info['bonus_credits']) ?></span>
                            </div>
                            <?php endif; ?>
                            
                            <div class="detail-row">
                                <span class="detail-label">Total Créditos</span>
                                <span class="detail-value fw-bold text-primary">
                                    <?= number_format($purchase_info['credits_purchased'] + $purchase_info['bonus_credits']) ?>
                                </span>
                            </div>
                            
                            <div class="detail-row">
                                <span class="detail-label">Monto Pagado</span>
                                <span class="detail-value fw-bold">
                                    $<?= number_format($purchase_info['amount_paid'], 2) ?> USD
                                </span>
                            </div>
                            
                            <div class="detail-row">
                                <span class="detail-label">Método de Pago</span>
                                <span class="detail-value">
                                    <i class="fab fa-<?= $purchase_info['payment_method'] === 'paypal' ? 'paypal' : ($purchase_info['payment_method'] === 'stripe' ? 'cc-visa' : 'bitcoin') ?> me-1"></i>
                                    <?= ucfirst(htmlspecialchars($purchase_info['payment_method'])) ?>
                                </span>
                            </div>
                            
                            <div class="detail-row">
                                <span class="detail-label">Fecha</span>
                                <span class="detail-value">
                                    <?= date('d/m/Y H:i', strtotime($purchase_info['payment_date'])) ?>
                                </span>
                            </div>
                        </div>
                        
                        <div class="feature-list">
                            <h5>
                                <i class="fas fa-bolt text-primary me-2"></i>
                                Tus créditos están listos
                            </h5>
                            <ul>
                                <li>Créditos actuales: <strong><?= number_format($user_info['credits']) ?></strong></li>
                                <li>Válidos para <strong>todas las herramientas de IA</strong></li>
                                <li><strong>No expiran nunca</strong></li>
                                <li>Acceso inmediato desde cualquier herramienta</li>
                            </ul>
                        </div>
                        
                        <div class="action-buttons">
                            <a href="<?php echo \ObelisIA\Router\MainRouter::url('herramientas-ia'); ?>" class="btn-primary-gradient flex-fill text-center">
                                <i class="fas fa-tools me-2"></i>
                                Usar Herramientas IA
                            </a>
                            <a href="<?php echo \ObelisIA\Router\MainRouter::url('creditos'); ?>" class="btn-outline flex-fill text-center">
                                <i class="fas fa-plus me-2"></i>
                                Comprar Más
                            </a>
                        </div>
                        
                        <?php elseif ($purchase_info): ?>
                        <!-- Contenido para suscripción (código original) -->
                        <div class="payment-details">
                            <h4 class="mb-3">
                                <i class="fas fa-receipt text-primary me-2"></i>
                                Detalles de la Transacción
                            </h4>
                            
                            <div class="detail-row">
                                <span class="detail-label">ID de Transacción</span>
                                <span class="detail-value font-monospace"><?= htmlspecialchars($purchase_info['transaction_id']) ?></span>
                            </div>
                            
                            <div class="detail-row">
                                <span class="detail-label">Plan</span>
                                <span class="detail-value">
                                    <span class="badge bg-primary"><?= ucfirst(htmlspecialchars($purchase_info['plan_type'])) ?></span>
                                </span>
                            </div>
                            
                            <div class="detail-row">
                                <span class="detail-label">Facturación</span>
                                <span class="detail-value"><?= ucfirst(htmlspecialchars($purchase_info['billing_cycle'])) ?></span>
                            </div>
                            
                            <div class="detail-row">
                                <span class="detail-label">Monto</span>
                                <span class="detail-value fw-bold">
                                    $<?= number_format($purchase_info['amount'], 2) ?> <?= strtoupper(htmlspecialchars($purchase_info['currency'])) ?>
                                </span>
                            </div>
                            
                            <div class="detail-row">
                                <span class="detail-label">Método de Pago</span>
                                <span class="detail-value">
                                    <i class="fab fa-<?= $purchase_info['payment_method'] === 'paypal' ? 'paypal' : 'cc-visa' ?> me-1"></i>
                                    <?= ucfirst(htmlspecialchars($purchase_info['payment_method'])) ?>
                                </span>
                            </div>
                            
                            <div class="detail-row">
                                <span class="detail-label">Fecha</span>
                                <span class="detail-value">
                                    <?= date('d/m/Y H:i', strtotime($purchase_info['completed_at'])) ?>
                                </span>
                            </div>
                        </div>
                        
                        <?php if ($user_info && $user_info['subscription_type'] === 'premium'): ?>
                        <div class="feature-list">
                            <h5>
                                <i class="fas fa-crown text-warning me-2"></i>
                                Ya puedes disfrutar de Premium
                            </h5>
                            <ul>
                                <li>Acceso completo a <strong>Obelis Studio</strong></li>
                                <li>Herramientas de IA avanzadas sin límites</li>
                                <li>Generación ilimitada de contenido</li>
                                <li>Exportación en múltiples formatos</li>
                                <li>Colaboración en tiempo real</li>
                                <li>Soporte prioritario</li>
                            </ul>
                            
                            <?php if ($user_info['subscription_expires_at']): ?>
                            <div class="mt-3 p-3 bg-light rounded">
                                <small class="text-muted">
                                    <i class="fas fa-calendar-alt me-1"></i>
                                    Tu suscripción es válida hasta: 
                                    <strong><?= date('d/m/Y', strtotime($user_info['subscription_expires_at'])) ?></strong>
                                </small>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                        
                        <div class="action-buttons">
                            <a href="/studio/" class="btn-primary-gradient flex-fill text-center">
                                <i class="fas fa-paint-brush me-2"></i>
                                Comenzar con Studio
                            </a>
                            <a href="<?php echo \ObelisIA\Router\MainRouter::url('perfil'); ?>" class="btn-outline flex-fill text-center">
                                <i class="fas fa-user me-2"></i>
                                Mi Perfil
                            </a>
                        </div>
                        <?php endif; ?>
                        
                        <div class="text-center mt-4">
                            <p class="text-muted mb-0">
                                <i class="fas fa-envelope me-1"></i>
                                Hemos enviado un email de confirmación a tu dirección registrada
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Confetti animation
function createConfetti() {
    const colors = ['#667eea', '#764ba2', '#48bb78', '#38a169', '#f093fb', '#f5576c'];
    
    for (let i = 0; i < 50; i++) {
        setTimeout(() => {
            const confetti = document.createElement('div');
            confetti.style.cssText = `
                position: fixed;
                top: -10px;
                left: ${Math.random() * 100}vw;
                width: 10px;
                height: 10px;
                background: ${colors[Math.floor(Math.random() * colors.length)]};
                z-index: 9999;
                border-radius: 50%;
                pointer-events: none;
                animation: confetti-fall 3s linear forwards;
            `;
            
            document.body.appendChild(confetti);
            
            setTimeout(() => {
                confetti.remove();
            }, 3000);
        }, i * 100);
    }
}

// CSS animation
const style = document.createElement('style');
style.textContent = `
    @keyframes confetti-fall {
        to {
            transform: translateY(100vh) rotate(360deg);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Start confetti
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(createConfetti, 500);
});
</script>
