<?php
// Verificar autenticación
if (!isset($_SESSION['user_id'])) {
    header('Location: /acceso');
    exit;
}

$search_query = trim($_GET['q'] ?? '');
$search_type = $_GET['type'] ?? 'all';
$creation_type = $_GET['creation_type'] ?? '';
$tool = $_GET['tool'] ?? '';

// Obtener herramientas disponibles para el filtro
try {
    $tools_stmt = $db->query("
        SELECT DISTINCT tool_used 
        FROM user_creations 
        WHERE privacy = 'public' AND tool_used IS NOT NULL 
        ORDER BY tool_used
    ");
    $available_tools = $tools_stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (Exception $e) {
    $available_tools = [];
}
?>

<div class="container-fluid py-4">
    <div class="row">
        <!-- Header -->
        <div class="col-12 mb-4">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h2 class="mb-1"><i class="fas fa-search me-2 text-primary"></i>Búsqueda Avanzada</h2>
                    <p class="text-muted mb-0">Encuentra creaciones y creadores increíbles</p>
                </div>
                <a href="/comunidad" class="btn btn-outline-primary">
                    <i class="fas fa-arrow-left me-1"></i>Volver al feed
                </a>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Filtros de búsqueda -->
        <div class="col-lg-3 col-md-4 mb-4">
            <div class="card shadow-sm sticky-top" style="top: 20px;">
                <div class="card-header bg-gradient-primary text-white">
                    <h5 class="mb-0"><i class="fas fa-sliders-h me-2"></i>Filtros de búsqueda</h5>
                </div>
                <div class="card-body">
                    <form method="GET" action="/buscar" id="searchForm">
                        <!-- Búsqueda principal -->
                        <div class="mb-3">
                            <label class="form-label"><i class="fas fa-search me-1"></i>Buscar</label>
                            <input type="text" class="form-control" name="q" value="<?= htmlspecialchars($search_query) ?>" 
                                   placeholder="Palabras clave..." required>
                        </div>

                        <!-- Tipo de búsqueda -->
                        <div class="mb-3">
                            <label class="form-label"><i class="fas fa-filter me-1"></i>Buscar en</label>
                            <select class="form-select" name="type">
                                <option value="all" <?= $search_type === 'all' ? 'selected' : '' ?>>Todo</option>
                                <option value="creations" <?= $search_type === 'creations' ? 'selected' : '' ?>>Solo creaciones</option>
                                <option value="users" <?= $search_type === 'users' ? 'selected' : '' ?>>Solo usuarios</option>
                            </select>
                        </div>

                        <!-- Tipo de creación -->
                        <div class="mb-3">
                            <label class="form-label"><i class="fas fa-layer-group me-1"></i>Tipo de creación</label>
                            <select class="form-select" name="creation_type">
                                <option value="">Todos los tipos</option>
                                <option value="image" <?= $creation_type === 'image' ? 'selected' : '' ?>>Imágenes</option>
                                <option value="text" <?= $creation_type === 'text' ? 'selected' : '' ?>>Texto</option>
                                <option value="video" <?= $creation_type === 'video' ? 'selected' : '' ?>>Videos</option>
                                <option value="music" <?= $creation_type === 'music' ? 'selected' : '' ?>>Música</option>
                                <option value="utility" <?= $creation_type === 'utility' ? 'selected' : '' ?>>Utilidades</option>
                            </select>
                        </div>

                        <!-- Herramienta -->
                        <div class="mb-3">
                            <label class="form-label"><i class="fas fa-tools me-1"></i>Herramienta</label>
                            <select class="form-select" name="tool">
                                <option value="">Todas las herramientas</option>
                                <?php foreach ($available_tools as $available_tool): ?>
                                    <option value="<?= htmlspecialchars($available_tool) ?>" <?= $tool === $available_tool ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($available_tool) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <button type="submit" class="btn btn-primary w-100 mb-2">
                            <i class="fas fa-search me-1"></i>Buscar
                        </button>
                        
                        <a href="/buscar" class="btn btn-outline-secondary w-100">
                            <i class="fas fa-times me-1"></i>Limpiar
                        </a>
                    </form>
                </div>
            </div>
        </div>

        <!-- Resultados -->
        <div class="col-lg-9 col-md-8">
            <div id="searchResults">
                <?php if (empty($search_query)): ?>
                    <!-- Estado inicial -->
                    <div class="text-center py-5">
                        <i class="fas fa-search fa-4x text-muted mb-4"></i>
                        <h3 class="text-muted mb-3">Busca creaciones y creadores</h3>
                        <p class="text-muted mb-4">Usa la barra de búsqueda para encontrar contenido increíble</p>
                        
                        <!-- Sugerencias populares -->
                        <div class="mb-4">
                            <h5 class="mb-3">Búsquedas populares:</h5>
                            <div class="d-flex flex-wrap justify-content-center gap-2">
                                <a href="/buscar?q=dragon" class="badge bg-primary fs-6 text-decoration-none">dragon</a>
                                <a href="/buscar?q=paisaje" class="badge bg-success fs-6 text-decoration-none">paisaje</a>
                                <a href="/buscar?q=retrato" class="badge bg-info fs-6 text-decoration-none">retrato</a>
                                <a href="/buscar?q=abstracto" class="badge bg-warning fs-6 text-decoration-none">abstracto</a>
                                <a href="/buscar?q=futurista" class="badge bg-danger fs-6 text-decoration-none">futurista</a>
                            </div>
                        </div>

                        <!-- Creaciones recientes -->
                        <div class="mt-5">
                            <h5 class="mb-3">Creaciones recientes</h5>
                            <?php
                            try {
                                $recent_sql = "
                                    SELECT 
                                        uc.id, uc.title, uc.file_path, uc.type,
                                        u.username, u.profile_image
                                    FROM user_creations uc
                                    JOIN users u ON uc.user_id = u.id
                                    WHERE uc.privacy = 'public' AND uc.status = 'completed' AND u.status = 'active'
                                    ORDER BY uc.created_at DESC
                                    LIMIT 6
                                ";
                                $recent_stmt = $db->query($recent_sql);
                                $recent_creations = $recent_stmt->fetchAll(PDO::FETCH_ASSOC);
                            ?>
                                <div class="row">
                                    <?php foreach ($recent_creations as $creation): ?>
                                        <div class="col-lg-4 col-md-6 mb-3">
                                            <div class="card shadow-sm">
                                                <?php if ($creation['type'] === 'image'): ?>
                                                    <img src="<?= htmlspecialchars($creation['file_path']) ?>" 
                                                         class="card-img-top" style="height: 150px; object-fit: cover;">
                                                <?php else: ?>
                                                    <div class="card-img-top bg-gradient-secondary d-flex align-items-center justify-content-center text-white" style="height: 150px;">
                                                        <i class="fas fa-file fa-2x"></i>
                                                    </div>
                                                <?php endif; ?>
                                                <div class="card-body p-3">
                                                    <h6 class="card-title mb-1"><?= htmlspecialchars($creation['title'] ?: 'Sin título') ?></h6>
                                                    <small class="text-muted">por @<?= htmlspecialchars($creation['username']) ?></small>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php } catch (Exception $e) { ?>
                                <p class="text-muted">No se pudieron cargar las creaciones recientes</p>
                            <?php } ?>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- Mostrar loading inicialmente -->
                    <div id="loadingResults" class="text-center py-5">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Buscando...</span>
                        </div>
                        <p class="mt-3 text-muted">Buscando contenido...</p>
                    </div>

                    <!-- Contenedor para resultados -->
                    <div id="resultsContent" style="display: none;">
                        <!-- Los resultados se cargarán aquí vía JavaScript -->
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Modal para ver creación -->
<div class="modal fade" id="creationModal" tabindex="-1" aria-labelledby="creationModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="creationModalLabel">Creación</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body" id="creationModalBody">
                <!-- Contenido dinámico -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" onclick="shareCreation()">
                    <i class="fas fa-share me-1"></i>Compartir
                </button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<style>
.creation-card {
    transition: transform 0.2s, box-shadow 0.2s;
    cursor: pointer;
}

.creation-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15) !important;
}

.user-card {
    transition: transform 0.2s, box-shadow 0.2s;
}

.user-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 20px rgba(0,0,0,0.1) !important;
}

.search-tabs .nav-link {
    border-radius: 0;
    border: none;
    background: transparent;
    color: #6c757d;
}

.search-tabs .nav-link.active {
    background: #fff;
    color: #495057;
    border-bottom: 3px solid #007bff;
}

.badge.fs-6 {
    font-size: 0.9rem !important;
    padding: 0.5rem 0.75rem;
    cursor: pointer;
}

.badge.fs-6:hover {
    transform: scale(1.05);
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Si hay una búsqueda, ejecutarla automáticamente
    <?php if (!empty($search_query)): ?>
        performSearch();
    <?php endif; ?>

    // Manejar envío del formulario
    document.getElementById('searchForm').addEventListener('submit', function(e) {
        e.preventDefault();
        performSearch();
    });
});

async function performSearch() {
    const form = document.getElementById('searchForm');
    const formData = new FormData(form);
    const params = new URLSearchParams(formData);

    // Mostrar loading
    document.getElementById('loadingResults').style.display = 'block';
    document.getElementById('resultsContent').style.display = 'none';

    try {
        const response = await fetch(`/api/social/search.php?${params}`);
        const data = await response.json();

        if (data.success) {
            displayResults(data);
        } else {
            showError(data.message);
        }
    } catch (error) {
        console.error('Error en búsqueda:', error);
        showError('Error al realizar la búsqueda');
    } finally {
        document.getElementById('loadingResults').style.display = 'none';
    }
}

function displayResults(data) {
    const resultsContent = document.getElementById('resultsContent');
    let html = '';

    // Header de resultados
    html += `
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h4>Resultados para "${data.query}" (${data.results.total})</h4>
        </div>
    `;

    // Tabs para separar tipos de resultados
    if (data.results.creations.length > 0 && data.results.users.length > 0) {
        html += `
            <ul class="nav nav-tabs search-tabs mb-4" id="resultsTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="creations-tab" data-bs-toggle="tab" data-bs-target="#creations-results" type="button" role="tab">
                        <i class="fas fa-images me-1"></i>Creaciones (${data.results.creations.length})
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="users-tab" data-bs-toggle="tab" data-bs-target="#users-results" type="button" role="tab">
                        <i class="fas fa-users me-1"></i>Usuarios (${data.results.users.length})
                    </button>
                </li>
            </ul>
            <div class="tab-content" id="resultsTabsContent">
                <div class="tab-pane fade show active" id="creations-results" role="tabpanel">
                    ${renderCreations(data.results.creations)}
                </div>
                <div class="tab-pane fade" id="users-results" role="tabpanel">
                    ${renderUsers(data.results.users)}
                </div>
            </div>
        `;
    } else if (data.results.creations.length > 0) {
        html += `
            <h5 class="mb-3"><i class="fas fa-images me-2"></i>Creaciones encontradas</h5>
            ${renderCreations(data.results.creations)}
        `;
    } else if (data.results.users.length > 0) {
        html += `
            <h5 class="mb-3"><i class="fas fa-users me-2"></i>Usuarios encontrados</h5>
            ${renderUsers(data.results.users)}
        `;
    } else {
        html += `
            <div class="text-center py-5">
                <i class="fas fa-search fa-3x text-muted mb-3"></i>
                <h4 class="text-muted">No se encontraron resultados</h4>
                <p class="text-muted">Prueba con otros términos de búsqueda o ajusta los filtros</p>
            </div>
        `;
    }

    resultsContent.innerHTML = html;
    resultsContent.style.display = 'block';

    // Agregar event listeners
    addResultEventListeners();
}

function renderCreations(creations) {
    if (creations.length === 0) return '';

    let html = '<div class="row">';
    
    creations.forEach(creation => {
        const imageHtml = creation.type === 'image' 
            ? `<img src="${creation.file_path}" class="card-img-top" style="height: 200px; object-fit: cover;" alt="${creation.title || 'Imagen'}">`
            : `<div class="card-img-top bg-gradient-secondary d-flex align-items-center justify-content-center text-white" style="height: 200px;">
                <div class="text-center">
                    <i class="fas fa-file fa-3x mb-2"></i>
                    <h6>${creation.type.charAt(0).toUpperCase() + creation.type.slice(1)}</h6>
                </div>
            </div>`;

        html += `
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card shadow-sm h-100 creation-card" data-creation='${JSON.stringify(creation)}'>
                    ${imageHtml}
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-2">
                            <div class="me-2">
                                ${creation.profile_image 
                                    ? `<img src="${creation.profile_image}" class="rounded-circle" width="32" height="32">`
                                    : `<div class="bg-primary rounded-circle d-flex align-items-center justify-content-center text-white" style="width: 32px; height: 32px; font-size: 14px;">
                                        ${creation.username.charAt(0).toUpperCase()}
                                    </div>`
                                }
                            </div>
                            <div class="flex-grow-1">
                                <a href="/usuario?id=${creation.user_id}" class="text-decoration-none fw-bold text-dark">
                                    ${creation.username}
                                </a>
                                <div class="small text-muted">${creation.created_at_formatted}</div>
                            </div>
                        </div>
                        
                        ${creation.title ? `<h6 class="card-title mb-1">${creation.title}</h6>` : ''}
                        ${creation.description ? `<p class="card-text text-muted small mb-2">${creation.description.substring(0, 100)}${creation.description.length > 100 ? '...' : ''}</p>` : ''}
                        
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <span class="badge bg-primary">${creation.type.charAt(0).toUpperCase() + creation.type.slice(1)}</span>
                                ${creation.tool_used ? `<span class="badge bg-light text-dark">${creation.tool_used}</span>` : ''}
                            </div>
                            <div class="text-muted small">
                                <i class="fas fa-heart me-1"></i>${creation.like_count}
                                <i class="fas fa-comment ms-2 me-1"></i>${creation.comment_count}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    });
    
    html += '</div>';
    return html;
}

function renderUsers(users) {
    if (users.length === 0) return '';

    let html = '<div class="row">';
    
    users.forEach(user => {
        html += `
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card shadow-sm h-100 user-card">
                    <div class="card-body text-center">
                        <div class="mb-3">
                            ${user.profile_image 
                                ? `<img src="${user.profile_image}" class="rounded-circle" width="80" height="80" style="object-fit: cover;">`
                                : `<div class="bg-primary rounded-circle d-flex align-items-center justify-content-center text-white mx-auto" style="width: 80px; height: 80px; font-size: 2rem;">
                                    ${user.username.charAt(0).toUpperCase()}
                                </div>`
                            }
                        </div>
                        
                        <h5 class="card-title mb-1">${user.full_name}</h5>
                        <p class="text-muted mb-2">@${user.username}</p>
                        
                        ${user.bio ? `<p class="card-text small text-muted mb-3">${user.bio.substring(0, 100)}${user.bio.length > 100 ? '...' : ''}</p>` : ''}
                        
                        <div class="row text-center mb-3">
                            <div class="col-4">
                                <div class="fw-bold text-primary">${user.creation_count}</div>
                                <small class="text-muted">Creaciones</small>
                            </div>
                            <div class="col-4">
                                <div class="fw-bold text-info">${user.followers_count}</div>
                                <small class="text-muted">Seguidores</small>
                            </div>
                            <div class="col-4">
                                <div class="fw-bold text-danger">${user.total_likes}</div>
                                <small class="text-muted">Likes</small>
                            </div>
                        </div>
                        
                        <div class="d-flex gap-2 justify-content-center">
                            <a href="/usuario?id=${user.id}" class="btn btn-outline-primary btn-sm">
                                <i class="fas fa-eye me-1"></i>Ver perfil
                            </a>
                            ${user.id != <?= $_SESSION['user_id'] ?> ? `
                                <button class="btn btn-${user.is_following ? 'danger' : 'primary'} btn-sm follow-btn" 
                                        data-user-id="${user.id}"
                                        data-following="${user.is_following ? '1' : '0'}">
                                    <i class="fas fa-${user.is_following ? 'user-minus' : 'user-plus'} me-1"></i>
                                    ${user.is_following ? 'Siguiendo' : 'Seguir'}
                                </button>
                            ` : ''}
                        </div>
                        
                        <div class="mt-2">
                            <span class="badge bg-${user.membership_type === 'premium' ? 'warning' : 'secondary'}">${user.membership_type.charAt(0).toUpperCase() + user.membership_type.slice(1)}</span>
                            <span class="badge bg-info">Nivel ${user.level}</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    });
    
    html += '</div>';
    return html;
}

function addResultEventListeners() {
    // Event listeners para creaciones
    document.querySelectorAll('.creation-card').forEach(card => {
        card.addEventListener('click', function() {
            const creation = JSON.parse(this.getAttribute('data-creation'));
            showCreationModal(creation);
        });
    });

    // Event listeners para botones de seguir
    document.querySelectorAll('.follow-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            toggleFollow(e);
        });
    });
}

function showCreationModal(creation) {
    const modal = new bootstrap.Modal(document.getElementById('creationModal'));
    const modalTitle = document.getElementById('creationModalLabel');
    const modalBody = document.getElementById('creationModalBody');
    
    modalTitle.textContent = creation.title || 'Creación sin título';
    
    let content = '';
    
    if (creation.type === 'image') {
        content = `
            <div class="text-center mb-3">
                <img src="${creation.file_path}" class="img-fluid rounded" style="max-height: 400px;">
            </div>
        `;
    }
    
    content += `
        <div class="d-flex align-items-center mb-3">
            <div class="me-3">
                ${creation.profile_image ? 
                    `<img src="${creation.profile_image}" class="rounded-circle" width="48" height="48">` :
                    `<div class="bg-primary rounded-circle d-flex align-items-center justify-content-center text-white" style="width: 48px; height: 48px;">
                        ${creation.username.charAt(0).toUpperCase()}
                    </div>`
                }
            </div>
            <div>
                <h6 class="mb-0">${creation.username}</h6>
                <small class="text-muted">${creation.created_at_formatted}</small>
            </div>
        </div>
        
        ${creation.description ? `<p class="text-muted">${creation.description}</p>` : ''}
        
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <span class="badge bg-primary">${creation.type.charAt(0).toUpperCase() + creation.type.slice(1)}</span>
                ${creation.tool_used ? `<span class="badge bg-secondary">${creation.tool_used}</span>` : ''}
            </div>
            <div>
                <span class="text-danger me-3">
                    <i class="fas fa-heart me-1"></i>${creation.like_count}
                </span>
                <span class="text-muted">
                    <i class="fas fa-comment me-1"></i>${creation.comment_count}
                </span>
            </div>
        </div>
    `;
    
    modalBody.innerHTML = content;
    modal.show();
}

async function toggleFollow(e) {
    const btn = e.currentTarget;
    const userId = btn.getAttribute('data-user-id');
    const isFollowing = btn.getAttribute('data-following') === '1';
    
    try {
        const response = await fetch('/api/social/toggle_follow.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: userId,
                action: isFollowing ? 'unfollow' : 'follow'
            })
        });

        const result = await response.json();
        
        if (result.success) {
            const icon = btn.querySelector('i');
            const text = btn.lastChild;
            
            if (isFollowing) {
                btn.classList.remove('btn-danger');
                btn.classList.add('btn-primary');
                icon.className = 'fas fa-user-plus me-1';
                text.textContent = 'Seguir';
                btn.setAttribute('data-following', '0');
            } else {
                btn.classList.remove('btn-primary');
                btn.classList.add('btn-danger');
                icon.className = 'fas fa-user-minus me-1';
                text.textContent = 'Siguiendo';
                btn.setAttribute('data-following', '1');
            }
        }
    } catch (error) {
        console.error('Error al procesar seguimiento:', error);
    }
}

function showError(message) {
    const resultsContent = document.getElementById('resultsContent');
    resultsContent.innerHTML = `
        <div class="alert alert-danger" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i>${message}
        </div>
    `;
    resultsContent.style.display = 'block';
}
</script>
