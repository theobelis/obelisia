<?php
// Verificar autenticación
if (!isset($_SESSION['user_id'])) {
    header('Location: /acceso');
    exit;
}

require_once __DIR__ . '/../../helpers/db.php';
require_once __DIR__ . '/../../helpers/social_functions.php';

$user_id = filter_var($_GET['id'] ?? $_SESSION['user_id'], FILTER_VALIDATE_INT);
$tab = $_GET['tab'] ?? 'followers'; // followers | following

if (!$user_id) {
    header('Location: /error/404');
    exit;
}

$current_user_id = $_SESSION['user_id'];
$is_own_profile = ($user_id == $current_user_id);

try {
    // Obtener información del usuario
    $stmt = $pdo->prepare("SELECT username, full_name, profile_image FROM users WHERE id = ? AND status = 'active'");
    $stmt->execute([$user_id]);
    $profile_user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$profile_user) {
        header('Location: /error/404');
        exit;
    }

    // Configuración de paginación
    $page = max(1, intval($_GET['page'] ?? 1));
    $limit = 20;
    $offset = ($page - 1) * $limit;

    if ($tab === 'followers') {
        // Obtener seguidores
        $sql = "
            SELECT 
                u.id,
                u.username,
                u.full_name,
                u.profile_image,
                u.bio,
                u.membership_type,
                uf.created_at as followed_since,
                (SELECT COUNT(*) FROM user_creations WHERE user_id = u.id AND privacy = 'public' AND status = 'completed') as creation_count,
                (SELECT COUNT(*) FROM user_follows WHERE following_id = u.id) as followers_count,
                EXISTS(SELECT 1 FROM user_follows WHERE follower_id = ? AND following_id = u.id) as is_following
            FROM user_follows uf
            JOIN users u ON uf.follower_id = u.id
            WHERE uf.following_id = ? AND u.status = 'active'
            ORDER BY uf.created_at DESC
            LIMIT " . intval($limit) . " OFFSET " . intval($offset);
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$current_user_id, $user_id]);
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Contar total
        $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM user_follows uf JOIN users u ON uf.follower_id = u.id WHERE uf.following_id = ? AND u.status = 'active'");
        $count_stmt->execute([$user_id]);
        $total_users = $count_stmt->fetchColumn();

    } else {
        // Obtener siguiendo
        $sql = "
            SELECT 
                u.id,
                u.username,
                u.full_name,
                u.profile_image,
                u.bio,
                u.membership_type,
                uf.created_at as followed_since,
                (SELECT COUNT(*) FROM user_creations WHERE user_id = u.id AND privacy = 'public' AND status = 'completed') as creation_count,
                (SELECT COUNT(*) FROM user_follows WHERE following_id = u.id) as followers_count,
                EXISTS(SELECT 1 FROM user_follows WHERE follower_id = ? AND following_id = u.id) as is_following
            FROM user_follows uf
            JOIN users u ON uf.following_id = u.id
            WHERE uf.follower_id = ? AND u.status = 'active'
            ORDER BY uf.created_at DESC
            LIMIT " . intval($limit) . " OFFSET " . intval($offset);
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$current_user_id, $user_id]);
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Contar total
        $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM user_follows uf JOIN users u ON uf.following_id = u.id WHERE uf.follower_id = ? AND u.status = 'active'");
        $count_stmt->execute([$user_id]);
        $total_users = $count_stmt->fetchColumn();
    }

    $total_pages = ceil($total_users / $limit);

} catch (Exception $e) {
    header('Location: /error/500');
    exit;
}
?>

<div class="container py-4">
    <!-- Header -->
    <div class="row mb-4">
        <div class="col-12">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/comunidad">Comunidad</a></li>
                    <li class="breadcrumb-item"><a href="/usuario?id=<?= $user_id ?>"><?= htmlspecialchars($profile_user['username']) ?></a></li>
                    <li class="breadcrumb-item active"><?= $tab === 'followers' ? 'Seguidores' : 'Siguiendo' ?></li>
                </ol>
            </nav>

            <div class="d-flex align-items-center mb-3">
                <div class="me-3">
                    <?php if (!empty($profile_user['profile_image'])): ?>
                        <img src="<?= htmlspecialchars($profile_user['profile_image']) ?>" 
                             class="rounded-circle" width="60" height="60">
                    <?php else: ?>
                        <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center text-white" 
                             style="width: 60px; height: 60px; font-size: 24px;">
                            <?= strtoupper(substr($profile_user['username'], 0, 1)) ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div>
                    <h2 class="mb-1"><?= htmlspecialchars($profile_user['full_name'] ?: $profile_user['username']) ?></h2>
                    <p class="text-muted mb-0">@<?= htmlspecialchars($profile_user['username']) ?></p>
                </div>
            </div>

            <!-- Tabs -->
            <ul class="nav nav-tabs">
                <li class="nav-item">
                    <a class="nav-link <?= $tab === 'followers' ? 'active' : '' ?>" 
                       href="?id=<?= $user_id ?>&tab=followers">
                        <i class="fas fa-users me-1"></i>Seguidores (<?= number_format($total_users) ?>)
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $tab === 'following' ? 'active' : '' ?>" 
                       href="?id=<?= $user_id ?>&tab=following">
                        <i class="fas fa-user-friends me-1"></i>Siguiendo
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <!-- Lista de usuarios -->
    <div class="row">
        <?php if (empty($users)): ?>
            <div class="col-12">
                <div class="text-center py-5">
                    <i class="fas fa-users fa-3x text-muted mb-3"></i>
                    <h4 class="text-muted">
                        <?php if ($tab === 'followers'): ?>
                            <?= $is_own_profile ? 'Aún no tienes seguidores' : 'Este usuario no tiene seguidores aún' ?>
                        <?php else: ?>
                            <?= $is_own_profile ? 'Aún no sigues a nadie' : 'Este usuario no sigue a nadie aún' ?>
                        <?php endif; ?>
                    </h4>
                    <p class="text-muted">
                        <?php if ($is_own_profile): ?>
                            <a href="/comunidad" class="btn btn-primary">Explorar comunidad</a>
                        <?php endif; ?>
                    </p>
                </div>
            </div>
        <?php else: ?>
            <?php foreach ($users as $user): ?>
                <div class="col-lg-6 col-md-12 mb-4">
                    <div class="card shadow-sm h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-start">
                                <div class="me-3">
                                    <?php if (!empty($user['profile_image'])): ?>
                                        <img src="<?= htmlspecialchars($user['profile_image']) ?>" 
                                             class="rounded-circle" width="50" height="50">
                                    <?php else: ?>
                                        <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center text-white" 
                                             style="width: 50px; height: 50px; font-size: 18px;">
                                            <?= strtoupper(substr($user['username'], 0, 1)) ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="flex-grow-1">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <h6 class="mb-1">
                                                <a href="/usuario?id=<?= $user['id'] ?>" class="text-decoration-none">
                                                    <?= htmlspecialchars($user['full_name'] ?: $user['username']) ?>
                                                </a>
                                            </h6>
                                            <p class="text-muted small mb-1">@<?= htmlspecialchars($user['username']) ?></p>
                                            
                                            <?php if (!empty($user['bio'])): ?>
                                                <p class="text-muted small mb-2">
                                                    <?= htmlspecialchars(substr($user['bio'], 0, 80)) ?>
                                                    <?= strlen($user['bio']) > 80 ? '...' : '' ?>
                                                </p>
                                            <?php endif; ?>

                                            <div class="d-flex gap-3 text-muted small">
                                                <span><i class="fas fa-images me-1"></i><?= $user['creation_count'] ?></span>
                                                <span><i class="fas fa-users me-1"></i><?= $user['followers_count'] ?></span>
                                                <span class="badge bg-<?= $user['membership_type'] === 'premium' ? 'warning' : 'secondary' ?>">
                                                    <?= ucfirst($user['membership_type']) ?>
                                                </span>
                                            </div>
                                        </div>
                                        
                                        <div class="text-end">
                                            <?php if ($user['id'] != $current_user_id): ?>
                                                <button class="btn btn-<?= $user['is_following'] ? 'danger' : 'primary' ?> btn-sm follow-btn mb-2" 
                                                        data-user-id="<?= $user['id'] ?>"
                                                        data-following="<?= $user['is_following'] ? '1' : '0' ?>">
                                                    <i class="fas fa-<?= $user['is_following'] ? 'user-minus' : 'user-plus' ?> me-1"></i>
                                                    <span class="follow-text"><?= $user['is_following'] ? 'Siguiendo' : 'Seguir' ?></span>
                                                </button>
                                            <?php endif; ?>
                                            <div class="text-muted small">
                                                <i class="fas fa-calendar me-1"></i>
                                                <?= timeAgo($user['followed_since']) ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Paginación -->
    <?php if ($total_pages > 1): ?>
        <nav aria-label="Paginación de usuarios" class="mt-4">
            <ul class="pagination justify-content-center">
                <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?id=<?= $user_id ?>&tab=<?= $tab ?>&page=<?= $page - 1 ?>">
                            <i class="fas fa-chevron-left"></i> Anterior
                        </a>
                    </li>
                <?php endif; ?>

                <?php
                $start = max(1, $page - 2);
                $end = min($total_pages, $start + 4);
                $start = max(1, $end - 4);

                for ($i = $start; $i <= $end; $i++):
                ?>
                    <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                        <a class="page-link" href="?id=<?= $user_id ?>&tab=<?= $tab ?>&page=<?= $i ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>

                <?php if ($page < $total_pages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?id=<?= $user_id ?>&tab=<?= $tab ?>&page=<?= $page + 1 ?>">
                            Siguiente <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Manejar botones de seguir
    document.querySelectorAll('.follow-btn').forEach(btn => {
        btn.addEventListener('click', toggleFollow);
    });
});

async function toggleFollow(e) {
    const btn = e.currentTarget;
    const userId = btn.getAttribute('data-user-id');
    const isFollowing = btn.getAttribute('data-following') === '1';
    
    try {
        const response = await fetch('/api/social/toggle_follow.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: userId,
                action: isFollowing ? 'unfollow' : 'follow'
            })
        });

        const result = await response.json();
        
        if (result.success) {
            const icon = btn.querySelector('i');
            const text = btn.querySelector('.follow-text');
            
            if (isFollowing) {
                btn.classList.remove('btn-danger');
                btn.classList.add('btn-primary');
                icon.className = 'fas fa-user-plus me-1';
                text.textContent = 'Seguir';
                btn.setAttribute('data-following', '0');
            } else {
                btn.classList.remove('btn-primary');
                btn.classList.add('btn-danger');
                icon.className = 'fas fa-user-minus me-1';
                text.textContent = 'Siguiendo';
                btn.setAttribute('data-following', '1');
            }
        }
    } catch (error) {
        console.error('Error al procesar seguimiento:', error);
    }
}
</script>
