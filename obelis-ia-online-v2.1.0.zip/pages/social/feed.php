<?php
// Incluir ObelisStudio para mostrar proyectos en la comunidad
require_once __DIR__ . '/../../src/ObelisStudio/ObelisStudio.php';
// Incluir conexión a la base de datos
require_once __DIR__ . '/../../helpers/db.php';
// Incluir funciones sociales
require_once __DIR__ . '/../../helpers/social_functions.php';

// Asegurar que $pdo esté disponible
global $pdo;
if (!isset($pdo)) {
    $pdo = getPdoConnection();
}

// Verificar autenticación
if (!isset($_SESSION['user_id'])) {
    header('Location: /acceso');
    exit;
}

// Configuración de paginación
$page = max(1, intval($_GET['page'] ?? 1));
$limit = 12;
$offset = ($page - 1) * $limit;

// Parámetros de búsqueda y filtros
$search = trim($_GET['search'] ?? '');
$type_filter = $_GET['type'] ?? '';
$tool_filter = $_GET['tool'] ?? '';
$sort_by = $_GET['sort'] ?? 'recent';

// Construir consulta SQL con filtros
$where_conditions = ["uc.privacy = 'public'", "uc.status = 'completed'", "u.status = 'active'"];
$params = [];

if (!empty($search)) {
    $where_conditions[] = "(uc.title LIKE ? OR uc.description LIKE ? OR u.username LIKE ?)";
    $search_term = "%{$search}%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
}

if (!empty($type_filter)) {
    $where_conditions[] = "uc.type = ?";
    $params[] = $type_filter;
}

if (!empty($tool_filter)) {
    $where_conditions[] = "uc.tool_used = ?";
    $params[] = $tool_filter;
}

$where_clause = implode(' AND ', $where_conditions);

// Determinar orden
$order_clause = match($sort_by) {
    'popular' => 'ORDER BY like_count DESC, uc.created_at DESC',
    'liked' => 'ORDER BY like_count DESC',
    'oldest' => 'ORDER BY uc.created_at ASC',
    default => 'ORDER BY uc.created_at DESC'
};

try {
    // Contar total de resultados
    $count_sql = "
        SELECT COUNT(DISTINCT uc.id) 
        FROM user_creations uc 
        JOIN users u ON uc.user_id = u.id 
        WHERE {$where_clause}
    ";
    $count_stmt = $pdo->prepare($count_sql);
    $count_stmt->execute($params);
    $total_posts = $count_stmt->fetchColumn();
    $total_pages = ceil($total_posts / $limit);

    // Obtener creaciones
    $sql = "
        SELECT 
            uc.id,
            uc.title,
            uc.description,
            uc.file_path,
            uc.type,
            uc.tool_used,
            uc.created_at,
            u.id as user_id,
            u.username,
            u.full_name,
            u.profile_image,
            COALESCE(likes.like_count, 0) as like_count,
            COALESCE(comments.comment_count, 0) as comment_count,
            COALESCE(user_liked.has_liked, 0) as user_has_liked
        FROM user_creations uc
        JOIN users u ON uc.user_id = u.id
        LEFT JOIN (
            SELECT creation_id, COUNT(*) as like_count
            FROM creation_likes 
            GROUP BY creation_id
        ) likes ON uc.id = likes.creation_id
        LEFT JOIN (
            SELECT creation_id, COUNT(*) as comment_count
            FROM creation_comments 
            WHERE status = 'active'
            GROUP BY creation_id
        ) comments ON uc.id = comments.creation_id
        LEFT JOIN (
            SELECT creation_id, 1 as has_liked
            FROM creation_likes
            WHERE user_id = ?
        ) user_liked ON uc.id = user_liked.creation_id
        WHERE {$where_clause}
        {$order_clause}
        LIMIT " . intval($limit) . " OFFSET " . intval($offset) . "
    ";
    
    $final_params = array_merge([$_SESSION['user_id']], $params);
    $stmt = $pdo->prepare($sql);
    $stmt->execute($final_params);
    $creations = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Obtener herramientas únicas
    $tools_sql = "SELECT DISTINCT tool_used FROM user_creations WHERE privacy = 'public' AND tool_used IS NOT NULL ORDER BY tool_used";
    $tools_stmt = $pdo->query($tools_sql);
    $available_tools = $tools_stmt->fetchAll(PDO::FETCH_COLUMN);

} catch (Exception $e) {
    error_log("Error en feed social: " . $e->getMessage());
    $creations = [];
    $total_pages = 0;
    $available_tools = [];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comunidad - ObelisIA</title>
    
    <!-- Estilos del sistema de diseño unificado -->
    <link rel="stylesheet" href="<?php echo \ObelisIA\Router\MainRouter::url('assets/css/tools/unified-design/main.css'); ?>">
    
    <!-- Estilos globales del sistema (cards, botones, etc.) -->
    <link rel="stylesheet" href="<?php echo \ObelisIA\Router\MainRouter::url('assets/css/general/main.css'); ?>">
    
    <!-- Font Awesome para iconos -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    
</head>
<body>
    <div class="community-container">
        <div class="community-layout">
            <!-- Sidebar -->
            <aside class="community-sidebar">
            <!-- Filtros y Búsqueda -->
            <div class="sidebar-section fade-in">
                <h3 class="sidebar-section-title">
                    <i class="fas fa-search"></i>
                    Explorar
                </h3>
                
                <form method="GET" action="/comunidad" class="filter-form" id="filterForm">
                    <div class="filter-group">
                        <label class="filter-label">
                            <i class="fas fa-search"></i>
                            Buscar contenido
                        </label>
                        <input type="text" class="filter-input" name="search" 
                               value="<?= htmlspecialchars($search) ?>" 
                               placeholder="Título, descripción o usuario...">
                    </div>

                    <div class="filter-group">
                        <label class="filter-label">
                            <i class="fas fa-layer-group"></i>
                            Tipo de contenido
                        </label>
                        <select class="filter-input" name="type">
                            <option value="">Todos los tipos</option>
                            <option value="image" <?= $type_filter === 'image' ? 'selected' : '' ?>>Imágenes</option>
                            <option value="text" <?= $type_filter === 'text' ? 'selected' : '' ?>>Texto</option>
                            <option value="music" <?= $type_filter === 'music' ? 'selected' : '' ?>>Música</option>
                            <option value="video" <?= $type_filter === 'video' ? 'selected' : '' ?>>Video</option>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label class="filter-label">
                            <i class="fas fa-tools"></i>
                            Herramienta
                        </label>
                        <select class="filter-input" name="tool">
                            <option value="">Todas las herramientas</option>
                            <?php foreach ($available_tools as $tool): ?>
                                <option value="<?= htmlspecialchars($tool) ?>" 
                                        <?= $tool_filter === $tool ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($tool) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="filter-buttons">
                        <button type="submit" class="btn-dashboard primary" style="flex: 1;">
                            <i class="fas fa-search"></i>
                            Buscar
                        </button>
                        <a href="/comunidad" class="btn-dashboard btn-outline primary" style="flex: 1;">
                            <i class="fas fa-times"></i>
                            Limpiar
                        </a>
                    </div>
                </form>
            </div>

            <!-- Ordenar -->
            <div class="sidebar-section slide-up">
                <h3 class="sidebar-section-title">
                    <i class="fas fa-sort"></i>
                    Ordenar por
                </h3>
                
                <div class="sort-pills">
                    <a href="?<?= http_build_query(array_merge($_GET, ['sort' => 'recent'])) ?>" 
                       class="sort-pill <?= $sort_by === 'recent' ? 'active' : '' ?>">
                        <i class="fas fa-clock"></i>
                        Recientes
                    </a>
                    <a href="?<?= http_build_query(array_merge($_GET, ['sort' => 'popular'])) ?>" 
                       class="sort-pill <?= $sort_by === 'popular' ? 'active' : '' ?>">
                        <i class="fas fa-fire"></i>
                        Populares
                    </a>
                    <a href="?<?= http_build_query(array_merge($_GET, ['sort' => 'liked'])) ?>" 
                       class="sort-pill <?= $sort_by === 'liked' ? 'active' : '' ?>">
                        <i class="fas fa-heart"></i>
                        Más liked
                    </a>
                </div>
            </div>

            <!-- Estadísticas -->
            <div class="sidebar-section slide-up">
                <h3 class="sidebar-section-title">
                    <i class="fas fa-chart-bar"></i>
                    Estadísticas
                </h3>
                
                <?php 
                try {
                    $stats = $pdo->query("
                        SELECT 
                            COUNT(DISTINCT uc.id) as total_creations,
                            COUNT(DISTINCT uc.user_id) as active_creators,
                            COUNT(DISTINCT CASE WHEN uc.created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR) THEN uc.id END) as today_creations
                        FROM user_creations uc 
                        WHERE uc.privacy = 'public' AND uc.status = 'completed'
                    ")->fetch(PDO::FETCH_ASSOC);
                ?>
                    <div class="stats-grid">
                        <div class="stat-card primary">
                            <div class="stat-icon">
                                <i class="fas fa-palette"></i>
                            </div>
                            <span class="stat-value"><?= number_format($stats['total_creations']) ?></span>
                            <span class="stat-label">Creaciones</span>
                        </div>
                        <div class="stat-card success">
                            <div class="stat-icon">
                                <i class="fas fa-users"></i>
                            </div>
                            <span class="stat-value"><?= number_format($stats['active_creators']) ?></span>
                            <span class="stat-label">Creadores</span>
                        </div>
                        <div class="stat-card purple">
                            <div class="stat-icon">
                                <i class="fas fa-clock"></i>
                            </div>
                            <span class="stat-value"><?= number_format($stats['today_creations']) ?></span>
                            <span class="stat-label">Hoy</span>
                        </div>
                    </div>
                <?php } catch (Exception $e) { ?>
                    <p style="color: var(--text-muted); font-size: var(--font-size-sm);">Estadísticas no disponibles</p>
                <?php } ?>
            </div>

            <!-- Enlaces rápidos -->
            <div class="sidebar-section slide-up">
                <h3 class="sidebar-section-title">
                    <i class="fas fa-link"></i>
                    Enlaces rápidos
                </h3>
                
                <div style="display: flex; flex-direction: column; gap: var(--spacing-sm);">
                    <a href="/mis-creaciones" class="btn-dashboard success">
                        <i class="fas fa-plus"></i>
                        Mis creaciones
                    </a>
                    <a href="/panel" class="btn-dashboard primary">
                        <i class="fas fa-home"></i>
                        Dashboard
                    </a>
                    <a href="/tools" class="btn-dashboard purple">
                        <i class="fas fa-magic"></i>
                        Herramientas IA
                    </a>
                </div>
            </div>
        </aside>

        <!-- Contenido principal -->
        <main class="community-main">
            <!-- Header -->
            <div class="community-header">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <h1 style="margin: 0; font-size: var(--font-size-2xl); font-weight: var(--font-weight-bold); color: var(--text-primary);">
                            <i class="fas fa-users" style="color: var(--accent-color); margin-right: var(--spacing-sm);"></i>
                            Comunidad ObelisIA
                        </h1>
                        <p style="margin: var(--spacing-sm) 0 0 0; color: var(--text-muted);">
                            Descubre las increíbles creaciones de nuestra comunidad de artistas IA
                        </p>
                    </div>
                    <div>
                        <a href="/mis-creaciones" class="btn btn-primary">
                            <i class="fas fa-plus"></i>
                            Crear contenido
                        </a>
                    </div>
                </div>
            </div>

            <!-- Información de resultados -->
            <?php if (!empty($search) || !empty($type_filter) || !empty($tool_filter)): ?>
                <div style="background: var(--bg-card); border: 1px solid var(--border-primary); border-radius: var(--radius-lg); padding: var(--spacing-lg); margin-bottom: var(--spacing-xl); display: flex; align-items: center; gap: var(--spacing-md);">
                    <i class="fas fa-info-circle" style="color: var(--accent-color); font-size: var(--font-size-lg);"></i>
                    <div>
                        <strong>Resultados de búsqueda:</strong> <?= number_format($total_posts) ?> creación(es) encontrada(s)
                        <?php if (!empty($search)): ?>
                            para "<strong><?= htmlspecialchars($search) ?></strong>"
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Grid de creaciones -->
            <?php if (empty($creations)): ?>
                <div class="empty-state">
                    <i class="fas fa-search"></i>
                    <h3>No se encontraron creaciones</h3>
                    <p>Prueba ajustando los filtros o términos de búsqueda</p>
                    <a href="/comunidad" class="btn-dashboard primary">Ver todas las creaciones</a>
                </div>
            <?php else: ?>
                <div class="creations-grid slide-up">
                    <?php foreach ($creations as $creation): ?>
                        <div class="creation-card fade-in" data-creation-id="<?= $creation['id'] ?>">
                            <!-- Imagen/Preview -->
                            <div class="creation-image-container">
                                <?php if ($creation['type'] === 'image' && !empty($creation['file_path'])): ?>
                                    <img src="<?= htmlspecialchars($creation['file_path']) ?>" 
                                         class="creation-image" 
                                         alt="<?= htmlspecialchars($creation['title'] ?? 'Imagen') ?>"
                                         loading="lazy">
                                <?php elseif ($creation['type'] === 'text'): ?>
                                    <div class="creation-placeholder" style="background: linear-gradient(135deg, #06b6d4, #3b82f6);">
                                        <i class="fas fa-file-text fa-2x"></i>
                                        <h6>Contenido de Texto</h6>
                                    </div>
                                <?php elseif ($creation['type'] === 'music'): ?>
                                    <div class="creation-placeholder" style="background: linear-gradient(135deg, #8b5cf6, #ec4899);">
                                        <i class="fas fa-music fa-2x"></i>
                                        <h6>Música Generada</h6>
                                    </div>
                                <?php elseif ($creation['type'] === 'video'): ?>
                                    <div class="creation-placeholder" style="background: linear-gradient(135deg, #f59e0b, #ef4444);">
                                        <i class="fas fa-video fa-2x"></i>
                                        <h6>Video Generado</h6>
                                    </div>
                                <?php else: ?>
                                    <div class="creation-placeholder">
                                        <i class="fas fa-file fa-2x"></i>
                                        <h6><?= ucfirst($creation['type']) ?></h6>
                                    </div>
                                <?php endif; ?>
                                
                                <!-- Overlay con acciones -->
                                <div class="creation-overlay">
                                    <div class="creation-actions">
                                        <button class="btn btn-outline-light" onclick="viewCreation(<?= $creation['id'] ?>)">
                                            <i class="fas fa-eye"></i>
                                            Ver
                                        </button>
                                        <button class="btn btn-outline-light" onclick="shareCreation(<?= $creation['id'] ?>)">
                                            <i class="fas fa-share"></i>
                                            Compartir
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Contenido de la tarjeta -->
                            <div class="creation-content">
                                <!-- Header con usuario -->
                                <div class="creation-header">
                                    <div>
                                        <?php if (!empty($creation['profile_image'])): ?>
                                            <img src="<?= htmlspecialchars($creation['profile_image']) ?>" 
                                                 class="user-avatar" 
                                                 alt="<?= htmlspecialchars($creation['username']) ?>">
                                        <?php else: ?>
                                            <div class="user-avatar-placeholder">
                                                <?= strtoupper(substr($creation['username'], 0, 1)) ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="user-info">
                                        <h4>
                                            <a href="/usuario?id=<?= $creation['user_id'] ?>" 
                                               style="color: var(--text-primary); text-decoration: none;">
                                                <?= htmlspecialchars($creation['full_name'] ?: $creation['username']) ?>
                                            </a>
                                        </h4>
                                        <div class="time"><?= timeAgo($creation['created_at']) ?></div>
                                    </div>
                                </div>

                                <!-- Título y descripción -->
                                <?php if (!empty($creation['title'])): ?>
                                    <h3 class="creation-title"><?= htmlspecialchars($creation['title']) ?></h3>
                                <?php endif; ?>
                                
                                <?php if (!empty($creation['description'])): ?>
                                    <p class="creation-description">
                                        <?= htmlspecialchars(strlen($creation['description']) > 150 
                                            ? substr($creation['description'], 0, 150) . '...' 
                                            : $creation['description']) ?>
                                    </p>
                                <?php endif; ?>

                                <!-- Tags -->
                                <div class="creation-tags">
                                    <span class="creation-tag primary">
                                        <?= ucfirst($creation['type']) ?>
                                    </span>
                                    <?php if (!empty($creation['tool_used'])): ?>
                                        <span class="creation-tag"><?= htmlspecialchars($creation['tool_used']) ?></span>
                                    <?php endif; ?>
                                </div>

                                <!-- Footer con acciones sociales -->
                                <div class="creation-footer">
                                    <div class="social-actions">
                                        <button class="social-btn like-btn <?= $creation['user_has_liked'] ? 'liked' : '' ?>" 
                                                data-creation-id="<?= $creation['id'] ?>"
                                                data-liked="<?= $creation['user_has_liked'] ?>">
                                            <i class="fas fa-heart"></i>
                                            <span class="like-count"><?= $creation['like_count'] ?></span>
                                        </button>
                                        <button class="social-btn comment-btn" 
                                                data-creation-id="<?= $creation['id'] ?>"
                                                onclick="openComments(<?= $creation['id'] ?>)">
                                            <i class="fas fa-comment"></i>
                                            <span class="comment-count"><?= $creation['comment_count'] ?></span>
                                        </button>
                                        <button class="social-btn" onclick="shareCreation(<?= $creation['id'] ?>)">
                                            <i class="fas fa-share"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Paginación -->
                <?php if ($total_pages > 1): ?>
                    <div class="pagination-container">
                        <div class="pagination">
                            <?php if ($page > 1): ?>
                                <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>" 
                                   class="pagination-btn">
                                    <i class="fas fa-chevron-left"></i>
                                    Anterior
                                </a>
                            <?php endif; ?>

                            <?php
                            $start = max(1, $page - 2);
                            $end = min($total_pages, $page + 2);
                            
                            for ($i = $start; $i <= $end; $i++):
                            ?>
                                <a href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>" 
                                   class="pagination-btn <?= $i === $page ? 'active' : '' ?>">
                                    <?= $i ?>
                                </a>
                            <?php endfor; ?>

                            <?php if ($page < $total_pages): ?>
                                <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>" 
                                   class="pagination-btn">
                                    Siguiente
                                    <i class="fas fa-chevron-right"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </main>
    </div>

    <!-- JavaScript -->
    <script>
        // Funciones para interacciones sociales
        async function toggleLike(creationId) {
            try {
                const response = await fetch('/api/social/toggle_like.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        creation_id: creationId
                    })
                });

                const result = await response.json();
                if (result.success) {
                    // Actualizar UI
                    const likeBtn = document.querySelector(`[data-creation-id="${creationId}"].like-btn`);
                    const likeCount = likeBtn.querySelector('.like-count');
                    
                    if (result.liked) {
                        likeBtn.classList.add('liked');
                        likeCount.textContent = parseInt(likeCount.textContent) + 1;
                    } else {
                        likeBtn.classList.remove('liked');
                        likeCount.textContent = parseInt(likeCount.textContent) - 1;
                    }
                }
            } catch (error) {
                console.error('Error al dar like:', error);
            }
        }

        function viewCreation(creationId) {
            // Implementar modal de vista de creación
            console.log('Ver creación:', creationId);
        }

        function shareCreation(creationId) {
            // Implementar funcionalidad de compartir
            const url = `${window.location.origin}/comunidad#creation-${creationId}`;
            if (navigator.share) {
                navigator.share({
                    title: 'Creación en ObelisIA',
                    url: url
                });
            } else {
                navigator.clipboard.writeText(url);
                alert('Enlace copiado al portapapeles');
            }
        }

        function openComments(creationId) {
            // Implementar modal de comentarios
            console.log('Abrir comentarios:', creationId);
        }

        // Event listeners
        document.addEventListener('DOMContentLoaded', function() {
            // Like buttons
            document.querySelectorAll('.like-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const creationId = this.dataset.creationId;
                    toggleLike(creationId);
                });
            });

            // Auto-submit filtros
            document.getElementById('filterForm').addEventListener('change', function() {
                this.submit();
            });
        });

        // Función timeAgo para mostrar tiempo relativo
        function timeAgo(datetime) {
            const now = new Date();
            const time = new Date(datetime);
            const diff = Math.floor((now - time) / 1000);
            
            if (diff < 60) return 'hace unos segundos';
            if (diff < 3600) return `hace ${Math.floor(diff/60)} minutos`;
            if (diff < 86400) return `hace ${Math.floor(diff/3600)} horas`;
            if (diff < 2592000) return `hace ${Math.floor(diff/86400)} días`;
            
            return time.toLocaleDateString();
        }
    </script>
    </div> <!-- .community-container -->
</body>
</html>
