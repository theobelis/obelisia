<?php
// pages/creacion/index.php
require_once __DIR__ . '/../../vendor/autoload.php';
session_start();

use ObelisIA\Router\MainRouter;
use ObelisIA\Database\Database;
use ObelisIA\Auth\Auth;
use ObelisIA\Services\MetaTagGenerator; // Para la generación de meta etiquetas con IA
require_once __DIR__ . '/../../helpers/hashids.php';

$database = new Database();
$db = $database->getConnection();
$auth = new Auth($db);


$hash = $_GET['id'] ?? '';
$hashids = getHashidsInstance();
$decoded = $hashids->decode($hash);
$id = isset($decoded[0]) ? (int)$decoded[0] : 0;
if (!$id) {
    http_response_code(404);
    echo '<h2>Creación no encontrada</h2>';
    exit;
}

$userId = $_SESSION['user_id'] ?? null;
$stmt = $db->prepare('SELECT * FROM user_creations WHERE id = ?');
$stmt->execute([$id]);
$creacion = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$creacion) {
    http_response_code(404);
    echo '<h2>Creación no encontrada</h2>';
    exit;
}

// Si es privada, solo el dueño puede verla
if ($creacion['privacy'] === 'private' && (!$userId || $creacion['user_id'] != $userId)) {
    http_response_code(403);
    echo '<h2>No tienes permisos para ver esta creación privada.</h2>';
    exit;
}
include __DIR__ . '/../../src/Utils/header.php';
?>


<div class="container py-5">
    <a href="/mis-creaciones" class="btn btn-link mb-4"><i class="fas fa-arrow-left me-2"></i>Volver a Mis Creaciones</a>
    <div class="mb-2">
        <span class="badge bg-<?php echo $creacion['privacy'] === 'public' ? 'success' : 'secondary'; ?>">
            <?php echo $creacion['privacy'] === 'public' ? 'Pública' : 'Privada'; ?>
        </span>
    </div>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-lg">
                <img src="<?php echo htmlspecialchars($creacion['file_path']); ?>" class="card-img-top" style="object-fit:cover;max-height:400px;">
                <div class="card-body">
                    <h2 class="card-title mb-3"><?php echo htmlspecialchars($creacion['title'] ?? 'Sin título'); ?></h2>
                    <?php if (!empty($creacion['description'])): ?>
                        <p class="card-text text-muted mb-3"><?php echo htmlspecialchars($creacion['description']); ?></p>
                    <?php endif; ?>
                    <ul class="list-group list-group-flush mb-3">
                        <li class="list-group-item"><strong>Herramienta:</strong> <?php echo htmlspecialchars($creacion['tool_used'] ?? 'Desconocida'); ?></li>
                        <li class="list-group-item"><strong>Fecha:</strong> <?php echo date('d/m/Y H:i', strtotime($creacion['created_at'])); ?></li>
                    </ul>
                    <div class="d-flex gap-2">
                        <button class="btn btn-outline-primary" onclick="compartirCreacion(<?php echo $creacion['id']; ?>, '<?php echo htmlspecialchars(addslashes($creacion['title'])); ?>', '<?php echo htmlspecialchars(addslashes($creacion['file_path'])); ?>')"><i class="fas fa-share-alt me-2"></i>Compartir</button>
                        <a href="/mis-creaciones" class="btn btn-outline-secondary">Volver</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
function compartirCreacion(id, titulo, img) {
  const url = window.location.origin + '/pages/creacion/index.php?id=' + id;
  if (navigator.share) {
    navigator.share({ title: titulo, url, text: 'Mira mi creación en ObelisIA' });
  } else {
    navigator.clipboard.writeText(url);
    alert('Enlace copiado al portapapeles');
  }
}
</script>

<?php include __DIR__ . '/../../src/Utils/footer.php'; ?>
