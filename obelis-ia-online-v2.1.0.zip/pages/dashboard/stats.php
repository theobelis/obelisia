<?php
/**
 * dashboard/stats.php - Dashboard de estadísticas usando las nuevas funciones
 */

session_start();
require_once '../helpers/db.php';
require_once '../helpers/creation_statistics.php';
require_once '../helpers/social_functions.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: /login');
    exit;
}

$user_id = $_SESSION['user_id'];

// Obtener estadísticas del usuario
$user_stats = getUserCreationStats($db, $user_id);

// Obtener las mejores creaciones del usuario
$top_user_creations = getCreationStatistics($db, [
    'user_id' => $user_id,
    'limit' => 6,
    'order_by' => 'engagement_score'
]);

// Obtener creaciones recientes del usuario
$recent_creations = getCreationStatistics($db, [
    'user_id' => $user_id,
    'limit' => 6,
    'order_by' => 'created_at'
]);

// Obtener tendencias globales
$trending_global = getTopCreations($db, 8, 7); // Últimos 7 días

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard de Estadísticas - ObelisIA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .stats-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 12px;
            padding: 1.5rem;
            height: 100%;
            transition: transform 0.3s ease;
        }
        .stats-card:hover {
            transform: translateY(-5px);
        }
        .stats-number {
            font-size: 2.5rem;
            font-weight: bold;
            margin-bottom: 0.5rem;
        }
        .creation-card {
            border: none;
            border-radius: 12px;
            overflow: hidden;
            transition: all 0.3s ease;
            height: 100%;
        }
        .creation-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }
        .engagement-badge {
            background: linear-gradient(45deg, #28a745, #20c997);
            color: white;
            padding: 0.25rem 0.5rem;
            border-radius: 20px;
            font-size: 0.8rem;
        }
        .trend-item {
            border-left: 4px solid #667eea;
            padding-left: 1rem;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body class="bg-light">
    <div class="container-fluid py-4">
        <div class="row mb-4">
            <div class="col">
                <h1 class="h3 mb-0">
                    <i class="fas fa-chart-line me-2"></i>
                    Dashboard de Estadísticas
                </h1>
                <p class="text-muted">Analiza el rendimiento de tus creaciones</p>
            </div>
        </div>

        <!-- Estadísticas principales -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="stats-card">
                    <div class="stats-number"><?php echo number_format($user_stats['total_creations'] ?? 0); ?></div>
                    <div class="h6">Creaciones Totales</div>
                    <small><i class="fas fa-eye me-1"></i><?php echo number_format($user_stats['public_creations'] ?? 0); ?> públicas</small>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="stats-card">
                    <div class="stats-number"><?php echo number_format($user_stats['total_likes'] ?? 0); ?></div>
                    <div class="h6">Likes Recibidos</div>
                    <small><i class="fas fa-heart me-1"></i>Total acumulado</small>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="stats-card">
                    <div class="stats-number"><?php echo number_format($user_stats['followers_count'] ?? 0); ?></div>
                    <div class="h6">Seguidores</div>
                    <small><i class="fas fa-users me-1"></i><?php echo number_format($user_stats['following_count'] ?? 0); ?> siguiendo</small>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="stats-card">
                    <div class="stats-number"><?php echo number_format($user_stats['avg_engagement'] ?? 0, 1); ?></div>
                    <div class="h6">Engagement Promedio</div>
                    <small><i class="fas fa-chart-bar me-1"></i>Por creación</small>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Mejores creaciones del usuario -->
            <div class="col-lg-6 mb-4">
                <div class="card h-100">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">
                            <i class="fas fa-trophy me-2"></i>
                            Mis Mejores Creaciones
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($top_user_creations)): ?>
                            <p class="text-muted text-center py-4">
                                <i class="fas fa-plus-circle fa-3x mb-3 d-block"></i>
                                ¡Crea tu primera obra maestra!
                            </p>
                        <?php else: ?>
                            <div class="row">
                                <?php foreach ($top_user_creations as $creation): ?>
                                <div class="col-md-6 mb-3">
                                    <div class="creation-card card">
                                        <div class="card-body p-3">
                                            <h6 class="card-title"><?php echo htmlspecialchars($creation['title']); ?></h6>
                                            <p class="card-text small text-muted mb-2">
                                                <?php echo ucfirst($creation['type']); ?> • 
                                                <?php echo $creation['created_at_formatted']; ?>
                                            </p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="small">
                                                    <span class="text-danger me-2">
                                                        <i class="fas fa-heart"></i> <?php echo $creation['like_count']; ?>
                                                    </span>
                                                    <span class="text-info">
                                                        <i class="fas fa-comments"></i> <?php echo $creation['comment_count']; ?>
                                                    </span>
                                                </div>
                                                <span class="engagement-badge">
                                                    <?php echo $creation['engagement_score']; ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Tendencias globales -->
            <div class="col-lg-6 mb-4">
                <div class="card h-100">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">
                            <i class="fas fa-fire me-2"></i>
                            Trending Esta Semana
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($trending_global)): ?>
                            <p class="text-muted text-center py-4">No hay tendencias disponibles</p>
                        <?php else: ?>
                            <?php foreach ($trending_global as $trending): ?>
                            <div class="trend-item">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div class="flex-grow-1">
                                        <h6 class="mb-1"><?php echo htmlspecialchars($trending['title']); ?></h6>
                                        <p class="mb-1 small text-muted">
                                            por @<?php echo htmlspecialchars($trending['username']); ?> • 
                                            <?php echo $trending['created_at_formatted']; ?>
                                        </p>
                                        <div class="small">
                                            <span class="text-danger me-2">
                                                <i class="fas fa-heart"></i> <?php echo $trending['like_count']; ?>
                                            </span>
                                            <span class="text-info me-2">
                                                <i class="fas fa-comments"></i> <?php echo $trending['comment_count']; ?>
                                            </span>
                                            <span class="badge bg-warning text-dark">
                                                <?php echo $trending['engagement_score']; ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Creaciones recientes -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0">
                            <i class="fas fa-clock me-2"></i>
                            Creaciones Recientes
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($recent_creations)): ?>
                            <p class="text-muted text-center py-4">
                                <i class="fas fa-plus fa-2x mb-3 d-block"></i>
                                Aún no tienes creaciones. <a href="/herramientas" class="btn btn-primary btn-sm">¡Crea algo increíble!</a>
                            </p>
                        <?php else: ?>
                            <div class="row">
                                <?php foreach ($recent_creations as $recent): ?>
                                <div class="col-md-4 col-lg-2 mb-3">
                                    <div class="creation-card card">
                                        <div class="card-body p-3">
                                            <h6 class="card-title small"><?php echo htmlspecialchars($recent['title']); ?></h6>
                                            <p class="card-text small text-muted mb-2">
                                                <?php echo ucfirst($recent['type']); ?>
                                            </p>
                                            <div class="small">
                                                <div class="text-muted mb-1"><?php echo $recent['created_at_formatted']; ?></div>
                                                <span class="text-danger me-2">
                                                    <i class="fas fa-heart"></i> <?php echo $recent['like_count']; ?>
                                                </span>
                                                <span class="text-info">
                                                    <i class="fas fa-comments"></i> <?php echo $recent['comment_count']; ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
