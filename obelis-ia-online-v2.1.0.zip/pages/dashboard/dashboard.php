<?php
// dashboard.php - Panel de control del usuario profesional
// Inicializar dependencias necesarias

// Incluir configuración
require_once __DIR__ . '/../../src/Config/config.php';

// Incluir autoloader si no está cargado
if (!class_exists('ObelisIA\Database\Database')) {
    require_once __DIR__ . '/../../vendor/autoload.php';
}

use ObelisIA\Database\Database;
use ObelisIA\Auth\Auth;

// Inicializar sesión si no está iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Inicializar auth y db si no están disponibles (acceso directo)
if (!isset($auth) || !is_object($auth)) {
    $database = new Database();
    $db = $database->getConnection();
    $auth = new Auth($db);
}

if (!isset($db) || !is_object($db)) {
    if (!isset($database)) {
        $database = new Database();
    }
    $db = $database->getConnection();
}

// Verificar autenticación
if (!$auth->isLoggedIn()) {
    if (class_exists('\ObelisIA\Router\MainRouter')) {
        \ObelisIA\Router\MainRouter::redirect('acceso');
    } else {
        header('Location: /acceso');
        exit;
    }
}

// Obtener datos del usuario
$user = $auth->getCurrentUser();
$user_data = $user; // Para compatibilidad con profile.php

// Variables específicas de esta página
$page_title = "Panel de Control - ObelisIA";
$page_description = "Gestiona tu cuenta, herramientas de IA y proyectos desde tu panel personal profesional.";
$body_class = "dashboard-page";

// Obtener estadísticas del usuario
try {
    // Consultar herramientas disponibles
    $stmt = $db->prepare("SELECT COUNT(*) as total_tools FROM tools WHERE status = 'active'");
    $stmt->execute();
    $total_tools = $stmt->fetch()['total_tools'] ?? 0;

    // Consultar creaciones del usuario
    $stmt = $db->prepare("SELECT COUNT(*) as total_creations FROM user_creations WHERE user_id = ?");
    $stmt->execute([$user['id']]);
    $total_creations = $stmt->fetch()['total_creations'] ?? 0;

    // Consultar actividad reciente
    $stmt = $db->prepare("
        SELECT activity_type, activity_description, created_at 
        FROM user_activity 
        WHERE user_id = ? 
        ORDER BY created_at DESC 
        LIMIT 5
    ");
    $stmt->execute([$user['id']]);
    $recent_activities = $stmt->fetchAll();

    // Calcular estadísticas de tiempo
    $stmt = $db->prepare("
        SELECT 
            COUNT(*) as sessions_today,
            SUM(CASE WHEN DATE(created_at) = CURDATE() THEN 1 ELSE 0 END) as today_activities
        FROM user_activity 
        WHERE user_id = ? AND DATE(created_at) >= CURDATE() - INTERVAL 7 DAY
    ");
    $stmt->execute([$user['id']]);
    $activity_stats = $stmt->fetch();

} catch (Exception $e) {
    // Valores por defecto en caso de error
    $total_tools = 0;
    $total_creations = 0;
    $recent_activities = [];
    $activity_stats = ['sessions_today' => 0, 'today_activities' => 0];
}

// Configurar imagen de perfil
require_once __DIR__ . '/../../helpers/profile_pic.php';
$profile_pic_url = get_profile_pic_url($user_data);

// Calcular progreso de experiencia
$exp_total = isset($user['exp_total']) && is_numeric($user['exp_total']) ? (int)$user['exp_total'] : 0;
$current_level = isset($user['level']) && is_numeric($user['level']) ? (int)$user['level'] : 1;
$exp_for_next = ($current_level * 100) + 500; // Fórmula de ejemplo
$exp_percent = $exp_for_next > 0 ? min(100, round(($exp_total / $exp_for_next) * 100)) : 0;
?>

<div class="dashboard-container">
    <div class="container-fluid px-4">
        
        <!-- Welcome Section -->
        <div class="welcome-section fade-in">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h1 class="welcome-title">¡Bienvenido de vuelta, <?php echo htmlspecialchars($user['username']); ?>!</h1>
                    <p class="welcome-description">
                        Gestiona tu cuenta, explora herramientas de IA avanzadas y dale vida a tus ideas creativas desde tu panel personal.
                    </p>
                    <div class="d-flex gap-3 mt-3 flex-wrap">
                        <a href="<?php echo \ObelisIA\Router\MainRouter::url('herramientas'); ?>" class="btn-dashboard primary">
                            <i class="fas fa-rocket"></i>
                            Explorar Herramientas
                        </a>
                        <a href="<?php echo \ObelisIA\Router\MainRouter::url('perfil'); ?>" class="btn-dashboard btn-outline primary">
                            <i class="fas fa-user"></i>
                            Ver Perfil
                        </a>
                    </div>
                </div>
                <div class="col-lg-4 text-center">
                    <div class="user-profile-circle">
                        <div class="exp-circle">
                            <svg width="140" height="140" class="exp-progress">
                                <defs>
                                    <linearGradient id="expGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                                        <stop offset="0%" stop-color="#3b82f6"/>
                                        <stop offset="100%" stop-color="#8b5cf6"/>
                                    </linearGradient>
                                </defs>
                                <circle cx="70" cy="70" r="60" stroke="#e2e8f0" stroke-width="8" fill="none"/>
                                <circle cx="70" cy="70" r="60" stroke="url(#expGradient)" stroke-width="8" fill="none" 
                                        stroke-linecap="round" stroke-dasharray="377" 
                                        stroke-dashoffset="<?php echo 377 - (377 * $exp_percent / 100); ?>"
                                        style="transition: stroke-dashoffset 1s ease-in-out;"/>
                            </svg>
                        </div>
                        <div class="profile-img-container">
                            <img src="<?php echo htmlspecialchars($profile_pic_url); ?>" 
                                 alt="Foto de perfil de <?php echo htmlspecialchars($user['full_name'] ?? $user['username']); ?>" 
                                 class="profile-img">
                            <span class="level-badge">Nivel <?php echo $current_level; ?></span>
                        </div>
                    </div>
                    <div class="exp-info">
                        <strong><?php echo $exp_total; ?></strong> / <?php echo $exp_for_next; ?> EXP
                        <div class="mt-1">
                            <small class="text-muted">Progreso al siguiente nivel</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Stats Grid -->
        <div class="stats-grid slide-up">
            <div class="stat-card primary">
                <div class="stat-icon">
                    <i class="fas fa-tools"></i>
                </div>
                <div class="text-center">
                    <div class="stat-value"><?php echo $total_tools; ?></div>
                    <div class="stat-label">Herramientas Disponibles</div>
                </div>
            </div>

            <div class="stat-card success">
                <div class="stat-icon">
                    <i class="fas fa-palette"></i>
                </div>
                <div class="text-center">
                    <div class="stat-value"><?php echo $total_creations; ?></div>
                    <div class="stat-label">Creaciones Realizadas</div>
                </div>
            </div>

            <div class="stat-card warning">
                <div class="stat-icon">
                    <i class="fas fa-crown"></i>
                </div>
                <div class="text-center">
                    <div class="stat-value"><?php echo ucfirst($user['subscription_type']); ?></div>
                    <div class="stat-label">Plan Actual</div>
                    <?php if ($user['subscription_type'] === 'premium'): ?>
                        <span class="premium-badge premium-glow">Premium</span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="stat-card purple">
                <div class="stat-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="text-center">
                    <div class="stat-value"><?php echo $activity_stats['today_activities']; ?></div>
                    <div class="stat-label">Actividades Hoy</div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="row">
            <div class="col-12">
                <h2 class="section-title">
                    <div class="section-icon">
                        <i class="fas fa-bolt"></i>
                    </div>
                    Acciones Rápidas
                </h2>
            </div>
        </div>
        
        <div class="quick-actions slide-up">
            <a href="<?php echo \ObelisIA\Router\MainRouter::url('herramientas'); ?>" class="action-card primary">
                <div class="action-header">
                    <div class="action-icon">
                        <i class="fas fa-magic"></i>
                    </div>
                    <div>
                        <h3 class="action-title">Generar Contenido IA</h3>
                        <p class="action-description">Crea imágenes, texto, música y videos con IA</p>
                    </div>
                </div>
            </a>

            <a href="<?php echo \ObelisIA\Router\MainRouter::url('perfil'); ?>" class="action-card success">
                <div class="action-header">
                    <div class="action-icon">
                        <i class="fas fa-user-cog"></i>
                    </div>
                    <div>
                        <h3 class="action-title">Gestionar Perfil</h3>
                        <p class="action-description">Actualiza tu información y preferencias</p>
                    </div>
                </div>
            </a>

            <a href="<?php echo \ObelisIA\Router\MainRouter::url('suscripcion'); ?>" class="action-card warning">
                <div class="action-header">
                    <div class="action-icon">
                        <i class="fas fa-credit-card"></i>
                    </div>
                    <div>
                        <h3 class="action-title">Mi Suscripción</h3>
                        <p class="action-description">Gestiona tu plan y métodos de pago</p>
                    </div>
                </div>
            </a>

            <a href="<?php echo \ObelisIA\Router\MainRouter::url('soporte'); ?>" class="action-card indigo">
                <div class="action-header">
                    <div class="action-icon">
                        <i class="fas fa-headset"></i>
                    </div>
                    <div>
                        <h3 class="action-title">Soporte</h3>
                        <p class="action-description">Obtén ayuda y contacta con nuestro equipo</p>
                    </div>
                </div>
            </a>

            <a href="<?php echo \ObelisIA\Router\MainRouter::url('recursos'); ?>" class="action-card pink">
                <div class="action-header">
                    <div class="action-icon">
                        <i class="fas fa-book-open"></i>
                    </div>
                    <div>
                        <h3 class="action-title">Recursos</h3>
                        <p class="action-description">Tutoriales, guías y documentación</p>
                    </div>
                </div>
            </a>

            <a href="<?php echo \ObelisIA\Router\MainRouter::url('configuracion'); ?>" class="action-card purple">
                <div class="action-header">
                    <div class="action-icon">
                        <i class="fas fa-cog"></i>
                    </div>
                    <div>
                        <h3 class="action-title">Configuración</h3>
                        <p class="action-description">Personaliza tu experiencia en la plataforma</p>
                    </div>
                </div>
            </a>
        </div>

        <!-- Recent Activity -->
        <div class="activity-section slide-up">
            <h2 class="section-title">
                <div class="section-icon">
                    <i class="fas fa-history"></i>
                </div>
                Actividad Reciente
            </h2>
            
            <?php if (!empty($recent_activities)): ?>
                <div class="activity-list">
                    <?php foreach ($recent_activities as $activity): 
                        $activity_color = '#3b82f6';
                        $activity_icon = 'fas fa-circle';
                        
                        switch ($activity['activity_type']) {
                            case 'Creación':
                                $activity_color = '#10b981';
                                $activity_icon = 'fas fa-plus-circle';
                                break;
                            case 'Navegación':
                                $activity_color = '#6366f1';
                                $activity_icon = 'fas fa-mouse';
                                break;
                            case 'Perfil':
                                $activity_color = '#8b5cf6';
                                $activity_icon = 'fas fa-user';
                                break;
                            case 'Suscripción':
                                $activity_color = '#f59e0b';
                                $activity_icon = 'fas fa-crown';
                                break;
                        }
                        
                        $time_ago = time() - strtotime($activity['created_at']);
                        if ($time_ago < 60) {
                            $time_text = 'Hace un momento';
                        } elseif ($time_ago < 3600) {
                            $time_text = 'Hace ' . floor($time_ago / 60) . ' min';
                        } elseif ($time_ago < 86400) {
                            $time_text = 'Hace ' . floor($time_ago / 3600) . ' h';
                        } else {
                            $time_text = date('d/m/Y', strtotime($activity['created_at']));
                        }
                    ?>
                        <div class="activity-item">
                            <div class="activity-icon" style="--activity-color: <?php echo $activity_color; ?>; background: <?php echo $activity_color; ?>;">
                                <i class="<?php echo $activity_icon; ?>"></i>
                            </div>
                            <div class="activity-content">
                                <div class="activity-title"><?php echo htmlspecialchars($activity['activity_type']); ?></div>
                                <div class="activity-description"><?php echo htmlspecialchars($activity['activity_description']); ?></div>
                            </div>
                            <div class="activity-time"><?php echo $time_text; ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <div class="mb-3">
                        <i class="fas fa-history" style="font-size: 3rem; color: #94a3b8;"></i>
                    </div>
                    <h4 class="text-muted">No hay actividad reciente</h4>
                    <p class="text-muted">Comienza a usar nuestras herramientas para ver tu actividad aquí.</p>
                    <a href="<?php echo \ObelisIA\Router\MainRouter::url('herramientas'); ?>" class="btn-dashboard primary">
                        <i class="fas fa-rocket"></i>
                        Explorar Herramientas
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <!-- Progress Section -->
        <div class="row">
            <div class="col-lg-6 mb-4">
                <div class="stat-card success">
                    <h3 class="stat-title">
                        <i class="fas fa-target me-2"></i>
                        Progreso del Mes
                    </h3>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between mb-2">
                            <span class="stat-label">Herramientas Utilizadas</span>
                            <span class="fw-bold"><?php echo min($total_creations, $total_tools); ?>/<?php echo $total_tools; ?></span>
                        </div>
                        <div class="progress-modern" style="--card-color: #10b981; --card-color-secondary: #059669;">
                            <div class="progress-bar-modern" style="width: <?php echo $total_tools > 0 ? min(100, ($total_creations / $total_tools) * 100) : 0; ?>%"></div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between mb-2">
                            <span class="stat-label">Experiencia del Nivel</span>
                            <span class="fw-bold"><?php echo $exp_percent; ?>%</span>
                        </div>
                        <div class="progress-modern" style="--card-color: #10b981; --card-color-secondary: #059669;">
                            <div class="progress-bar-modern" style="width: <?php echo $exp_percent; ?>%"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 mb-4">
                <div class="stat-card primary">
                    <h3 class="stat-title">
                        <i class="fas fa-chart-pie me-2"></i>
                        Resumen de Cuenta
                    </h3>
                    <div class="row text-center">
                        <div class="col-6 mb-3">
                            <div class="stat-value" style="font-size: 1.5rem;"><?php echo $current_level; ?></div>
                            <div class="stat-label">Nivel</div>
                        </div>
                        <div class="col-6 mb-3">
                            <div class="stat-value" style="font-size: 1.5rem;"><?php echo $exp_total; ?></div>
                            <div class="stat-label">EXP Total</div>
                        </div>
                        <div class="col-6">
                            <div class="stat-value" style="font-size: 1.5rem;"><?php echo $total_creations; ?></div>
                            <div class="stat-label">Creaciones</div>
                        </div>
                        <div class="col-6">
                            <div class="stat-value" style="font-size: 1.5rem;">
                                <?php echo ucfirst(substr($user['subscription_type'], 0, 4)); ?>
                            </div>
                            <div class="stat-label">Plan</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<script>
// Animaciones al cargar
document.addEventListener('DOMContentLoaded', function() {
    // Animar el círculo de experiencia
    const expCircle = document.querySelector('.exp-progress circle:last-child');
    if (expCircle) {
        const circumference = 2 * Math.PI * 60;
        const percent = <?php echo $exp_percent; ?>;
        const offset = circumference - (percent / 100) * circumference;
        
        setTimeout(() => {
            expCircle.style.strokeDashoffset = offset;
        }, 500);
    }

    // Animar las barras de progreso
    const progressBars = document.querySelectorAll('.progress-bar-modern');
    progressBars.forEach((bar, index) => {
        const width = bar.style.width;
        bar.style.width = '0%';
        setTimeout(() => {
            bar.style.width = width;
        }, 1000 + (index * 200));
    });

    // Efectos de hover mejorados
    const cards = document.querySelectorAll('.stat-card, .action-card');
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-8px)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
});
</script>
