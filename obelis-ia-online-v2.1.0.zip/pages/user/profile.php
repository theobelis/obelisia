<?php
// pages/user/profile.php - Perfil de usuario
// Inicializar dependencias necesarias

// Activar reporte de errores para debug (temporal)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Incluir configuración
require_once __DIR__ . '/../../src/Config/config.php';

// Incluir autoloader si no está cargado
if (!class_exists('ObelisIA\Database\Database')) {
    require_once __DIR__ . '/../../vendor/autoload.php';
}

use ObelisIA\Database\Database;
use ObelisIA\Auth\Auth;

// Inicializar sesión si no está iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Inicializar auth y db si no están disponibles (acceso directo)
if (!isset($auth) || !is_object($auth)) {
    $database = new Database();
    $db = $database->getConnection();
    $auth = new Auth($db);
}

if (!isset($db) || !is_object($db)) {
    if (!isset($database)) {
        $database = new Database();
    }
    $db = $database->getConnection();
}

// Verificar si está logueado
if (!$auth->isLoggedIn()) {
    if (class_exists('\ObelisIA\Router\MainRouter')) {
        \ObelisIA\Router\MainRouter::redirect('acceso');
    } else {
        header('Location: /acceso');
        exit;
    }
}

$page_title = "Editar Perfil - ObelisIA";
$success_message = '';
$error_message = '';

// Obtener datos del usuario actual a través del método de la clase Auth
$user_data = $auth->getCurrentUser();

// --- CÓDIGO AÑADIDO PARA LA IMAGEN DE PERFIL ---

$profile_pic_url = '';

// Verificar si el usuario tiene una imagen de perfil guardada
if (!empty($user_data['profile_image'])) {
    // Si la tiene, usamos esa URL
    $profile_pic_url = $user_data['profile_image'];
} else {
    // Si no, generamos el placeholder con su inicial
    
    // 1. Obtener la inicial del nombre completo y convertirla a mayúscula
    $initial = strtoupper(substr($user_data['full_name'], 0, 1));
    
    // 2. Construir la URL de placehold.co con colores y la inicial
    // Formato: /tamaño/color_fondo/color_texto?text=INICIAL
    $profile_pic_url = 'https://placehold.co/200x200/667eea/ffffff?text=' . urlencode($initial);
}

// Generar token CSRF si no existe
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Manejar actualización de perfil
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verificar token CSRF
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $error_message = "Token de seguridad inválido. Por favor, recarga la página e intenta de nuevo.";
    } else {
        $full_name = $_POST['full_name'] ?? '';
        $email = $_POST['email'] ?? '';
        $phone = $_POST['phone'] ?? '';
        $bio = $_POST['bio'] ?? '';
        $address = $_POST['address'] ?? '';
        
        if (empty($full_name) || empty($email)) {
            $error_message = "El nombre completo y el email son obligatorios.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error_message = "Por favor, ingrese un email válido.";
        } else {
            // Verificar si el email ya existe (excluyendo el usuario actual)
            $check_query = "SELECT id FROM users WHERE email = ? AND id != ?";
            $check_stmt = $db->prepare($check_query);
            $check_stmt->execute([$email, $_SESSION['user_id']]);
            
            if ($check_stmt->rowCount() > 0) {
                $error_message = "Este email ya está en uso por otro usuario.";
            } else {
                // Actualizar perfil
                $update_query = "UPDATE users SET full_name = ?, email = ?, phone = ?, bio = ?, address = ?, updated_at = NOW() WHERE id = ?";
                $update_stmt = $db->prepare($update_query);
                
                if ($update_stmt->execute([$full_name, $email, $phone, $bio, $address, $_SESSION['user_id']])) {
                    $success_message = "Perfil actualizado correctamente.";
                    $_SESSION['full_name'] = $full_name;
                    $_SESSION['email'] = $email;
                    // Recargar datos del usuario forzando una nueva consulta a la BD
                    $user_data = $auth->getCurrentUser(true);
                } else {
                    $error_message = "Error al actualizar el perfil.";
                }
            }
        }
    }
}

// Manejar todas las peticiones POST (Actualizar Perfil, Contraseña, Foto, Eliminar Cuenta)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Verificar el token CSRF para todas las peticiones POST
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $error_message = "Token de seguridad inválido. Por favor, recarga la página e intenta de nuevo.";
    } else {
        // 2. Determinar la acción a realizar
        $action = $_POST['action'] ?? 'update_profile'; // Acción por defecto

        // =======================================================
        // --- LÓGICA PARA CAMBIAR CONTRASEÑA ---
        // =======================================================
        if ($action === 'change_password') {
            $current_password = $_POST['current_password'] ?? '';
            $new_password = $_POST['new_password'] ?? '';
            $confirm_new_password = $_POST['confirm_new_password'] ?? '';

            if (empty($current_password) || empty($new_password) || empty($confirm_new_password)) {
                $error_message = "Todos los campos de contraseña son obligatorios.";
            } elseif ($new_password !== $confirm_new_password) {
                $error_message = "La nueva contraseña y su confirmación no coinciden.";
            } elseif (strlen($new_password) < 8) {
                $error_message = "La nueva contraseña debe tener al menos 8 caracteres.";
            } else {
                // Obtener el hash de la contraseña actual de la BD
                $pass_query = "SELECT password FROM users WHERE id = ?";
                $pass_stmt = $db->prepare($pass_query);
                $pass_stmt->execute([$_SESSION['user_id']]);
                $stored_hash = $pass_stmt->fetchColumn();

                // Verificar si la contraseña actual es correcta
                if (password_verify($current_password, $stored_hash)) {
                    // Hashear la nueva contraseña
                    $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);
                    
                    // Actualizar en la base de datos
                    $update_pass_query = "UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?";
                    $update_pass_stmt = $db->prepare($update_pass_query);
                    if ($update_pass_stmt->execute([$new_password_hash, $_SESSION['user_id']])) {
                        $success_message = "Contraseña actualizada correctamente.";
                    } else {
                        $error_message = "Error al actualizar la contraseña.";
                    }
                } else {
                    $error_message = "La contraseña actual es incorrecta.";
                }
            }
        
        // =======================================================
        // --- LÓGICA PARA CAMBIAR FOTO DE PERFIL ---
        // =======================================================
        } elseif ($action === 'change_profile_pic') {
            if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
                $file = $_FILES['profile_image'];
                $upload_dir = 'uploads/'; // Asegúrate que esta carpeta exista y tenga permisos
                $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
                $max_size = 5 * 1024 * 1024; // 5 MB

                if (!in_array($file['type'], $allowed_types)) {
                    $error_message = 'Tipo de archivo no permitido. Solo se aceptan JPG, PNG y GIF.';
                } elseif ($file['size'] > $max_size) {
                    $error_message = 'El archivo es demasiado grande. El tamaño máximo es 5 MB.';
                } else {
                    // Crear un nombre de archivo único
                    $file_extension = pathinfo($file['name'], PATHINFO_EXTENSION);
                    $unique_filename = uniqid('user_' . $_SESSION['user_id'] . '_', true) . '.' . $file_extension;
                    $upload_path = $upload_dir . $unique_filename;

                    if (move_uploaded_file($file['tmp_name'], $upload_path)) {
                        // Actualizar la ruta de la imagen en la base de datos
                        $update_pic_query = "UPDATE users SET profile_image = ? WHERE id = ?";
                        $update_pic_stmt = $db->prepare($update_pic_query);
                        
                        if ($update_pic_stmt->execute([$upload_path, $_SESSION['user_id']])) {
                            $success_message = "Foto de perfil actualizada.";
                            // Forzar la recarga de datos para mostrar la nueva foto inmediatamente
                            $user_data = $auth->getCurrentUser(true); 
                            $profile_pic_url = $user_data['profile_image'];
                        } else {
                            $error_message = "Error al guardar la ruta de la imagen.";
                            // Opcional: eliminar el archivo subido si falla la BD
                            unlink($upload_path); 
                        }
                    } else {
                        $error_message = "Error al subir el archivo.";
                    }
                }
            } else {
                $error_message = "No se ha seleccionado ningún archivo o hubo un error en la subida.";
            }

        // =======================================================
        // --- LÓGICA PARA ELIMINAR CUENTA ---
        // =======================================================
        } elseif ($action === 'delete_account') {
            $user_id_to_delete = $_SESSION['user_id'];
            $delete_query = "DELETE FROM users WHERE id = ?";
            $delete_stmt = $db->prepare($delete_query);

            if ($delete_stmt->execute([$user_id_to_delete])) {
                session_unset();
                session_destroy();
                \ObelisIA\Router\MainRouter::redirect('acceso', ['account_deleted' => 'true']);
                exit();
            } else {
                $error_message = "Error al intentar eliminar la cuenta.";
            }
        
        // =======================================================
        // --- LÓGICA PARA ACTUALIZAR PERFIL (ACCIÓN POR DEFECTO) ---
        // =======================================================
        } elseif ($action === 'update_profile') {
            $full_name = $_POST['full_name'] ?? '';
            $email = $_POST['email'] ?? '';
            // ... (resto de la lógica de actualización de perfil que ya tenías)
            // ...
            // Actualizar perfil
            $update_query = "UPDATE users SET full_name = ?, email = ?, phone = ?, bio = ?, address = ?, updated_at = NOW() WHERE id = ?";
            $update_stmt = $db->prepare($update_query);
            
            if ($update_stmt->execute([$_POST['full_name'], $_POST['email'], $_POST['phone'], $_POST['bio'], $_POST['address'], $_SESSION['user_id']])) {
                $success_message = "Perfil actualizado correctamente.";
                $_SESSION['full_name'] = $_POST['full_name'];
                $_SESSION['email'] = $_POST['email'];
                $user_data = $auth->getCurrentUser(true);
            } else {
                $error_message = "Error al actualizar el perfil.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?></title>
    
    <!-- Estilos del sistema de diseño unificado -->
    <link rel="stylesheet" href="<?php echo \ObelisIA\Router\MainRouter::url('assets/css/tools/unified-design/main.css'); ?>">
    
    <!-- Font Awesome para iconos -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <!-- Bootstrap para algunos componentes -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <style>
        body {
            background: var(--bg-primary);
            min-height: 100vh;
        }
        
        .profile-layout {
            display: flex;
            min-height: 100vh;
            background: var(--bg-primary);
        }
        
        .profile-sidebar {
            width: 280px;
            background: var(--bg-card);
            border-right: 1px solid var(--border-primary);
            padding: var(--spacing-xl);
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            backdrop-filter: blur(20px);
            box-shadow: var(--shadow-lg);
        }
        
        .profile-main {
            flex: 1;
            margin-left: 280px;
            padding: var(--spacing-xl);
            min-height: 100vh;
        }
        
        .profile-header {
            background: var(--bg-card);
            border-radius: var(--radius-xl);
            padding: var(--spacing-xl);
            margin-bottom: var(--spacing-xl);
            box-shadow: var(--shadow-md);
            border: 1px solid var(--border-primary);
            position: relative;
            overflow: hidden;
        }
        
        .profile-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--accent-gradient);
        }
        
        .profile-content {
            display: grid;
            grid-template-columns: 1fr 400px;
            gap: var(--spacing-xl);
        }
        
        .profile-card {
            background: var(--bg-card);
            border-radius: var(--radius-xl);
            padding: var(--spacing-xl);
            box-shadow: var(--shadow-md);
            border: 1px solid var(--border-primary);
            height: fit-content;
        }
        
        .profile-card-header {
            display: flex;
            align-items: center;
            gap: var(--spacing-md);
            margin-bottom: var(--spacing-xl);
            padding-bottom: var(--spacing-lg);
            border-bottom: 1px solid var(--border-primary);
        }
        
        .profile-card-icon {
            width: 40px;
            height: 40px;
            background: var(--accent-gradient);
            border-radius: var(--radius-lg);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.2rem;
        }
        
        .profile-card-title {
            font-size: var(--font-size-xl);
            font-weight: var(--font-weight-bold);
            color: var(--text-primary);
            margin: 0;
        }
        
        .profile-avatar-section {
            text-align: center;
            margin-bottom: var(--spacing-xl);
        }
        
        .profile-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            border: 4px solid var(--accent-color);
            object-fit: cover;
            margin-bottom: var(--spacing-md);
            transition: all var(--transition-normal);
            cursor: pointer;
            box-shadow: var(--shadow-lg);
        }
        
        .profile-avatar:hover {
            transform: scale(1.05);
            box-shadow: var(--shadow-xl);
        }
        
        .profile-name {
            font-size: var(--font-size-xl);
            font-weight: var(--font-weight-bold);
            color: var(--text-primary);
            margin-bottom: var(--spacing-sm);
        }
        
        .profile-role {
            display: inline-flex;
            align-items: center;
            gap: var(--spacing-xs);
            background: var(--accent-gradient);
            color: white;
            padding: var(--spacing-xs) var(--spacing-md);
            border-radius: var(--radius-full);
            font-size: var(--font-size-sm);
            font-weight: var(--font-weight-medium);
            margin-bottom: var(--spacing-lg);
        }
        
        .profile-stats {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: var(--spacing-md);
            margin-bottom: var(--spacing-xl);
        }
        
        .profile-stat {
            text-align: center;
            padding: var(--spacing-md);
            background: var(--bg-secondary);
            border-radius: var(--radius-lg);
            border: 1px solid var(--border-primary);
        }
        
        .profile-stat-value {
            font-size: var(--font-size-xl);
            font-weight: var(--font-weight-bold);
            color: var(--accent-color);
            display: block;
        }
        
        .profile-stat-label {
            font-size: var(--font-size-sm);
            color: var(--text-muted);
            margin-top: var(--spacing-xs);
        }
        
        .sidebar-nav {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .sidebar-nav-item {
            margin-bottom: var(--spacing-sm);
        }
        
        .sidebar-nav-link {
            display: flex;
            align-items: center;
            gap: var(--spacing-md);
            padding: var(--spacing-md) var(--spacing-lg);
            color: var(--text-muted);
            text-decoration: none;
            border-radius: var(--radius-lg);
            transition: all var(--transition-normal);
            font-weight: var(--font-weight-medium);
        }
        
        .sidebar-nav-link:hover {
            background: var(--bg-secondary);
            color: var(--text-primary);
            transform: translateX(4px);
        }
        
        .sidebar-nav-link.active {
            background: var(--accent-gradient);
            color: white;
            box-shadow: var(--shadow-md);
        }
        
        .sidebar-nav-icon {
            width: 20px;
            text-align: center;
        }
        
        .form-section {
            margin-bottom: var(--spacing-xl);
        }
        
        .form-section-title {
            font-size: var(--font-size-lg);
            font-weight: var(--font-weight-semibold);
            color: var(--text-primary);
            margin-bottom: var(--spacing-lg);
            display: flex;
            align-items: center;
            gap: var(--spacing-sm);
        }
        
        .form-section-title i {
            color: var(--accent-color);
        }
        
        .form-group {
            margin-bottom: var(--spacing-lg);
        }
        
        .form-label {
            display: block;
            font-weight: var(--font-weight-medium);
            color: var(--text-primary);
            margin-bottom: var(--spacing-sm);
            font-size: var(--font-size-sm);
        }
        
        .form-control {
            width: 100%;
            padding: var(--spacing-md) var(--spacing-lg);
            background: var(--bg-secondary);
            border: 1px solid var(--border-primary);
            border-radius: var(--radius-lg);
            color: var(--text-primary);
            font-size: var(--font-size-base);
            transition: all var(--transition-normal);
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--accent-color);
            box-shadow: 0 0 0 3px rgba(6, 182, 212, 0.1);
        }
        
        .form-control[readonly] {
            background: var(--bg-primary);
            opacity: 0.7;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: var(--spacing-lg);
        }
        
        .action-buttons {
            display: flex;
            flex-direction: column;
            gap: var(--spacing-md);
        }
        
        .action-button {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: var(--spacing-sm);
            padding: var(--spacing-md) var(--spacing-lg);
            background: var(--bg-secondary);
            border: 1px solid var(--border-primary);
            border-radius: var(--radius-lg);
            color: var(--text-primary);
            text-decoration: none;
            font-weight: var(--font-weight-medium);
            transition: all var(--transition-normal);
            cursor: pointer;
        }
        
        .action-button:hover {
            background: var(--accent-color);
            color: white;
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
        }
        
        .action-button.danger:hover {
            background: var(--error-color);
        }
        
        .alert {
            padding: var(--spacing-lg);
            border-radius: var(--radius-lg);
            margin-bottom: var(--spacing-lg);
            border: 1px solid;
            display: flex;
            align-items: center;
            gap: var(--spacing-sm);
        }
        
        .alert-success {
            background: rgba(34, 197, 94, 0.1);
            border-color: var(--success-color);
            color: var(--success-color);
        }
        
        .alert-error {
            background: rgba(239, 68, 68, 0.1);
            border-color: var(--error-color);
            color: var(--error-color);
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        
        .modal-content {
            background: var(--bg-card);
            border-radius: var(--radius-xl);
            padding: var(--spacing-xl);
            max-width: 500px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
            border: 1px solid var(--border-primary);
            box-shadow: var(--shadow-xl);
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: var(--spacing-lg);
            padding-bottom: var(--spacing-lg);
            border-bottom: 1px solid var(--border-primary);
        }
        
        .modal-title {
            font-size: var(--font-size-xl);
            font-weight: var(--font-weight-bold);
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: var(--spacing-sm);
            margin: 0;
        }
        
        .btn-close {
            background: none;
            border: none;
            color: var(--text-muted);
            font-size: 1.5rem;
            cursor: pointer;
            padding: var(--spacing-xs);
            border-radius: var(--radius-md);
            transition: all var(--transition-normal);
        }
        
        .btn-close:hover {
            background: var(--bg-secondary);
            color: var(--text-primary);
        }
        
        @media (max-width: 768px) {
            .profile-layout {
                flex-direction: column;
            }
            
            .profile-sidebar {
                position: relative;
                width: 100%;
                height: auto;
            }
            
            .profile-main {
                margin-left: 0;
            }
            
            .profile-content {
                grid-template-columns: 1fr;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="profile-layout">
        <!-- Sidebar -->
        <aside class="profile-sidebar">
            <div class="profile-card-header">
                <div class="profile-card-icon">
                    <i class="fas fa-user"></i>
                </div>
                <h2 class="profile-card-title">Mi Perfil</h2>
            </div>
            
            <nav>
                <ul class="sidebar-nav">
                    <li class="sidebar-nav-item">
                        <a href="<?php echo \ObelisIA\Router\MainRouter::url('panel'); ?>" class="sidebar-nav-link">
                            <i class="fas fa-home sidebar-nav-icon"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="sidebar-nav-item">
                        <a href="<?php echo \ObelisIA\Router\MainRouter::url('perfil'); ?>" class="sidebar-nav-link active">
                            <i class="fas fa-user sidebar-nav-icon"></i>
                            <span>Editar Perfil</span>
                        </a>
                    </li>
                    <li class="sidebar-nav-item">
                        <a href="<?php echo \ObelisIA\Router\MainRouter::url('premium'); ?>" class="sidebar-nav-link">
                            <i class="fas fa-crown sidebar-nav-icon"></i>
                            <span>Upgrade Premium</span>
                        </a>
                    </li>
                    <li class="sidebar-nav-item">
                        <a href="<?php echo \ObelisIA\Router\MainRouter::url('suscripcion'); ?>" class="sidebar-nav-link">
                            <i class="fas fa-credit-card sidebar-nav-icon"></i>
                            <span>Mi Suscripción</span>
                        </a>
                    </li>
                    <li class="sidebar-nav-item">
                        <a href="<?php echo \ObelisIA\Router\MainRouter::url('tools'); ?>" class="sidebar-nav-link">
                            <i class="fas fa-magic sidebar-nav-icon"></i>
                            <span>Herramientas IA</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>

        <!-- Contenido principal -->
        <main class="profile-main">
            <!-- Header -->
            <div class="profile-header">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <h1 style="margin: 0; font-size: var(--font-size-2xl); font-weight: var(--font-weight-bold); color: var(--text-primary);">
                            <i class="fas fa-user-edit" style="color: var(--accent-color); margin-right: var(--spacing-sm);"></i>
                            Gestión de Perfil
                        </h1>
                        <p style="margin: var(--spacing-sm) 0 0 0; color: var(--text-muted);">
                            Administra tu información personal y configuración de cuenta
                        </p>
                    </div>
                    <div>
                        <a href="<?php echo \ObelisIA\Router\MainRouter::url('panel'); ?>" class="btn btn-outline">
                            <i class="fas fa-arrow-left"></i>
                            Volver al Panel
                        </a>
                    </div>
                </div>
            </div>

            <!-- Alertas -->
            <?php if (!empty($error_message)): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-triangle"></i>
                    <?php echo htmlspecialchars($error_message); ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($success_message)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo htmlspecialchars($success_message); ?>
                </div>
            <?php endif; ?>

            <!-- Contenido -->
            <div class="profile-content">
                <!-- Formulario de edición -->
                <div class="profile-card">
                    <div class="profile-card-header">
                        <div class="profile-card-icon">
                            <i class="fas fa-edit"></i>
                        </div>
                        <h3 class="profile-card-title">Información Personal</h3>
                    </div>

                    <form method="POST" class="needs-validation" novalidate autocomplete="off">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                        <input type="hidden" name="action" value="update_profile">

                        <div class="form-section">
                            <div class="form-section-title">
                                <i class="fas fa-user"></i>
                                Datos Básicos
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="full_name" class="form-label">Nombre Completo</label>
                                    <input type="text" class="form-control" id="full_name" name="full_name" 
                                           required value="<?php echo htmlspecialchars($user_data['full_name']); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="email" class="form-label">Correo Electrónico</label>
                                    <input type="email" class="form-control" id="email" name="email" 
                                           required value="<?php echo htmlspecialchars($user_data['email']); ?>">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="username" class="form-label">Nombre de Usuario</label>
                                    <input type="text" class="form-control" id="username" 
                                           value="<?php echo htmlspecialchars($user_data['username']); ?>" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="phone" class="form-label">Teléfono</label>
                                    <input type="tel" class="form-control" id="phone" name="phone" 
                                           value="<?php echo htmlspecialchars($user_data['phone'] ?? ''); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="form-section">
                            <div class="form-section-title">
                                <i class="fas fa-info-circle"></i>
                                Información Adicional
                            </div>
                            
                            <div class="form-group">
                                <label for="bio" class="form-label">Biografía</label>
                                <textarea class="form-control" id="bio" name="bio" rows="3" 
                                          placeholder="Cuéntanos sobre ti..."><?php echo htmlspecialchars($user_data['bio'] ?? ''); ?></textarea>
                            </div>
                            
                            <div class="form-group">
                                <label for="address" class="form-label">Dirección</label>
                                <textarea class="form-control" id="address" name="address" rows="2" 
                                          placeholder="Tu dirección..."><?php echo htmlspecialchars($user_data['address'] ?? ''); ?></textarea>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-save"></i>
                            Guardar Cambios
                        </button>
                    </form>
                </div>

                <!-- Panel lateral -->
                <div class="profile-card">
                    <div class="profile-avatar-section">
                        <img src="<?php echo htmlspecialchars($profile_pic_url); ?>" 
                             alt="Foto de perfil de <?php echo htmlspecialchars($user_data['full_name']); ?>" 
                             class="profile-avatar"
                             onclick="openModal('changeProfilePicModal')">
                        
                        <div class="profile-name"><?php echo htmlspecialchars($user_data['full_name']); ?></div>
                        
                        <div class="profile-role">
                            <i class="fas fa-<?php echo $user_data['membership_type'] === 'premium' ? 'crown' : 'user'; ?>"></i>
                            <?php echo ucfirst(htmlspecialchars($user_data['role'])); ?> - <?php echo ucfirst(htmlspecialchars($user_data['membership_type'])); ?>
                        </div>
                    </div>

                    <div class="profile-stats">
                        <div class="profile-stat">
                            <span class="profile-stat-value">
                                <?php echo date('Y', strtotime($user_data['created_at'])); ?>
                            </span>
                            <span class="profile-stat-label">Miembro desde</span>
                        </div>
                        <div class="profile-stat">
                            <span class="profile-stat-value">
                                <?php echo $user_data['membership_type'] === 'premium' ? 'Premium' : 'Básico'; ?>
                            </span>
                            <span class="profile-stat-label">Plan actual</span>
                        </div>
                    </div>

                    <div class="action-buttons">
                        <button class="action-button" onclick="openModal('changeProfilePicModal')">
                            <i class="fas fa-camera"></i>
                            Cambiar Foto
                        </button>
                        
                        <button class="action-button" onclick="openModal('changePasswordModal')">
                            <i class="fas fa-lock"></i>
                            Cambiar Contraseña
                        </button>
                        
                        <button class="action-button danger" onclick="openModal('deleteAccountModal')">
                            <i class="fas fa-trash"></i>
                            Eliminar Cuenta
                        </button>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Modales -->
    
    <!-- Modal Cambiar Foto de Perfil -->
    <div id="changeProfilePicModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-camera"></i>
                    Cambiar Foto de Perfil
                </h5>
                <button type="button" class="btn-close" onclick="closeModal('changeProfilePicModal')">&times;</button>
            </div>
            
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="action" value="change_profile_pic">
                
                <div class="form-group">
                    <label for="profile_pic" class="form-label">
                        <i class="fas fa-upload"></i>
                        Seleccionar nueva imagen
                    </label>
                    <input type="file" class="form-control" id="profile_pic" name="profile_image" 
                           accept="image/*" required>
                    <small class="form-text text-muted" style="color: var(--text-muted) !important; margin-top: var(--spacing-xs);">
                        Formatos permitidos: JPG, PNG, GIF. Tamaño máximo: 5MB
                    </small>
                </div>
                
                <div style="display: flex; gap: var(--spacing-md); margin-top: var(--spacing-lg);">
                    <button type="button" class="btn btn-outline" onclick="closeModal('changeProfilePicModal')" style="flex: 1;">
                        Cancelar
                    </button>
                    <button type="submit" class="btn btn-primary" style="flex: 1;">
                        <i class="fas fa-upload"></i>
                        Subir Imagen
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Cambiar Contraseña -->
    <div id="changePasswordModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-lock"></i>
                    Cambiar Contraseña
                </h5>
                <button type="button" class="btn-close" onclick="closeModal('changePasswordModal')">&times;</button>
            </div>
            
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="action" value="change_password">
                
                <div class="form-group">
                    <label for="current_password" class="form-label">
                        <i class="fas fa-key"></i>
                        Contraseña Actual
                    </label>
                    <input type="password" class="form-control" id="current_password" name="current_password" required>
                </div>
                
                <div class="form-group">
                    <label for="new_password" class="form-label">
                        <i class="fas fa-lock"></i>
                        Nueva Contraseña
                    </label>
                    <input type="password" class="form-control" id="new_password" name="new_password" 
                           required minlength="8">
                    <small class="form-text text-muted" style="color: var(--text-muted) !important; margin-top: var(--spacing-xs);">
                        Mínimo 8 caracteres
                    </small>
                </div>
                
                <div class="form-group">
                    <label for="confirm_password" class="form-label">
                        <i class="fas fa-check"></i>
                        Confirmar Nueva Contraseña
                    </label>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_new_password" required>
                </div>
                
                <div style="display: flex; gap: var(--spacing-md); margin-top: var(--spacing-lg);">
                    <button type="button" class="btn btn-outline" onclick="closeModal('changePasswordModal')" style="flex: 1;">
                        Cancelar
                    </button>
                    <button type="submit" class="btn btn-primary" style="flex: 1;">
                        <i class="fas fa-save"></i>
                        Cambiar Contraseña
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Eliminar Cuenta -->
    <div id="deleteAccountModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" style="color: var(--error-color);">
                    <i class="fas fa-exclamation-triangle"></i>
                    Eliminar Cuenta
                </h5>
                <button type="button" class="btn-close" onclick="closeModal('deleteAccountModal')">&times;</button>
            </div>
            
            <div style="margin-bottom: var(--spacing-lg);">
                <div class="alert alert-error">
                    <i class="fas fa-warning"></i>
                    <strong>¡Atención!</strong> Esta acción no se puede deshacer. Se eliminarán permanentemente todos tus datos, incluyendo:
                    <ul style="margin: var(--spacing-sm) 0 0 var(--spacing-lg); padding: 0;">
                        <li>Tu perfil y configuraciones</li>
                        <li>Todas tus creaciones y proyectos</li>
                        <li>Tu historial de actividad</li>
                        <li>Tu suscripción premium (si tienes)</li>
                    </ul>
                </div>
            </div>
            
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="action" value="delete_account">
                
                <div class="form-group">
                    <label for="confirm_delete_text" class="form-label">
                        <i class="fas fa-keyboard"></i>
                        Para confirmar, escribe "ELIMINAR" en el campo siguiente
                    </label>
                    <input type="text" class="form-control" id="confirm_delete_text" name="confirm_delete" 
                           required placeholder="ELIMINAR">
                </div>
                
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: var(--spacing-sm); cursor: pointer;">
                        <input type="checkbox" id="confirm_delete_check" name="confirm_delete_check" required 
                               style="width: auto; margin: 0;">
                        <span style="font-size: var(--font-size-sm);">
                            Confirmo que entiendo que esta acción eliminará permanentemente mi cuenta y todos mis datos
                        </span>
                    </label>
                </div>
                
                <div style="display: flex; gap: var(--spacing-md); margin-top: var(--spacing-lg);">
                    <button type="button" class="btn btn-outline" onclick="closeModal('deleteAccountModal')" style="flex: 1;">
                        Cancelar
                    </button>
                    <button type="submit" class="btn btn-primary" style="flex: 1; background: var(--error-color); border-color: var(--error-color);">
                        <i class="fas fa-trash"></i>
                        Eliminar Cuenta
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Funciones para manejar modales
        function openModal(modalId) {
            const modal = document.getElementById(modalId);
            if (modal) {
                modal.style.display = 'flex';
                document.body.style.overflow = 'hidden';
            }
        }

        function closeModal(modalId) {
            const modal = document.getElementById(modalId);
            if (modal) {
                modal.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        }

        // Cerrar modal al hacer clic fuera
        window.addEventListener('click', function(event) {
            if (event.target.classList.contains('modal')) {
                closeModal(event.target.id);
            }
        });

        // Cerrar modal con ESC
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                const modals = document.querySelectorAll('.modal');
                modals.forEach(modal => {
                    if (modal.style.display === 'flex') {
                        closeModal(modal.id);
                    }
                });
            }
        });

        // Validación de contraseñas
        document.getElementById('new_password').addEventListener('input', function() {
            const password = this.value;
            const confirmPassword = document.getElementById('confirm_password');
            
            if (confirmPassword.value && password !== confirmPassword.value) {
                confirmPassword.setCustomValidity('Las contraseñas no coinciden');
            } else {
                confirmPassword.setCustomValidity('');
            }
        });

        document.getElementById('confirm_password').addEventListener('input', function() {
            const newPassword = document.getElementById('new_password').value;
            
            if (this.value !== newPassword) {
                this.setCustomValidity('Las contraseñas no coinciden');
            } else {
                this.setCustomValidity('');
            }
        });

        // Validación de bootstrap
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                var forms = document.getElementsByClassName('needs-validation');
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();

        // Validación especial para eliminar cuenta
        document.getElementById('confirm_delete_text').addEventListener('input', function() {
            if (this.value.toUpperCase() !== 'ELIMINAR') {
                this.setCustomValidity('Debes escribir exactamente "ELIMINAR"');
            } else {
                this.setCustomValidity('');
            }
        });

        // Auto-hide alerts after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                setTimeout(function() {
                    alert.style.opacity = '0';
                    alert.style.transform = 'translateY(-20px)';
                    setTimeout(function() {
                        alert.style.display = 'none';
                    }, 300);
                }, 5000);
            });
        });
    </script>
</body>
</html>