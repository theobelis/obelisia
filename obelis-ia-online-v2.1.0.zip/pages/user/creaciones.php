<?php
// pages/user/creaciones.php - Versión con soporte para Studio
// Activar reporte de errores para debug
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Incluir configuración
require_once __DIR__ . '/../../src/Config/config.php';
// Incluir autoloader si no está cargado
if (!class_exists('ObelisIA\Database\Database')) {
    require_once __DIR__ . '/../../vendor/autoload.php';
}
// Incluir ObelisStudio para mostrar proyectos
require_once __DIR__ . '/../../src/ObelisStudio/ObelisStudio.php';
require_once __DIR__ . '/../../src/ObelisStudio/ProjectManager.php';

use ObelisIA\Database\Database;
use ObelisIA\Auth\Auth;

try {
    // Debug: verificar qué variables están disponibles
    if (DEBUG_MODE) {
        error_log("=== DEBUG CREACIONES.PHP ===");
        error_log("auth isset: " . (isset($auth) ? 'SI' : 'NO'));
        error_log("db isset: " . (isset($db) ? 'SI' : 'NO'));
        error_log("pdo isset: " . (isset($pdo) ? 'SI' : 'NO'));
        error_log("SESSION user_id: " . (isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'NO_SET'));
    }
    
    // Inicializar sesión si no está iniciada
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    // Inicializar auth y db si no están disponibles (acceso directo)
    if (!isset($auth) || !is_object($auth)) {
        $database = new Database();
        $db = $database->getConnection();
        $auth = new Auth($db);
    }
    
    if (!isset($db) || !is_object($db)) {
        if (!isset($database)) {
            $database = new Database();
        }
        $db = $database->getConnection();
    }
    
    if (!isset($db) || !is_object($db)) {
        throw new Exception("Conexión a base de datos no inicializada correctamente");
    }
    
    // Asegurar que tenemos acceso a PDO también
    if (!isset($pdo) || !is_object($pdo)) {
        // Crear conexión PDO si no existe
        require_once __DIR__ . '/../../src/Database/Database.php';
        $database = new \ObelisIA\Database\Database();
        $pdo = $database->getConnection();
    }
    
    if (!$auth->isLoggedIn()) {
        if (class_exists('\ObelisIA\Router\MainRouter')) {
            \ObelisIA\Router\MainRouter::redirect('acceso');
        } else {
            header('Location: /acceso');
        }
        exit;
    }
    
    $user = $auth->getCurrentUser();
    if (!$user) {
        throw new Exception("No se pudieron obtener los datos del usuario");
    }
    
    $isPremium = ($user['subscription_type'] ?? '') === 'premium';
    
    // Inicializar ObelisStudio
    $studio = new \ObelisIA\ObelisStudio\ObelisStudio($user['id']);
    $projectManager = new \ObelisIA\ObelisStudio\ProjectManager($user['id']);
    
} catch (Exception $e) {
    // Registrar el error y mostrar una página de error amigable
    if (function_exists('writeLog')) {
        writeLog("Error en creaciones.php: " . $e->getMessage(), 'ERROR');
    }
    
    // En producción, mostrar un error genérico
    echo '<!DOCTYPE html>';
    echo '<html><head><title>Error - ObelisIA</title>';
    echo '<meta charset="utf-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">';
    echo '</head><body>';
    echo '<div class="container mt-5">';
    echo '<div class="alert alert-danger">';
    echo '<h4>Error temporal</h4>';
    echo '<p>Lo sentimos, estamos experimentando problemas técnicos. Por favor, inténtalo más tarde.</p>';
    
    // Solo mostrar detalles si estamos en modo debug
    if (defined('DEBUG_MODE') && DEBUG_MODE) {
        echo '<hr>';
        echo '<p><strong>Detalles del error:</strong> ' . htmlspecialchars($e->getMessage()) . '</p>';
        echo '<p><strong>Archivo:</strong> ' . htmlspecialchars($e->getFile()) . '</p>';
        echo '<p><strong>Línea:</strong> ' . $e->getLine() . '</p>';
    }
    
    echo '</div>';
    echo '<a href="/" class="btn btn-primary">Volver al inicio</a>';
    echo '</div>';
    echo '</body></html>';
    exit;
}
?>
<div class="container py-5">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="mb-2">
                <i class="fas fa-palette me-2 text-primary"></i>
                Mis Creaciones
            </h1>
            <p class="text-muted mb-0">Gestiona tus creaciones de IA y proyectos del Studio</p>
        </div>
        <div class="d-flex gap-2">
            <a href="/studio/" class="btn btn-primary">
                <i class="fas fa-magic me-1"></i>Nuevo Proyecto Studio
            </a>
            <a href="/herramientas" class="btn btn-outline-primary">
                <i class="fas fa-tools me-1"></i>Herramientas IA
            </a>
        </div>
    </div>

    <!-- Tabs de navegación -->
    <ul class="nav nav-pills mb-4" id="creacionesTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="ia-creations-tab" data-bs-toggle="pill" 
                    data-bs-target="#ia-creations" type="button" role="tab" 
                    aria-controls="ia-creations" aria-selected="true">
                <i class="fas fa-robot me-2"></i>Creaciones IA
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="studio-projects-tab" data-bs-toggle="pill" 
                    data-bs-target="#studio-projects" type="button" role="tab" 
                    aria-controls="studio-projects" aria-selected="false">
                <i class="fas fa-magic me-2"></i>Proyectos Studio
            </button>
        </li>
    </ul>

    <!-- Contenido de las tabs -->
    <div class="tab-content" id="creacionesTabContent">
        <!-- Tab: Creaciones IA -->
        <div class="tab-pane fade show active" id="ia-creations" role="tabpanel" aria-labelledby="ia-creations-tab">
            <div class="row">
                <div class="col-lg-8">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="mb-0">Creaciones con Herramientas IA</h4>
                        <small class="text-muted">Arrastra estas creaciones al Studio para crear proyectos</small>
                    </div>
                    <div class="row" id="ia-creations-grid">
                        <?php
                        try {
                            // Obtener creaciones reales del usuario desde la base de datos
                            $hashidsPath = __DIR__ . '/../../helpers/hashids.php';
                            if (file_exists($hashidsPath)) {
                                require_once $hashidsPath;
                                $hashids = function_exists('getHashidsInstance') ? getHashidsInstance() : null;
                            } else {
                                $hashids = null;
                            }
                            
                            // Usar PDO en lugar de mysqli para consistencia
                            $stmt = $pdo->prepare("SELECT id, file_path, title, description, type, tool_used, created_at FROM user_creations WHERE user_id = ? ORDER BY created_at DESC");
                            $stmt->execute([$user['id']]);
                            $creaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);
                            
                            // Debug: mostrar cantidad encontrada
                            if (defined('DEBUG_MODE') && DEBUG_MODE) {
                                echo "<!-- Debug: Encontradas " . count($creaciones) . " creaciones para el usuario " . $user['id'] . " -->";
                            }
                            
                            if (empty($creaciones)) {
                                echo '<div class="col-12">';
                                echo '<div class="text-center py-5">';
                                echo '<i class="fas fa-robot fa-3x text-muted mb-3"></i>';
                                echo '<h5 class="text-muted">No tienes creaciones de IA aún</h5>';
                                echo '<p class="text-muted">Crea contenido con nuestras herramientas de IA</p>';
                                echo '<a href="/herramientas" class="btn btn-primary">Explorar Herramientas</a>';
                                echo '</div>';
                                echo '</div>';
                            } else {
                                foreach ($creaciones as $c) {
                                    $img = htmlspecialchars($c['file_path'] ?? '/assets/img/placeholder.png');
                                    $title = htmlspecialchars($c['title'] ?? 'Sin título');
                                    $desc = htmlspecialchars($c['description'] ?? '');
                                    $type = htmlspecialchars($c['type'] ?? 'unknown');
                                    $tool = htmlspecialchars($c['tool_used'] ?? 'Herramienta IA');
                                    $id = (int)($c['id'] ?? 0);
                                    
                                    if ($id <= 0) continue;
                                    
                                    $hashid = $hashids ? $hashids->encode($id) : $id;
                                    if (empty($hashid)) $hashid = $id;
                                    
                                    echo '<div class="col-lg-6 col-xl-4 mb-4">';
                                    echo '<div class="card h-100 shadow-sm creation-card" ';
                                    echo 'draggable="true" ';
                                    echo 'data-creation-id="' . $id . '" ';
                                    echo 'data-creation-type="' . htmlspecialchars($type) . '" ';
                                    echo 'data-creation-title="' . htmlspecialchars($title) . '" ';
                                    echo 'data-creation-content="' . htmlspecialchars($img) . '" ';
                                    echo 'data-creation-tool="' . htmlspecialchars($tool) . '" ';
                                    echo 'ondragstart="handleCreationDragStart(event)" ';
                                    echo 'style="cursor: grab;">';
                                    
                                    // Imagen/Preview
                                    if ($type === 'image') {
                                        echo '<img src="' . $img . '" class="card-img-top" style="height: 200px; object-fit: cover;" alt="' . $title . '" onerror="this.src=\'/assets/img/placeholder.png\'">';
                                    } else {
                                        $icon = $type === 'text' ? 'file-text' : ($type === 'audio' ? 'music' : 'file');
                                        $bgColor = $type === 'text' ? 'info' : ($type === 'audio' ? 'warning' : 'secondary');
                                        echo '<div class="card-img-top bg-gradient-' . $bgColor . ' d-flex align-items-center justify-content-center text-white" style="height: 200px;">';
                                        echo '<div class="text-center">';
                                        echo '<i class="fas fa-' . $icon . ' fa-3x mb-2"></i>';
                                        echo '<h6>' . ucfirst($type) . '</h6>';
                                        echo '</div>';
                                        echo '</div>';
                                    }
                                    
                                    echo '<div class="card-body">';
                                    echo '<div class="d-flex justify-content-between align-items-start mb-2">';
                                    echo '<h6 class="card-title mb-0">' . $title . '</h6>';
                                    echo '<i class="fas fa-grip-vertical text-muted drag-handle" title="Arrastra al Studio"></i>';
                                    echo '</div>';
                                    
                                    if ($desc) {
                                        echo '<p class="card-text text-muted small mb-2">' . substr($desc, 0, 100) . (strlen($desc) > 100 ? '...' : '') . '</p>';
                                    }
                                    
                                    echo '<div class="d-flex justify-content-between align-items-center">';
                                    echo '<div>';
                                    echo '<span class="badge bg-primary">' . ucfirst($type) . '</span>';
                                    echo '<span class="badge bg-light text-dark ms-1">' . $tool . '</span>';
                                    echo '</div>';
                                    echo '<small class="text-muted">' . date('d/m/Y', strtotime($c['created_at'])) . '</small>';
                                    echo '</div>';
                                    echo '</div>';
                                    
                                    // Footer con acciones
                                    echo '<div class="card-footer bg-transparent border-0 d-flex justify-content-between gap-2">';
                                    echo '<a href="/pages/creacion/index.php?id=' . urlencode($hashid) . '" class="btn btn-outline-primary btn-sm" title="Ver creación">';
                                    echo '<i class="fas fa-eye"></i>';
                                    echo '</a>';
                                    echo '<button class="btn btn-outline-secondary btn-sm" title="Compartir" onclick="compartirCreacion(\'' . htmlspecialchars($hashid, ENT_QUOTES) . '\', \'' . htmlspecialchars($title, ENT_QUOTES) . '\', \'' . htmlspecialchars($img, ENT_QUOTES) . '\')">';
                                    echo '<i class="fas fa-share-alt"></i>';
                                    echo '</button>';
                                    echo '<button class="btn btn-outline-danger btn-sm" title="Eliminar" onclick="eliminarCreacion(' . $id . ', this)">';
                                    echo '<i class="fas fa-trash"></i>';
                                    echo '</button>';
                                    echo '</div>';
                                    
                                    echo '</div>';
                                    echo '</div>';
                                }
                            }
                        } catch (Exception $e) {
                            echo '<div class="col-12">';
                            echo '<div class="alert alert-danger">';
                            echo '<h5><i class="fas fa-exclamation-triangle"></i> Error al cargar las creaciones</h5>';
                            echo '<p>Lo sentimos, no pudimos cargar tus creaciones en este momento.</p>';
                            if (defined('DEBUG_MODE') && DEBUG_MODE) {
                                echo '<hr><p><strong>Error:</strong> ' . htmlspecialchars($e->getMessage()) . '</p>';
                                echo '<p><strong>Archivo:</strong> ' . htmlspecialchars($e->getFile()) . ' Línea: ' . $e->getLine() . '</p>';
                            }
                            echo '<button class="btn btn-primary btn-sm mt-2" onclick="location.reload()">Reintentar</button>';
                            echo '</div>';
                            echo '</div>';
                        }
                        ?>
                    </div>
                </div>
                
                <!-- Sidebar con información de drag & drop -->
                <div class="col-lg-4">
                    <div class="card bg-light">
                        <div class="card-body">
                            <h6 class="card-title">
                                <i class="fas fa-info-circle me-2"></i>
                                Drag & Drop al Studio
                            </h6>
                            <p class="card-text small text-muted">
                                Arrastra tus creaciones de IA directamente al Studio para crear proyectos multimedia complejos.
                            </p>
                            <div class="d-flex align-items-center mb-2">
                                <i class="fas fa-grip-vertical me-2 text-primary"></i>
                                <small>Usa el ícono de agarre para arrastrar</small>
                            </div>
                            <div class="d-flex align-items-center mb-2">
                                <i class="fas fa-magic me-2 text-success"></i>
                                <small>Suelta en el área del Studio</small>
                            </div>
                            <div class="d-flex align-items-center">
                                <i class="fas fa-project-diagram me-2 text-info"></i>
                                <small>Combina múltiples elementos</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tab: Proyectos Studio -->
        <div class="tab-pane fade" id="studio-projects" role="tabpanel" aria-labelledby="studio-projects-tab">
            <div class="row">
                <div class="col-12">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="mb-0">Proyectos del Studio</h4>
                        <div class="d-flex gap-2">
                            <select class="form-select form-select-sm" id="projectFilter" style="width: auto;">
                                <option value="">Todos los proyectos</option>
                                <option value="draft">Borradores</option>
                                <option value="published">Publicados</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="row" id="studio-projects-grid">
                        <?php
                        try {
                            // Obtener proyectos del Studio
                            $projects = $projectManager->getUserProjects();
                            $stats = $studio->getUserStats();
                            
                            // Debug: mostrar cantidad encontrada
                            if (defined('DEBUG_MODE') && DEBUG_MODE) {
                                echo "<!-- Debug: Encontrados " . count($projects) . " proyectos para el usuario " . $user['id'] . " -->";
                            }
                            
                            if (empty($projects)) {
                                echo '<div class="col-12">';
                                echo '<div class="text-center py-5">';
                                echo '<i class="fas fa-magic fa-3x text-muted mb-3"></i>';
                                echo '<h5 class="text-muted">No tienes proyectos del Studio aún</h5>';
                                echo '<p class="text-muted">Crea tu primer proyecto multimedia</p>';
                                echo '<a href="/studio/" class="btn btn-primary">Crear Proyecto</a>';
                                echo '</div>';
                                echo '</div>';
                            } else {
                                foreach ($projects as $project) {
                                    $title = htmlspecialchars($project['title']);
                                    $description = htmlspecialchars($project['description'] ?? '');
                                    $status = $project['status'];
                                    $isPublic = $project['is_public'] ?? 0;
                                    $views = $project['views'] ?? 0;
                                    $id = $project['id'];
                                    
                                    $statusColor = $status === 'published' ? 'success' : 'warning';
                                    $statusText = $status === 'published' ? 'Publicado' : 'Borrador';
                                    
                                    echo '<div class="col-lg-6 col-xl-4 mb-4 project-card" data-status="' . $status . '">';
                                    echo '<div class="card h-100 shadow-sm studio-project-card">';
                                    
                                    // Preview del proyecto
                                    echo '<div class="card-img-top bg-gradient-primary d-flex align-items-center justify-content-center text-white" style="height: 200px;">';
                                    echo '<div class="text-center">';
                                    echo '<i class="fas fa-magic fa-3x mb-2"></i>';
                                    echo '<h6>Proyecto Studio</h6>';
                                    if ($isPublic) {
                                        echo '<span class="badge bg-success"><i class="fas fa-globe me-1"></i>Público</span>';
                                    } else {
                                        echo '<span class="badge bg-secondary"><i class="fas fa-lock me-1"></i>Privado</span>';
                                    }
                                    echo '</div>';
                                    echo '</div>';
                                    
                                    echo '<div class="card-body">';
                                    echo '<h6 class="card-title">' . $title . '</h6>';
                                    
                                    if ($description) {
                                        echo '<p class="card-text text-muted small mb-2">' . substr($description, 0, 100) . (strlen($description) > 100 ? '...' : '') . '</p>';
                                    }
                                    
                                    echo '<div class="d-flex justify-content-between align-items-center mb-2">';
                                    echo '<span class="badge bg-' . $statusColor . '">' . $statusText . '</span>';
                                    echo '<small class="text-muted"><i class="fas fa-eye me-1"></i>' . $views . ' vistas</small>';
                                    echo '</div>';
                                    
                                    echo '<small class="text-muted">Actualizado: ' . date('d/m/Y', strtotime($project['updated_at'])) . '</small>';
                                    echo '</div>';
                                    
                                    // Footer con acciones
                                    echo '<div class="card-footer bg-transparent border-0">';
                                    echo '<div class="d-flex gap-2">';
                                    
                                    // Botón editar (principal)
                                    echo '<a href="/studio/editor.php?id=' . $id . '" class="btn btn-primary btn-sm flex-fill">';
                                    echo '<i class="fas fa-edit me-1"></i>Editar';
                                    echo '</a>';
                                    
                                    // Botón ver/preview
                                    echo '<a href="/studio/viewer.php?id=' . $id . '" class="btn btn-outline-secondary btn-sm" title="Vista previa">';
                                    echo '<i class="fas fa-eye"></i>';
                                    echo '</a>';
                                    
                                    // Dropdown con más opciones
                                    echo '<div class="dropdown">';
                                    echo '<button class="btn btn-outline-secondary btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown">';
                                    echo '<i class="fas fa-ellipsis-v"></i>';
                                    echo '</button>';
                                    echo '<ul class="dropdown-menu dropdown-menu-end">';
                                    
                                    if ($status === 'draft') {
                                        echo '<li><a class="dropdown-item" href="#" onclick="publishProject(' . $id . ')">';
                                        echo '<i class="fas fa-globe me-2"></i>Publicar</a></li>';
                                    }
                                    
                                    echo '<li><a class="dropdown-item" href="#" onclick="duplicateProject(' . $id . ')">';
                                    echo '<i class="fas fa-copy me-2"></i>Duplicar</a></li>';
                                    
                                    echo '<li><a class="dropdown-item" href="#" onclick="shareProject(' . $id . ', \'' . htmlspecialchars($title, ENT_QUOTES) . '\')">';
                                    echo '<i class="fas fa-share me-2"></i>Compartir</a></li>';
                                    
                                    echo '<li><hr class="dropdown-divider"></li>';
                                    
                                    echo '<li><a class="dropdown-item text-danger" href="#" onclick="deleteProject(' . $id . ', this)">';
                                    echo '<i class="fas fa-trash me-2"></i>Eliminar</a></li>';
                                    
                                    echo '</ul>';
                                    echo '</div>';
                                    
                                    echo '</div>';
                                    echo '</div>';
                                    
                                    echo '</div>';
                                    echo '</div>';
                                }
                            }
                        } catch (Exception $e) {
                            echo '<div class="col-12">';
                            echo '<div class="alert alert-danger">';
                            echo '<h5><i class="fas fa-exclamation-triangle"></i> Error al cargar los proyectos</h5>';
                            echo '<p>Lo sentimos, no pudimos cargar tus proyectos en este momento.</p>';
                            if (defined('DEBUG_MODE') && DEBUG_MODE) {
                                echo '<hr><p><strong>Error:</strong> ' . htmlspecialchars($e->getMessage()) . '</p>';
                                echo '<p><strong>Archivo:</strong> ' . htmlspecialchars($e->getFile()) . ' Línea: ' . $e->getLine() . '</p>';
                            }
                            echo '<button class="btn btn-primary btn-sm mt-2" onclick="location.reload()">Reintentar</button>';
                            echo '</div>';
                            echo '</div>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Estilos específicos -->
<style>
.creation-card, .studio-project-card {
    transition: transform 0.2s, box-shadow 0.2s;
    cursor: grab;
}

.creation-card:hover, .studio-project-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15) !important;
}

.creation-card.dragging {
    opacity: 0.8;
    transform: rotate(5deg);
    cursor: grabbing;
}

.drag-handle {
    cursor: grab;
    font-size: 1.2em;
}

.drag-handle:hover {
    color: #007bff !important;
}

.drop-zone {
    border: 2px dashed #007bff;
    background-color: rgba(0, 123, 255, 0.1);
    border-radius: 8px;
    min-height: 200px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 20px;
}

.nav-pills .nav-link {
    border-radius: 8px;
    margin-right: 8px;
}

.nav-pills .nav-link.active {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Inicializar funcionalidades
    initializeDragAndDrop();
    initializeProjectFilters();
    initializeTooltips();
});

// Funcionalidad de Drag & Drop mejorada
function initializeDragAndDrop() {
    // Ya no necesitamos esta función aquí porque handleCreationDragStart se llama directamente
    console.log('Drag and Drop inicializado');
}

// Función para manejar el inicio del drag de una creación
function handleCreationDragStart(event) {
    const card = event.target.closest('.creation-card');
    if (!card) return;
    
    // Datos de la creación
    const creationData = {
        id: card.dataset.creationId,
        type: card.dataset.creationType,
        title: card.dataset.creationTitle,
        content: card.dataset.creationContent,
        tool: card.dataset.creationTool
    };
    
    // Almacenar datos para el drop
    event.dataTransfer.setData('application/json', JSON.stringify(creationData));
    event.dataTransfer.setData('text/plain', 'creation'); // Identificador del tipo
    
    // Efectos visuales
    card.style.opacity = '0.7';
    card.classList.add('dragging');
    
    console.log('Iniciando drag de creación:', creationData);
}

// Función para abrir el Studio con una creación específica
function openStudioWithCreation(creationData) {
    // Crear un enlace temporal para abrir el Studio
    const studioUrl = `/studio/editor.php?import_creation=${encodeURIComponent(JSON.stringify(creationData))}`;
    window.open(studioUrl, '_blank');
}

// Añadir event listeners para dragend
document.addEventListener('DOMContentLoaded', function() {
    document.addEventListener('dragend', function(event) {
        const card = event.target.closest('.creation-card');
        if (card) {
            card.style.opacity = '1';
            card.classList.remove('dragging');
        }
    });
});

// Filtros de proyectos
function initializeProjectFilters() {
    const projectFilter = document.getElementById('projectFilter');
    if (projectFilter) {
        projectFilter.addEventListener('change', function() {
            const filterValue = this.value;
            const projectCards = document.querySelectorAll('.project-card');
            
            projectCards.forEach(card => {
                const status = card.dataset.status;
                
                if (filterValue === '' || status === filterValue) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    }
}

// Inicializar tooltips
function initializeTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[title]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

// Funciones para creaciones IA
function compartirCreacion(hashid, titulo, img) {
    try {
        const url = window.location.origin + '/pages/creacion/index.php?id=' + encodeURIComponent(hashid);
        if (navigator.share) {
            navigator.share({ 
                title: titulo, 
                url, 
                text: 'Mira mi creación en ObelisIA' 
            });
        } else {
            navigator.clipboard.writeText(url).then(() => {
                showNotification('Enlace copiado al portapapeles', 'success');
            }).catch(() => {
                prompt('Copia este enlace:', url);
            });
        }
    } catch (error) {
        console.error('Error al compartir:', error);
        showNotification('Error al compartir la creación', 'error');
    }
}

function eliminarCreacion(id, btn) {
    if (!confirm('¿Seguro que deseas eliminar esta creación?')) return;
    
    const originalHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
    
    fetch('/api/delete_creation.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Error de red: ' + response.status);
        }
        return response.json();
    })
    .then(data => {
        if (data.status === 'success') {
            btn.closest('.col-lg-6, .col-xl-4').remove();
            showNotification('Creación eliminada correctamente', 'success');
        } else {
            throw new Error(data.message || 'Error al eliminar');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Error al eliminar la creación: ' + error.message, 'error');
        btn.disabled = false;
        btn.innerHTML = originalHtml;
    });
}

// Funciones para proyectos del Studio
async function publishProject(projectId) {
    try {
        const response = await fetch('/api/studio/publish_project.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                project_id: projectId,
                is_public: 1 
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('Proyecto publicado correctamente', 'success');
            setTimeout(() => location.reload(), 1500);
        } else {
            throw new Error(data.message || 'Error al publicar proyecto');
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('Error al publicar el proyecto: ' + error.message, 'error');
    }
}

async function duplicateProject(projectId) {
    try {
        const response = await fetch('/api/studio/duplicate_project.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ project_id: projectId })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('Proyecto duplicado correctamente', 'success');
            setTimeout(() => location.reload(), 1500);
        } else {
            throw new Error(data.message || 'Error al duplicar proyecto');
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('Error al duplicar el proyecto: ' + error.message, 'error');
    }
}

function shareProject(projectId, title) {
    const url = window.location.origin + '/studio/viewer.php?id=' + projectId;
    
    if (navigator.share) {
        navigator.share({
            title: title,
            text: 'Mira mi proyecto del Studio en ObelisIA',
            url: url
        });
    } else {
        navigator.clipboard.writeText(url).then(() => {
            showNotification('Enlace del proyecto copiado al portapapeles', 'success');
        }).catch(() => {
            prompt('Copia este enlace:', url);
        });
    }
}

async function deleteProject(projectId, btn) {
    if (!confirm('¿Seguro que deseas eliminar este proyecto? Esta acción no se puede deshacer.')) return;
    
    const originalHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Eliminando...';
    
    try {
        const response = await fetch('/api/studio/delete_project.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ project_id: projectId })
        });
        
        const data = await response.json();
        
        if (data.success) {
            const projectCard = btn.closest('.col-lg-6, .col-xl-4');
            projectCard.style.transition = 'opacity 0.3s';
            projectCard.style.opacity = '0';
            
            setTimeout(() => {
                projectCard.remove();
                showNotification('Proyecto eliminado correctamente', 'success');
            }, 300);
        } else {
            throw new Error(data.message || 'Error al eliminar proyecto');
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('Error al eliminar el proyecto: ' + error.message, 'error');
        btn.disabled = false;
        btn.innerHTML = originalHtml;
    }
}

// Función auxiliar para mostrar notificaciones
function showNotification(message, type = 'info') {
    // Crear elemento de notificación
    const notification = document.createElement('div');
    notification.className = `alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show position-fixed`;
    notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; max-width: 350px;';
    
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto-remover después de 5 segundos
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

// Integración con el Studio (para cuando el usuario viene del Studio)
if (window.location.hash === '#studio-projects') {
    // Cambiar a la tab de proyectos del Studio
    const studioTab = document.getElementById('studio-projects-tab');
    if (studioTab) {
        studioTab.click();
    }
}

// Función para recibir elementos del Studio (cuando se implemente)
window.receiveFromStudio = function(elementData) {
    console.log('Elemento recibido del Studio:', elementData);
    // Esta función se puede usar para manejar elementos que el Studio envíe de vuelta
};
</script>

