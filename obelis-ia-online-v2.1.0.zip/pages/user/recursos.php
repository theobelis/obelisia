<?php
// Centro de recursos y tutoriales
$recursos = [
    [
        'titulo' => 'Guía rápida: Cómo usar el generador de imágenes IA',
        'enlace' => '#',
        'descripcion' => 'Aprende a crear imágenes sorprendentes en minutos.'
    ],
    [
        'titulo' => 'Video: Mejora tus textos con IA',
        'enlace' => '#',
        'descripcion' => 'Descubre cómo la IA puede ayudarte a escribir mejor.'
    ],
    [
        'titulo' => 'Tips para aprovechar tu suscripción premium',
        'enlace' => '#',
        'descripcion' => 'Sácale el máximo partido a todas las funciones avanzadas.'
    ]
];
?>
<div class="container my-4">
    <div class="row">
        <div class="col-12">
            <div class="card dashboard-card bg-light text-dark">
                <div class="card-header bg-transparent">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-book-open me-2"></i>Centro de Recursos y Tutoriales
                    </h5>
                </div>
                <div class="card-body">
                    <ul class="list-group">
                        <?php foreach ($recursos as $r): ?>
                            <li class="list-group-item">
                                <a href="<?php echo htmlspecialchars($r['enlace']); ?>" target="_blank">
                                    <strong><?php echo htmlspecialchars($r['titulo']); ?></strong>
                                </a>
                                <br><span class="text-muted small"><?php echo htmlspecialchars($r['descripcion']); ?></span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
