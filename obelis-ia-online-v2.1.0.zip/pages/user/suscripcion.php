<?php
/**
 * Página de Usuario: Mi Suscripción y Facturación
 * Conectada a la base de datos para mostrar datos reales.
 */

// 1. VERIFICACIÓN DE SESIÓN Y CONEXIÓN A BD
// Asumimos que el index.php principal ya ha iniciado la sesión
// y ha creado la conexión $db a la base de datos.

if (!isset($_SESSION['user_id'])) {
    // Si no hay usuario en la sesión, redirigir a la página de acceso
    \ObelisIA\Router\MainRouter::redirect('acceso');
}

$user_id = $_SESSION['user_id'];
$subscription_data = null;
$payments = [];

try {
    // 2. OBTENER DATOS DE LA SUSCRIPCIÓN DEL USUARIO
    $stmt = $db->prepare("SELECT membership_type, subscription_end FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $subscription_data = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$subscription_data) {
        // Manejar el caso improbable de que el usuario no exista en la BD
        throw new Exception("No se pudieron encontrar los datos del usuario.");
    }

    // 3. OBTENER HISTORIAL DE PAGOS
    $stmt_payments = $db->prepare("SELECT id, created_at, amount, status, transaction_id FROM payments WHERE user_id = ? ORDER BY created_at DESC");
    $stmt_payments->execute([$user_id]);
    $payments = $stmt_payments->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    // En un caso real, podrías registrar este error y mostrar una página de error amigable.
    error_log("Error en la página de suscripción: " . $e->getMessage());
    // Podríamos redirigir a una página de error 500 o mostrar un mensaje aquí mismo.
    echo "<div class='alert alert-danger'>Ha ocurrido un error al cargar tus datos. Por favor, intenta más tarde.</div>";
    // Detenemos la ejecución para no mostrar el resto de la página con datos incorrectos.
    return; 
}

?>
<main class="container py-5">
    <h1 class="mb-4">Mi Suscripción</h1>

    <div class="row">
        <div class="col-lg-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Plan Actual</h5>
                </div>
                <div class="card-body text-center">
                    <h2 class="h1 text-primary"><?php echo htmlspecialchars(ucfirst($subscription_data['membership_type'])); ?></h2>
                    
                    <?php if ($subscription_data['subscription_end']): ?>
                        <p class="text-muted">
                            Tu plan se renueva el <?php echo date('d/m/Y', strtotime($subscription_data['subscription_end'])); ?>
                        </p>
                    <?php else: ?>
                        <p class="text-muted">No tienes una suscripción activa.</p>
                    <?php endif; ?>

                    <?php if ($subscription_data['membership_type'] !== 'free'): ?>
                        <button id="cancel-sub-btn" class="btn btn-outline-danger mt-3">Cancelar Suscripción</button>
                    <?php else: ?>
                        <a href="/precios" class="btn btn-primary mt-3">Ver Planes Premium</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Historial de Pagos</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Fecha</th>
                                    <th>Descripción</th>
                                    <th>Monto</th>
                                    <th>Estado</th>
                                    <th>Factura</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($payments)): ?>
                                    <tr>
                                        <td colspan="5" class="text-center text-muted py-4">No tienes pagos registrados.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($payments as $payment): ?>
                                        <tr>
                                            <td><?php echo date('d/m/Y', strtotime($payment['created_at'])); ?></td>
                                            <td>Suscripción ObelisIA</td>
                                            <td>$<?php echo number_format($payment['amount'], 2); ?></td>
                                            <td><span class="badge bg-success"><?php echo ucfirst($payment['status']); ?></span></td>
                                            <td>
                                                <a href="/descargar-factura?id=<?php echo htmlspecialchars($payment['transaction_id']); ?>" class="btn btn-sm btn-outline-primary" title="Descargar Factura">
                                                    <i class="fas fa-download"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
document.getElementById('cancel-sub-btn')?.addEventListener('click', () => {
    if (confirm('¿Estás seguro de que quieres cancelar tu suscripción? Perderás acceso a los beneficios premium al final de tu ciclo de facturación.')) {
        fetch('/cancelar-suscripcion', { method: 'POST' })
            .then(res => res.json())
            .then(data => {
                alert(data.message);
                if (data.success) {
                    window.location.reload();
                }
            })
            .catch(err => alert('Hubo un error. Por favor, intenta de nuevo.'));
    }
});
</script>
