<?php
// buy.php - Página de métodos de pago premium
require_once __DIR__ . '/../../config.php';
// Ahora tienes disponibles las constantes PAYPAL_CLIENT_ID y GEMINI_API_KEY
if (!$auth->isLoggedIn()) {
    \ObelisIA\Router\MainRouter::redirect('acceso');
}
$page_title = "Elige tu método de pago - ObelisIA Premium";
// Ejemplo de uso de GEMINI_API_KEY:
// echo GEMINI_API_KEY;
?>
<style>
    body {
        background: var(--degradado-one) !important;
        color: var(--white);
    }
</style>
<div class="container py-5">
    <div class="floating-elements-section">
        <div class="floating-element" style="top:6%;left:4%;width:100px;height:100px;"></div>
        <div class="floating-element" style="top:24%;left:76%;width:80px;height:80px;"></div>
        <div class="floating-element" style="top:54%;left:16%;width:90px;height:90px;"></div>
        <div class="floating-element" style="top:69%;left:66%;width:110px;height:110px;"></div>
        <div class="floating-element" style="top:16%;left:46%;width:75px;height:75px;"></div>
        <div class="floating-element" style="top:44%;left:56%;width:95px;height:95px;"></div>
        <div class="floating-element" style="top:76%;left:26%;width:85px;height:85px;"></div>
        <div class="floating-element" style="top:81%;left:81%;width:78px;height:78px;"></div>
        <div class="floating-element" style="top:38%;left:33%;width:90px;height:90px;"></div>
        <div class="floating-element" style="top:63%;left:88%;width:80px;height:80px;"></div>
        <div class="floating-element" style="top:90%;left:10%;width:110px;height:110px;"></div>
        <div class="floating-element" style="top:92%;left:40%;width:95px;height:95px;"></div>
        <div class="floating-element" style="top:94%;left:70%;width:100px;height:100px;"></div>
        <div class="floating-element" style="top:97%;left:85%;width:85px;height:85px;"></div>
        <div class="floating-element" style="top:99%;left:55%;width:120px;height:120px;"></div>
    </div>
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card shadow-lg border-0">
                <div class="card-body p-5">
                    <h2 class="mb-4 text-center violet-blue-text">Elige tu método de pago</h2>
                    <div class="text-center mb-4">
                        <div class="mt-2">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/4/41/Visa_Logo.png" alt="Visa" style="height:32px; margin-right:8px;">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/0/04/Mastercard-logo.png" alt="Mastercard" style="height:32px; margin-right:8px;">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg" alt="PayPal" style="height:32px; margin-right:8px;">
                            <img src="https://getlogovector.com/wp-content/uploads/2023/12/mercado-pago-logo-vector-2023.png" alt="MercadoPago" style="height:32px;">
                        </div>
                        <small class="text-muted d-block mt-2">Tus datos están protegidos con cifrado SSL <i class="fas fa-lock"></i></small>
                    </div>
                    <div id="payment-error-message" class="alert alert-danger text-white d-none" role="alert"></div>
                    <div class="d-grid gap-3">
                        <!-- Botón Mercado Pago -->
                        <button id="mp-button" class="btn btn-info text-white w-100 btn-lg">
                            <img src="https://getlogovector.com/wp-content/uploads/2023/12/mercado-pago-logo-vector-2023.png" alt="MercadoPago" style="height:24px; margin-right:8px; vertical-align:middle;">Pagar con Mercado Pago
                        </button>

                        <!-- Formulario Tarjeta de Crédito/Débito -->
                        <button class="btn btn-primary w-100 btn-lg" type="button" data-bs-toggle="collapse" data-bs-target="#card-form-container" aria-expanded="false" aria-controls="card-form-container">
                            <i class="fas fa-credit-card me-2"></i>Pagar con Tarjeta de Crédito/Débito
                        </button>
                        <div class="collapse mt-3" id="card-form-container">
                            <form id="card-payment-form">
                                <div class="mb-3">
                                    <label for="card-number" class="form-label">Número de tarjeta</label>
                                    <input type="text" class="form-control" id="card-number" maxlength="19" required>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <label for="card-expiry" class="form-label">Vencimiento (MM/AA)</label>
                                        <input type="text" class="form-control" id="card-expiry" maxlength="5" required>
                                    </div>
                                    <div class="col">
                                        <label for="card-cvc" class="form-label">CVC</label>
                                        <input type="text" class="form-control" id="card-cvc" maxlength="4" required>
                                    </div>
                                </div>
                                <div class="mb-3 mt-3">
                                    <label for="card-name" class="form-label">Nombre en la tarjeta</label>
                                    <input type="text" class="form-control" id="card-name" required>
                                </div>
                                <button type="submit" class="btn btn-success w-100">Pagar $19.00 USD</button>
                            </form>
                        </div>

                        <!-- Botón PayPal -->
                        <div id="paypal-button-container"></div>

                        
                    </div>
                    <small class="text-muted d-block mt-3 text-center">*Serás redirigido a una pasarela de pago segura.</small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- PayPal SDK debe ir antes del JS de pagos -->
<?php if(defined('PAYPAL_CLIENT_ID') && PAYPAL_CLIENT_ID): ?>
<script src="https://www.paypal.com/sdk/js?client-id=<?php echo PAYPAL_CLIENT_ID; ?>&currency=USD"></script>
<?php endif; ?>
<script src="/assets/js/payments/buy.js"></script>
