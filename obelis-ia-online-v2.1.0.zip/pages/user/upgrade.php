<?php
// El front controller (index.php) ya ha inicializado $auth, $db y la sesión.

// Verificar si está logueado
if (!$auth->isLoggedIn()) {
    \ObelisIA\Router\MainRouter::redirect('acceso');
}

$page_title = "Upgrade a Premium - ObelisIA";
$success_message = '';
$error_message = '';

// Generar token CSRF si no existe
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Manejar upgrade (simulado)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upgrade'])) {
    // Verificar token CSRF
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $error_message = "Acción no permitida. Por favor, recarga la página e intenta de nuevo.";
    } else {
        // En un sistema real, aquí se integraría con un procesador de pagos como Stripe
        $update_query = "UPDATE users SET membership_type = 'premium', membership_expires_at = DATE_ADD(NOW(), INTERVAL 1 MONTH) WHERE id = ?";
        $update_stmt = $db->prepare($update_query);
        
        if ($update_stmt->execute([$_SESSION['user_id']])) {
            $_SESSION['membership_type'] = 'premium';
            $success_message = "¡Felicidades! Tu cuenta ha sido actualizada a Premium.";
        } else {
            $error_message = "Error al procesar el upgrade. Inténtalo nuevamente.";
        }
    }
}
?>

<?php include __DIR__ . '/../../src/Tools/views/premium_banner.php'; ?>

<!-- Floating Elements para fondo decorativo -->
<div class="floating-elements-section">
    <div class="floating-element"></div>
    <div class="floating-element"></div>
    <div class="floating-element"></div>
    <div class="floating-element"></div>
    <div class="floating-element"></div>
    <div class="floating-element"></div>
    <div class="floating-element"></div>
    <div class="floating-element"></div>
    <div class="floating-element"></div>
    <div class="floating-element"></div>
    <div class="floating-element"></div>
    <div class="floating-element"></div>
    <div class="floating-element"></div>
</div>
<script>
document.addEventListener("DOMContentLoaded", function() {
    const section = document.querySelector('.floating-elements-section');
    if (!section) return;
    const elements = Array.from(section.querySelectorAll('.floating-element'));
    const sectionRect = () => section.getBoundingClientRect();

    // Inicializar posiciones y velocidades
    const balls = elements.map((el, i) => {
        const w = el.offsetWidth || 100;
        const h = el.offsetHeight || 100;
        const secRect = sectionRect();
        let x = Math.random() * (secRect.width - w);
        let y = Math.random() * (secRect.height - h);
        let dx = (Math.random() - 0.5) * 1.5;
        let dy = (Math.random() - 0.5) * 1.5;
        el.style.left = x + "px";
        el.style.top = y + "px";
        el.style.right = "";
        el.style.bottom = "";
        el.style.transition = "none";
        el.style.width = w + "px";
        el.style.height = h + "px";
        return {el, x, y, dx, dy, w, h};
    });

    function animate() {
        const secRect = sectionRect();
        for (let i = 0; i < balls.length; i++) {
            let b = balls[i];
            b.x += b.dx;
            b.y += b.dy;
            if (b.x <= 0 || b.x + b.w >= secRect.width) b.dx *= -1;
            if (b.y <= 0 || b.y + b.h >= secRect.height) b.dy *= -1;
            for (let j = i + 1; j < balls.length; j++) {
                let b2 = balls[j];
                let dx = (b.x + b.w/2) - (b2.x + b2.w/2);
                let dy = (b.y + b.h/2) - (b2.y + b2.h/2);
                let dist = Math.sqrt(dx*dx + dy*dy);
                let minDist = (b.w + b2.w) / 2 * 0.9;
                if (dist < minDist) {
                    let tempDx = b.dx;
                    let tempDy = b.dy;
                    b.dx = b2.dx;
                    b.dy = b2.dy;
                    b2.dx = tempDx;
                    b2.dy = tempDy;
                    let angle = Math.atan2(dy, dx);
                    let overlap = minDist - dist;
                    b.x += Math.cos(angle) * (overlap/2);
                    b.y += Math.sin(angle) * (overlap/2);
                    b2.x -= Math.cos(angle) * (overlap/2);
                    b2.y -= Math.sin(angle) * (overlap/2);
                }
            }
            b.el.style.left = b.x + "px";
            b.el.style.top = b.y + "px";
        }
        requestAnimationFrame(animate);
    }
    animate();
});
</script>
<div class="g-sidenav-show bg-gray-200">

    <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg">
        

        <div class="container-fluid py-4">
             <?php if (!empty($success_message)): ?>
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="card card-custom text-center">
                            <div class="card-body p-5">
                                <div class="icon-box bg-gradient-success mx-auto mb-4" style="width: 80px; height: 80px; display: flex; align-items: center; justify-content: center;">
                                    <i class="material-icons text-white" style="font-size: 2.5rem;">star</i>
                                </div>
                                <h3 class="mb-3">¡Ya eres Premium!</h3>
                                <p class="text-muted mb-4"><?php echo htmlspecialchars($success_message); ?></p>
                                <a href="<?php echo \ObelisIA\Router\MainRouter::url('panel'); ?>" class="btn btn-primary-custom btn-lg">
                                    <i class="material-icons me-2">dashboard</i>
                                    Ir al Dashboard
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php elseif (($_SESSION['membership_type'] ?? 'free') === 'premium'): ?>
                 <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="card card-custom text-center">
                            <div class="card-body p-5">
                                <div class="icon-box bg-gradient-success mx-auto mb-4" style="width: 80px; height: 80px; display: flex; align-items: center; justify-content: center;">
                                    <i class="material-icons text-white" style="font-size: 2.5rem;">check_circle</i>
                                </div>
                                <h3 class="mb-3">Tu cuenta ya es Premium</h3>
                                <p class="text-muted mb-4">Ya disfrutas de todas las funciones ilimitadas de ObelisIA.</p>
                                <a href="<?php echo \ObelisIA\Router\MainRouter::url('panel'); ?>" class="btn btn-primary-custom btn-lg">
                                    <i class="material-icons me-2">dashboard</i>
                                    Ir al Dashboard
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="row">
                    <div class="col-12 text-center">
                        <h2 class="section-title text-white">Desbloquea el Poder Completo de la IA</h2>
                        <p class="section-subtitle text-white">Crea sin límites con nuestro plan Premium</p>
                    </div>
                </div>
                
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-4 col-md-6 mb-4">
                            <div class="pricing-card h-100">
                                <div class="pricing-header">
                                    <h3>Plan Actual: Gratuito</h3>
                                    <div class="price">
                                        <span class="currency">$</span>
                                        <span class="amount">0</span>
                                        <span class="period">/mes</span>
                                    </div>
                                </div>
                                <ul class="pricing-features">
                                    <li><i class="material-icons text-warning">warning</i> Generaciones limitadas</li>
                                    <li><i class="material-icons text-warning">warning</i> Con marca de agua</li>
                                    <li><i class="material-icons text-warning">warning</i> Resolución estándar</li>
                                    <li><i class="material-icons text-warning">warning</i> Sin soporte prioritario</li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-6 mb-4">
                            <div class="pricing-card pricing-card-premium h-100">
                                <div class="pricing-badge">¡Recomendado!</div>
                                <div class="pricing-header">
                                    <h3>Premium</h3>
                                    <div class="price">
                                        <span class="currency">$</span>
                                        <span class="amount">19</span>
                                        <span class="period">/mes</span>
                                    </div>
                                </div>
                                <ul class="pricing-features">
                                    <li><i class="material-icons text-success">check_circle</i> Generaciones ilimitadas</li>
                                    <li><i class="material-icons text-success">check_circle</i> Sin marca de agua</li>
                                    <li><i class="material-icons text-success">check_circle</i> Máxima resolución (4K)</li>
                                    <li><i class="material-icons text-success">check_circle</i> Soporte prioritario 24/7</li>
                                    <li><i class="material-icons text-success">check_circle</i> Acceso API</li>
                                </ul>
                                <div class="pricing-footer mt-auto">
                                    <?php if (!empty($error_message)): ?>
                                        <div class="alert alert-danger text-white" role="alert">
                                            <i class="material-icons me-2">error</i>
                                            <?php echo htmlspecialchars($error_message); ?>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <a href="<?php echo \ObelisIA\Router\MainRouter::url('buy'); ?>" class="btn btn-primary-custom w-100 btn-lg">
                                        <i class="material-icons me-2">rocket_launch</i>
                                        Upgrade a Premium
                                    </a>
                                    <a href="<?php echo \ObelisIA\Router\MainRouter::url('suscripcion'); ?>" class="btn btn-outline-secondary w-100 btn-sm mt-2">
                                        <i class="material-icons me-2">credit_card</i>
                                        Mi Suscripción
                                    </a>
                                    <!-- <small class="text-muted d-block mt-2">*Prueba gratuita por 7 días, luego se cobra mensualmente.</small> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>


<script src="https://www.paypal.com/sdk/js?client-id=<?php echo PAYPAL_CLIENT_ID; ?>&currency=USD"></script>
<script>
    paypal.Buttons({
        // Configurar la transacción
        createOrder: function(data, actions) {
            return actions.order.create({
                purchase_units: [{
                    description: 'Suscripción ObelisIA Premium (Mensual)',
                    amount: {
                        value: '19.00' // Asegúrate que el precio coincida
                    }
                }]
            });
        },
        // Finalizar la transacción
        onApprove: function(data, actions) {
            return actions.order.capture().then(function(details) {
                // LLAMADA AL BACKEND PARA VERIFICAR Y ACTUALIZAR
                fetch('/ajax/payments/paypal_capture_order.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        orderID: data.orderID,
                        payerID: details.payer.payer_id
                    })
                })
                .then(res => res.json())
                .then(result => {
                    if(result.success) {
                        alert('¡Pago completado! Tu cuenta ha sido actualizada.');
                        window.location.href = '/suscripcion';
                    } else {
                        alert('Error: ' + result.message);
                    }
                });
            });
        },
        onError: function(err) {
            console.error('Error en el pago con PayPal:', err);
            document.getElementById('payment-error-message').textContent = 'Ocurrió un error con PayPal. Por favor, intenta de nuevo.';
            document.getElementById('payment-error-message').classList.remove('d-none');
        }
    }).render('#paypal-button-container');
</script>
