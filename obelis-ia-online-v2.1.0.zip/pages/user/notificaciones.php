<?php
// Notificaciones del usuario
// Aquí puedes cargar notificaciones desde la base de datos o un array de ejemplo
$notificaciones = [
    [
        'fecha' => '05/08/2025',
        'mensaje' => '¡Bienvenido a ObelisIA! Descubre las nuevas herramientas de IA.',
        'tipo' => 'info'
    ],
    [
        'fecha' => '04/08/2025',
        'mensaje' => 'Tu suscripción ha sido renovada con éxito.',
        'tipo' => 'success'
    ],
    [
        'fecha' => '03/08/2025',
        'mensaje' => 'Recuerda completar tu perfil para una mejor experiencia.',
        'tipo' => 'warning'
    ]
];
?>
<div class="container my-4">
    <div class="row">
        <div class="col-12">
            <div class="card dashboard-card">
                <div class="card-header bg-transparent">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-bell me-2"></i>Notificaciones
                    </h5>
                </div>
                <div class="card-body">
                    <ul class="list-group">
                        <?php foreach ($notificaciones as $n): ?>
                            <li class="list-group-item list-group-item-<?php echo $n['tipo']; ?>">
                                <strong><?php echo htmlspecialchars($n['fecha']); ?>:</strong> <?php echo htmlspecialchars($n['mensaje']); ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
