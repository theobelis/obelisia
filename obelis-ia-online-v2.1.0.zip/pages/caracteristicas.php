<div class="container py-5">
    <div class="text-center mb-5">
        <h1 class="display-4 fw-bold">Un Universo de Herramientas</h1>
        <p class="lead text-muted">Descubre todo lo que puedes crear con ObelisIA.</p>
    </div>
    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card text-center h-100">
                <div class="card-body">
                    <div class="feature-icon bg-primary text-white fs-2 mb-3"><i class="fas fa-image"></i></div>
                    <h3 class="h4">Generador de Imágenes</h3>
                    <p class="text-muted">Crea imágenes espectaculares a partir de texto en segundos.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="card text-center h-100">
                <div class="card-body">
                    <div class="feature-icon bg-primary text-white fs-2 mb-3"><i class="fas fa-pen-alt"></i></div>
                    <h3 class="h4">Asistente de Escritura</h3>
                    <p class="text-muted">Redacta artículos, emails y contenido creativo sin esfuerzo.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="card text-center h-100">
                <div class="card-body">
                    <div class="feature-icon bg-primary text-white fs-2 mb-3"><i class="fas fa-music"></i></div>
                    <h3 class="h4">Compositor Musical</h3>
                    <p class="text-muted">Genera pistas de música originales para tus proyectos.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<style>.feature-icon { display: inline-flex; align-items: center; justify-content: center; width: 4rem; height: 4rem; border-radius: 50%; }</style>