<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Asegurar que tenemos acceso a las clases necesarias
if (!isset($auth)) {
    session_start();
    require_once __DIR__ . '/../../vendor/autoload.php';
    require_once __DIR__ . '/../../src/Config/config.php';
    
    $database = new \ObelisIA\Database\Database();
    $db = $database->getConnection();
    $auth = new \ObelisIA\Auth\Auth($db);
}

if ($auth->isLoggedIn()) {
    \ObelisIA\Router\MainRouter::redirect('panel');
}

$error_message = '';
$success_message = '';
$step = 1; // 1 = email, 2 = verificación, 3 = nueva contraseña

// Verificar si hay un token en la URL
$token = $_GET['token'] ?? '';
if (!empty($token)) {
    $step = 3;
}

if ($_POST) {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'request_reset':
                $email = $_POST['email'] ?? '';
                if (empty($email)) {
                    $error_message = "Por favor, ingrese su email.";
                } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $error_message = "Por favor, ingrese un email válido.";
                } else {
                    require_once __DIR__ . '/../../src/Auth/PasswordReset.php';
                    $result = \ObelisIA\Auth\PasswordReset::requestReset($email);
                    if ($result['success']) {
                        $success_message = $result['message'];
                        $step = 2;
                    } else {
                        $error_message = $result['message'];
                    }
                }
                break;
                
            case 'reset_password':
                $token = $_POST['token'] ?? '';
                $password = $_POST['password'] ?? '';
                $confirm_password = $_POST['confirm_password'] ?? '';
                
                if (empty($password) || empty($confirm_password)) {
                    $error_message = "Por favor, complete todos los campos.";
                } elseif (strlen($password) < 6) {
                    $error_message = "La contraseña debe tener al menos 6 caracteres.";
                } elseif ($password !== $confirm_password) {
                    $error_message = "Las contraseñas no coinciden.";
                } else {
                    require_once __DIR__ . '/../../src/Auth/PasswordReset.php';
                    $result = \ObelisIA\Auth\PasswordReset::resetPassword($token, $password);
                    if ($result['success']) {
                        $success_message = $result['message'];
                        // Redirigir al login después de 3 segundos
                        header("refresh:3;url=" . \ObelisIA\Router\MainRouter::url('login'));
                    } else {
                        $error_message = $result['message'];
                    }
                }
                break;
        }
    }
}

$page_title = "Recuperar Contraseña - ObelisIA";
$body_class = "auth-page";
?>

<!-- Password Recovery Section -->
<section class="auth-section">
    <div class="auth-background">
        <div class="auth-grid"></div>
        <div class="auth-gradient"></div>
        <div class="floating-particles"></div>
    </div>
    
    <div class="container position-relative">
        <div class="row justify-content-center min-vh-100 align-items-center py-5">
            <div class="col-md-6 col-lg-5 col-xl-4">
                <div class="auth-card">
                    <!-- Header -->
                    <div class="auth-header">
                        <div class="auth-logo">
                            <div class="logo-icon">
                                <i class="fas fa-brain"></i>
                            </div>
                            <h1>ObelisIA</h1>
                        </div>
                        
                        <?php if ($step == 1): ?>
                            <h2>Recuperar Contraseña</h2>
                            <p>Ingresa tu email para recuperar tu cuenta</p>
                        <?php elseif ($step == 2): ?>
                            <h2>Email Enviado</h2>
                            <p>Revisa tu bandeja de entrada</p>
                        <?php else: ?>
                            <h2>Nueva Contraseña</h2>
                            <p>Crea tu nueva contraseña</p>
                        <?php endif; ?>
                    </div>

                    <!-- Alerts -->
                    <div id="alert-container">
                        <?php if (!empty($error_message)): ?>
                            <div class="alert alert-error">
                                <i class="fas fa-exclamation-circle"></i>
                                <span><?php echo htmlspecialchars($error_message); ?></span>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($success_message)): ?>
                            <div class="alert alert-success">
                                <i class="fas fa-check-circle"></i>
                                <span><?php echo htmlspecialchars($success_message); ?></span>
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php if ($step == 1): ?>
                        <!-- Paso 1: Solicitar recuperación -->
                        <form method="POST" class="auth-form" id="requestResetForm">
                            <input type="hidden" name="action" value="request_reset">
                            
                            <div class="form-group">
                                <label for="email" class="form-label">
                                    <i class="fas fa-envelope"></i>
                                    Email
                                </label>
                                <input type="email" 
                                       id="email" 
                                       name="email" 
                                       class="form-input" 
                                       placeholder="tu@email.com"
                                       autocomplete="email"
                                       required>
                                <div class="form-error" id="emailError"></div>
                                <div class="form-hint">
                                    Te enviaremos un enlace para restablecer tu contraseña
                                </div>
                            </div>

                            <button type="submit" class="btn-auth btn-primary" id="requestBtn">
                                <span class="btn-text">Enviar enlace de recuperación</span>
                                <i class="fas fa-paper-plane btn-icon"></i>
                                <div class="btn-loading">
                                    <i class="fas fa-spinner fa-spin"></i>
                                </div>
                            </button>

                            <div class="auth-divider">
                                <span>¿Recordaste tu contraseña?</span>
                            </div>

                            <a href="<?php echo \ObelisIA\Router\MainRouter::url('login'); ?>" 
                               class="btn-auth btn-outline">
                                <i class="fas fa-sign-in-alt"></i>
                                <span>Volver al login</span>
                            </a>
                        </form>
                        
                    <?php elseif ($step == 2): ?>
                        <!-- Paso 2: Confirmación de envío -->
                        <div class="success-step">
                            <div class="success-icon">
                                <i class="fas fa-envelope-circle-check"></i>
                            </div>
                            <h3>¡Email enviado!</h3>
                            <p class="success-message">
                                Hemos enviado un enlace de recuperación a tu email. 
                                Revisa tu bandeja de entrada y sigue las instrucciones.
                            </p>
                            
                            <div class="verification-notice">
                                <div class="notice-icon">
                                    <i class="fas fa-info-circle"></i>
                                </div>
                                <div class="notice-content">
                                    <h4>Importante</h4>
                                    <p>El enlace expirará en 1 hora. Si no recibes el email, revisa tu carpeta de spam.</p>
                                </div>
                            </div>
                            
                            <div class="verification-actions">
                                <a href="<?php echo \ObelisIA\Router\MainRouter::url('login'); ?>" 
                                   class="btn-auth btn-primary">
                                    <i class="fas fa-sign-in-alt"></i>
                                    <span>Volver al login</span>
                                </a>
                                
                                <button type="button" class="btn-auth btn-outline" onclick="requestNewReset()">
                                    <i class="fas fa-redo"></i>
                                    <span>Enviar otro enlace</span>
                                </button>
                            </div>
                        </div>
                        
                    <?php else: ?>
                        <!-- Paso 3: Restablecer contraseña -->
                        <form method="POST" class="auth-form" id="resetPasswordForm">
                            <input type="hidden" name="action" value="reset_password">
                            <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                            
                            <div class="form-group">
                                <label for="password" class="form-label">
                                    <i class="fas fa-lock"></i>
                                    Nueva contraseña
                                </label>
                                <div class="input-wrapper">
                                    <input type="password" 
                                           id="password" 
                                           name="password" 
                                           class="form-input" 
                                           placeholder="Crea una contraseña segura"
                                           autocomplete="new-password"
                                           required>
                                    <button type="button" class="password-toggle" onclick="togglePassword('password')">
                                        <i class="fas fa-eye" id="passwordToggleIcon"></i>
                                    </button>
                                </div>
                                <div class="password-strength" id="passwordStrength"></div>
                                <div class="form-error" id="passwordError"></div>
                            </div>

                            <div class="form-group">
                                <label for="confirm_password" class="form-label">
                                    <i class="fas fa-lock"></i>
                                    Confirmar contraseña
                                </label>
                                <div class="input-wrapper">
                                    <input type="password" 
                                           id="confirm_password" 
                                           name="confirm_password" 
                                           class="form-input" 
                                           placeholder="Repite tu nueva contraseña"
                                           autocomplete="new-password"
                                           required>
                                    <button type="button" class="password-toggle" onclick="togglePassword('confirm_password')">
                                        <i class="fas fa-eye" id="confirmPasswordToggleIcon"></i>
                                    </button>
                                </div>
                                <div class="password-match" id="passwordMatch"></div>
                                <div class="form-error" id="confirmPasswordError"></div>
                            </div>

                            <button type="submit" class="btn-auth btn-primary" id="resetBtn">
                                <span class="btn-text">Cambiar contraseña</span>
                                <i class="fas fa-key btn-icon"></i>
                                <div class="btn-loading">
                                    <i class="fas fa-spinner fa-spin"></i>
                                </div>
                            </button>

                            <div class="auth-divider">
                                <span>¿Recordaste tu contraseña?</span>
                            </div>

                            <a href="<?php echo \ObelisIA\Router\MainRouter::url('login'); ?>" 
                               class="btn-auth btn-outline">
                                <i class="fas fa-sign-in-alt"></i>
                                <span>Ir al login</span>
                            </a>
                        </form>
                    <?php endif; ?>

                    <!-- Footer -->
                    <div class="auth-footer">
                        <a href="<?php echo \ObelisIA\Router\MainRouter::url('inicio'); ?>" class="back-home">
                            <i class="fas fa-home"></i>
                            <span>Volver al inicio</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<style>
/* Password Recovery Page Styles */
.auth-page {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    overflow-x: hidden;
}

/* Auth Section */
.auth-section {
    min-height: 100vh;
    position: relative;
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
    color: #f8fafc;
}

.auth-background {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 1;
}

.auth-grid {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-image: 
        linear-gradient(rgba(59, 130, 246, 0.1) 1px, transparent 1px),
        linear-gradient(90deg, rgba(59, 130, 246, 0.1) 1px, transparent 1px);
    background-size: 50px 50px;
    animation: gridMove 20s linear infinite;
}

@keyframes gridMove {
    0% { transform: translate(0, 0); }
    100% { transform: translate(50px, 50px); }
}

.auth-gradient {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: radial-gradient(circle at 30% 20%, rgba(59, 130, 246, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 70% 80%, rgba(139, 92, 246, 0.1) 0%, transparent 50%);
}

.floating-particles::before,
.floating-particles::after {
    content: '';
    position: absolute;
    width: 400px;
    height: 400px;
    border-radius: 50%;
    filter: blur(100px);
    animation: float 20s ease-in-out infinite;
}

.floating-particles::before {
    background: rgba(59, 130, 246, 0.1);
    top: 10%;
    left: 10%;
    animation-delay: 0s;
}

.floating-particles::after {
    background: rgba(139, 92, 246, 0.1);
    bottom: 10%;
    right: 10%;
    animation-delay: 10s;
}

@keyframes float {
    0%, 100% { transform: translateY(0px) scale(1); }
    50% { transform: translateY(-20px) scale(1.1); }
}

/* Auth Card */
.auth-card {
    background: rgba(30, 41, 59, 0.9);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(71, 85, 105, 0.3);
    border-radius: 24px;
    padding: 3rem 2.5rem;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.4);
    position: relative;
    z-index: 10;
    overflow: hidden;
}

.auth-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #3b82f6, #8b5cf6);
    border-radius: 24px 24px 0 0;
}

/* Header */
.auth-header {
    text-align: center;
    margin-bottom: 2.5rem;
}

.auth-logo {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 1rem;
    margin-bottom: 1.5rem;
}

.logo-icon {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, #3b82f6, #8b5cf6);
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 8px 32px rgba(59, 130, 246, 0.3);
}

.logo-icon i {
    font-size: 1.8rem;
    color: white;
}

.auth-logo h1 {
    font-size: 2rem;
    font-weight: 700;
    margin: 0;
    background: linear-gradient(135deg, #3b82f6, #8b5cf6);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.auth-header h2 {
    font-size: 1.5rem;
    font-weight: 600;
    margin: 0 0 0.5rem 0;
    color: #f8fafc;
}

.auth-header p {
    color: #94a3b8;
    margin: 0;
    font-size: 0.95rem;
}

/* Form Styles */
.auth-form {
    margin-bottom: 2rem;
}

.form-group {
    margin-bottom: 1.5rem;
    position: relative;
}

.form-label {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.9rem;
    font-weight: 500;
    color: #cbd5e1;
    margin-bottom: 0.5rem;
}

.form-label i {
    color: #6366f1;
}

.input-wrapper {
    position: relative;
}

.form-input {
    width: 100%;
    padding: 1rem 1.25rem;
    background: rgba(15, 23, 42, 0.5);
    border: 1px solid rgba(71, 85, 105, 0.5);
    border-radius: 12px;
    color: #f8fafc;
    font-size: 1rem;
    transition: all 0.3s ease;
}

.form-input:focus {
    outline: none;
    border-color: #6366f1;
    box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
    background: rgba(15, 23, 42, 0.7);
}

.form-input::placeholder {
    color: #64748b;
}

.form-input.success {
    border-color: #10b981;
}

.form-input.error {
    border-color: #ef4444;
}

.password-toggle {
    position: absolute;
    right: 1rem;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    color: #64748b;
    cursor: pointer;
    padding: 0.25rem;
    border-radius: 4px;
    transition: color 0.3s ease;
}

.password-toggle:hover {
    color: #6366f1;
}

.form-hint {
    font-size: 0.8rem;
    color: #64748b;
    margin-top: 0.5rem;
}

.password-strength,
.password-match {
    font-size: 0.85rem;
    margin-top: 0.5rem;
    font-weight: 500;
}

.password-strength.weak {
    color: #ef4444;
}

.password-strength.medium {
    color: #f59e0b;
}

.password-strength.strong {
    color: #10b981;
}

.password-match.match {
    color: #10b981;
}

.password-match.no-match {
    color: #ef4444;
}

/* Buttons */
.btn-auth {
    width: 100%;
    padding: 1rem 1.5rem;
    border-radius: 12px;
    border: none;
    font-weight: 600;
    font-size: 1rem;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    text-decoration: none;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
    cursor: pointer;
}

.btn-auth.btn-primary {
    background: linear-gradient(135deg, #3b82f6, #6366f1);
    color: white;
    box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3);
}

.btn-auth.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(59, 130, 246, 0.4);
}

.btn-auth.btn-outline {
    background: transparent;
    color: #cbd5e1;
    border: 1px solid rgba(71, 85, 105, 0.5);
}

.btn-auth.btn-outline:hover {
    background: rgba(59, 130, 246, 0.1);
    border-color: #6366f1;
    color: #6366f1;
}

.btn-loading {
    position: absolute;
    right: 1rem;
    display: none;
}

/* Success Step */
.success-step {
    text-align: center;
    padding: 2rem 0;
}

.success-icon {
    width: 100px;
    height: 100px;
    background: linear-gradient(135deg, #10b981, #059669);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 2rem;
    box-shadow: 0 10px 30px rgba(16, 185, 129, 0.3);
}

.success-icon i {
    font-size: 3rem;
    color: white;
}

.success-step h3 {
    font-size: 1.5rem;
    font-weight: 600;
    color: #f8fafc;
    margin-bottom: 1rem;
}

.success-message {
    color: #94a3b8;
    margin-bottom: 2rem;
    line-height: 1.6;
}

.verification-notice {
    background: rgba(59, 130, 246, 0.1);
    border: 1px solid rgba(59, 130, 246, 0.2);
    border-radius: 12px;
    padding: 1.5rem;
    margin-bottom: 2rem;
    display: flex;
    gap: 1rem;
    text-align: left;
}

.notice-icon {
    color: #6366f1;
    font-size: 1.25rem;
    flex-shrink: 0;
}

.notice-content h4 {
    font-size: 1rem;
    font-weight: 600;
    color: #f8fafc;
    margin: 0 0 0.5rem 0;
}

.notice-content p {
    font-size: 0.9rem;
    color: #94a3b8;
    margin: 0;
    line-height: 1.5;
}

.verification-actions {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

/* Alerts */
.alert {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 1rem 1.25rem;
    border-radius: 12px;
    margin-bottom: 1.5rem;
    font-size: 0.9rem;
    font-weight: 500;
}

.alert-error {
    background: rgba(239, 68, 68, 0.1);
    border: 1px solid rgba(239, 68, 68, 0.2);
    color: #fca5a5;
}

.alert-success {
    background: rgba(16, 185, 129, 0.1);
    border: 1px solid rgba(16, 185, 129, 0.2);
    color: #6ee7b7;
}

.form-error {
    color: #f87171;
    font-size: 0.85rem;
    margin-top: 0.5rem;
    display: none;
}

/* Divider */
.auth-divider {
    text-align: center;
    margin: 2rem 0;
    position: relative;
}

.auth-divider::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    height: 1px;
    background: rgba(71, 85, 105, 0.3);
}

.auth-divider span {
    background: rgba(30, 41, 59, 0.9);
    padding: 0 1rem;
    color: #64748b;
    font-size: 0.9rem;
}

/* Footer */
.auth-footer {
    text-align: center;
    padding-top: 2rem;
    border-top: 1px solid rgba(71, 85, 105, 0.3);
}

.back-home {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    color: #64748b;
    text-decoration: none;
    font-size: 0.9rem;
    padding: 0.5rem 1rem;
    border-radius: 8px;
    transition: all 0.3s ease;
}

.back-home:hover {
    color: #6366f1;
    background: rgba(99, 102, 241, 0.1);
}

/* Responsive */
@media (max-width: 768px) {
    .auth-card {
        margin: 1rem;
        padding: 2rem 1.5rem;
    }
    
    .auth-logo h1 {
        font-size: 1.5rem;
    }
    
    .verification-actions {
        gap: 0.75rem;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirm_password');
    
    // Verificar fortaleza de contraseña
    if (passwordInput) {
        passwordInput.addEventListener('input', function() {
            checkPasswordStrength(this.value);
            if (confirmPasswordInput && confirmPasswordInput.value) {
                checkPasswordMatch(this.value, confirmPasswordInput.value);
            }
        });
    }
    
    if (confirmPasswordInput) {
        confirmPasswordInput.addEventListener('input', function() {
            if (passwordInput && passwordInput.value) {
                checkPasswordMatch(passwordInput.value, this.value);
            }
        });
    }
    
    // Validación de formularios
    const requestForm = document.getElementById('requestResetForm');
    if (requestForm) {
        requestForm.addEventListener('submit', function(e) {
            const email = document.getElementById('email').value;
            if (!email || !isValidEmail(email)) {
                e.preventDefault();
                showFieldError('emailError', 'Por favor, ingrese un email válido');
                return;
            }
            
            const requestBtn = document.getElementById('requestBtn');
            const btnText = requestBtn.querySelector('.btn-text');
            const btnLoading = requestBtn.querySelector('.btn-loading');
            
            requestBtn.disabled = true;
            btnText.style.opacity = '0.7';
            btnLoading.style.display = 'block';
        });
    }
    
    const resetForm = document.getElementById('resetPasswordForm');
    if (resetForm) {
        resetForm.addEventListener('submit', function(e) {
            if (!validatePasswordForm()) {
                e.preventDefault();
                return;
            }
            
            const resetBtn = document.getElementById('resetBtn');
            const btnText = resetBtn.querySelector('.btn-text');
            const btnLoading = resetBtn.querySelector('.btn-loading');
            
            resetBtn.disabled = true;
            btnText.style.opacity = '0.7';
            btnLoading.style.display = 'block';
        });
    }
});

function checkPasswordStrength(password) {
    const strengthDiv = document.getElementById('passwordStrength');
    if (!strengthDiv) return;
    
    let strength = 0;
    let message = '';
    
    if (password.length >= 6) strength++;
    if (password.match(/[a-z]/)) strength++;
    if (password.match(/[A-Z]/)) strength++;
    if (password.match(/[0-9]/)) strength++;
    if (password.match(/[^a-zA-Z0-9]/)) strength++;
    
    strengthDiv.className = 'password-strength';
    
    if (strength <= 2) {
        strengthDiv.className += ' weak';
        message = '🔴 Débil';
    } else if (strength <= 3) {
        strengthDiv.className += ' medium';
        message = '🟡 Media';
    } else {
        strengthDiv.className += ' strong';
        message = '🟢 Fuerte';
    }
    
    strengthDiv.textContent = 'Seguridad: ' + message;
}

function checkPasswordMatch(password, confirmPassword) {
    const matchDiv = document.getElementById('passwordMatch');
    if (!matchDiv) return;
    
    const confirmInput = document.getElementById('confirm_password');
    
    matchDiv.className = 'password-match';
    
    if (password === confirmPassword) {
        matchDiv.className += ' match';
        matchDiv.textContent = '✅ Las contraseñas coinciden';
        confirmInput.classList.remove('error');
        confirmInput.classList.add('success');
    } else {
        matchDiv.className += ' no-match';
        matchDiv.textContent = '❌ Las contraseñas no coinciden';
        confirmInput.classList.remove('success');
        confirmInput.classList.add('error');
    }
}

function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const iconId = inputId === 'password' ? 'passwordToggleIcon' : 'confirmPasswordToggleIcon';
    const icon = document.getElementById(iconId);
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'fas fa-eye-slash';
    } else {
        input.type = 'password';
        icon.className = 'fas fa-eye';
    }
}

function validatePasswordForm() {
    let isValid = true;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm_password').value;
    
    if (!password) {
        showFieldError('passwordError', 'La contraseña es obligatoria');
        isValid = false;
    } else if (password.length < 6) {
        showFieldError('passwordError', 'La contraseña debe tener al menos 6 caracteres');
        isValid = false;
    }
    
    if (!confirmPassword) {
        showFieldError('confirmPasswordError', 'Confirme su contraseña');
        isValid = false;
    } else if (password !== confirmPassword) {
        showFieldError('confirmPasswordError', 'Las contraseñas no coinciden');
        isValid = false;
    }
    
    return isValid;
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function showFieldError(errorId, message) {
    const errorElement = document.getElementById(errorId);
    if (errorElement) {
        errorElement.textContent = message;
        errorElement.style.display = 'block';
    }
}

function requestNewReset() {
    // Recargar la página para volver al paso 1
    window.location.href = window.location.pathname;
}
</script>
