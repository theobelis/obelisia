<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Asegurar que tenemos acceso a las clases necesarias
if (!isset($auth)) {
    session_start();
    require_once __DIR__ . '/../../vendor/autoload.php';
    require_once __DIR__ . '/../../src/Config/config.php';
    
    $database = new \ObelisIA\Database\Database();
    $db = $database->getConnection();
    $auth = new \ObelisIA\Auth\Auth($db);
}

if ($auth->isLoggedIn()) {
    \ObelisIA\Router\MainRouter::redirect('panel');
}

$error_message = '';
$success_message = '';
$step = 1; // Paso del login: 1 = usuario/email, 2 = contraseña
$user_info = null;

// Manejar AJAX para verificar usuario
if (isset($_POST['action']) && $_POST['action'] === 'check_user') {
    // Desactivar visualización de errores para AJAX
    ini_set('display_errors', 0);
    
    // Limpiar cualquier salida previa
    if (ob_get_length()) ob_clean();
    
    header('Content-Type: application/json');
    $username = $_POST['username'] ?? '';
    
    if (empty($username)) {
        echo json_encode(['success' => false, 'message' => 'Por favor, ingrese su usuario o email']);
        exit;
    }
    
    try {
        require_once __DIR__ . '/../../src/Auth/Login.php';
        $result = \ObelisIA\Auth\Login::checkUserExists($username);
        echo json_encode($result);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error de conexión: ' . $e->getMessage()]);
    }
    exit;
}

// Manejar login final
if ($_POST && !isset($_POST['action'])) {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error_message = "Por favor, complete todos los campos.";
    } else {
        require_once __DIR__ . '/../../src/Auth/Login.php';
        $result = \ObelisIA\Auth\Login::loginUser($username, $password);
        if ($result['success']) {
            $_SESSION['user_id'] = $result['user']['id'];
            $_SESSION['email'] = $result['user']['email'];
            $_SESSION['full_name'] = $result['user']['full_name'];
            $_SESSION['username'] = $result['user']['username'];
            $_SESSION['role'] = $result['user']['role'] ?? 'user';
            \ObelisIA\Router\MainRouter::redirect('panel');
        } else {
            $error_message = $result['message'];
            unset($_SESSION['user_id'], $_SESSION['email'], $_SESSION['full_name'], $_SESSION['username']);
        }
    }
}

$page_title = "Iniciar Sesión - ObelisIA";
$body_class = "auth-page";
?>

<!-- Login Section -->
<section class="auth-section">
    <div class="auth-background">
        <div class="auth-grid"></div>
        <div class="auth-gradient"></div>
        <div class="floating-particles"></div>
    </div>
    
    <div class="container position-relative">
        <div class="row justify-content-center min-vh-100 align-items-center">
            <div class="col-md-6 col-lg-5 col-xl-4">
                <div class="auth-card">
                    <!-- Header -->
                    <div class="auth-header">
                        <div class="auth-logo">
                            <div class="logo-icon">
                                <i class="fas fa-brain"></i>
                            </div>
                            <h1>ObelisIA</h1>
                        </div>
                        <h2>Bienvenido de vuelta</h2>
                        <p>Accede a tu suite de herramientas de IA</p>
                    </div>

                    <!-- Alerts -->
                    <div id="alert-container">
                        <?php if (!empty($error_message)): ?>
                            <div class="alert alert-error">
                                <i class="fas fa-exclamation-circle"></i>
                                <span><?php echo is_string($error_message) ? htmlspecialchars($error_message) : $error_message; ?></span>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($success_message)): ?>
                            <div class="alert alert-success">
                                <i class="fas fa-check-circle"></i>
                                <span><?php echo htmlspecialchars($success_message); ?></span>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Paso 1: Usuario/Email -->
                    <div id="step1" class="auth-step active">
                        <form id="userForm" class="auth-form">
                            <div class="form-group">
                                <label for="username" class="form-label">
                                    <i class="fas fa-user"></i>
                                    Usuario o Email
                                </label>
                                <input type="text" 
                                       id="username" 
                                       name="username" 
                                       class="form-input" 
                                       placeholder="Ingresa tu usuario o email"
                                       autocomplete="username"
                                       required>
                                <div class="input-loading" id="userSpinner">
                                    <i class="fas fa-spinner fa-spin"></i>
                                </div>
                                <div class="form-error" id="usernameError"></div>
                            </div>

                            <button type="submit" class="btn-auth btn-primary" id="continueBtn">
                                <span class="btn-text">Continuar</span>
                                <i class="fas fa-arrow-right btn-icon"></i>
                            </button>

                            <div class="auth-divider">
                                <span>¿No tienes cuenta?</span>
                            </div>

                            <a href="<?php echo \ObelisIA\Router\MainRouter::url('registro'); ?>" 
                               class="btn-auth btn-outline">
                                <i class="fas fa-user-plus"></i>
                                <span>Crear cuenta nueva</span>
                            </a>
                        </form>
                    </div>

                    <!-- Paso 2: Contraseña -->
                    <div id="step2" class="auth-step">
                        <div class="user-preview" id="userPreview">
                            <button type="button" class="back-btn" onclick="goBackToStep1()">
                                <i class="fas fa-arrow-left"></i>
                            </button>
                            <div class="user-avatar">
                                <img id="userAvatar" src="" alt="Avatar" class="avatar-img">
                                <div class="avatar-placeholder" id="avatarPlaceholder">
                                    <i class="fas fa-user"></i>
                                </div>
                            </div>
                            <div class="user-info">
                                <h6 id="userDisplayName"></h6>
                                <p id="userEmail"></p>
                            </div>
                        </div>

                        <form method="POST" class="auth-form" id="passwordForm">
                            <input type="hidden" name="username" id="hiddenUsername">
                            
                            <div class="form-group">
                                <label for="password" class="form-label">
                                    <i class="fas fa-lock"></i>
                                    Contraseña
                                </label>
                                <div class="input-wrapper">
                                    <input type="password" 
                                           id="password" 
                                           name="password" 
                                           class="form-input" 
                                           placeholder="Ingresa tu contraseña"
                                           autocomplete="current-password"
                                           required>
                                    <button type="button" class="password-toggle" onclick="togglePassword('password')">
                                        <i class="fas fa-eye" id="passwordToggleIcon"></i>
                                    </button>
                                </div>
                                <div class="form-error" id="passwordError"></div>
                            </div>

                            <div class="forgot-password">
                                <a href="<?php echo \ObelisIA\Router\MainRouter::url('recuperar-password'); ?>" 
                                   class="forgot-link">
                                    ¿Olvidaste tu contraseña?
                                </a>
                            </div>

                            <button type="submit" class="btn-auth btn-primary" id="loginBtn">
                                <span class="btn-text">Iniciar sesión</span>
                                <i class="fas fa-sign-in-alt btn-icon"></i>
                                <div class="btn-loading">
                                    <i class="fas fa-spinner fa-spin"></i>
                                </div>
                            </button>
                        </form>
                    </div>

                    <!-- Footer -->
                    <div class="auth-footer">
                        <a href="<?php echo \ObelisIA\Router\MainRouter::url('inicio'); ?>" class="back-home">
                            <i class="fas fa-home"></i>
                            <span>Volver al inicio</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
/* Auth Page Styles - Inspired by ObelisIA theme */
.auth-page {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    overflow-x: hidden;
}

/* Auth Section */
.auth-section {
    min-height: 100vh;
    position: relative;
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
    color: #f8fafc;
}

.auth-background {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 1;
}

.auth-grid {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-image: 
        linear-gradient(rgba(59, 130, 246, 0.1) 1px, transparent 1px),
        linear-gradient(90deg, rgba(59, 130, 246, 0.1) 1px, transparent 1px);
    background-size: 50px 50px;
    animation: gridMove 20s linear infinite;
}

@keyframes gridMove {
    0% { transform: translate(0, 0); }
    100% { transform: translate(50px, 50px); }
}

.auth-gradient {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: radial-gradient(circle at 30% 20%, rgba(59, 130, 246, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 70% 80%, rgba(139, 92, 246, 0.1) 0%, transparent 50%);
}

.floating-particles::before,
.floating-particles::after {
    content: '';
    position: absolute;
    width: 400px;
    height: 400px;
    border-radius: 50%;
    filter: blur(100px);
    animation: float 20s ease-in-out infinite;
}

.floating-particles::before {
    background: rgba(59, 130, 246, 0.1);
    top: 10%;
    left: 10%;
    animation-delay: 0s;
}

.floating-particles::after {
    background: rgba(139, 92, 246, 0.1);
    bottom: 10%;
    right: 10%;
    animation-delay: 10s;
}

@keyframes float {
    0%, 100% { transform: translateY(0px) scale(1); }
    50% { transform: translateY(-20px) scale(1.1); }
}

/* Auth Card */
.auth-card {
    background: rgba(30, 41, 59, 0.9);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(71, 85, 105, 0.3);
    border-radius: 24px;
    padding: 3rem 2.5rem;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.4);
    position: relative;
    z-index: 10;
    overflow: hidden;
}

.auth-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #3b82f6, #8b5cf6);
    border-radius: 24px 24px 0 0;
}

/* Header */
.auth-header {
    text-align: center;
    margin-bottom: 2.5rem;
}

.auth-logo {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 1rem;
    margin-bottom: 1.5rem;
}

.logo-icon {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, #3b82f6, #8b5cf6);
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 8px 32px rgba(59, 130, 246, 0.3);
}

.logo-icon i {
    font-size: 1.8rem;
    color: white;
}

.auth-logo h1 {
    font-size: 2rem;
    font-weight: 700;
    margin: 0;
    background: linear-gradient(135deg, #3b82f6, #8b5cf6);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.auth-header h2 {
    font-size: 1.5rem;
    font-weight: 600;
    margin: 0 0 0.5rem 0;
    color: #f8fafc;
}

.auth-header p {
    color: #94a3b8;
    margin: 0;
    font-size: 0.95rem;
}

/* Form Styles */
.auth-step {
    display: none;
}

.auth-step.active {
    display: block;
}

.auth-form {
    margin-bottom: 2rem;
}

.form-group {
    margin-bottom: 1.5rem;
    position: relative;
}

.form-label {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.9rem;
    font-weight: 500;
    color: #cbd5e1;
    margin-bottom: 0.5rem;
}

.form-label i {
    color: #6366f1;
}

.input-wrapper {
    position: relative;
}

.form-input {
    width: 100%;
    padding: 1rem 1.25rem;
    background: rgba(15, 23, 42, 0.5);
    border: 1px solid rgba(71, 85, 105, 0.5);
    border-radius: 12px;
    color: #f8fafc;
    font-size: 1rem;
    transition: all 0.3s ease;
}

.form-input:focus {
    outline: none;
    border-color: #6366f1;
    box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
    background: rgba(15, 23, 42, 0.7);
}

.form-input::placeholder {
    color: #64748b;
}

.password-toggle {
    position: absolute;
    right: 1rem;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    color: #64748b;
    cursor: pointer;
    padding: 0.25rem;
    border-radius: 4px;
    transition: color 0.3s ease;
}

.password-toggle:hover {
    color: #6366f1;
}

.input-loading {
    position: absolute;
    right: 1rem;
    top: 50%;
    transform: translateY(-50%);
    color: #6366f1;
    display: none;
}

/* Buttons */
.btn-auth {
    width: 100%;
    padding: 1rem 1.5rem;
    border-radius: 12px;
    border: none;
    font-weight: 600;
    font-size: 1rem;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    text-decoration: none;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
    cursor: pointer;
}

.btn-auth.btn-primary {
    background: linear-gradient(135deg, #3b82f6, #6366f1);
    color: white;
    box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3);
}

.btn-auth.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(59, 130, 246, 0.4);
}

.btn-auth.btn-outline {
    background: transparent;
    color: #cbd5e1;
    border: 1px solid rgba(71, 85, 105, 0.5);
}

.btn-auth.btn-outline:hover {
    background: rgba(59, 130, 246, 0.1);
    border-color: #6366f1;
    color: #6366f1;
}

.btn-loading {
    position: absolute;
    right: 1rem;
    display: none;
}

/* User Preview */
.user-preview {
    background: rgba(15, 23, 42, 0.5);
    border: 1px solid rgba(71, 85, 105, 0.3);
    border-radius: 16px;
    padding: 1.5rem;
    margin-bottom: 1.5rem;
    display: none;
    align-items: center;
    gap: 1rem;
    position: relative;
}

.back-btn {
    position: absolute;
    top: 0.75rem;
    left: 0.75rem;
    background: rgba(71, 85, 105, 0.5);
    border: none;
    color: #cbd5e1;
    width: 32px;
    height: 32px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
}

.back-btn:hover {
    background: rgba(99, 102, 241, 0.2);
    color: #6366f1;
}

.user-avatar {
    position: relative;
}

.avatar-img,
.avatar-placeholder {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    border: 3px solid rgba(71, 85, 105, 0.3);
}

.avatar-placeholder {
    background: linear-gradient(135deg, #3b82f6, #6366f1);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.5rem;
}

.user-info h6 {
    margin: 0 0 0.25rem 0;
    font-weight: 600;
    color: #f8fafc;
}

.user-info p {
    margin: 0;
    font-size: 0.9rem;
    color: #94a3b8;
}

/* Alerts */
.alert {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 1rem 1.25rem;
    border-radius: 12px;
    margin-bottom: 1.5rem;
    font-size: 0.9rem;
    font-weight: 500;
}

.alert-error {
    background: rgba(239, 68, 68, 0.1);
    border: 1px solid rgba(239, 68, 68, 0.2);
    color: #fca5a5;
}

.alert-success {
    background: rgba(16, 185, 129, 0.1);
    border: 1px solid rgba(16, 185, 129, 0.2);
    color: #6ee7b7;
}

.form-error {
    color: #f87171;
    font-size: 0.85rem;
    margin-top: 0.5rem;
    display: none;
}

/* Divider */
.auth-divider {
    text-align: center;
    margin: 2rem 0;
    position: relative;
}

.auth-divider::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    height: 1px;
    background: rgba(71, 85, 105, 0.3);
}

.auth-divider span {
    background: rgba(30, 41, 59, 0.9);
    padding: 0 1rem;
    color: #64748b;
    font-size: 0.9rem;
}

/* Footer */
.auth-footer {
    text-align: center;
    padding-top: 2rem;
    border-top: 1px solid rgba(71, 85, 105, 0.3);
}

.back-home {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    color: #64748b;
    text-decoration: none;
    font-size: 0.9rem;
    padding: 0.5rem 1rem;
    border-radius: 8px;
    transition: all 0.3s ease;
}

.back-home:hover {
    color: #6366f1;
    background: rgba(99, 102, 241, 0.1);
}

.forgot-password {
    text-align: right;
    margin-bottom: 1.5rem;
}

.forgot-link {
    color: #6366f1;
    text-decoration: none;
    font-size: 0.9rem;
    font-weight: 500;
}

.forgot-link:hover {
    text-decoration: underline;
}

/* Responsive */
@media (max-width: 768px) {
    .auth-card {
        margin: 1rem;
        padding: 2rem 1.5rem;
    }
    
    .auth-logo h1 {
        font-size: 1.5rem;
    }
}
</style>

<script>
let currentStep = 1;
let userInfo = null;

document.addEventListener('DOMContentLoaded', function() {
    const userForm = document.getElementById('userForm');
    const usernameInput = document.getElementById('username');
    const continueBtn = document.getElementById('continueBtn');
    const userSpinner = document.getElementById('userSpinner');
    
    userForm.addEventListener('submit', function(e) {
        e.preventDefault();
        checkUser();
    });
    
    usernameInput.addEventListener('input', function() {
        clearErrors();
    });
});

async function checkUser() {
    const username = document.getElementById('username').value.trim();
    const continueBtn = document.getElementById('continueBtn');
    const userSpinner = document.getElementById('userSpinner');
    const usernameError = document.getElementById('usernameError');
    
    if (!username) {
        showError('usernameError', 'Por favor, ingrese su usuario o email');
        return;
    }
    
    // Mostrar loading
    continueBtn.disabled = true;
    userSpinner.style.display = 'block';
    clearErrors();
    
    try {
        const formData = new FormData();
        formData.append('action', 'check_user');
        formData.append('username', username);
        
        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData
        });
        
        // Verificar si la respuesta es válida
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const text = await response.text();
        console.log('Respuesta del servidor:', text);
        
        let result;
        try {
            result = JSON.parse(text);
        } catch (parseError) {
            console.error('Error parsing JSON:', parseError);
            console.error('Texto recibido:', text);
            throw new Error('Respuesta inválida del servidor');
        }
        
        if (result.success) {
            userInfo = result.user;
            showStep2();
        } else {
            showError('usernameError', result.message);
        }
    } catch (error) {
        console.error('Error en checkUser:', error);
        showError('usernameError', 'Error de conexión. Por favor, inténtelo de nuevo.');
    } finally {
        continueBtn.disabled = false;
        userSpinner.style.display = 'none';
    }
}

function showStep2() {
    document.getElementById('step1').classList.remove('active');
    document.getElementById('step2').classList.add('active');
    
    // Mostrar información del usuario
    const userPreview = document.getElementById('userPreview');
    const userAvatar = document.getElementById('userAvatar');
    const avatarPlaceholder = document.getElementById('avatarPlaceholder');
    const userDisplayName = document.getElementById('userDisplayName');
    const userEmail = document.getElementById('userEmail');
    const hiddenUsername = document.getElementById('hiddenUsername');
    
    userDisplayName.textContent = userInfo.full_name || userInfo.username;
    userEmail.textContent = userInfo.email;
    hiddenUsername.value = userInfo.username;
    
    if (userInfo.profile_image) {
        userAvatar.src = userInfo.profile_image;
        userAvatar.style.display = 'block';
        avatarPlaceholder.style.display = 'none';
    } else {
        userAvatar.style.display = 'none';
        avatarPlaceholder.style.display = 'flex';
    }
    
    userPreview.style.display = 'flex';
    document.getElementById('password').focus();
    currentStep = 2;
}

function goBackToStep1() {
    document.getElementById('step2').classList.remove('active');
    document.getElementById('step1').classList.add('active');
    document.getElementById('username').focus();
    currentStep = 1;
    clearErrors();
}

function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const icon = document.getElementById('passwordToggleIcon');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'fas fa-eye-slash';
    } else {
        input.type = 'password';
        icon.className = 'fas fa-eye';
    }
}

function showError(elementId, message) {
    const errorElement = document.getElementById(elementId);
    errorElement.textContent = message;
    errorElement.style.display = 'block';
}

function clearErrors() {
    const errors = document.querySelectorAll('.form-error');
    errors.forEach(error => {
        error.style.display = 'none';
        error.textContent = '';
    });
}

// Manejar envío del formulario de contraseña
document.getElementById('passwordForm').addEventListener('submit', function(e) {
    const loginBtn = document.getElementById('loginBtn');
    const btnText = loginBtn.querySelector('.btn-text');
    const btnLoading = loginBtn.querySelector('.btn-loading');
    
    loginBtn.disabled = true;
    btnText.style.opacity = '0.7';
    btnLoading.style.display = 'block';
});
</script>