
<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Asegurar que tenemos acceso a las clases necesarias
if (!isset($auth)) {
    session_start();
    require_once __DIR__ . '/../../vendor/autoload.php';
    require_once __DIR__ . '/../../src/Config/config.php';
    
    $database = new \ObelisIA\Database\Database();
    $db = $database->getConnection();
    $auth = new \ObelisIA\Auth\Auth($db);
}

// Si ya está logueado, redirigir al dashboard
if ($auth->isLoggedIn()) {
    \ObelisIA\Router\MainRouter::redirect('panel');
}

$error_message = '';
$success_message = '';
$step = 1; // Pasos del registro: 1 = datos básicos, 2 = verificación email

if ($_POST) {
    if (isset($_POST['action']) && $_POST['action'] === 'check_availability') {
        // AJAX para verificar disponibilidad
        header('Content-Type: application/json');
        $type = $_POST['type'] ?? '';
        $value = $_POST['value'] ?? '';
        
        require_once __DIR__ . '/../../src/Auth/Register.php';
        $result = \ObelisIA\Auth\Register::checkAvailability($type, $value);
        echo json_encode($result);
        exit;
    }
    
    // Procesamiento del registro
    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $full_name = $_POST['full_name'] ?? '';
    $terms_accepted = isset($_POST['terms_accepted']);
    
    if (empty($username) || empty($email) || empty($password) || empty($confirm_password) || empty($full_name)) {
        $error_message = "Por favor, complete todos los campos.";
    } elseif (!$terms_accepted) {
        $error_message = "Debe aceptar los términos y condiciones.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Por favor, ingrese un email válido.";
    } elseif (strlen($password) < 6) {
        $error_message = "La contraseña debe tener al menos 6 caracteres.";
    } elseif ($password !== $confirm_password) {
        $error_message = "Las contraseñas no coinciden.";
    } else {
        require_once __DIR__ . '/../../src/Auth/Register.php';
        $site_url = SITE_URL;
        $result = \ObelisIA\Auth\Register::registerUser($username, $email, $password, $full_name, $site_url);
        if ($result['success']) {
            $success_message = $result['message'];
            $step = 2;
            
            // Crear notificación automática para el admin cuando se registra un usuario
            try {
                require_once __DIR__ . '/../../admin/includes/functions.php';
                notifyNewUserRegistration($result['user_id'] ?? 0, $username, $email);
            } catch (Exception $e) {
                // Log error but don't break the registration process
                error_log("Error creating admin notification: " . $e->getMessage());
            }
        } else {
            $error_message = $result['message'];
        }
    }
}

$page_title = "Crear Cuenta - ObelisIA";
$body_class = "auth-page";
?>

<!-- Register Section -->
<section class="auth-section">
    <div class="auth-background">
        <div class="auth-grid"></div>
        <div class="auth-gradient"></div>
        <div class="floating-particles"></div>
    </div>
    
    <div class="container position-relative">
        <div class="row justify-content-center min-vh-100 align-items-center py-5">
            <div class="col-md-6 col-lg-5 col-xl-4">
                <div class="auth-card">
                    <!-- Header -->
                    <div class="auth-header">
                        <div class="auth-logo">
                            <div class="logo-icon">
                                <i class="fas fa-brain"></i>
                            </div>
                            <h1>ObelisIA</h1>
                        </div>
                        
                        <?php if ($step == 1): ?>
                            <h2>Únete a ObelisIA</h2>
                            <p>Crea tu cuenta y descubre el poder de la IA</p>
                        <?php else: ?>
                            <h2>¡Cuenta creada!</h2>
                            <p>Verifica tu email para comenzar</p>
                        <?php endif; ?>
                    </div>

                    <!-- Alerts -->
                    <div id="alert-container">
                        <?php if (!empty($error_message)): ?>
                            <div class="alert alert-error">
                                <i class="fas fa-exclamation-circle"></i>
                                <span><?php echo htmlspecialchars($error_message); ?></span>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($success_message)): ?>
                            <div class="alert alert-success">
                                <i class="fas fa-check-circle"></i>
                                <span><?php echo htmlspecialchars($success_message); ?></span>
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php if ($step == 1): ?>
                        <!-- Paso 1: Formulario de registro -->
                        <form method="POST" class="auth-form" id="registerForm">
                            <div class="form-group">
                                <label for="full_name" class="form-label">
                                    <i class="fas fa-user"></i>
                                    Nombre completo
                                </label>
                                <input type="text" 
                                       id="full_name" 
                                       name="full_name" 
                                       class="form-input" 
                                       placeholder="Tu nombre completo"
                                       autocomplete="name"
                                       value="<?php echo htmlspecialchars($full_name ?? ''); ?>"
                                       required>
                                <div class="form-error" id="fullNameError"></div>
                            </div>

                            <div class="form-group">
                                <label for="username" class="form-label">
                                    <i class="fas fa-at"></i>
                                    Nombre de usuario
                                </label>
                                <div class="input-wrapper">
                                    <input type="text" 
                                           id="username" 
                                           name="username" 
                                           class="form-input" 
                                           placeholder="Tu nombre de usuario único"
                                           autocomplete="username"
                                           value="<?php echo htmlspecialchars($username ?? ''); ?>"
                                           required>
                                    <div class="availability-check" id="usernameCheck">
                                        <i class="fas fa-spinner fa-spin"></i>
                                    </div>
                                </div>
                                <div class="form-error" id="usernameError"></div>
                                <div class="form-hint">Solo letras, números y guiones. Mínimo 3 caracteres.</div>
                            </div>

                            <div class="form-group">
                                <label for="email" class="form-label">
                                    <i class="fas fa-envelope"></i>
                                    Email
                                </label>
                                <div class="input-wrapper">
                                    <input type="email" 
                                           id="email" 
                                           name="email" 
                                           class="form-input" 
                                           placeholder="tu@email.com"
                                           autocomplete="email"
                                           value="<?php echo htmlspecialchars($email ?? ''); ?>"
                                           required>
                                    <div class="availability-check" id="emailCheck">
                                        <i class="fas fa-spinner fa-spin"></i>
                                    </div>
                                </div>
                                <div class="form-error" id="emailError"></div>
                            </div>

                            <div class="form-group">
                                <label for="password" class="form-label">
                                    <i class="fas fa-lock"></i>
                                    Contraseña
                                </label>
                                <div class="input-wrapper">
                                    <input type="password" 
                                           id="password" 
                                           name="password" 
                                           class="form-input" 
                                           placeholder="Crea una contraseña segura"
                                           autocomplete="new-password"
                                           required>
                                    <button type="button" class="password-toggle" onclick="togglePassword('password')">
                                        <i class="fas fa-eye" id="passwordToggleIcon"></i>
                                    </button>
                                </div>
                                <div class="password-strength" id="passwordStrength"></div>
                                <div class="form-error" id="passwordError"></div>
                            </div>

                            <div class="form-group">
                                <label for="confirm_password" class="form-label">
                                    <i class="fas fa-lock"></i>
                                    Confirmar contraseña
                                </label>
                                <div class="input-wrapper">
                                    <input type="password" 
                                           id="confirm_password" 
                                           name="confirm_password" 
                                           class="form-input" 
                                           placeholder="Repite tu contraseña"
                                           autocomplete="new-password"
                                           required>
                                    <button type="button" class="password-toggle" onclick="togglePassword('confirm_password')">
                                        <i class="fas fa-eye" id="confirmPasswordToggleIcon"></i>
                                    </button>
                                </div>
                                <div class="password-match" id="passwordMatch"></div>
                                <div class="form-error" id="confirmPasswordError"></div>
                            </div>

                            <div class="form-group">
                                <div class="checkbox-wrapper">
                                    <input type="checkbox" id="terms_accepted" name="terms_accepted" required>
                                    <label for="terms_accepted" class="checkbox-label">
                                        <span class="checkbox-custom">
                                            <i class="fas fa-check"></i>
                                        </span>
                                        <span class="checkbox-text">
                                            Acepto los <a href="#" class="terms-link">términos y condiciones</a> 
                                            y la <a href="#" class="terms-link">política de privacidad</a>
                                        </span>
                                    </label>
                                </div>
                                <div class="form-error" id="termsError"></div>
                            </div>

                            <button type="submit" class="btn-auth btn-primary" id="registerBtn">
                                <span class="btn-text">Crear mi cuenta</span>
                                <i class="fas fa-rocket btn-icon"></i>
                                <div class="btn-loading">
                                    <i class="fas fa-spinner fa-spin"></i>
                                </div>
                            </button>

                            <div class="auth-divider">
                                <span>¿Ya tienes cuenta?</span>
                            </div>

                            <a href="<?php echo \ObelisIA\Router\MainRouter::url('login'); ?>" 
                               class="btn-auth btn-outline">
                                <i class="fas fa-sign-in-alt"></i>
                                <span>Iniciar sesión</span>
                            </a>
                        </form>
                        
                    <?php else: ?>
                        <!-- Paso 2: Confirmación -->
                        <div class="success-step">
                            <div class="success-icon">
                                <i class="fas fa-envelope-circle-check"></i>
                            </div>
                            <h3>¡Bienvenido a ObelisIA!</h3>
                            <p class="success-message">
                                Tu cuenta ha sido creada exitosamente. Hemos enviado un email de verificación a 
                                <strong><?php echo htmlspecialchars($_POST['email'] ?? ''); ?></strong>
                            </p>
                            
                            <div class="verification-notice">
                                <div class="notice-icon">
                                    <i class="fas fa-info-circle"></i>
                                </div>
                                <div class="notice-content">
                                    <h4>Importante</h4>
                                    <p>Debes verificar tu email antes de poder iniciar sesión. Revisa tu bandeja de entrada y sigue las instrucciones.</p>
                                </div>
                            </div>
                            
                            <div class="verification-actions">
                                <a href="<?php echo \ObelisIA\Router\MainRouter::url('login'); ?>" 
                                   class="btn-auth btn-primary">
                                    <i class="fas fa-sign-in-alt"></i>
                                    <span>Ir al login</span>
                                </a>
                                
                                <button type="button" class="btn-auth btn-outline" onclick="resendVerificationEmail()">
                                    <i class="fas fa-paper-plane"></i>
                                    <span>Reenviar email</span>
                                </button>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Footer -->
                    <div class="auth-footer">
                        <a href="<?php echo \ObelisIA\Router\MainRouter::url('inicio'); ?>" class="back-home">
                            <i class="fas fa-home"></i>
                            <span>Volver al inicio</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
/* Register Page Additional Styles */
.auth-page {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    overflow-x: hidden;
}

/* Auth Section */
.auth-section {
    min-height: 100vh;
    position: relative;
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
    color: #f8fafc;
}

.auth-background {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 1;
}

.auth-grid {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-image: 
        linear-gradient(rgba(59, 130, 246, 0.1) 1px, transparent 1px),
        linear-gradient(90deg, rgba(59, 130, 246, 0.1) 1px, transparent 1px);
    background-size: 50px 50px;
    animation: gridMove 20s linear infinite;
}

@keyframes gridMove {
    0% { transform: translate(0, 0); }
    100% { transform: translate(50px, 50px); }
}

.auth-gradient {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: radial-gradient(circle at 30% 20%, rgba(59, 130, 246, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 70% 80%, rgba(139, 92, 246, 0.1) 0%, transparent 50%);
}

.floating-particles::before,
.floating-particles::after {
    content: '';
    position: absolute;
    width: 400px;
    height: 400px;
    border-radius: 50%;
    filter: blur(100px);
    animation: float 20s ease-in-out infinite;
}

.floating-particles::before {
    background: rgba(59, 130, 246, 0.1);
    top: 10%;
    left: 10%;
    animation-delay: 0s;
}

.floating-particles::after {
    background: rgba(139, 92, 246, 0.1);
    bottom: 10%;
    right: 10%;
    animation-delay: 10s;
}

@keyframes float {
    0%, 100% { transform: translateY(0px) scale(1); }
    50% { transform: translateY(-20px) scale(1.1); }
}

/* Auth Card */
.auth-card {
    background: rgba(30, 41, 59, 0.9);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(71, 85, 105, 0.3);
    border-radius: 24px;
    padding: 3rem 2.5rem;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.4);
    position: relative;
    z-index: 10;
    overflow: hidden;
}

.auth-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #3b82f6, #8b5cf6);
    border-radius: 24px 24px 0 0;
}

/* Header */
.auth-header {
    text-align: center;
    margin-bottom: 2.5rem;
}

.auth-logo {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 1rem;
    margin-bottom: 1.5rem;
}

.logo-icon {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, #3b82f6, #8b5cf6);
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 8px 32px rgba(59, 130, 246, 0.3);
}

.logo-icon i {
    font-size: 1.8rem;
    color: white;
}

.auth-logo h1 {
    font-size: 2rem;
    font-weight: 700;
    margin: 0;
    background: linear-gradient(135deg, #3b82f6, #8b5cf6);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.auth-header h2 {
    font-size: 1.5rem;
    font-weight: 600;
    margin: 0 0 0.5rem 0;
    color: #f8fafc;
}

.auth-header p {
    color: #94a3b8;
    margin: 0;
    font-size: 0.95rem;
}

/* Form Styles */
.auth-form {
    margin-bottom: 2rem;
}

.form-group {
    margin-bottom: 1.5rem;
    position: relative;
}

.form-label {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.9rem;
    font-weight: 500;
    color: #cbd5e1;
    margin-bottom: 0.5rem;
}

.form-label i {
    color: #6366f1;
}

.input-wrapper {
    position: relative;
}

.form-input {
    width: 100%;
    padding: 1rem 1.25rem;
    background: rgba(15, 23, 42, 0.5);
    border: 1px solid rgba(71, 85, 105, 0.5);
    border-radius: 12px;
    color: #f8fafc;
    font-size: 1rem;
    transition: all 0.3s ease;
}

.form-input:focus {
    outline: none;
    border-color: #6366f1;
    box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
    background: rgba(15, 23, 42, 0.7);
}

.form-input::placeholder {
    color: #64748b;
}

.form-input.success {
    border-color: #10b981;
}

.form-input.error {
    border-color: #ef4444;
}

.password-toggle {
    position: absolute;
    right: 1rem;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    color: #64748b;
    cursor: pointer;
    padding: 0.25rem;
    border-radius: 4px;
    transition: color 0.3s ease;
}

.password-toggle:hover {
    color: #6366f1;
}

.availability-check {
    position: absolute;
    right: 1rem;
    top: 50%;
    transform: translateY(-50%);
    color: #6366f1;
    display: none;
}

.availability-check.checking {
    display: block;
    color: #f59e0b;
}

.availability-check.available {
    display: block;
    color: #10b981;
}

.availability-check.taken {
    display: block;
    color: #ef4444;
}

.form-hint {
    font-size: 0.8rem;
    color: #64748b;
    margin-top: 0.5rem;
}

.password-strength,
.password-match {
    font-size: 0.85rem;
    margin-top: 0.5rem;
    font-weight: 500;
}

.password-strength.weak {
    color: #ef4444;
}

.password-strength.medium {
    color: #f59e0b;
}

.password-strength.strong {
    color: #10b981;
}

.password-match.match {
    color: #10b981;
}

.password-match.no-match {
    color: #ef4444;
}

/* Checkbox */
.checkbox-wrapper {
    display: flex;
    align-items: flex-start;
    gap: 1rem;
    margin: 1.5rem 0;
}

.checkbox-wrapper input[type="checkbox"] {
    display: none;
}

.checkbox-custom {
    width: 22px;
    height: 22px;
    background: rgba(15, 23, 42, 0.5);
    border: 1px solid rgba(71, 85, 105, 0.5);
    border-radius: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
    flex-shrink: 0;
    cursor: pointer;
}

.checkbox-custom i {
    font-size: 12px;
    color: white;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.checkbox-wrapper input[type="checkbox"]:checked + .checkbox-label .checkbox-custom {
    background: linear-gradient(135deg, #3b82f6, #6366f1);
    border-color: #6366f1;
}

.checkbox-wrapper input[type="checkbox"]:checked + .checkbox-label .checkbox-custom i {
    opacity: 1;
}

.checkbox-label {
    display: flex;
    align-items: flex-start;
    gap: 0.75rem;
    cursor: pointer;
    line-height: 1.5;
}

.checkbox-text {
    font-size: 0.9rem;
    color: #cbd5e1;
}

.terms-link {
    color: #6366f1;
    text-decoration: none;
}

.terms-link:hover {
    text-decoration: underline;
}

/* Buttons */
.btn-auth {
    width: 100%;
    padding: 1rem 1.5rem;
    border-radius: 12px;
    border: none;
    font-weight: 600;
    font-size: 1rem;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    text-decoration: none;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
    cursor: pointer;
}

.btn-auth.btn-primary {
    background: linear-gradient(135deg, #3b82f6, #6366f1);
    color: white;
    box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3);
}

.btn-auth.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(59, 130, 246, 0.4);
}

.btn-auth.btn-outline {
    background: transparent;
    color: #cbd5e1;
    border: 1px solid rgba(71, 85, 105, 0.5);
}

.btn-auth.btn-outline:hover {
    background: rgba(59, 130, 246, 0.1);
    border-color: #6366f1;
    color: #6366f1;
}

.btn-loading {
    position: absolute;
    right: 1rem;
    display: none;
}

/* Success Step */
.success-step {
    text-align: center;
    padding: 2rem 0;
}

.success-icon {
    width: 100px;
    height: 100px;
    background: linear-gradient(135deg, #10b981, #059669);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 2rem;
    box-shadow: 0 10px 30px rgba(16, 185, 129, 0.3);
}

.success-icon i {
    font-size: 3rem;
    color: white;
}

.success-step h3 {
    font-size: 1.5rem;
    font-weight: 600;
    color: #f8fafc;
    margin-bottom: 1rem;
}

.success-message {
    color: #94a3b8;
    margin-bottom: 2rem;
    line-height: 1.6;
}

.verification-notice {
    background: rgba(59, 130, 246, 0.1);
    border: 1px solid rgba(59, 130, 246, 0.2);
    border-radius: 12px;
    padding: 1.5rem;
    margin-bottom: 2rem;
    display: flex;
    gap: 1rem;
    text-align: left;
}

.notice-icon {
    color: #6366f1;
    font-size: 1.25rem;
    flex-shrink: 0;
}

.notice-content h4 {
    font-size: 1rem;
    font-weight: 600;
    color: #f8fafc;
    margin: 0 0 0.5rem 0;
}

.notice-content p {
    font-size: 0.9rem;
    color: #94a3b8;
    margin: 0;
    line-height: 1.5;
}

.verification-actions {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

/* Alerts */
.alert {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 1rem 1.25rem;
    border-radius: 12px;
    margin-bottom: 1.5rem;
    font-size: 0.9rem;
    font-weight: 500;
}

.alert-error {
    background: rgba(239, 68, 68, 0.1);
    border: 1px solid rgba(239, 68, 68, 0.2);
    color: #fca5a5;
}

.alert-success {
    background: rgba(16, 185, 129, 0.1);
    border: 1px solid rgba(16, 185, 129, 0.2);
    color: #6ee7b7;
}

.form-error {
    color: #f87171;
    font-size: 0.85rem;
    margin-top: 0.5rem;
    display: none;
}

/* Divider */
.auth-divider {
    text-align: center;
    margin: 2rem 0;
    position: relative;
}

.auth-divider::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    height: 1px;
    background: rgba(71, 85, 105, 0.3);
}

.auth-divider span {
    background: rgba(30, 41, 59, 0.9);
    padding: 0 1rem;
    color: #64748b;
    font-size: 0.9rem;
}

/* Footer */
.auth-footer {
    text-align: center;
    padding-top: 2rem;
    border-top: 1px solid rgba(71, 85, 105, 0.3);
}

.back-home {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    color: #64748b;
    text-decoration: none;
    font-size: 0.9rem;
    padding: 0.5rem 1rem;
    border-radius: 8px;
    transition: all 0.3s ease;
}

.back-home:hover {
    color: #6366f1;
    background: rgba(99, 102, 241, 0.1);
}

/* Responsive */
@media (max-width: 768px) {
    .auth-card {
        margin: 1rem;
        padding: 2rem 1.5rem;
    }
    
    .auth-logo h1 {
        font-size: 1.5rem;
    }
    
    .verification-actions {
        gap: 0.75rem;
    }
}
</style>

<script>
let availabilityTimeout = {};

document.addEventListener('DOMContentLoaded', function() {
    const usernameInput = document.getElementById('username');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirm_password');
    
    // Verificar disponibilidad de usuario y email
    if (usernameInput) {
        usernameInput.addEventListener('input', function() {
            clearTimeout(availabilityTimeout.username);
            availabilityTimeout.username = setTimeout(() => {
                checkAvailability('username', this.value);
            }, 500);
        });
    }
    
    if (emailInput) {
        emailInput.addEventListener('input', function() {
            clearTimeout(availabilityTimeout.email);
            availabilityTimeout.email = setTimeout(() => {
                checkAvailability('email', this.value);
            }, 500);
        });
    }
    
    // Verificar fortaleza de contraseña
    if (passwordInput) {
        passwordInput.addEventListener('input', function() {
            checkPasswordStrength(this.value);
            if (confirmPasswordInput.value) {
                checkPasswordMatch(this.value, confirmPasswordInput.value);
            }
        });
    }
    
    if (confirmPasswordInput) {
        confirmPasswordInput.addEventListener('input', function() {
            if (passwordInput.value) {
                checkPasswordMatch(passwordInput.value, this.value);
            }
        });
    }
    
    // Validación del formulario
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            if (!validateForm()) {
                e.preventDefault();
                return false;
            }
            
            const registerBtn = document.getElementById('registerBtn');
            const btnText = registerBtn.querySelector('.btn-text');
            const btnLoading = registerBtn.querySelector('.btn-loading');
            
            registerBtn.disabled = true;
            btnText.style.opacity = '0.7';
            btnLoading.style.display = 'block';
        });
    }
});

async function checkAvailability(type, value) {
    if (!value || value.length < 3) return;
    
    const checkElement = document.getElementById(type + 'Check');
    const inputElement = document.getElementById(type);
    
    // Mostrar loading
    checkElement.className = 'availability-check checking';
    checkElement.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    
    try {
        const formData = new FormData();
        formData.append('action', 'check_availability');
        formData.append('type', type);
        formData.append('value', value);
        
        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.available) {
            checkElement.className = 'availability-check available';
            checkElement.innerHTML = '<i class="fas fa-check"></i>';
            inputElement.classList.remove('error');
            inputElement.classList.add('success');
        } else {
            checkElement.className = 'availability-check taken';
            checkElement.innerHTML = '<i class="fas fa-times"></i>';
            inputElement.classList.remove('success');
            inputElement.classList.add('error');
            showFieldError(type + 'Error', result.message);
        }
    } catch (error) {
        checkElement.style.display = 'none';
    }
}

function checkPasswordStrength(password) {
    const strengthDiv = document.getElementById('passwordStrength');
    let strength = 0;
    let message = '';
    
    if (password.length >= 6) strength++;
    if (password.match(/[a-z]/)) strength++;
    if (password.match(/[A-Z]/)) strength++;
    if (password.match(/[0-9]/)) strength++;
    if (password.match(/[^a-zA-Z0-9]/)) strength++;
    
    strengthDiv.className = 'password-strength';
    
    if (strength <= 2) {
        strengthDiv.className += ' weak';
        message = '🔴 Débil';
    } else if (strength <= 3) {
        strengthDiv.className += ' medium';
        message = '🟡 Media';
    } else {
        strengthDiv.className += ' strong';
        message = '🟢 Fuerte';
    }
    
    strengthDiv.textContent = 'Seguridad: ' + message;
}

function checkPasswordMatch(password, confirmPassword) {
    const matchDiv = document.getElementById('passwordMatch');
    const confirmInput = document.getElementById('confirm_password');
    
    matchDiv.className = 'password-match';
    
    if (password === confirmPassword) {
        matchDiv.className += ' match';
        matchDiv.textContent = '✅ Las contraseñas coinciden';
        confirmInput.classList.remove('error');
        confirmInput.classList.add('success');
    } else {
        matchDiv.className += ' no-match';
        matchDiv.textContent = '❌ Las contraseñas no coinciden';
        confirmInput.classList.remove('success');
        confirmInput.classList.add('error');
    }
}

function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const iconId = inputId === 'password' ? 'passwordToggleIcon' : 'confirmPasswordToggleIcon';
    const icon = document.getElementById(iconId);
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'fas fa-eye-slash';
    } else {
        input.type = 'password';
        icon.className = 'fas fa-eye';
    }
}

function validateForm() {
    let isValid = true;
    const fields = ['full_name', 'username', 'email', 'password', 'confirm_password'];
    
    fields.forEach(field => {
        const input = document.getElementById(field);
        const error = document.getElementById(field.replace('_', '') + 'Error');
        
        if (!input.value.trim()) {
            showFieldError(error.id, 'Este campo es obligatorio');
            input.classList.add('error');
            isValid = false;
        }
    });
    
    // Verificar términos
    const termsCheckbox = document.getElementById('terms_accepted');
    if (!termsCheckbox.checked) {
        showFieldError('termsError', 'Debe aceptar los términos y condiciones');
        isValid = false;
    }
    
    return isValid;
}

function showFieldError(errorId, message) {
    const errorElement = document.getElementById(errorId);
    errorElement.textContent = message;
    errorElement.style.display = 'block';
}

function resendVerificationEmail() {
    // Implementar reenvío de email de verificación
    alert('Email de verificación reenviado. Revisa tu bandeja de entrada.');
}
</script>