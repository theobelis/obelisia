<section id="pricing" class="">
    <div class="floating-elements-section">
        <div class="floating-element" style="top:6%;left:4%;width:100px;height:100px;"></div>
        <div class="floating-element" style="top:24%;left:76%;width:80px;height:80px;"></div>
        <div class="floating-element" style="top:54%;left:16%;width:90px;height:90px;"></div>
        <div class="floating-element" style="top:69%;left:66%;width:110px;height:110px;"></div>
        <div class="floating-element" style="top:16%;left:46%;width:75px;height:75px;"></div>
        <div class="floating-element" style="top:44%;left:56%;width:95px;height:95px;"></div>
        <div class="floating-element" style="top:76%;left:26%;width:85px;height:85px;"></div>
        <div class="floating-element" style="top:81%;left:81%;width:78px;height:78px;"></div>
        <div class="floating-element" style="top:38%;left:33%;width:90px;height:90px;"></div>
        <div class="floating-element" style="top:63%;left:88%;width:80px;height:80px;"></div>
        <div class="floating-element" style="top:90%;left:10%;width:110px;height:110px;"></div>
        <div class="floating-element" style="top:92%;left:40%;width:95px;height:95px;"></div>
        <div class="floating-element" style="top:94%;left:70%;width:100px;height:100px;"></div>
        <div class="floating-element" style="top:97%;left:85%;width:85px;height:85px;"></div>
        <div class="floating-element" style="top:99%;left:55%;width:120px;height:120px;"></div>
    </div>
    <div class="container py-5">
        <div class="row">
            <div class="col-lg-8 mx-auto text-center mb-5">
                <h2 class="section-title text-white">Planes y Precios</h2>
                <p class="section-subtitle text-white">Elige el plan perfecto para tus necesidades creativas</p>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-4 col-md-2 mb-4">
                <div class="pricing-card">
                    <div class="pricing-header text-muted">
                        <h3>Gratuito</h3>
                        <div class="price">
                            <span class="currency">$</span>
                            <span class="amount">0</span>
                            <span class="period">/mes</span>
                        </div>
                        <p class="pricing-subtitle">Perfecto para empezar</p>
                    </div>
                    <ul class="pricing-features">
                        <li><i class="material-icons">check</i> Generaciones ilimitadas (Anuncios)</li>
                        <li><i class="material-icons">check</i> Removedor de fondo básico</li>
                        <li><i class="material-icons">check</i> Editor de imágenes estándar</li>
                        <li><i class="material-icons">check</i> Máxima resolución (4K)</li>
                        <li><i class="material-icons">check</i> Acceso a herramientas básicas</li>
                        <li><i class="material-icons">close</i> Videos IA Sin límite</li>
                        <li><i class="material-icons">close</i> Sin marca de agua</li>
                        <li><i class="material-icons">close</i> Todas las herramientas</li>
                        <li><i class="material-icons">close</i> Soporte prioritario 24/7</li>
                    </ul>
                    <div class="pricing-footer">
                        <?php if (!$auth->isLoggedIn()): ?>
                            <a href="<?php echo \ObelisIA\Router\MainRouter::url('registro'); ?>" class="btn btn-primary-custom w-100">Comenzar Gratis</a>
                        <?php else: ?>
                            <a href="<?php echo \ObelisIA\Router\MainRouter::url('panel'); ?>" class="btn btn-primary-custom w-100">Acceder</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-2 mb-4">
                <div class="pricing-card pricing-card-premium">
                    <div class="pricing-badge">Más Popular</div>
                    <div class="pricing-header text-muted">
                        <h3>Premium</h3>
                        <div class="price">
                            <span class="currency">$</span>
                            <span class="amount">19</span>
                            <span class="period">/mes</span>
                        </div>
                        <p class="pricing-subtitle">Para creativos profesionales</p>
                    </div>
                    <ul class="pricing-features">
                        <li><i class="material-icons">check</i> Generaciones ilimitadas (Sin Anuncios)</li>
                        <li><i class="material-icons">check</i> Removedor de Fondo Avanzado</li>
                        <li><i class="material-icons">check</i> Editor de imágenes Avanzado</li>
                        <li><i class="material-icons">check</i> Máxima resolución (4K)</li>
                        <li><i class="material-icons">check</i> Acceso a todas las herramientas</li>
                        <li><i class="material-icons">check</i> Videos IA Sin límite</li>
                        <li><i class="material-icons">check</i> Sin marca de agua</li>
                        <li><i class="material-icons">check</i> Soporte prioritario 24/7</li>
                    </ul>
                    <div class="pricing-footer">
                        <?php if (!$auth->isLoggedIn()): ?>
                            <a href="<?php echo \ObelisIA\Router\MainRouter::url('registro'); ?>" class="btn btn-primary-custom w-100">Comenzar Premium</a>
                        <?php else: ?>
                            <a href="<?php echo \ObelisIA\Router\MainRouter::url('buy'); ?>" class="btn btn-primary-custom w-100">Upgrade a Premium</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<script src="/assets/js/general/effects/floating-elements.js"></script>