<div class="container py-5 my-5 bg-light" style="border-radius: var(--border-radius-lg); box-shadow: var(--shadow-lg);">
    <div class="row justify-content-center mb-4">
        <div class="col-lg-8 text-center">
            <span style="font-size:3rem; background:var(--primary-color); -webkit-background-clip:text; color:transparent; display:inline-block;">
                <i class="material-icons">psychology</i>
            </span>
            <h1 class="mb-3" style="font-weight:700; letter-spacing:1px; background:var(--primary-color); -webkit-background-clip:text; color:transparent;">Acerca de ObelisIA</h1>
            <p class="lead" style="color:var(--gray-600);">ObelisIA es una plataforma integral de inteligencia artificial que facilita el acceso a herramientas avanzadas de IA para usuarios, empresas y creadores de habla hispana. Nuestra misión es potenciar la creatividad, la productividad y la innovación a través de soluciones inteligentes, seguras, intuitivas y accesibles para todos, con opciones gratuitas y de pago, y una experiencia de usuario de primer nivel.</p>
            <div class="d-flex justify-content-center gap-3 mt-3 flex-wrap">
                <span class="badge fs-6" style="background:var(--primary-color); color:#fff;"><i class="material-icons align-middle">security</i> Seguro</span>
                <span class="badge fs-6" style="background:var(--success-color); color:#fff;"><i class="material-icons align-middle">lightbulb</i> Innovador</span>
                <span class="badge fs-6" style="background:var(--warning-color); color:#fff;"><i class="material-icons align-middle">groups</i> Comunitario</span>
                <span class="badge fs-6" style="background:var(--info-color); color:#fff;"><i class="material-icons align-middle">accessibility</i> Accesible</span>
            </div>
        </div>
    </div>
    <div class="row g-4 mt-4">
        <div class="col-md-6">
            <div class="card shadow-sm border-0 h-100 bg-light" style="border-top:4px solid var(--primary-color); border-radius: var(--border-radius);">
                <div class="card-body">
                    <h3 class="card-title" style="color:#2196f3;">Misión</h3>
                    <p class="card-text">Brindar acceso sencillo, ético y seguro a tecnologías de IA de vanguardia, ayudando a personas y organizaciones a transformar sus ideas en soluciones reales y eficientes.</p>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card shadow-sm border-0 h-100 bg-light" style="border-top:4px solid var(--success-color); border-radius: var(--border-radius);">
                <div class="card-body">
                    <h3 class="card-title" style="color:#43a047;">Visión</h3>
                    <p class="card-text">Ser la plataforma líder en inteligencia artificial en el mundo hispanohablante, promoviendo la innovación, el desarrollo responsable y la inclusión digital a través de soluciones tecnológicas de alto impacto.</p>
                </div>
            </div>
        </div>
    </div>
    <div class="row g-4 mt-3">
        <div class="col-md-4">
            <div class="card shadow-sm border-0 h-100 bg-light" style="border-top:4px solid var(--warning-color); border-radius: var(--border-radius);">
                <div class="card-body">
                    <h4 class="card-title" style="color:#ff9800;">¿Qué es ObelisIA?</h4>
                    <p class="card-text">ObelisIA es un ecosistema digital que integra múltiples servicios de IA: generación de texto, imágenes, música, análisis de datos, asistentes virtuales y herramientas de productividad. Todo en un entorno seguro, intuitivo y adaptable a diferentes necesidades, diseñado para que cualquier usuario pueda aprovechar el poder de la inteligencia artificial sin complicaciones técnicas.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm border-0 h-100 bg-light" style="border-top:4px solid var(--secondary-color); border-radius: var(--border-radius);">
                <div class="card-body">
                    <h4 class="card-title" style="background:var(--secondary-color); -webkit-background-clip:text; color:transparent;">Características principales</h4>
                    <ul class="card-text ps-3">
                        <li><i class="material-icons text-primary align-middle">edit</i> Generación de texto, imágenes y música con IA</li>
                        <li><i class="material-icons text-success align-middle">analytics</i> Herramientas de análisis y automatización</li>
                        <li><i class="material-icons text-warning align-middle">dashboard</i> Panel de control profesional, seguro e intuitivo</li>
                        <li><i class="material-icons text-info align-middle">help</i> Soporte y documentación en español</li>
                        <li><i class="material-icons text-secondary align-middle">update</i> Actualizaciones constantes y mejoras basadas en la comunidad</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm border-0 h-100 bg-light" style="border-top:4px solid var(--info-color); border-radius: var(--border-radius);">
                <div class="card-body">
                    <h4 class="card-title" style="background:var(--info-color); -webkit-background-clip:text; color:transparent;">¿A quién va dirigido?</h4>
                    <ul class="card-text ps-3">
                        <li><i class="material-icons text-primary align-middle">business_center</i> Emprendedores y empresas</li>
                        <li><i class="material-icons text-success align-middle">brush</i> Creadores de contenido digital</li>
                        <li><i class="material-icons text-warning align-middle">school</i> Educadores y estudiantes</li>
                        <li><i class="material-icons text-info align-middle">trending_up</i> Profesionales y usuarios que buscan potenciar su productividad y creatividad</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="row g-4 mt-3">
        <div class="col-md-6">
            <div class="card shadow-sm border-0 h-100 bg-light" style="border-top:4px solid var(--violet); border-radius: var(--border-radius);">
                <div class="card-body">
                    <h4 class="card-title" style="background:var(--violet); -webkit-background-clip:text; color:transparent;">Valores</h4>
                    <ul class="card-text ps-3">
                        <li><i class="material-icons text-primary align-middle">auto_awesome</i> Innovación constante y responsable</li>
                        <li><i class="material-icons text-success align-middle">gavel</i> Transparencia y ética en el uso de IA</li>
                        <li><i class="material-icons text-warning align-middle">verified_user</i> Compromiso con la privacidad, seguridad y experiencia de usuario</li>
                        <li><i class="material-icons text-info align-middle">diversity_3</i> Accesibilidad, diversidad e inclusión</li>
                        <li><i class="material-icons text-secondary align-middle">groups</i> Colaboración y comunidad</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card shadow-sm border-0 h-100 bg-light" style="border-top:4px solid var(--error-color); border-radius: var(--border-radius);">
                <div class="card-body">
                    <h4 class="card-title" style="background:var(--error-color); -webkit-background-clip:text; color:transparent;">Impacto</h4>
                    <p class="card-text"><i class="material-icons text-danger align-middle">favorite</i> ObelisIA ha ayudado a miles de usuarios a automatizar tareas, crear contenido original, analizar datos y desarrollar proyectos innovadores. Nuestra comunidad crece cada día, impulsando el desarrollo tecnológico y la creatividad en la región, y promoviendo el acceso igualitario a la inteligencia artificial.</p>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-5">
        <div class="col-lg-8 mx-auto text-center">
            <hr>
            <p class="text-muted small">¿Tienes preguntas, sugerencias o quieres colaborar? <i class="material-icons align-middle" style="color:var(--primary-color);">mail</i> Contáctanos a través del <a href="<?php echo \ObelisIA\Router\MainRouter::url('soporte'); ?>" style="background:var(--primary-color); -webkit-background-clip:text; color:transparent;">formulario de soporte</a> o síguenos en nuestras redes sociales.<br><span style="font-weight:600; background:var(--primary-color); -webkit-background-clip:text; color:transparent;">ObelisIA</span> &copy; 2025</p>
        </div>
    </div>
</div>
