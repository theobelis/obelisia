<?php
require_once __DIR__ . '/../../src/Database/Database.php';
require_once __DIR__ . '/../../src/Config/config.php';
session_start();

// Obtener datos del usuario desde la sesión (ajusta según tu sistema de login)
$user_id = $_SESSION['user_id'] ?? null;
$email = $_SESSION['email'] ?? '';
$user_name = $_SESSION['full_name'] ?? '';

$mensaje = '';
$icono = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $user_name;
    $email = $email;
    $mensaje_texto = trim($_POST['mensaje'] ?? '');
    if (!$user_id || !$email || !$user_name) {
        $mensaje = 'No se pudo identificar al usuario. Por favor, inicia sesión nuevamente.';
        $icono = 'error';
    } elseif (empty($mensaje_texto)) {
        $mensaje = 'Por favor, completa todos los campos.';
        $icono = 'error';
    } else {
        try {
            $dbClass = new \ObelisIA\Database\Database();
            $db = $dbClass->getConnection();
            $stmt = $db->prepare("INSERT INTO contact_messages (user_id, full_name, email, message, created_at) VALUES (?, ?, ?, ?, NOW())");
            $stmt->execute([$user_id, $nombre, $email, $mensaje_texto]);
            // Enviar correo al administrador usando PHPMailer
            require_once __DIR__ . '/../../vendor/autoload.php';
            $mail = new PHPMailer\PHPMailer\PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = SMTP_HOST;
                $mail->SMTPAuth = true;
                $mail->Username = SMTP_USERNAME;
                $mail->Password = SMTP_PASSWORD;
                $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = SMTP_PORT;

                $mail->setFrom(FROM_EMAIL, FROM_NAME);
                $mail->addAddress(FROM_EMAIL);
                $mail->addReplyTo($email, $nombre);

                // Cargar plantilla HTML y reemplazar marcadores
                $plantilla = file_get_contents(__DIR__ . '/../../emails/contact/contact.html');
                $plantilla = str_replace(['{{nombre}}', '{{email}}', '{{mensaje}}'], [htmlspecialchars($nombre), htmlspecialchars($email), nl2br(htmlspecialchars($mensaje_texto))], $plantilla);

                $mail->isHTML(true);
                $mail->Subject = 'Nuevo mensaje de contacto desde ObelisIA';
                $mail->Body = $plantilla;

                $mail->AltBody = "Has recibido un nuevo mensaje desde el formulario de contacto de ObelisIA.\n\n" .
                    "Nombre: $nombre\n" .
                    "Correo: $email\n" .
                    "Mensaje:\n$mensaje_texto\n";

                $mail->send();
            } catch (Exception $e) {
                // Puedes registrar el error si lo deseas: $mail->ErrorInfo
            }
            $mensaje = '¡Mensaje enviado exitosamente!';
            $icono = 'check_circle';
            $_POST = [];
        } catch (\PDOException $e) {
            $mensaje = 'Error al guardar el mensaje. Intenta más tarde.';
            $icono = 'error';
        }
    }
}
?>
<div class="container py-4 my-5 bg-light" style="border-radius: var(--border-radius-lg); box-shadow: var(--shadow-lg); max-width:600px;">
    <div class="text-center mb-4">

        <?php if ($mensaje): ?>
            <div class="alert <?php echo $icono === 'check_circle' ? 'alert-success' : 'alert-danger'; ?> d-flex align-items-center justify-content-center gap-2" role="alert" style="border-radius:var(--border-radius);">
                <span style="font-size:1.7rem; background:var(--primary-color); -webkit-background-clip:text; color:transparent; display:inline-block;">
                    <i class="material-icons"><?php echo htmlspecialchars($icono); ?></i>
                </span>
                <span class="text-muted"><?php echo htmlspecialchars($mensaje); ?></span>
            </div>
        <?php endif; ?>
        <span style="font-size:2.5rem; background:var(--primary-color); -webkit-background-clip:text; color:transparent; display:inline-block;">
            <i class="material-icons">mail</i>
        </span>
        <h1 class="mb-2" style="font-weight:700; letter-spacing:1px; background:var(--primary-color); -webkit-background-clip:text; color:transparent;">Contacto</h1>
        <p class="lead " style="color:var(--gray-600);">¿Tienes dudas, sugerencias o necesitas soporte? Completa el formulario o escríbenos a <a href="mailto:theobeliscorp@gmail.com" style="background:var(--primary-color); -webkit-background-clip:text; color:transparent; font-weight:600;">theobeliscorp@gmail.com</a></p>
    </div>
    <form method="post" action="#" class="p-4 bg-white rounded shadow-sm" style="border-radius: var(--border-radius);">
        <div class="mb-3">
            <label for="nombre" class="form-label text-muted" style="color:var(--gray-700); font-weight:500;">Nombre</label>
            <input type="text" class="form-control text-muted" id="nombre" name="nombre" placeholder="Tu nombre" required style="background:var(--input-bg-light); color:var(--input-text-light);" value="<?php echo htmlspecialchars($user_name); ?>" readonly>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label text-muted" style="color:var(--gray-700); font-weight:500;">Correo electrónico</label>
            <input type="email" class="form-control text-muted" id="email" name="email" placeholder="tucorreo@ejemplo.com" required style="background:var(--input-bg-light); color:var(--input-text-light);" value="<?php echo htmlspecialchars($_SESSION['email'] ?? ''); ?>" readonly>
        </div>
        <div class="mb-3">
            <label for="mensaje" class="form-label text-muted" style="color:var(--gray-700); font-weight:500;">Mensaje</label>
            <textarea class="form-control text-muted" id="mensaje" name="mensaje" rows="4" placeholder="Escribe tu mensaje aquí..." required style="background:var(--input-bg-light); color:var(--input-text-light);"><?php echo htmlspecialchars($_POST['mensaje'] ?? ''); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary w-100" style="background:var(--primary-color); border:none; font-weight:600;">Enviar mensaje</button>
    </form>
</div>
