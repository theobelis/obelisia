<?php
$page_title = "Preguntas Frecuentes - Obelis";
?>

<style>
.faq-container {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    min-height: 100vh;
    padding: 40px 0;
}

.faq-content {
    background: white;
    border-radius: 20px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.1);
    overflow: hidden;
}

.faq-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 40px;
    text-align: center;
}

.faq-body {
    padding: 40px;
}

.faq-search {
    background: #f8f9fa;
    border-radius: 15px;
    padding: 30px;
    margin-bottom: 40px;
    text-align: center;
}

.faq-search input {
    border: none;
    border-radius: 50px;
    padding: 15px 25px;
    font-size: 16px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    width: 100%;
    max-width: 500px;
}

.faq-categories {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-bottom: 40px;
}

.category-card {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 25px;
    border-radius: 15px;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
}

.category-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 35px rgba(102, 126, 234, 0.3);
    color: white;
    text-decoration: none;
}

.category-icon {
    font-size: 2.5rem;
    margin-bottom: 15px;
    display: block;
}

.faq-section {
    margin-bottom: 40px;
}

.faq-section h2 {
    color: #2d3748;
    border-bottom: 3px solid #667eea;
    padding-bottom: 10px;
    margin-bottom: 30px;
    font-weight: 600;
}

.faq-item {
    background: white;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    margin-bottom: 15px;
    overflow: hidden;
    transition: all 0.3s ease;
}

.faq-item:hover {
    box-shadow: 0 5px 20px rgba(0,0,0,0.1);
}

.faq-question {
    background: #f8f9fa;
    padding: 20px 25px;
    cursor: pointer;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-weight: 600;
    color: #2d3748;
    border: none;
    width: 100%;
    text-align: left;
    transition: all 0.3s ease;
}

.faq-question:hover {
    background: #e9ecef;
}

.faq-question.active {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
}

.faq-answer {
    padding: 0 25px;
    max-height: 0;
    overflow: hidden;
    transition: all 0.3s ease;
}

.faq-answer.active {
    padding: 25px;
    max-height: 500px;
}

.faq-answer p, .faq-answer li {
    color: #718096;
    line-height: 1.7;
    margin-bottom: 15px;
}

.faq-answer ul {
    padding-left: 25px;
}

.toggle-icon {
    transition: transform 0.3s ease;
}

.toggle-icon.rotated {
    transform: rotate(180deg);
}

.highlight-box {
    background: #f0f4ff;
    border-left: 4px solid #667eea;
    padding: 20px;
    margin: 20px 0;
    border-radius: 8px;
}

.contact-support {
    background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
    color: white;
    border-radius: 15px;
    padding: 30px;
    text-align: center;
    margin-top: 40px;
}

.contact-support a {
    color: white;
    text-decoration: underline;
}

@media (max-width: 768px) {
    .faq-header, .faq-body {
        padding: 30px 20px;
    }
    
    .faq-categories {
        grid-template-columns: 1fr;
    }
}
</style>

<div class="faq-container">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="faq-content">
                    <div class="faq-header">
                        <h1 class="mb-3">
                            <i class="fas fa-question-circle me-3"></i>
                            Preguntas Frecuentes
                        </h1>
                        <p class="mb-0 opacity-90">Encuentra respuestas rápidas a las preguntas más comunes sobre Obelis</p>
                    </div>
                    
                    <div class="faq-body">
                        <div class="faq-search">
                            <h3 class="mb-3">¿Tienes una pregunta específica?</h3>
                            <input type="text" id="faq-search" placeholder="Buscar en preguntas frecuentes..." class="form-control">
                        </div>
                        
                        <div class="faq-categories">
                            <a href="#general" class="category-card">
                                <i class="fas fa-info-circle category-icon"></i>
                                <h4>General</h4>
                                <p class="mb-0">Información básica sobre Obelis</p>
                            </a>
                            <a href="#studio" class="category-card">
                                <i class="fas fa-paint-brush category-icon"></i>
                                <h4>Obelis Studio</h4>
                                <p class="mb-0">Editor visual y proyectos</p>
                            </a>
                            <a href="#ia" class="category-card">
                                <i class="fas fa-robot category-icon"></i>
                                <h4>Herramientas IA</h4>
                                <p class="mb-0">Generación de contenido</p>
                            </a>
                            <a href="#cuenta" class="category-card">
                                <i class="fas fa-user category-icon"></i>
                                <h4>Cuenta y Suscripción</h4>
                                <p class="mb-0">Gestión de cuenta y pagos</p>
                            </a>
                        </div>
                        
                        <!-- Sección General -->
                        <div class="faq-section" id="general">
                            <h2><i class="fas fa-info-circle me-2"></i>General</h2>
                            
                            <div class="faq-item">
                                <button class="faq-question" onclick="toggleFaq(this)">
                                    ¿Qué es Obelis?
                                    <i class="fas fa-chevron-down toggle-icon"></i>
                                </button>
                                <div class="faq-answer">
                                    <p>Obelis es una plataforma completa de creación de contenido que combina herramientas de inteligencia artificial avanzadas con un editor visual intuitivo. Permite a usuarios de todos los niveles crear proyectos multimedia profesionales, desde textos e imágenes hasta experiencias interactivas completas.</p>
                                    <p>Nuestros servicios incluyen:</p>
                                    <ul>
                                        <li><strong>Obelis Studio:</strong> Editor visual de arrastrar y soltar</li>
                                        <li><strong>Herramientas de IA:</strong> Generación de texto, imágenes y audio</li>
                                        <li><strong>Plataforma Social:</strong> Comunidad para compartir y colaborar</li>
                                        <li><strong>Almacenamiento en la nube:</strong> Acceso desde cualquier dispositivo</li>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="faq-item">
                                <button class="faq-question" onclick="toggleFaq(this)">
                                    ¿Es gratis usar Obelis?
                                    <i class="fas fa-chevron-down toggle-icon"></i>
                                </button>
                                <div class="faq-answer">
                                    <p>Obelis ofrece tanto una versión gratuita como planes premium:</p>
                                    <ul>
                                        <li><strong>Plan Gratuito:</strong> Acceso a funciones básicas, creación limitada de contenido, proyectos públicos</li>
                                        <li><strong>Plan Premium:</strong> $19/mes o $190/año con acceso completo a todas las herramientas, generación ilimitada, proyectos privados y soporte prioritario</li>
                                    </ul>
                                    <p>Puedes comenzar gratis y actualizar cuando necesites más funcionalidades.</p>
                                </div>
                            </div>
                            
                            <div class="faq-item">
                                <button class="faq-question" onclick="toggleFaq(this)">
                                    ¿Necesito conocimientos técnicos para usar Obelis?
                                    <i class="fas fa-chevron-down toggle-icon"></i>
                                </button>
                                <div class="faq-answer">
                                    <p>¡No! Obelis está diseñado para ser accesible a usuarios de todos los niveles. Nuestra interfaz intuitiva de arrastrar y soltar permite crear contenido profesional sin conocimientos de programación o diseño avanzado.</p>
                                    <p>Ofrecemos:</p>
                                    <ul>
                                        <li>Plantillas prediseñadas</li>
                                        <li>Tutoriales paso a paso</li>
                                        <li>Asistencia de IA para generar contenido</li>
                                        <li>Comunidad de ayuda mutua</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Sección Obelis Studio -->
                        <div class="faq-section" id="studio">
                            <h2><i class="fas fa-paint-brush me-2"></i>Obelis Studio</h2>
                            
                            <div class="faq-item">
                                <button class="faq-question" onclick="toggleFaq(this)">
                                    ¿Qué puedo crear con Obelis Studio?
                                    <i class="fas fa-chevron-down toggle-icon"></i>
                                </button>
                                <div class="faq-answer">
                                    <p>Obelis Studio es increíblemente versátil. Puedes crear:</p>
                                    <ul>
                                        <li><strong>Presentaciones interactivas:</strong> Con multimedia y transiciones</li>
                                        <li><strong>Páginas web:</strong> Landing pages y sitios simples</li>
                                        <li><strong>Infografías:</strong> Visualizaciones de datos atractivas</li>
                                        <li><strong>Materiales educativos:</strong> Cursos y contenido didáctico</li>
                                        <li><strong>Portfolios:</strong> Galerías de trabajo profesional</li>
                                        <li><strong>Documentos multimedia:</strong> Reportes con elementos visuales</li>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="faq-item">
                                <button class="faq-question" onclick="toggleFaq(this)">
                                    ¿Cómo funciona el drag and drop desde Mis Creaciones?
                                    <i class="fas fa-chevron-down toggle-icon"></i>
                                </button>
                                <div class="faq-answer">
                                    <p>La función de arrastrar y soltar te permite usar fácilmente el contenido generado con IA en tus proyectos de Studio:</p>
                                    <ol>
                                        <li>Ve a tu página "Mis Creaciones"</li>
                                        <li>Encuentra el contenido que quieres usar (texto, imagen, audio)</li>
                                        <li>Arrastra el elemento directamente al editor de Studio</li>
                                        <li>El contenido se insertará automáticamente y podrás editarlo</li>
                                    </ol>
                                    <p>Esto acelera significativamente tu flujo de trabajo creativo.</p>
                                </div>
                            </div>
                            
                            <div class="faq-item">
                                <button class="faq-question" onclick="toggleFaq(this)">
                                    ¿Puedo colaborar con otros usuarios en Studio?
                                    <i class="fas fa-chevron-down toggle-icon"></i>
                                </button>
                                <div class="faq-answer">
                                    <p>Sí, Obelis Studio incluye funciones de colaboración:</p>
                                    <ul>
                                        <li><strong>Proyectos compartidos:</strong> Invita colaboradores a tu proyecto</li>
                                        <li><strong>Edición en tiempo real:</strong> Varios usuarios pueden trabajar simultáneamente</li>
                                        <li><strong>Control de versiones:</strong> Historial de cambios y restauración</li>
                                        <li><strong>Comentarios:</strong> Feedback directo en elementos específicos</li>
                                        <li><strong>Permisos:</strong> Controla quién puede ver o editar</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Sección Herramientas IA -->
                        <div class="faq-section" id="ia">
                            <h2><i class="fas fa-robot me-2"></i>Herramientas de IA</h2>
                            
                            <div class="faq-item">
                                <button class="faq-question" onclick="toggleFaq(this)">
                                    ¿Qué herramientas de IA están disponibles?
                                    <i class="fas fa-chevron-down toggle-icon"></i>
                                </button>
                                <div class="faq-answer">
                                    <p>Obelis incluye un conjunto completo de herramientas de IA:</p>
                                    <ul>
                                        <li><strong>Generador de Texto:</strong> Artículos, blogs, copy publicitario, scripts</li>
                                        <li><strong>Generador de Imágenes:</strong> Ilustraciones, fotos, logos, arte digital</li>
                                        <li><strong>Generador de Audio:</strong> Voz sintética, efectos sonoros, música</li>
                                        <li><strong>Editor Inteligente:</strong> Mejora automática de contenido existente</li>
                                        <li><strong>Traductor:</strong> Traducción automática a múltiples idiomas</li>
                                        <li><strong>Optimizador SEO:</strong> Mejora de contenido para buscadores</li>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="faq-item">
                                <button class="faq-question" onclick="toggleFaq(this)">
                                    ¿Hay límites en la generación de contenido?
                                    <i class="fas fa-chevron-down toggle-icon"></i>
                                </button>
                                <div class="faq-answer">
                                    <p>Los límites dependen de tu plan:</p>
                                    <div class="highlight-box">
                                        <strong>Plan Gratuito:</strong>
                                        <ul>
                                            <li>50 generaciones de texto al mes</li>
                                            <li>20 imágenes al mes</li>
                                            <li>10 minutos de audio al mes</li>
                                        </ul>
                                    </div>
                                    <div class="highlight-box">
                                        <strong>Plan Premium:</strong>
                                        <ul>
                                            <li>Generación ilimitada de texto</li>
                                            <li>Hasta 1000 imágenes al mes</li>
                                            <li>Hasta 5 horas de audio al mes</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="faq-item">
                                <button class="faq-question" onclick="toggleFaq(this)">
                                    ¿El contenido generado es original?
                                    <i class="fas fa-chevron-down toggle-icon"></i>
                                </button>
                                <div class="faq-answer">
                                    <p>Sí, todo el contenido generado por nuestras herramientas de IA es único y original. Sin embargo:</p>
                                    <ul>
                                        <li>El contenido se genera basado en patrones aprendidos de datos públicos</li>
                                        <li>Es tu responsabilidad verificar que el contenido cumpla con tus necesidades específicas</li>
                                        <li>Recomendamos revisar y editar el contenido generado</li>
                                        <li>Para uso comercial importante, considera una revisión adicional</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Sección Cuenta y Suscripción -->
                        <div class="faq-section" id="cuenta">
                            <h2><i class="fas fa-user me-2"></i>Cuenta y Suscripción</h2>
                            
                            <div class="faq-item">
                                <button class="faq-question" onclick="toggleFaq(this)">
                                    ¿Cómo actualizo mi cuenta a Premium?
                                    <i class="fas fa-chevron-down toggle-icon"></i>
                                </button>
                                <div class="faq-answer">
                                    <p>Actualizar a Premium es simple:</p>
                                    <ol>
                                        <li>Ve a tu perfil de usuario</li>
                                        <li>Haz clic en "Actualizar a Premium"</li>
                                        <li>Elige entre plan mensual ($19) o anual ($190)</li>
                                        <li>Completa el pago con tarjeta de crédito o PayPal</li>
                                        <li>¡Tu cuenta se actualizará inmediatamente!</li>
                                    </ol>
                                    <p>Los usuarios anuales ahorran aproximadamente 2 meses comparado con el plan mensual.</p>
                                </div>
                            </div>
                            
                            <div class="faq-item">
                                <button class="faq-question" onclick="toggleFaq(this)">
                                    ¿Puedo cancelar mi suscripción en cualquier momento?
                                    <i class="fas fa-chevron-down toggle-icon"></i>
                                </button>
                                <div class="faq-answer">
                                    <p>Sí, puedes cancelar tu suscripción cuando quieras:</p>
                                    <ul>
                                        <li>Ve a Configuración de Cuenta > Suscripción</li>
                                        <li>Haz clic en "Cancelar Suscripción"</li>
                                        <li>Confirma la cancelación</li>
                                        <li>Mantendrás acceso Premium hasta el final del período pagado</li>
                                        <li>Después, tu cuenta volverá al plan gratuito automáticamente</li>
                                    </ul>
                                    <p>No ofrecemos reembolsos por períodos no utilizados, pero puedes reactivar tu suscripción en cualquier momento.</p>
                                </div>
                            </div>
                            
                            <div class="faq-item">
                                <button class="faq-question" onclick="toggleFaq(this)">
                                    ¿Qué métodos de pago aceptan?
                                    <i class="fas fa-chevron-down toggle-icon"></i>
                                </button>
                                <div class="faq-answer">
                                    <p>Aceptamos múltiples métodos de pago seguros:</p>
                                    <ul>
                                        <li><strong>Tarjetas de crédito:</strong> Visa, MasterCard, American Express</li>
                                        <li><strong>Tarjetas de débito:</strong> Con logo Visa o MasterCard</li>
                                        <li><strong>PayPal:</strong> Pago directo desde tu cuenta PayPal</li>
                                        <li><strong>Apple Pay / Google Pay:</strong> En dispositivos compatibles</li>
                                    </ul>
                                    <p>Todos los pagos son procesados de forma segura a través de proveedores certificados. No almacenamos información de tarjetas en nuestros servidores.</p>
                                </div>
                            </div>
                            
                            <div class="faq-item">
                                <button class="faq-question" onclick="toggleFaq(this)">
                                    ¿Qué pasa con mis proyectos si cancelo Premium?
                                    <i class="fas fa-chevron-down toggle-icon"></i>
                                </button>
                                <div class="faq-answer">
                                    <p>Tus proyectos están seguros:</p>
                                    <ul>
                                        <li><strong>Proyectos existentes:</strong> Conservas acceso a todos tus proyectos</li>
                                        <li><strong>Funciones limitadas:</strong> Algunas características premium se deshabilitarán</li>
                                        <li><strong>Exportación:</strong> Puedes exportar tus proyectos en cualquier momento</li>
                                        <li><strong>Nuevos proyectos:</strong> Limitados a funciones del plan gratuito</li>
                                        <li><strong>Reactivación:</strong> Al renovar Premium, recuperas todas las funciones</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        
                        <div class="contact-support">
                            <h3><i class="fas fa-headset me-2"></i>¿No encontraste tu respuesta?</h3>
                            <p class="mb-3">Nuestro equipo de soporte está aquí para ayudarte con cualquier pregunta específica.</p>
                            <a href="<?php echo \ObelisIA\Router\MainRouter::url('soporte/contacto'); ?>" class="btn btn-light btn-lg me-3">
                                <i class="fas fa-envelope me-2"></i>Contactar Soporte
                            </a>
                            <a href="mailto:soporte@obelis.com" class="btn btn-outline-light btn-lg">
                                <i class="fas fa-paper-plane me-2"></i>soporte@obelis.com
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function toggleFaq(button) {
    const answer = button.nextElementSibling;
    const icon = button.querySelector('.toggle-icon');
    const isActive = answer.classList.contains('active');
    
    // Cerrar otras preguntas abiertas
    document.querySelectorAll('.faq-answer.active').forEach(item => {
        if (item !== answer) {
            item.classList.remove('active');
            item.previousElementSibling.classList.remove('active');
            item.previousElementSibling.querySelector('.toggle-icon').classList.remove('rotated');
        }
    });
    
    // Toggle la pregunta actual
    if (isActive) {
        answer.classList.remove('active');
        button.classList.remove('active');
        icon.classList.remove('rotated');
    } else {
        answer.classList.add('active');
        button.classList.add('active');
        icon.classList.add('rotated');
    }
}

// Funcionalidad de búsqueda
document.getElementById('faq-search').addEventListener('input', function(e) {
    const searchTerm = e.target.value.toLowerCase();
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question').textContent.toLowerCase();
        const answer = item.querySelector('.faq-answer').textContent.toLowerCase();
        
        if (question.includes(searchTerm) || answer.includes(searchTerm)) {
            item.style.display = 'block';
        } else {
            item.style.display = searchTerm === '' ? 'block' : 'none';
        }
    });
});

// Navegación suave para categorías
document.querySelectorAll('.category-card').forEach(card => {
    card.addEventListener('click', function(e) {
        e.preventDefault();
        const targetId = this.getAttribute('href').substring(1);
        const targetElement = document.getElementById(targetId);
        
        if (targetElement) {
            targetElement.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});
</script>