<?php
/**
 * pages/tools_page.php - VERSIÓN CORREGIDA Y COMPLETA
 * La variable $tool_slug es proporcionada por index.php
 */

// --- La lógica de PHP para obtener la herramienta y procesar el POST no cambia ---
$current_tool = null;
$result_data = null;
$page_title = "Herramientas IA";

if (isset($tool_slug)) {
    $stmt = $db->prepare("SELECT * FROM tools WHERE slug = ? AND is_active = 1");
    $stmt->execute([$tool_slug]);
    $current_tool = $stmt->fetch();
    if ($current_tool) {
        $page_title = $current_tool['name'] . " - ObelisIA";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $posted_slug = filter_var($_POST['tool_slug'] ?? '', FILTER_SANITIZE_STRING);
    if ($posted_slug && $current_tool && $posted_slug === $current_tool['slug']) {
        // Lista blanca de archivos PHP permitidos para herramientas
        $allowed_tool_files = [
            'TextGenerator.php',
            'ImageGenerator.php', 
            'MusicComposer.php',
            'VideoGenerator.php',
            'WordCounter.php',
            'BackgroundRemover.php',
            'ColorPaletteGenerator.php',
            'ContentCreator.php',
            'NEW_TextGenerator.php',
            'NEW_ImageGenerator.php',
            'NEW_MusicComposer.php',
            'NEW_ColorPaletteGenerator.php'
        ];
        
        // Validar que el archivo esté en la lista permitida
        if (!in_array($current_tool['php_file'], $allowed_tool_files)) {
            error_log("Intento de acceso a herramienta no permitida: " . $current_tool['php_file']);
            $result_data = ['error' => 'Herramienta no válida'];
        } else {
            $tool_logic_file = __DIR__ . '/../src/Tools/' . $current_tool['php_file'];
            // Validar que el archivo existe y está dentro del directorio esperado
            $real_path = realpath($tool_logic_file);
            $expected_dir = realpath(__DIR__ . '/../src/Tools/');
            
            if ($real_path && $expected_dir && str_starts_with($real_path, $expected_dir) && file_exists($tool_logic_file)) {
                include $tool_logic_file; // Esto creará la variable $result_data
            } else {
                error_log("Intento de acceso a archivo fuera del directorio permitido: " . $tool_logic_file);
                $result_data = ['error' => 'Archivo de herramienta no encontrado'];
            }
        }
    }
}

$tools_list = $db->query("SELECT name, slug, icon FROM tools WHERE is_active = 1 ORDER BY name ASC")->fetchAll();
?>

<link rel="stylesheet" href="<?php echo \ObelisIA\Router\MainRouter::url('/assets/css/tools/general/tools-modal.css'); ?>">

<body class="tools-page-body">

<div class="tools-page-container">
    <!-- Botón flotante para abrir modal de herramientas -->
    <button id="toolsModalToggle" class="tools-modal-toggle" aria-label="Abrir herramientas">
        <i class="fas fa-tools"></i>
    </button>

    <!-- Modal de herramientas -->
    <div id="toolsModal" class="tools-modal">
        <div class="tools-modal-overlay"></div>
        <div class="tools-modal-content">
            <div class="tools-modal-header">
                <h3><i class="fas fa-tools me-2"></i>Herramientas IA</h3>
                <button class="tools-modal-close" id="toolsModalClose">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="tools-modal-body">
                <div class="tools-grid">
                    <?php foreach ($tools_list as $tool_item): ?>
                        <a href="<?php echo \ObelisIA\Router\MainRouter::url('herramientas/' . $tool_item['slug']); ?>" 
                           class="tool-card <?php echo ($current_tool && $current_tool['slug'] === $tool_item['slug']) ? 'active' : ''; ?>">
                            <div class="tool-card-icon">
                                <i class="fas fa-<?php echo htmlspecialchars($tool_item['icon'] ?? 'cog'); ?>"></i>
                            </div>
                            <h4><?php echo htmlspecialchars($tool_item['name']); ?></h4>
                            <p>Herramienta de IA avanzada</p>
                        </a>
                    <?php endforeach; ?>
                    
                    <!-- Enlace al dashboard de estadísticas -->
                    <a href="/dashboard/stats.php" class="tool-card dashboard-card">
                        <div class="tool-card-icon">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <h4>Dashboard</h4>
                        <p>Estadísticas y análisis</p>
                    </a>
                </div>
                
                <div class="tools-modal-footer">
                    <div class="text-muted">
                        <i class="fas fa-info-circle me-1"></i>
                        <?php echo count($tools_list); ?> herramientas disponibles
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Contenido principal de la herramienta -->
    <main class="tool-main-content">
        <?php if ($current_tool): ?>
            
            <?php
            // Cargar el formulario (la "vista") de la herramienta con validación mejorada
            $view_filename = str_replace('.php', '_view.php', $current_tool['php_file']);
            
            // Lista blanca de archivos de vista permitidos
            $allowed_view_files = [
                'TextGenerator_view.php',
                'ImageGenerator_view.php', 
                'MusicComposer_view.php',
                'VideoGenerator_view.php',
                'WordCounter_view.php',
                'BackgroundRemover_view.php',
                'ColorPaletteGenerator_view.php',
                'ContentCreator_view.php',
                'NEW_TextGenerator_view.php',
                'NEW_ImageGenerator_view.php',
                'NEW_MusicComposer_view.php',
                'NEW_ColorPaletteGenerator_view.php'
            ];
            
            if (!in_array($view_filename, $allowed_view_files)) {
                echo "<div class='error-container'>";
                echo "<div class='error-content'>";
                echo "<i class='fas fa-exclamation-triangle fa-3x text-danger mb-3'></i>";
                echo "<h3>Error: Vista no permitida</h3>";
                echo "<p class='text-muted'>La vista solicitada no está en la lista de archivos permitidos.</p>";
                echo "<a href='/herramientas' class='btn btn-primary'>Volver a herramientas</a>";
                echo "</div>";
                echo "</div>";
            } else {
                $tool_view_file = __DIR__ . '/../src/Tools/views/' . $view_filename;
                // Validar que el archivo existe y está dentro del directorio esperado
                $real_view_path = realpath($tool_view_file);
                $expected_view_dir = realpath(__DIR__ . '/../src/Tools/views/');
                
                if ($real_view_path && $expected_view_dir && str_starts_with($real_view_path, $expected_view_dir) && file_exists($tool_view_file)) {
                    include $tool_view_file;
                } else {
                    echo "<div class='error-container'>";
                    echo "<div class='error-content'>";
                    echo "<i class='fas fa-exclamation-triangle fa-3x text-danger mb-3'></i>";
                    echo "<h3>Error: Vista no encontrada</h3>";
                    echo "<p class='text-muted'>No se encontró la vista para esta herramienta.</p>";
                    echo "<a href='/herramientas' class='btn btn-primary'>Volver a herramientas</a>";
                    echo "</div>";
                    echo "</div>";
                }
            }
            ?>

            <?php // La sección de resultados se mantiene igual, se mostrará debajo del contenido de la herramienta si existe.
            if (isset($result_data)): ?>
                <div id="results" class="results-container">
                    <div class="results-card">
                        <div class="results-header">
                            <h4><i class="fas fa-chart-line me-2"></i>Resultados</h4>
                        </div>
                        <div class="results-body">
                            <?php if (isset($result_data['error'])): ?>
                                <div class="alert alert-danger">
                                    <i class="fas fa-exclamation-circle me-2"></i>
                                    <?php echo htmlspecialchars($result_data['error']); ?>
                                </div>
                            <?php elseif ($current_tool['slug'] === 'generador-de-imagenes-ia'): ?>
                                <!-- Contenido específico para generador de imágenes -->
                            <?php else: ?>
                                <!-- Otros tipos de resultados -->
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

        <?php else: ?>
            <div class="welcome-container">
                <div class="welcome-content">
                    <div class="welcome-icon">
                        <i class="fas fa-tools fa-4x text-primary mb-4"></i>
                    </div>
                    <h1 class="welcome-title">Herramientas de IA</h1>
                    <p class="welcome-subtitle">Selecciona una herramienta del menú lateral para comenzar a crear contenido increíble</p>
                    <div class="welcome-stats">
                        <div class="stat-item">
                            <span class="stat-number"><?php echo count($tools_list); ?></span>
                            <span class="stat-label">Herramientas</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-number">∞</span>
                            <span class="stat-label">Posibilidades</span>
                        </div>
                    </div>
                    <button class="btn btn-primary btn-lg mt-4" onclick="openToolsModal()">
                        <i class="fas fa-rocket me-2"></i>Explorar Herramientas
                    </button>
                </div>
            </div>
        <?php endif; ?>
    </main>

</div>

<!-- JavaScript para el modal de herramientas -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const modalToggle = document.getElementById('toolsModalToggle');
    const modal = document.getElementById('toolsModal');
    const modalClose = document.getElementById('toolsModalClose');
    const modalOverlay = modal?.querySelector('.tools-modal-overlay');
    const modalContent = modal?.querySelector('.tools-modal-content');
    const body = document.body;

    let isModalOpen = false;

    function openModal() {
        if (isModalOpen) return;
        
        isModalOpen = true;
        modal.classList.add('active');
        body.classList.add('modal-open');
        body.style.overflow = 'hidden';
        
        // Animación de entrada
        setTimeout(() => {
            modalContent.style.transform = 'scale(1)';
            modalContent.style.opacity = '1';
        }, 10);
        
        // Animar botón
        modalToggle.style.transform = 'scale(1.1) rotate(180deg)';
        setTimeout(() => {
            modalToggle.style.transform = 'scale(1) rotate(180deg)';
        }, 200);
    }

    function closeModal() {
        if (!isModalOpen) return;
        
        isModalOpen = false;
        
        // Animación de salida
        modalContent.style.transform = 'scale(0.95)';
        modalContent.style.opacity = '0';
        
        setTimeout(() => {
            modal.classList.remove('active');
            body.classList.remove('modal-open');
            body.style.overflow = '';
            modalContent.style.transform = '';
            modalContent.style.opacity = '';
        }, 200);
        
        // Animar botón
        modalToggle.style.transform = 'scale(1.1) rotate(0deg)';
        setTimeout(() => {
            modalToggle.style.transform = 'scale(1) rotate(0deg)';
        }, 200);
    }

    // Event listeners
    modalToggle?.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        openModal();
    });

    modalClose?.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        closeModal();
    });

    modalOverlay?.addEventListener('click', function(e) {
        e.preventDefault();
        closeModal();
    });

    // Cerrar con ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && isModalOpen) {
            closeModal();
        }
    });

    // Prevenir cierre al hacer clic dentro del contenido
    modalContent?.addEventListener('click', function(e) {
        e.stopPropagation();
    });

    // Efectos en las tarjetas
    const toolCards = document.querySelectorAll('.tool-card');
    toolCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-8px) scale(1.02)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = '';
        });
        
        card.addEventListener('click', function() {
            // Cerrar modal al seleccionar herramienta
            setTimeout(closeModal, 100);
        });
    });

    // Función global
    window.openToolsModal = openModal;
    window.closeToolsModal = closeModal;
});

// Función global para abrir modal (usada en welcome)
function openToolsModal() {
    if (window.openToolsModal) {
        window.openToolsModal();
    }
}
</script>
