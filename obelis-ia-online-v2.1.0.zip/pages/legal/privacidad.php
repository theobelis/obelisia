<?php
$page_title = "Política de Privacidad - Obelis";
?>

<style>
.legal-container {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    min-height: 100vh;
    padding: 40px 0;
}

.legal-content {
    background: white;
    border-radius: 20px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.1);
    overflow: hidden;
}

.legal-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 40px;
    text-align: center;
}

.legal-body {
    padding: 40px;
}

.section {
    margin-bottom: 35px;
    padding-bottom: 25px;
    border-bottom: 1px solid #e9ecef;
}

.section:last-child {
    border-bottom: none;
    margin-bottom: 0;
}

.section h2 {
    color: #2d3748;
    margin-bottom: 20px;
    font-weight: 600;
    font-size: 1.5rem;
}

.section h3 {
    color: #4a5568;
    margin: 25px 0 15px;
    font-weight: 600;
    font-size: 1.2rem;
}

.section p, .section li {
    color: #718096;
    line-height: 1.7;
    margin-bottom: 15px;
}

.section ul {
    padding-left: 25px;
}

.highlight-box {
    background: #f0f4ff;
    border-left: 4px solid #667eea;
    padding: 20px;
    margin: 20px 0;
    border-radius: 8px;
}

.contact-info {
    background: #f8f9fa;
    border-radius: 12px;
    padding: 25px;
    margin: 30px 0;
}

.last-updated {
    background: #e6fffa;
    border: 1px solid #b2f5ea;
    border-radius: 8px;
    padding: 15px;
    margin-bottom: 30px;
    text-align: center;
}

@media (max-width: 768px) {
    .legal-header, .legal-body {
        padding: 30px 20px;
    }
}
</style>

<div class="legal-container">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="legal-content">
                    <div class="legal-header">
                        <h1 class="mb-3">
                            <i class="fas fa-shield-alt me-3"></i>
                            Política de Privacidad
                        </h1>
                        <p class="mb-0 opacity-90">Tu privacidad es fundamental para nosotros</p>
                    </div>
                    
                    <div class="legal-body">
                        <div class="last-updated">
                            <strong>Última actualización:</strong> 7 de agosto de 2025
                        </div>
                        
                        <div class="section">
                            <h2>1. Introducción</h2>
                            <p>En Obelis, respetamos tu privacidad y nos comprometemos a proteger la información personal que compartes con nosotros. Esta Política de Privacidad describe cómo recopilamos, usamos, almacenamos y protegemos tu información cuando utilizas nuestros servicios, incluyendo:</p>
                            <ul>
                                <li><strong>Obelis Studio:</strong> Nuestro editor visual de proyectos multimedia</li>
                                <li><strong>Herramientas de IA:</strong> Generación de texto, imágenes y audio</li>
                                <li><strong>Plataforma Social:</strong> Comunidad y compartición de contenido</li>
                                <li><strong>Servicios Premium:</strong> Funcionalidades avanzadas de suscripción</li>
                            </ul>
                        </div>
                        
                        <div class="section">
                            <h2>2. Información que Recopilamos</h2>
                            
                            <h3>2.1 Información de Cuenta</h3>
                            <ul>
                                <li>Nombre y apellidos</li>
                                <li>Dirección de correo electrónico</li>
                                <li>Contraseña (encriptada)</li>
                                <li>Foto de perfil (opcional)</li>
                                <li>Información de facturación para suscripciones premium</li>
                            </ul>
                            
                            <h3>2.2 Contenido Creado</h3>
                            <ul>
                                <li>Proyectos creados en Obelis Studio</li>
                                <li>Contenido generado con herramientas de IA</li>
                                <li>Textos, imágenes y archivos multimedia subidos</li>
                                <li>Configuraciones de proyectos y preferencias</li>
                            </ul>
                            
                            <h3>2.3 Información de Uso</h3>
                            <ul>
                                <li>Actividad en la plataforma</li>
                                <li>Herramientas y funciones utilizadas</li>
                                <li>Tiempo y frecuencia de uso</li>
                                <li>Interacciones sociales (likes, comentarios, seguimientos)</li>
                            </ul>
                            
                            <h3>2.4 Información Técnica</h3>
                            <ul>
                                <li>Dirección IP</li>
                                <li>Tipo de navegador y dispositivo</li>
                                <li>Sistema operativo</li>
                                <li>Cookies y tecnologías similares</li>
                            </ul>
                        </div>
                        
                        <div class="section">
                            <h2>3. Cómo Utilizamos tu Información</h2>
                            
                            <h3>3.1 Provisión del Servicio</h3>
                            <ul>
                                <li>Crear y mantener tu cuenta</li>
                                <li>Procesar y almacenar tus proyectos</li>
                                <li>Ejecutar herramientas de IA según tus solicitudes</li>
                                <li>Sincronizar datos entre dispositivos</li>
                            </ul>
                            
                            <h3>3.2 Mejora del Producto</h3>
                            <ul>
                                <li>Analizar patrones de uso para optimizar funcionalidades</li>
                                <li>Entrenar modelos de IA (solo con datos anonimizados)</li>
                                <li>Identificar y solucionar problemas técnicos</li>
                                <li>Desarrollar nuevas características</li>
                            </ul>
                            
                            <h3>3.3 Comunicación</h3>
                            <ul>
                                <li>Enviar confirmaciones de cuenta y transacciones</li>
                                <li>Notificar actualizaciones del servicio</li>
                                <li>Proporcionar soporte técnico</li>
                                <li>Enviar newsletter (solo con consentimiento)</li>
                            </ul>
                        </div>
                        
                        <div class="section">
                            <h2>4. Protección de Datos</h2>
                            
                            <div class="highlight-box">
                                <strong>Seguridad de Primera Clase:</strong> Implementamos medidas de seguridad técnicas y organizativas para proteger tu información contra acceso no autorizado, alteración, divulgación o destrucción.
                            </div>
                            
                            <h3>4.1 Medidas Técnicas</h3>
                            <ul>
                                <li>Encriptación SSL/TLS para todas las transmisiones</li>
                                <li>Encriptación de contraseñas con algoritmos seguros</li>
                                <li>Autenticación de dos factores disponible</li>
                                <li>Respaldos seguros y redundantes</li>
                            </ul>
                            
                            <h3>4.2 Medidas Organizativas</h3>
                            <ul>
                                <li>Acceso limitado al personal autorizado</li>
                                <li>Capacitación regular en privacidad y seguridad</li>
                                <li>Auditorías de seguridad periódicas</li>
                                <li>Políticas internas de protección de datos</li>
                            </ul>
                        </div>
                        
                        <div class="section">
                            <h2>5. Compartición de Información</h2>
                            
                            <p><strong>No vendemos tu información personal.</strong> Solo compartimos información en circunstancias específicas:</p>
                            
                            <h3>5.1 Con tu Consentimiento</h3>
                            <ul>
                                <li>Proyectos marcados como públicos en la comunidad</li>
                                <li>Información de perfil visible (nombre, foto)</li>
                                <li>Contenido compartido voluntariamente</li>
                            </ul>
                            
                            <h3>5.2 Proveedores de Servicios</h3>
                            <ul>
                                <li>Procesadores de pagos (PayPal, Stripe) - solo datos necesarios</li>
                                <li>Servicios de almacenamiento en la nube</li>
                                <li>Proveedores de IA para procesamiento de contenido</li>
                                <li>Servicios de análisis (datos anonimizados)</li>
                            </ul>
                            
                            <h3>5.3 Obligaciones Legales</h3>
                            <ul>
                                <li>Cumplimiento de órdenes judiciales</li>
                                <li>Prevención de fraude o actividades ilegales</li>
                                <li>Protección de derechos y seguridad</li>
                            </ul>
                        </div>
                        
                        <div class="section">
                            <h2>6. Tus Derechos</h2>
                            
                            <h3>6.1 Acceso y Control</h3>
                            <ul>
                                <li><strong>Acceso:</strong> Ver toda la información que tenemos sobre ti</li>
                                <li><strong>Rectificación:</strong> Corregir información inexacta</li>
                                <li><strong>Eliminación:</strong> Solicitar borrado de tu cuenta y datos</li>
                                <li><strong>Portabilidad:</strong> Exportar tus datos en formato estándar</li>
                            </ul>
                            
                            <h3>6.2 Configuración de Privacidad</h3>
                            <ul>
                                <li>Controlar visibilidad de proyectos</li>
                                <li>Gestionar notificaciones</li>
                                <li>Configurar preferencias de cookies</li>
                                <li>Opt-out de comunicaciones promocionales</li>
                            </ul>
                        </div>
                        
                        <div class="section">
                            <h2>7. Cookies y Tecnologías de Seguimiento</h2>
                            
                            <h3>7.1 Tipos de Cookies</h3>
                            <ul>
                                <li><strong>Esenciales:</strong> Necesarias para el funcionamiento básico</li>
                                <li><strong>Funcionalidad:</strong> Recordar preferencias y configuraciones</li>
                                <li><strong>Analíticas:</strong> Entender el uso de la plataforma</li>
                                <li><strong>Publicitarias:</strong> Mostrar contenido relevante (con consentimiento)</li>
                            </ul>
                            
                            <h3>7.2 Control de Cookies</h3>
                            <p>Puedes gestionar las cookies a través de:</p>
                            <ul>
                                <li>Configuración de tu navegador</li>
                                <li>Panel de preferencias en tu cuenta</li>
                                <li>Banner de cookies en tu primera visita</li>
                            </ul>
                        </div>
                        
                        <div class="section">
                            <h2>8. Retención de Datos</h2>
                            
                            <ul>
                                <li><strong>Cuentas Activas:</strong> Mientras mantengas tu cuenta</li>
                                <li><strong>Cuentas Eliminadas:</strong> 30 días para recuperación, luego eliminación completa</li>
                                <li><strong>Datos de Facturación:</strong> 7 años por obligaciones fiscales</li>
                                <li><strong>Logs de Sistema:</strong> 12 meses para seguridad y debugging</li>
                            </ul>
                        </div>
                        
                        <div class="section">
                            <h2>9. Transferencias Internacionales</h2>
                            
                            <p>Algunos de nuestros proveedores pueden estar ubicados fuera de tu país. Garantizamos que cualquier transferencia internacional cumple con:</p>
                            <ul>
                                <li>Decisiones de adecuación de la Comisión Europea</li>
                                <li>Cláusulas contractuales estándar</li>
                                <li>Certificaciones de privacidad reconocidas</li>
                                <li>Medidas adicionales de seguridad cuando sea necesario</li>
                            </ul>
                        </div>
                        
                        <div class="section">
                            <h2>10. Privacidad de Menores</h2>
                            
                            <div class="highlight-box">
                                <strong>Importante:</strong> Obelis está dirigido a usuarios mayores de 13 años. Si eres menor de 16 años, necesitas el consentimiento de tus padres o tutores.
                            </div>
                            
                            <ul>
                                <li>No recopilamos conscientemente datos de menores de 13 años</li>
                                <li>Para usuarios de 13-16 años, requerimos consentimiento parental</li>
                                <li>Si detectamos datos de menores sin consentimiento, los eliminamos inmediatamente</li>
                            </ul>
                        </div>
                        
                        <div class="section">
                            <h2>11. Cambios en esta Política</h2>
                            
                            <p>Podemos actualizar esta Política de Privacidad ocasionalmente. Te notificaremos sobre cambios importantes mediante:</p>
                            <ul>
                                <li>Email a tu dirección registrada</li>
                                <li>Notificación en la plataforma</li>
                                <li>Actualización de la fecha en esta página</li>
                            </ul>
                            
                            <p>Tu uso continuado del servicio después de los cambios constituye aceptación de la nueva política.</p>
                        </div>
                        
                        <div class="contact-info">
                            <h2>
                                <i class="fas fa-envelope text-primary me-2"></i>
                                Contacto
                            </h2>
                            <p>Para cualquier pregunta sobre esta Política de Privacidad o ejercer tus derechos, contáctanos:</p>
                            <ul class="list-unstyled">
                                <li><strong>Email:</strong> privacidad@obelis.com</li>
                                <li><strong>Formulario:</strong> <a href="<?php echo \ObelisIA\Router\MainRouter::url('soporte/contacto'); ?>">Centro de Soporte</a></li>
                                <li><strong>Dirección:</strong> Disponible en nuestro sitio web</li>
                            </ul>
                            
                            <p class="mb-0 text-muted">
                                <i class="fas fa-info-circle me-1"></i>
                                Nos esforzamos por responder a todas las consultas en un plazo máximo de 30 días.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>