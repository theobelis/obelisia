<?php
$page_title = "Términos y Condiciones - Obelis";
?>

<style>
.legal-container {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    min-height: 100vh;
    padding: 40px 0;
}

.legal-content {
    background: white;
    border-radius: 20px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.1);
    overflow: hidden;
}

.legal-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 40px;
    text-align: center;
}

.legal-body {
    padding: 40px;
}

.section {
    margin-bottom: 35px;
    padding-bottom: 25px;
    border-bottom: 1px solid #e9ecef;
}

.section:last-child {
    border-bottom: none;
    margin-bottom: 0;
}

.section h2 {
    color: #2d3748;
    margin-bottom: 20px;
    font-weight: 600;
    font-size: 1.5rem;
}

.section h3 {
    color: #4a5568;
    margin: 25px 0 15px;
    font-weight: 600;
    font-size: 1.2rem;
}

.section p, .section li {
    color: #718096;
    line-height: 1.7;
    margin-bottom: 15px;
}

.section ul {
    padding-left: 25px;
}

.highlight-box {
    background: #f0f4ff;
    border-left: 4px solid #667eea;
    padding: 20px;
    margin: 20px 0;
    border-radius: 8px;
}

.warning-box {
    background: #fff8e1;
    border-left: 4px solid #ff9800;
    padding: 20px;
    margin: 20px 0;
    border-radius: 8px;
}

.contact-info {
    background: #f8f9fa;
    border-radius: 12px;
    padding: 25px;
    margin: 30px 0;
}

.last-updated {
    background: #e6fffa;
    border: 1px solid #b2f5ea;
    border-radius: 8px;
    padding: 15px;
    margin-bottom: 30px;
    text-align: center;
}

.pricing-table {
    background: #f8f9fa;
    border-radius: 12px;
    padding: 20px;
    margin: 20px 0;
}

.pricing-table table {
    width: 100%;
    margin: 0;
}

.pricing-table th, .pricing-table td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #dee2e6;
}

@media (max-width: 768px) {
    .legal-header, .legal-body {
        padding: 30px 20px;
    }
}
</style>

<div class="legal-container">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="legal-content">
                    <div class="legal-header">
                        <h1 class="mb-3">
                            <i class="fas fa-file-contract me-3"></i>
                            Términos y Condiciones
                        </h1>
                        <p class="mb-0 opacity-90">Condiciones de uso de los servicios Obelis</p>
                    </div>
                    
                    <div class="legal-body">
                        <div class="last-updated">
                            <strong>Última actualización:</strong> 7 de agosto de 2025
                        </div>
                        
                        <div class="section">
                            <h2>1. Aceptación de los Términos</h2>
                            <p>Al acceder y utilizar los servicios de Obelis, incluyendo nuestro sitio web, aplicaciones móviles, Obelis Studio, herramientas de inteligencia artificial y cualquier otro servicio relacionado (colectivamente, "los Servicios"), usted acepta quedar vinculado por estos Términos y Condiciones ("Términos").</p>
                            
                            <div class="highlight-box">
                                <strong>Importante:</strong> Si no está de acuerdo con alguna parte de estos términos, no debe utilizar nuestros servicios.
                            </div>
                            
                            <p>Estos Términos constituyen un acuerdo legal entre usted ("Usuario" o "usted") y Obelis ("nosotros", "nuestro" o "la Empresa").</p>
                        </div>
                        
                        <div class="section">
                            <h2>2. Descripción de los Servicios</h2>
                            
                            <h3>2.1 Obelis Studio</h3>
                            <p>Una plataforma de diseño visual que permite crear, editar y gestionar proyectos multimedia mediante una interfaz intuitiva de arrastrar y soltar.</p>
                            
                            <h3>2.2 Herramientas de Inteligencia Artificial</h3>
                            <ul>
                                <li><strong>Generación de Texto:</strong> Creación automática de contenido textual</li>
                                <li><strong>Generación de Imágenes:</strong> Creación de imágenes basada en descripciones</li>
                                <li><strong>Generación de Audio:</strong> Síntesis de voz y efectos sonoros</li>
                                <li><strong>Edición Inteligente:</strong> Mejoras automáticas de contenido</li>
                            </ul>
                            
                            <h3>2.3 Plataforma Social</h3>
                            <ul>
                                <li>Compartición de proyectos y creaciones</li>
                                <li>Comunidad de usuarios y colaboración</li>
                                <li>Sistema de seguimiento y notificaciones</li>
                                <li>Comentarios y valoraciones</li>
                            </ul>
                            
                            <h3>2.4 Servicios Premium</h3>
                            <ul>
                                <li>Acceso completo a todas las herramientas</li>
                                <li>Capacidades avanzadas de IA</li>
                                <li>Almacenamiento ampliado</li>
                                <li>Soporte prioritario</li>
                            </ul>
                        </div>
                        
                        <div class="section">
                            <h2>3. Registro y Cuenta de Usuario</h2>
                            
                            <h3>3.1 Requisitos de Registro</h3>
                            <ul>
                                <li>Debe ser mayor de 13 años para usar nuestros servicios</li>
                                <li>Si es menor de 16 años, necesita consentimiento parental</li>
                                <li>Debe proporcionar información precisa y completa</li>
                                <li>Es responsable de mantener la seguridad de su cuenta</li>
                            </ul>
                            
                            <h3>3.2 Responsabilidades del Usuario</h3>
                            <ul>
                                <li>Mantener la confidencialidad de sus credenciales</li>
                                <li>Notificar inmediatamente cualquier uso no autorizado</li>
                                <li>Actualizar información de cuenta cuando sea necesario</li>
                                <li>Cumplir con todos los términos y políticas aplicables</li>
                            </ul>
                        </div>
                        
                        <div class="section">
                            <h2>4. Uso Aceptable</h2>
                            
                            <h3>4.1 Usos Permitidos</h3>
                            <ul>
                                <li>Crear contenido original y legítimo</li>
                                <li>Compartir proyectos respetando derechos de autor</li>
                                <li>Colaborar de manera constructiva en la comunidad</li>
                                <li>Usar las herramientas para fines creativos y profesionales</li>
                            </ul>
                            
                            <h3>4.2 Usos Prohibidos</h3>
                            <div class="warning-box">
                                <strong>Está estrictamente prohibido:</strong>
                            </div>
                            <ul>
                                <li>Crear contenido ilegal, amenazante, abusivo o difamatorio</li>
                                <li>Generar contenido que infrinja derechos de propiedad intelectual</li>
                                <li>Crear material pornográfico, violento o que promueva odio</li>
                                <li>Intentar acceder sin autorización a sistemas o datos</li>
                                <li>Distribuir malware, virus o código malicioso</li>
                                <li>Realizar ingeniería inversa de nuestros servicios</li>
                                <li>Usar los servicios para spam o actividades comerciales no autorizadas</li>
                                <li>Suplantar identidades o crear cuentas falsas</li>
                            </ul>
                        </div>
                        
                        <div class="section">
                            <h2>5. Propiedad Intelectual</h2>
                            
                            <h3>5.1 Su Contenido</h3>
                            <ul>
                                <li>Usted conserva todos los derechos sobre el contenido que crea</li>
                                <li>Nos otorga una licencia limitada para alojar y mostrar su contenido</li>
                                <li>Es responsable de garantizar que tiene derechos sobre todo el contenido que sube</li>
                                <li>Puede eliminar su contenido en cualquier momento</li>
                            </ul>
                            
                            <h3>5.2 Nuestro Contenido</h3>
                            <ul>
                                <li>Los servicios de Obelis están protegidos por derechos de autor y otras leyes</li>
                                <li>No puede copiar, modificar o distribuir nuestro software sin permiso</li>
                                <li>Las marcas comerciales de Obelis son de nuestra propiedad exclusiva</li>
                                <li>Respetamos los derechos de propiedad intelectual de terceros</li>
                            </ul>
                            
                            <h3>5.3 Contenido Generado por IA</h3>
                            <ul>
                                <li>El contenido generado mediante nuestras herramientas de IA se considera suyo</li>
                                <li>Debe cumplir con las leyes aplicables de derechos de autor</li>
                                <li>No podemos garantizar la originalidad absoluta del contenido generado</li>
                                <li>Es su responsabilidad verificar y garantizar el uso legal del contenido</li>
                            </ul>
                        </div>
                        
                        <div class="section">
                            <h2>6. Suscripciones y Pagos</h2>
                            
                            <div class="pricing-table">
                                <h3>6.1 Planes de Suscripción</h3>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Plan</th>
                                            <th>Precio Mensual</th>
                                            <th>Precio Anual</th>
                                            <th>Características</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><strong>Gratuito</strong></td>
                                            <td>$0</td>
                                            <td>$0</td>
                                            <td>Funciones básicas limitadas</td>
                                        </tr>
                                        <tr>
                                            <td><strong>Premium</strong></td>
                                            <td>$19</td>
                                            <td>$190</td>
                                            <td>Acceso completo a todas las funciones</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            
                            <h3>6.2 Términos de Pago</h3>
                            <ul>
                                <li>Los precios están en dólares estadounidenses (USD)</li>
                                <li>Las suscripciones se renuevan automáticamente</li>
                                <li>Los pagos se procesan de forma segura a través de terceros</li>
                                <li>Todos los pagos son no reembolsables salvo excepcioneslegales</li>
                            </ul>
                            
                            <h3>6.3 Cancelación y Reembolsos</h3>
                            <ul>
                                <li>Puede cancelar su suscripción en cualquier momento</li>
                                <li>La cancelación será efectiva al final del período facturado</li>
                                <li>No ofrecemos reembolsos por períodos no utilizados</li>
                                <li>Mantendrá acceso hasta el final del período pagado</li>
                            </ul>
                        </div>
                        
                        <div class="section">
                            <h2>7. Privacidad y Protección de Datos</h2>
                            
                            <p>Su privacidad es importante para nosotros. El uso de nuestros servicios también está regido por nuestra <a href="<?php echo \ObelisIA\Router\MainRouter::url('legal/privacidad'); ?>">Política de Privacidad</a>, que forma parte integral de estos términos.</p>
                            
                            <h3>7.1 Recopilación de Datos</h3>
                            <ul>
                                <li>Recopilamos solo los datos necesarios para proporcionar nuestros servicios</li>
                                <li>Sus proyectos y creaciones son privados por defecto</li>
                                <li>Puede controlar la visibilidad de su contenido</li>
                                <li>Implementamos medidas de seguridad para proteger sus datos</li>
                            </ul>
                        </div>
                        
                        <div class="section">
                            <h2>8. Disponibilidad del Servicio</h2>
                            
                            <h3>8.1 Disponibilidad</h3>
                            <ul>
                                <li>Nos esforzamos por mantener nuestros servicios disponibles 24/7</li>
                                <li>Puede haber interrupciones ocasionales por mantenimiento</li>
                                <li>No garantizamos disponibilidad ininterrumpida</li>
                                <li>Notificaremos sobre mantenimientos programados cuando sea posible</li>
                            </ul>
                            
                            <h3>8.2 Modificaciones del Servicio</h3>
                            <ul>
                                <li>Podemos actualizar, modificar o discontinuar funciones</li>
                                <li>Notificaremos cambios significativos con anticipación</li>
                                <li>Las mejoras y nuevas características pueden requerir suscripción premium</li>
                            </ul>
                        </div>
                        
                        <div class="section">
                            <h2>9. Limitación de Responsabilidad</h2>
                            
                            <div class="warning-box">
                                <strong>Limitaciones Importantes:</strong> Los servicios se proporcionan "tal como están" sin garantías de ningún tipo.
                            </div>
                            
                            <h3>9.1 Exclusión de Garantías</h3>
                            <ul>
                                <li>No garantizamos que los servicios sean libres de errores</li>
                                <li>No garantizamos resultados específicos del uso de nuestras herramientas</li>
                                <li>El contenido generado por IA puede tener limitaciones o inexactitudes</li>
                                <li>Es su responsabilidad respaldar su contenido importante</li>
                            </ul>
                            
                            <h3>9.2 Limitación de Daños</h3>
                            <ul>
                                <li>Nuestra responsabilidad total está limitada al monto pagado por los servicios</li>
                                <li>No somos responsables de daños indirectos o consecuenciales</li>
                                <li>No somos responsables de pérdida de datos o ganancias</li>
                                <li>Algunas jurisdicciones no permiten estas limitaciones</li>
                            </ul>
                        </div>
                        
                        <div class="section">
                            <h2>10. Terminación</h2>
                            
                            <h3>10.1 Terminación por el Usuario</h3>
                            <ul>
                                <li>Puede terminar su cuenta en cualquier momento</li>
                                <li>La terminación no afecta obligaciones ya contraídas</li>
                                <li>Puede exportar su contenido antes de la terminación</li>
                            </ul>
                            
                            <h3>10.2 Terminación por Obelis</h3>
                            <ul>
                                <li>Podemos suspender o terminar cuentas por violación de términos</li>
                                <li>Proporcionaremos aviso cuando sea posible</li>
                                <li>En casos graves, la terminación puede ser inmediata</li>
                                <li>La terminación puede resultar en pérdida de acceso y contenido</li>
                            </ul>
                        </div>
                        
                        <div class="section">
                            <h2>11. Resolución de Disputas</h2>
                            
                            <h3>11.1 Proceso de Resolución</h3>
                            <ul>
                                <li>Primero, intente resolver disputas contactando nuestro soporte</li>
                                <li>Proporcionaremos un proceso de mediación para resolver conflictos</li>
                                <li>Las disputas no resueltas pueden requerir arbitraje</li>
                            </ul>
                            
                            <h3>11.2 Ley Aplicable</h3>
                            <ul>
                                <li>Estos términos se rigen por las leyes de la jurisdicción aplicable</li>
                                <li>Las disputas se resolverán en los tribunales competentes</li>
                                <li>Se aplican las protecciones del consumidor según la ley local</li>
                            </ul>
                        </div>
                        
                        <div class="section">
                            <h2>12. Cambios en los Términos</h2>
                            
                            <p>Podemos actualizar estos Términos ocasionalmente para reflejar:</p>
                            <ul>
                                <li>Cambios en nuestros servicios</li>
                                <li>Nuevos requisitos legales</li>
                                <li>Mejoras en nuestras políticas</li>
                            </ul>
                            
                            <h3>12.1 Notificación de Cambios</h3>
                            <ul>
                                <li>Notificaremos cambios significativos por email</li>
                                <li>Los cambios serán efectivos 30 días después de la notificación</li>
                                <li>Su uso continuado constituye aceptación de los nuevos términos</li>
                                <li>Si no acepta los cambios, debe discontinuar el uso del servicio</li>
                            </ul>
                        </div>
                        
                        <div class="section">
                            <h2>13. Disposiciones Generales</h2>
                            
                            <h3>13.1 Divisibilidad</h3>
                            <p>Si alguna disposición de estos términos se considera inválida, el resto permanecerá en efecto.</p>
                            
                            <h3>13.2 Acuerdo Completo</h3>
                            <p>Estos términos, junto con nuestra Política de Privacidad, constituyen el acuerdo completo entre usted y Obelis.</p>
                            
                            <h3>13.3 Renuncia</h3>
                            <p>La falta de ejercicio de cualquier derecho no constituye una renuncia a ese derecho.</p>
                            
                            <h3>13.4 Asignación</h3>
                            <p>No puede transferir sus derechos bajo estos términos sin nuestro consentimiento escrito.</p>
                        </div>
                        
                        <div class="contact-info">
                            <h2>
                                <i class="fas fa-gavel text-primary me-2"></i>
                                Contacto Legal
                            </h2>
                            <p>Para preguntas sobre estos Términos y Condiciones:</p>
                            <ul class="list-unstyled">
                                <li><strong>Email Legal:</strong> legal@obelis.com</li>
                                <li><strong>Soporte General:</strong> soporte@obelis.com</li>
                                <li><strong>Centro de Ayuda:</strong> <a href="<?php echo \ObelisIA\Router\MainRouter::url('soporte/contacto'); ?>">Formulario de Contacto</a></li>
                            </ul>
                            
                            <div class="highlight-box mt-3">
                                <strong>¿Tienes preguntas?</strong> Nuestro equipo legal está disponible para aclarar cualquier duda sobre estos términos y su aplicación a su uso específico de nuestros servicios.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
