<?php
// Listado público de posts del blog
require_once __DIR__ . '/../../src/Database/Database.php';
use ObelisIA\Database\Database;

$dbClass = new Database();
$pdo = $dbClass->getConnection();
$stmt = $pdo->query("SELECT * FROM blog_posts WHERE status='publicado' ORDER BY date_published DESC, id DESC");
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog | ObelisIA</title>
    <link rel="stylesheet" href="/assets/css/blog.css">
</head>
<body>
    <main class="container py-4">
        <h1 class="mb-4"><i class="fas fa-blog me-2"></i>Blog de ObelisIA</h1>
        <div class="row">
            <?php foreach ($posts as $post): ?>
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="card h-100">
                    <?php if ($post['image']): ?>
                        <img src="<?php echo htmlspecialchars($post['image']); ?>" class="card-img-top" alt="Imagen del post">
                    <?php endif; ?>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($post['headline']); ?></h5>
                        <p class="card-text text-muted small mb-1">
                            <i class="fas fa-user"></i> <?php echo htmlspecialchars($post['author']); ?> |
                            <i class="fas fa-calendar"></i> <?php echo date('d/m/Y', strtotime($post['date_published'])); ?>
                        </p>
                        <p class="card-text"><?php echo htmlspecialchars($post['description']); ?></p>
                        <a href="post.php?id=<?php echo $post['id']; ?>" class="btn btn-primary btn-sm">Leer más</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php if (empty($posts)): ?>
            <div class="alert alert-info">Aún no hay publicaciones en el blog.</div>
        <?php endif; ?>
    </main>
</body>
</html>
