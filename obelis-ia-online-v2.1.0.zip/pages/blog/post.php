<?php
// Vista pública de un post individual
require_once __DIR__ . '/../../src/Database/Database.php';
use ObelisIA\Database\Database;

$dbClass = new Database();
$pdo = $dbClass->getConnection();
$id = intval($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM blog_posts WHERE id=? AND status='publicado'");
$stmt->execute([$id]);
$post = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$post) {
    http_response_code(404);
    echo '<h1>Post no encontrado</h1>';
    exit;
}
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($post['headline']); ?> | Blog ObelisIA</title>
    <link rel="stylesheet" href="/assets/css/blog.css">
</head>
<body>
    <main class="container py-4">
        <a href="index.php" class="btn btn-link mb-3"><i class="fas fa-arrow-left"></i> Volver al blog</a>
        <article class="blog-post">
            <h1><?php echo htmlspecialchars($post['headline']); ?></h1>
            <?php if ($post['alt_headline']): ?>
                <h2 class="h5 text-muted"><?php echo htmlspecialchars($post['alt_headline']); ?></h2>
            <?php endif; ?>
            <p class="text-muted small mb-2">
                <i class="fas fa-user"></i> <?php echo htmlspecialchars($post['author']); ?> |
                <i class="fas fa-calendar"></i> <?php echo date('d/m/Y', strtotime($post['date_published'])); ?>
            </p>
            <?php if ($post['image']): ?>
                <img src="<?php echo htmlspecialchars($post['image']); ?>" class="img-fluid mb-3" alt="Imagen del post">
            <?php endif; ?>
            <div class="mb-3">
                <span class="badge bg-secondary"><?php echo htmlspecialchars($post['genre']); ?></span>
                <?php if ($post['keywords']): ?>
                    <span class="badge bg-info text-dark"><?php echo htmlspecialchars($post['keywords']); ?></span>
                <?php endif; ?>
            </div>
            <p class="lead"><?php echo htmlspecialchars($post['description']); ?></p>
            <div class="blog-content">
                <?php echo nl2br(htmlspecialchars($post['content'])); ?>
            </div>
        </article>
    </main>
</body>
</html>
