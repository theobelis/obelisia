<?php
// Plantilla base para un post de blog dinámico en ObelisIA
// Copia este archivo y personaliza las variables para cada nuevo post

$blog_headline = "ObelisIA lanza nuevas herramientas de IA para creadores";
$blog_alt_headline = "Nuevas funciones de IA para potenciar tu creatividad";
$blog_image = "https://obelis.online/assets/img/social-share-default.jpg";
$blog_editor = "ObelisIA Team";
$blog_genre = "Tecnología, IA, Creatividad";
$blog_keywords = "IA, inteligencia artificial, herramientas, creatividad, blog";
$blog_wordcount = "800";
$blog_url = "https://obelis.online/blog/nuevas-herramientas-ia";
$blog_date_published = "2025-08-05";
$blog_date_created = "2025-08-05";
$blog_date_modified = "2025-08-05";
$blog_description = "Descubre las nuevas herramientas de inteligencia artificial que ObelisIA pone a disposición de creadores y empresas para potenciar su creatividad.";
$blog_author = "Equipo ObelisIA";

$page_title = $blog_headline;
$page_description = $blog_description;
$og_image = "assets/img/social-share-default.jpg";
$og_url_route = "blog/nuevas-herramientas-ia";

include __DIR__ . '/../../src/Utils/header.php';
?>

<main class="container py-5">
    <article class="mx-auto" style="max-width: 800px;">
        <h1 class="mb-4"><?php echo htmlspecialchars($blog_headline); ?></h1>
        <img src="<?php echo htmlspecialchars($blog_image); ?>" alt="Imagen del post" class="img-fluid rounded mb-4">
        <p class="lead text-muted"><?php echo htmlspecialchars($blog_description); ?></p>
        <hr>
        <section>
            <h2>Nuevas funciones de IA para potenciar tu creatividad</h2>
            <p>ObelisIA presenta una nueva suite de herramientas de inteligencia artificial diseñadas para creadores, empresas y entusiastas de la tecnología. Estas herramientas permiten generar imágenes, editar contenido visual, componer música y mucho más, todo desde la web.</p>
            <ul>
                <li>Generador de imágenes por IA</li>
                <li>Editor de imágenes fácil de usar</li>
                <li>Composición musical automática</li>
                <li>Asistente de texto inteligente</li>
            </ul>
            <p>¡Explora todas las novedades en <a href="/herramientas">nuestra sección de herramientas</a>!</p>
        </section>
        <footer class="mt-5 text-muted">
            Publicado el <?php echo htmlspecialchars($blog_date_published); ?> por <?php echo htmlspecialchars($blog_author); ?>
        </footer>
    </article>
</main>

<?php include __DIR__ . '/../../src/Utils/footer.php'; ?>
