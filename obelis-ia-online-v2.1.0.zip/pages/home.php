
<?php
// Inicializar dependencias necesarias

// Incluir configuración
require_once __DIR__ . '/../src/Config/config.php';

// Incluir autoloader si no está cargado
if (!class_exists('ObelisIA\Database\Database')) {
    require_once __DIR__ . '/../vendor/autoload.php';
}

use ObelisIA\Database\Database;
use ObelisIA\Auth\Auth;

// Inicializar sesión si no está iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Inicializar auth y db si no están disponibles (acceso directo)
if (!isset($auth) || !is_object($auth)) {
    $database = new Database();
    $db = $database->getConnection();
    $auth = new Auth($db);
}

if (!isset($db) || !is_object($db)) {
    if (!isset($database)) {
        $database = new Database();
    }
    $db = $database->getConnection();
}

// Variables específicas de esta página
$page_title = "ObelisIA - Herramientas de IA Profesionales para Creativos";
$page_description = "Potencia tu creatividad con nuestra suite completa de herramientas de IA. Genera imágenes, videos, texto y música. Edita profesionalmente y transforma tu contenido.";
$body_class = "home-page";
?>

<!-- Hero Section -->
<section class="hero-section">
    <div class="hero-background">
        <div class="hero-grid"></div>
        <div class="hero-gradient"></div>
    </div>
    
    <div class="container position-relative">
        <div class="row align-items-center min-vh-100 py-5">
            <div class="col-lg-6">
                <div class="hero-content">
                    <div class="hero-badge">
                        <i class="fas fa-sparkles"></i>
                        <span>Herramientas de IA Profesionales</span>
                    </div>
                    
                    <h1 class="hero-title">
                        Potencia tu <span class="text-gradient">creatividad</span> 
                        con inteligencia artificial
                    </h1>
                    
                    <p class="hero-description">
                        Suite completa de herramientas de IA para crear, editar y transformar contenido digital. 
                        Genera imágenes, videos, música y texto con la tecnología más avanzada del mercado.
                    </p>
                    
                    <div class="hero-features">
                        <div class="feature-item">
                            <i class="fas fa-check-circle"></i>
                            <span>Generación ilimitada</span>
                        </div>
                        <div class="feature-item">
                            <i class="fas fa-check-circle"></i>
                            <span>Calidad profesional 4K</span>
                        </div>
                        <div class="feature-item">
                            <i class="fas fa-check-circle"></i>
                            <span>10+ herramientas especializadas</span>
                        </div>
                    </div>
                    
                    <div class="hero-actions">
                        <?php if ($auth->isLoggedIn()): ?>
                            <a href="<?php echo \ObelisIA\Router\MainRouter::url('panel'); ?>" class="btn-hero btn-primary">
                                <i class="material-icons">dashboard</i>
                                <span>Acceder al Panel</span>
                            </a>
                            <a href="<?php echo \ObelisIA\Router\MainRouter::url('herramientas'); ?>" class="btn-hero btn-secondary">
                                <i class="material-icons">auto_awesome</i>
                                <span>Explorar Herramientas</span>
                            </a>
                        <?php else: ?>
                            <a href="<?php echo \ObelisIA\Router\MainRouter::url('registro'); ?>" class="btn-hero btn-primary">
                                <i class="material-icons">auto_awesome</i>
                                <span>Comenzar Gratis</span>
                            </a>
                            <a href="<?php echo \ObelisIA\Router\MainRouter::url('acceso'); ?>" class="btn-hero btn-secondary">
                                <i class="material-icons">login</i>
                                <span>Iniciar Sesión</span>
                            </a>
                        <?php endif; ?>
                    </div>
                    
                    <div class="hero-stats">
                        <div class="stat-item">
                            <div class="stat-number">50K+</div>
                            <div class="stat-label">Creaciones generadas</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number">15+</div>
                            <div class="stat-label">Herramientas IA</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number">99.9%</div>
                            <div class="stat-label">Tiempo activo</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-6">
                <div class="hero-visual">
                    <div class="demo-cards">
                        <!-- Card 1 - Image Generation -->
                        <div class="demo-card card-1">
                            <div class="card-header">
                                <i class="material-icons">image</i>
                                <span>Generador de Imágenes</span>
                            </div>
                            <div class="card-content">
                                <div class="progress-demo">
                                    <div class="progress-bar"></div>
                                </div>
                                <div class="status-demo">
                                    <i class="fas fa-check-circle text-success"></i>
                                    <span>Imagen generada con éxito</span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Card 2 - Text Generation -->
                        <div class="demo-card card-2">
                            <div class="card-header">
                                <i class="material-icons">article</i>
                                <span>Generador de Texto</span>
                            </div>
                            <div class="card-content">
                                <div class="typing-demo">
                                    <span class="typing-cursor">|</span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Card 3 - Video Generation -->
                        <div class="demo-card card-3">
                            <div class="card-header">
                                <i class="material-icons">videocam</i>
                                <span>Generador de Video</span>
                            </div>
                            <div class="card-content">
                                <div class="video-demo">
                                    <div class="play-button">
                                        <i class="fas fa-play"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Floating Elements -->
                    <div class="floating-elements">
                        <div class="floating-icon icon-1">
                            <i class="fas fa-brain"></i>
                        </div>
                        <div class="floating-icon icon-2">
                            <i class="fas fa-magic"></i>
                        </div>
                        <div class="floating-icon icon-3">
                            <i class="fas fa-palette"></i>
                        </div>
                        <div class="floating-icon icon-4">
                            <i class="fas fa-robot"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="features-section">
    <div class="container">
        <div class="section-header">
            <div class="section-badge">
                <i class="fas fa-tools"></i>
                <span>Herramientas Profesionales</span>
            </div>
            <h2 class="section-title">
                Todo lo que necesitas para crear con <span class="text-gradient">IA</span>
            </h2>
            <p class="section-description">
                Accede a la suite más completa de herramientas de inteligencia artificial 
                diseñadas para profesionales creativos y empresas.
            </p>
        </div>

        <?php
        // Consultar herramientas activas
        $tools_list = $db->query("SELECT * FROM tools WHERE is_active = 1 ORDER BY name ASC")->fetchAll();
        ?>

        <div class="tools-grid">
            <?php if (!empty($tools_list)): ?>
                <?php foreach ($tools_list as $tool): ?>
                    <div class="tool-card" data-tool="<?php echo htmlspecialchars($tool['slug']); ?>">
                        <a href="<?php echo \ObelisIA\Router\MainRouter::url('herramientas/' . $tool['slug']); ?>" class="tool-link">
                            <div class="tool-icon">
                                <i class="material-icons"><?php echo htmlspecialchars($tool['icon'] ?: 'auto_awesome'); ?></i>
                            </div>
                            <div class="tool-content">
                                <h3 class="tool-title"><?php echo htmlspecialchars($tool['name']); ?></h3>
                                <p class="tool-description"><?php echo htmlspecialchars($tool['description']); ?></p>
                            </div>
                            <div class="tool-arrow">
                                <i class="fas fa-arrow-right"></i>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-12 text-center">
                    <p class="text-muted">Herramientas en desarrollo. ¡Pronto disponibles!</p>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="features-cta">
            <a href="<?php echo \ObelisIA\Router\MainRouter::url('herramientas'); ?>" class="btn-hero btn-outline">
                <i class="material-icons">explore</i>
                <span>Explorar todas las herramientas</span>
            </a>
        </div>
    </div>
</section>

<!-- Pricing Section -->
<section class="pricing-section">
    <div class="pricing-background">
        <div class="pricing-grid"></div>
    </div>
    
    <div class="container">
        <div class="section-header">
            <div class="section-badge">
                <i class="fas fa-crown"></i>
                <span>Planes y Precios</span>
            </div>
            <h2 class="section-title text-white">
                Elige el plan perfecto para <span class="text-gradient">tu creatividad</span>
            </h2>
            <p class="section-description text-white">
                Planes flexibles diseñados para adaptarse a tus necesidades, 
                desde creadores individuales hasta equipos empresariales.
            </p>
        </div>
        
        <div class="pricing-cards">
            <!-- Free Plan -->
            <div class="pricing-card">
                <div class="pricing-header">
                    <div class="plan-name">Gratuito</div>
                    <div class="plan-price">
                        <span class="currency">$</span>
                        <span class="amount">0</span>
                        <span class="period">/mes</span>
                    </div>
                    <div class="plan-description">Perfecto para comenzar</div>
                </div>
                
                <div class="pricing-features">
                    <div class="feature-item">
                        <i class="fas fa-check"></i>
                        <span>Generaciones con anuncios</span>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-check"></i>
                        <span>Resolución estándar</span>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-check"></i>
                        <span>Herramientas básicas</span>
                    </div>
                    <div class="feature-item disabled">
                        <i class="fas fa-times"></i>
                        <span>Sin marca de agua</span>
                    </div>
                    <div class="feature-item disabled">
                        <i class="fas fa-times"></i>
                        <span>Soporte prioritario</span>
                    </div>
                </div>
                
                <div class="pricing-action">
                    <?php if (!$auth->isLoggedIn()): ?>
                        <a href="<?php echo \ObelisIA\Router\MainRouter::url('registro'); ?>" class="btn-pricing">
                            Comenzar Gratis
                        </a>
                    <?php else: ?>
                        <a href="<?php echo \ObelisIA\Router\MainRouter::url('panel'); ?>" class="btn-pricing">
                            Acceder
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Premium Plan -->
            <div class="pricing-card featured">
                <div class="popular-badge">
                    <i class="fas fa-star"></i>
                    <span>Más Popular</span>
                </div>
                
                <div class="pricing-header">
                    <div class="plan-name">Premium</div>
                    <div class="plan-price">
                        <span class="currency">$</span>
                        <span class="amount">19</span>
                        <span class="period">/mes</span>
                    </div>
                    <div class="plan-description">Para creativos profesionales</div>
                </div>
                
                <div class="pricing-features">
                    <div class="feature-item">
                        <i class="fas fa-check"></i>
                        <span>Generaciones ilimitadas</span>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-check"></i>
                        <span>Calidad 4K</span>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-check"></i>
                        <span>Todas las herramientas</span>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-check"></i>
                        <span>Sin marca de agua</span>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-check"></i>
                        <span>Soporte prioritario 24/7</span>
                    </div>
                </div>
                
                <div class="pricing-action">
                    <?php if (!$auth->isLoggedIn()): ?>
                        <a href="<?php echo \ObelisIA\Router\MainRouter::url('registro'); ?>" class="btn-pricing">
                            Comenzar Premium
                        </a>
                    <?php else: ?>
                        <a href="<?php echo \ObelisIA\Router\MainRouter::url('buy'); ?>" class="btn-pricing">
                            Upgrade a Premium
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Stats Section -->
<section class="stats-section">
    <div class="container">
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-content">
                    <div class="stat-number">5K+</div>
                    <div class="stat-label">Usuarios activos</div>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-images"></i>
                </div>
                <div class="stat-content">
                    <div class="stat-number">50K+</div>
                    <div class="stat-label">Creaciones generadas</div>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-tools"></i>
                </div>
                <div class="stat-content">
                    <div class="stat-number">15+</div>
                    <div class="stat-label">Herramientas IA</div>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-star"></i>
                </div>
                <div class="stat-content">
                    <div class="stat-number">99.9%</div>
                    <div class="stat-label">Satisfacción</div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta-section">
    <div class="container">
        <div class="cta-content">
            <div class="cta-icon">
                <i class="fas fa-rocket"></i>
            </div>
            <h2 class="cta-title">
                ¿Listo para transformar tu creatividad con <span class="text-gradient">IA</span>?
            </h2>
            <p class="cta-description">
                Únete a miles de creadores que ya utilizan ObelisIA para dar vida 
                a sus ideas con la tecnología más avanzada del mercado.
            </p>
            
            <div class="cta-actions">
                <?php if (!$auth->isLoggedIn()): ?>
                    <a href="<?php echo \ObelisIA\Router\MainRouter::url('registro'); ?>" class="btn-hero btn-primary">
                        <i class="material-icons">auto_awesome</i>
                        <span>Comenzar Gratis Ahora</span>
                    </a>
                    <a href="<?php echo \ObelisIA\Router\MainRouter::url('herramientas'); ?>" class="btn-hero btn-outline">
                        <i class="material-icons">explore</i>
                        <span>Explorar Herramientas</span>
                    </a>
                <?php else: ?>
                    <a href="<?php echo \ObelisIA\Router\MainRouter::url('panel'); ?>" class="btn-hero btn-primary">
                        <i class="material-icons">dashboard</i>
                        <span>Acceder al Panel</span>
                    </a>
                    <a href="<?php echo \ObelisIA\Router\MainRouter::url('herramientas'); ?>" class="btn-hero btn-outline">
                        <i class="material-icons">auto_awesome</i>
                        <span>Crear Contenido</span>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>