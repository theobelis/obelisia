<?php
/**
 * bootstrap.php - General AJAX Security
 * Este archivo se usa para endpoints AJAX que requieren que un usuario
 * esté logueado, pero no necesariamente que sea un administrador.
 */
session_start();

// Cargar clases
require_once __DIR__ . '/../vendor/autoload.php';

use ObelisIA\Database\Database;
use ObelisIA\Auth\Auth;

// Instanciar objetos
try {
    $database = new Database();
    $db = $database->getConnection();
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $auth = new Auth($db);
} catch (Exception $e) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Error de conexión con el servidor.']);
    exit();
}

// Verificación de seguridad: solo requiere que el usuario esté logueado.
if (!$auth->isLoggedIn()) {
    http_response_code(403); // Forbidden
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Acceso denegado. Debes iniciar sesión.']);
    exit();
}