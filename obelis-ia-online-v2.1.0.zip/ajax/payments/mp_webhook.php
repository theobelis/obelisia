<?php
// ajax/payments/mp_webhook.php
// Este script NO inicia sesión. Es llamado por el servidor de Mercado Pago.

require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../../src/Config/config.php';
require_once __DIR__ . '/../../src/Database/Database.php';

use MercadoPago\Client\Payment\PaymentClient;
use MercadoPago\MercadoPagoConfig;

MercadoPagoConfig::setAccessToken(MERCADOPAGO_ACCESS_TOKEN);

$body = file_get_contents('php://input');
$data = json_decode($body, true);

if (isset($data['type']) && $data['type'] === 'payment') {
    $payment_id = $data['data']['id'];

    try {
        $client = new PaymentClient();
        $payment = $client->get($payment_id);

        if ($payment && $payment->status == 'approved') {
            $user_id = $payment->external_reference;
            $amount = $payment->transaction_amount;
            $currency = $payment->currency_id;
            $transaction_id = $payment->id;

            $database = new \ObelisIA\Database\Database();
            $db = $database->getConnection();
            
            // 1. Actualizar al usuario a premium
            $update_user_query = "UPDATE users SET membership_type = 'premium', membership_expires_at = DATE_ADD(NOW(), INTERVAL 1 MONTH) WHERE id = ?";
            $stmt = $db->prepare($update_user_query);
            $stmt->execute([$user_id]);

            // 2. Registrar el pago en la tabla `payments`
            $insert_payment_query = "INSERT INTO payments (user_id, transaction_id, amount, currency, status, payment_method, gateway, plan_type, completed_at) VALUES (?, ?, ?, ?, 'completed', ?, 'MercadoPago', 'premium_monthly', NOW())";
            $stmt = $db->prepare($insert_payment_query);
            $stmt->execute([
                $user_id,
                $transaction_id,
                $amount,
                $currency,
                $payment->payment_type_id // ej. 'credit_card'
            ]);
        }
    } catch (Exception $e) {
        error_log("Mercado Pago Webhook Error: " . $e->getMessage());
        http_response_code(500);
        exit();
    }
}

http_response_code(200); // Responder a Mercado Pago que todo está bien