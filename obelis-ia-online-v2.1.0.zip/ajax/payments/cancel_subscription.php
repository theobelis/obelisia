<?php
/**
 * Backend para cancelar la suscripción de un usuario.
 */
require_once __DIR__ . '/../bootstrap.php'; // Usa el bootstrap para la sesión y BD

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método no permitido.']);
    exit();
}

if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Acceso denegado.']);
    exit();
}

$user_id = $_SESSION['user_id'];

try {
    // Aquí iría la lógica para cancelar en la pasarela de pago (ej. Stripe)
    // $stripe_customer_id = ...;
    // $stripe->subscriptions->cancel($stripe_customer_id);

    // Actualizar la base de datos
    $stmt = $db->prepare(
        "UPDATE users SET membership_type = 'free', subscription_end = NULL, stripe_subscription_id = NULL WHERE id = ?"
    );
    $stmt->execute([$user_id]);

    echo json_encode(['success' => true, 'message' => 'Tu suscripción ha sido cancelada exitosamente.']);

} catch (Exception $e) {
    error_log("Error al cancelar suscripción para el usuario $user_id: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'No se pudo cancelar la suscripción. Por favor, contacta a soporte.']);
}