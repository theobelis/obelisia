<?php
/**
 * Genera y descarga una factura en PDF para un pago específico.
 */
require_once __DIR__ . '/../bootstrap.php'; // Para sesión y BD
require_once __DIR__ . '/../../lib/fpdf/fpdf.php'; // Requiere la librería FPDF

if (!isset($_SESSION['user_id'])) {
    \ObelisIA\Router\MainRouter::redirect('acceso');
}

$user_id = $_SESSION['user_id'];
$transaction_id = $_GET['id'] ?? null;

if (!$transaction_id) {
    die("ID de transacción no proporcionado.");
}

try {
    // Obtener datos del pago y del usuario
    $stmt = $db->prepare(
        "SELECT p.created_at, p.amount, u.full_name, u.email 
         FROM payments p 
         JOIN users u ON p.user_id = u.id 
         WHERE p.transaction_id = ? AND p.user_id = ?"
    );
    $stmt->execute([$transaction_id, $user_id]);
    $invoice_data = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$invoice_data) {
        die("Factura no encontrada o no tienes permiso para verla.");
    }

    // Creación del PDF
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 16);
    
    // Cabecera
    $pdf->Cell(40, 10, 'ObelisIA');
    $pdf->Ln(20);
    $pdf->Cell(0, 10, 'Factura', 0, 1, 'C');
    $pdf->Ln(10);

    // Datos del cliente
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 10, 'Cliente: ' . utf8_decode($invoice_data['full_name']), 0, 1);
    $pdf->Cell(0, 10, 'Email: ' . $invoice_data['email'], 0, 1);
    $pdf->Ln(10);

    // Detalles de la factura
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(130, 10, 'Descripcion', 1);
    $pdf->Cell(60, 10, 'Monto', 1);
    $pdf->Ln();
    
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(130, 10, 'Suscripcion Premium Mensual', 1);
    $pdf->Cell(60, 10, '$' . number_format($invoice_data['amount'], 2), 1);
    $pdf->Ln(20);
    
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(130, 10, 'Total', 1);
    $pdf->Cell(60, 10, '$' . number_format($invoice_data['amount'], 2), 1);

    // Salida
    $pdf->Output('D', 'Factura-ObelisIA-' . $transaction_id . '.pdf');

} catch (Exception $e) {
    error_log("Error al generar factura: " . $e->getMessage());
    die("No se pudo generar la factura.");
}