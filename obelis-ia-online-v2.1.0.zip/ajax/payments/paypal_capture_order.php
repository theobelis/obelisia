<?php
// ajax/payments/paypal_capture_order.php
require_once __DIR__ . '/../bootstrap.php';

header('Content-Type: application/json');
$input = json_decode(file_get_contents('php://input'), true);
$orderID = $input['orderID'] ?? null;

if (!$orderID) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID de orden no proporcionado.']);
    exit();
}

// --- LÓGICA DE VERIFICACIÓN CON PAYPAL (SIMULADA) ---
// En un sistema real, aquí harías una llamada a la API de PayPal
// para verificar que el 'orderID' es válido y ha sido pagado.

try {
    $user_id = $_SESSION['user_id'];
    
    // 1. Actualizar usuario a premium
    $update_user_query = "UPDATE users SET membership_type = 'premium', membership_expires_at = DATE_ADD(NOW(), INTERVAL 1 MONTH) WHERE id = ?";
    $stmt = $db->prepare($update_user_query);
    $stmt->execute([$user_id]);

    // 2. Registrar el pago
    $insert_payment_query = "INSERT INTO payments (user_id, transaction_id, amount, currency, status, payment_method, gateway, plan_type, completed_at) VALUES (?, ?, ?, 'USD', 'completed', 'paypal', 'PayPal', 'premium_monthly', NOW())";
    $stmt = $db->prepare($insert_payment_query);
    $stmt->execute([$user_id, $orderID, 19.00]);
    
    echo json_encode(['success' => true, 'message' => 'Pago verificado y cuenta actualizada.']);

} catch (Exception $e) {
    http_response_code(500);
    error_log("PayPal Capture Error (User ID: $user_id): " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error al actualizar la base de datos.']);
}