<?php
/**
 * Backend para iniciar el proceso de pago (ej. con Stripe).
 */
require_once __DIR__ . '/../bootstrap.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Debes iniciar sesión para comprar.']);
    exit();
}

// Aquí iría la integración real con Stripe
// 1. Cargar la librería de Stripe: require_once 'vendor/autoload.php';
// 2. Configurar tu clave secreta: \Stripe\Stripe::setApiKey('sk_test_...');
// 3. Crear la sesión de Checkout:
// $session = \Stripe\Checkout\Session::create([...]);
// 4. Devolver el ID de la sesión:
// echo json_encode(['id' => $session->id]);

// --- SIMULACIÓN PARA EL EJEMPLO ---
// Simulamos una respuesta exitosa de la API de pago.
echo json_encode([
    'success' => true,
    'sessionId' => 'cs_test_a1B2c3D4e5F6g7H8i9J0k' // ID de sesión simulado
]);