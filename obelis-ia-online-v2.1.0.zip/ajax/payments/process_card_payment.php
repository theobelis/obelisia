<?php
/**
 * API: Procesar pago con tarjeta de crédito
 * Integración con Stripe para procesar pagos seguros
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../../src/Config/config.php';

// Verificar autenticación
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Usuario no autenticado']);
    exit;
}

// Verificar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('Datos inválidos');
    }
    
    // Validar datos requeridos
    $requiredFields = ['method', 'plan', 'billing', 'amount', 'currency', 'card'];
    foreach ($requiredFields as $field) {
        if (!isset($input[$field])) {
            throw new Exception("Campo requerido faltante: {$field}");
        }
    }
    
    $user_id = $_SESSION['user_id'];
    $plan = $input['plan'];
    $billing_cycle = $input['billing'];
    $amount = floatval($input['amount']);
    $currency = $input['currency'];
    $card_data = $input['card'];
    $billing_data = $input['billing'];
    
    // Validar plan y precio
    $valid_plans = [
        'premium' => [
            'monthly' => 19.00,
            'yearly' => 190.00
        ]
    ];
    
    if (!isset($valid_plans[$plan][$billing_cycle]) || 
        $valid_plans[$plan][$billing_cycle] !== $amount) {
        throw new Exception('Plan o precio inválido');
    }
    
    // Validar datos de tarjeta básicamente (en producción usar Stripe)
    if (empty($card_data['number']) || empty($card_data['expiry']) || 
        empty($card_data['cvc']) || empty($card_data['name'])) {
        throw new Exception('Datos de tarjeta incompletos');
    }
    
    // Validar número de tarjeta (algoritmo de Luhn simplificado)
    $card_number = preg_replace('/\D/', '', $card_data['number']);
    if (strlen($card_number) < 13 || strlen($card_number) > 19) {
        throw new Exception('Número de tarjeta inválido');
    }
    
    // Validar fecha de vencimiento
    if (!preg_match('/^\d{2}\/\d{2}$/', $card_data['expiry'])) {
        throw new Exception('Fecha de vencimiento inválida');
    }
    
    list($exp_month, $exp_year) = explode('/', $card_data['expiry']);
    $exp_year = 2000 + intval($exp_year);
    $current_year = date('Y');
    $current_month = date('n');
    
    if ($exp_year < $current_year || 
        ($exp_year == $current_year && intval($exp_month) < $current_month)) {
        throw new Exception('Tarjeta vencida');
    }
    
    // En producción, aquí iría la integración con Stripe:
    /*
    require_once 'vendor/autoload.php';
    \Stripe\Stripe::setApiKey('sk_live_...');
    
    $payment_intent = \Stripe\PaymentIntent::create([
        'amount' => $amount * 100, // Stripe usa centavos
        'currency' => strtolower($currency),
        'payment_method_data' => [
            'type' => 'card',
            'card' => [
                'number' => $card_data['number'],
                'exp_month' => intval($exp_month),
                'exp_year' => $exp_year,
                'cvc' => $card_data['cvc'],
            ],
        ],
        'confirm' => true,
        'description' => "ObelisIA {$plan} subscription - {$billing_cycle}",
        'metadata' => [
            'user_id' => $user_id,
            'plan' => $plan,
            'billing_cycle' => $billing_cycle
        ]
    ]);
    
    $transaction_id = $payment_intent->id;
    */
    
    // SIMULACIÓN para desarrollo
    $transaction_id = 'sim_' . uniqid() . '_' . time();
    
    // Registrar el pago en la base de datos
    $insert_payment = "INSERT INTO payments (
        user_id, transaction_id, amount, currency, status, 
        payment_method, gateway, plan_type, billing_cycle, 
        card_last_four, billing_data, completed_at
    ) VALUES (?, ?, ?, ?, 'completed', 'card', 'stripe', ?, ?, ?, ?, NOW())";
    
    $stmt = $db->prepare($insert_payment);
    $card_last_four = substr($card_number, -4);
    $billing_json = json_encode($billing_data);
    
    $stmt->execute([
        $user_id, 
        $transaction_id, 
        $amount, 
        $currency, 
        $plan, 
        $billing_cycle,
        $card_last_four,
        $billing_json
    ]);
    
    // Actualizar usuario a premium
    $expiry_date = $billing_cycle === 'yearly' ? 'DATE_ADD(NOW(), INTERVAL 1 YEAR)' : 'DATE_ADD(NOW(), INTERVAL 1 MONTH)';
    
    $update_user = "UPDATE users SET 
        subscription_type = 'premium',
        subscription_status = 'active',
        subscription_expires_at = {$expiry_date},
        updated_at = NOW()
        WHERE id = ?";
    
    $stmt = $db->prepare($update_user);
    $stmt->execute([$user_id]);
    
    // Log de actividad
    $log_activity = "INSERT INTO activity_logs (user_id, action, description, ip_address, created_at) 
                     VALUES (?, 'subscription_upgrade', ?, ?, NOW())";
    $stmt = $db->prepare($log_activity);
    $stmt->execute([
        $user_id,
        "Upgraded to {$plan} ({$billing_cycle}) - Transaction: {$transaction_id}",
        $_SERVER['REMOTE_ADDR'] ?? 'unknown'
    ]);
    
    // Enviar email de confirmación (opcional)
    try {
        require_once __DIR__ . '/../../helpers/send_subscription_confirmation.php';
        send_subscription_confirmation($user_id, $plan, $billing_cycle, $amount, $transaction_id);
    } catch (Exception $e) {
        error_log("Error enviando email de confirmación: " . $e->getMessage());
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Pago procesado exitosamente',
        'transaction_id' => $transaction_id,
        'plan' => $plan,
        'billing_cycle' => $billing_cycle,
        'amount' => $amount,
        'currency' => $currency
    ]);
    
} catch (Exception $e) {
    error_log("Error en process_card_payment.php: " . $e->getMessage());
    
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'error_code' => 'PAYMENT_ERROR'
    ]);
}
?>
