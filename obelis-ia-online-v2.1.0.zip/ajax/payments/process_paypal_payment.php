<?php
/**
 * API: Procesar pago con PayPal
 * Verificación y procesamiento de pagos PayPal
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../../src/Config/config.php';

// Verificar autenticación
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Usuario no autenticado']);
    exit;
}

// Verificar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('Datos inválidos');
    }
    
    // Validar datos requeridos
    $requiredFields = ['method', 'plan', 'billing', 'paypal_order_id', 'amount', 'currency'];
    foreach ($requiredFields as $field) {
        if (!isset($input[$field])) {
            throw new Exception("Campo requerido faltante: {$field}");
        }
    }
    
    $user_id = $_SESSION['user_id'];
    $plan = $input['plan'];
    $billing_cycle = $input['billing'];
    $paypal_order_id = $input['paypal_order_id'];
    $paypal_payer_id = $input['paypal_payer_id'] ?? '';
    $amount = floatval($input['amount']);
    $currency = $input['currency'];
    $billing_data = $input['billing'] ?? [];
    
    // Validar plan y precio
    $valid_plans = [
        'premium' => [
            'monthly' => 19.00,
            'yearly' => 190.00
        ]
    ];
    
    if (!isset($valid_plans[$plan][$billing_cycle]) || 
        $valid_plans[$plan][$billing_cycle] !== $amount) {
        throw new Exception('Plan o precio inválido');
    }
    
    // En producción, aquí verificarías el pago con la API de PayPal:
    /*
    $paypal_client_id = PAYPAL_CLIENT_ID;
    $paypal_client_secret = PAYPAL_CLIENT_SECRET; // Definir en config
    
    // Obtener token de acceso
    $auth_url = 'https://api.paypal.com/v1/oauth2/token'; // o sandbox
    $auth_data = 'grant_type=client_credentials';
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $auth_url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $auth_data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERPWD, $paypal_client_id . ':' . $paypal_client_secret);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Accept: application/json']);
    
    $auth_response = curl_exec($ch);
    $auth_result = json_decode($auth_response, true);
    curl_close($ch);
    
    $access_token = $auth_result['access_token'];
    
    // Verificar la orden
    $order_url = "https://api.paypal.com/v2/checkout/orders/{$paypal_order_id}";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $order_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $access_token,
        'Content-Type: application/json'
    ]);
    
    $order_response = curl_exec($ch);
    $order_result = json_decode($order_response, true);
    curl_close($ch);
    
    // Validar que el pago fue completado
    if ($order_result['status'] !== 'COMPLETED') {
        throw new Exception('El pago de PayPal no fue completado');
    }
    
    // Validar el monto
    $paid_amount = floatval($order_result['purchase_units'][0]['amount']['value']);
    if ($paid_amount !== $amount) {
        throw new Exception('El monto pagado no coincide');
    }
    */
    
    // SIMULACIÓN para desarrollo
    // En este punto, asumimos que PayPal ya validó el pago
    
    // Verificar que el pago no haya sido procesado antes
    $check_payment = "SELECT id FROM payments WHERE transaction_id = ?";
    $stmt = $db->prepare($check_payment);
    $stmt->execute([$paypal_order_id]);
    
    if ($stmt->fetch()) {
        throw new Exception('Este pago ya fue procesado');
    }
    
    // Registrar el pago en la base de datos
    $insert_payment = "INSERT INTO payments (
        user_id, transaction_id, amount, currency, status, 
        payment_method, gateway, plan_type, billing_cycle, 
        paypal_payer_id, billing_data, completed_at
    ) VALUES (?, ?, ?, ?, 'completed', 'paypal', 'PayPal', ?, ?, ?, ?, NOW())";
    
    $stmt = $db->prepare($insert_payment);
    $billing_json = json_encode($billing_data);
    
    $stmt->execute([
        $user_id, 
        $paypal_order_id, 
        $amount, 
        $currency, 
        $plan, 
        $billing_cycle,
        $paypal_payer_id,
        $billing_json
    ]);
    
    // Actualizar usuario a premium
    $expiry_date = $billing_cycle === 'yearly' ? 'DATE_ADD(NOW(), INTERVAL 1 YEAR)' : 'DATE_ADD(NOW(), INTERVAL 1 MONTH)';
    
    $update_user = "UPDATE users SET 
        subscription_type = 'premium',
        subscription_status = 'active',
        subscription_expires_at = {$expiry_date},
        updated_at = NOW()
        WHERE id = ?";
    
    $stmt = $db->prepare($update_user);
    $stmt->execute([$user_id]);
    
    // Log de actividad
    $log_activity = "INSERT INTO activity_logs (user_id, action, description, ip_address, created_at) 
                     VALUES (?, 'subscription_upgrade', ?, ?, NOW())";
    $stmt = $db->prepare($log_activity);
    $stmt->execute([
        $user_id,
        "Upgraded to {$plan} ({$billing_cycle}) via PayPal - Order: {$paypal_order_id}",
        $_SERVER['REMOTE_ADDR'] ?? 'unknown'
    ]);
    
    // Enviar email de confirmación (opcional)
    try {
        require_once __DIR__ . '/../../helpers/send_subscription_confirmation.php';
        send_subscription_confirmation($user_id, $plan, $billing_cycle, $amount, $paypal_order_id);
    } catch (Exception $e) {
        error_log("Error enviando email de confirmación: " . $e->getMessage());
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Pago con PayPal procesado exitosamente',
        'transaction_id' => $paypal_order_id,
        'plan' => $plan,
        'billing_cycle' => $billing_cycle,
        'amount' => $amount,
        'currency' => $currency
    ]);
    
} catch (Exception $e) {
    error_log("Error en process_paypal_payment.php: " . $e->getMessage());
    
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'error_code' => 'PAYPAL_ERROR'
    ]);
}
?>
