<?php
// ajax/payments/create_mp_preference.php

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../../src/Config/config.php';

use MercadoPago\Client\Preference\PreferenceClient;
use MercadoPago\MercadoPagoConfig;

header('Content-Type: application/json');

try {
    MercadoPagoConfig::setAccessToken(MERCADOPAGO_ACCESS_TOKEN);
    $client = new PreferenceClient();

    $user_id = $_SESSION['user_id'];
    $back_url_base = 'https://' . SITE_URL; // Asegúrate que SITE_URL no incluya http/https

    $preference = $client->create([
        "items"=> [
            [
                "title" => "Suscripción ObelisIA Premium (Mensual)",
                "quantity" => 1,
                "unit_price" => 19.00, // Precio de tu plan
                "currency_id" => "PEN" // Moneda local (Soles) o USD
            ]
        ],
        "back_urls" => [
            "success" => $back_url_base . \ObelisIA\Router\MainRouter::url('suscripcion'),
            "failure" => $back_url_base . \ObelisIA\Router\MainRouter::url('premium'),
            "pending" => $back_url_base . \ObelisIA\Router\MainRouter::url('suscripcion')
        ],
        "auto_return" => "approved",
        "notification_url" => $back_url_base . "/ajax/payments/mp_webhook.php", // URL para notificaciones
        "external_reference" => $user_id // ID de nuestro usuario para identificarlo en el webhook
    ]);

    echo json_encode(['id' => $preference->id, 'init_point' => $preference->init_point]);

} catch (Exception $e) {
    http_response_code(500);
    error_log("Mercado Pago Error: " . $e->getMessage());
    echo json_encode(['error' => 'No se pudo iniciar el proceso de pago.']);
}