<?php
namespace ObelisIA\Router;

class MainRouter {
    
    // Directorio base donde está instalado el proyecto
    private static $basePath = '';

    // Mapa de rutas amigables a archivos reales
    private static $routes = [
        // --- Rutas Públicas Principales ---
        '' => 'pages/home.php',
        'inicio' => 'pages/home.php',
        'precios' => 'pages/precios.php',
        'caracteristicas' => 'pages/caracteristicas.php',
        'herramientas' => 'pages/tools_page.php',
        'acerca' => 'pages/static/about.php',
        
        // --- Rutas de Autenticación ---
        'login' => 'pages/auth/login.php',
        'acceso' => 'pages/auth/login.php',
        'registro' => 'pages/auth/register.php',
        'recuperar-password' => 'pages/auth/recover-password.php',
        'recuperar-contrasena' => 'pages/auth/recover-password.php',

        // --- Rutas de Usuario (requieren login) ---
        'panel' => 'pages/dashboard/dashboard.php',
        'perfil' => 'pages/user/profile.php',
        'premium' => 'pages/user/upgrade.php',
        'suscripcion' => 'pages/user/suscripcion.php',
        'mis-creaciones' => 'pages/user/creaciones.php',
        'comunidad' => 'pages/social/feed.php',
        'usuario' => 'pages/social/profile.php',
        'buscar' => 'pages/social/search.php',
        'seguidores' => 'pages/social/followers.php',

        // --- Nuevas páginas de usuario ---
        'notificaciones' => 'pages/user/notificaciones.php',
        'recursos' => 'pages/user/recursos.php',

        // --- Herramientas Especiales ---
        'herramientas/creador-de-creaciones' => 'src/Tools/views/Editor_view.php',
        'herramientas/creador-de-contenido' => 'src/Tools/views/ContentCreator_view.php',

        // --- Obelis Studio ---
        'studio' => 'studio/index.php',
        'studio/editor' => 'studio/editor.php',
        'studio/viewer' => 'studio/viewer.php',
        'studio/proyecto' => 'studio/viewer.php', // Alias para URLs más amigables

        // --- Rutas Legales y de Soporte ---
        'legal/terminos' => 'pages/legal/terminos.php',
        'legal/privacidad' => 'pages/legal/privacidad.php',
        'soporte/faq' => 'pages/soporte/faq.php',
        'soporte/contacto' => 'pages/soporte/contacto.php',
        'soporte' => 'pages/soporte/index.php',
        
        // --- Rutas de Checkout y Créditos ---
        'checkout' => 'pages/checkout/checkout.php',
        'checkout/success' => 'pages/checkout/success.php',
        'creditos' => 'pages/checkout/credits.php',
        'creditos/comprar' => 'pages/checkout/credits_checkout.php',
        
        // --- Rutas de Herramientas ---
        'herramientas-ia' => 'pages/tools_page.php',
        
        // --- Rutas de Administración ---
        'admin' => 'admin/index.php',
        'admin/usuarios' => 'admin/users.php',
        'admin/estadisticas' => 'admin/analytics.php',
        'admin/configuracion' => 'admin/settings.php',
        'admin/creaciones' => 'admin/creations.php',
        'admin/herramientas' => 'admin/admin_panel.php',
        'admin/registros' => 'admin/debug_admin.php',
        'admin/pagos' => 'admin/payments.php',

        // --- Páginas de Error ---
        'error/404' => 'pages/error/404.php',
        'error/403' => 'pages/error/403.php',
        'error/500' => 'pages/error/500.php',

        // --- RUTAS DE BACKEND PARA FUNCIONALIDADES ---
        'cancelar-suscripcion' => 'ajax/payments/cancel_subscription.php', // <-- NUEVA
        'descargar-factura' => 'ajax/payments/download_invoice.php',     // <-- NUEVA
        'crear-sesion-pago' => 'ajax/payments/create_checkout_session.php', // <-- NUEVA
    ];

    /**
     * Genera una URL completa y correcta, incluyendo el subdirectorio.
     */
    public static function url($friendlyRoute) {
        return self::$basePath . '/' . ltrim($friendlyRoute, '/');
    }

    /**
     * Redirige a una ruta amigable.
     */
    public static function redirect($friendlyRoute) {
        header('Location: ' . self::url($friendlyRoute));
        exit(302);
    }

    /**
     * Resuelve la ruta solicitada y devuelve la ruta del archivo a incluir.
     */
    public static function resolve() {
        $requestUri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $route = substr($requestUri, strlen(self::$basePath));
        $route = trim($route, '/');
        
        if (isset(self::$routes[$route])) {
            $file = self::$routes[$route];
            
            if (strpos($file, '#') !== false) {
                $file = substr($file, 0, strpos($file, '#'));
            }

            $filePath = __DIR__ . '/../../' . $file;

            if (file_exists($filePath)) {
                return $filePath;
            }
        }
        
        return __DIR__ . '/../../pages/error/404.php';
    }

    public static function getBasePath() {
        return self::$basePath;
    }
}
