<?php
/**
 * Template base para todas las herramientas de IA
 * Este archivo sirve como plantilla para mantener consistencia en el diseño
 */

// Variables que deben ser definidas antes de incluir este template:
// $tool_name - Nombre de la herramienta
// $tool_icon - Icono de la herramienta (sin 'fas fa-')
// $tool_description - Descripción breve de la herramienta
// $tool_slug - Slug de la herramienta para identificación
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($tool_name ?? 'Herramienta IA'); ?> - ObelisIA</title>
    
    <!-- Estilos del sistema de diseño unificado -->
    <link rel="stylesheet" href="<?php echo \ObelisIA\Router\MainRouter::url('assets/css/tools/unified-design/main.css'); ?>">
    
    <!-- Font Awesome para iconos -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <!-- Estilos específicos de la herramienta (opcional) -->
    <?php if (isset($additional_css)): ?>
        <?php foreach ($additional_css as $css_file): ?>
            <link rel="stylesheet" href="<?php echo \ObelisIA\Router\MainRouter::url($css_file); ?>">
        <?php endforeach; ?>
    <?php endif; ?>
</head>
<body>
    <div class="tool-layout">
        <!-- Header de la herramienta -->
        <header class="tool-header">
            <div class="tool-header-title">
                <div class="tool-icon">
                    <i class="fas fa-<?php echo htmlspecialchars($tool_icon ?? 'cog'); ?>"></i>
                </div>
                <h1><?php echo htmlspecialchars($tool_name ?? 'Herramienta IA'); ?></h1>
            </div>
            
            <div class="tool-header-actions">
                <!-- Botón de ayuda -->
                <button class="btn btn-ghost tooltip" data-tooltip="Ayuda" onclick="toggleHelp()">
                    <i class="fas fa-question-circle"></i>
                </button>
                
                <!-- Botón de configuración -->
                <button class="btn btn-ghost tooltip" data-tooltip="Configuración" onclick="toggleSettings()">
                    <i class="fas fa-cog"></i>
                </button>
                
                <!-- Indicador de estado premium -->
                <?php if (isset($is_premium) && $is_premium): ?>
                    <div class="premium-badge">
                        <i class="fas fa-crown"></i> Premium
                    </div>
                <?php endif; ?>
            </div>
        </header>

        <!-- Contenido principal -->
        <main class="tool-main">
            <!-- Sidebar con opciones -->
            <aside class="tool-sidebar" id="toolSidebar">
                <!-- Sección de configuración básica -->
                <div class="sidebar-section">
                    <div class="sidebar-header">
                        <i class="fas fa-sliders-h"></i> Configuración
                    </div>
                    <div class="sidebar-content">
                        <?php 
                        // Aquí se incluirá el contenido específico del sidebar de cada herramienta
                        if (isset($sidebar_content)) {
                            echo $sidebar_content;
                        } else {
                            // Contenido por defecto del sidebar
                            ?>
                            <div class="form-group">
                                <label class="form-label">Configuración básica</label>
                                <p class="text-muted">Las opciones de configuración aparecerán aquí.</p>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                </div>

                <!-- Sección de historial (opcional) -->
                <?php if (isset($show_history) && $show_history): ?>
                <div class="sidebar-section">
                    <div class="sidebar-header">
                        <i class="fas fa-history"></i> Historial
                    </div>
                    <div class="sidebar-content">
                        <div id="historyContainer">
                            <p class="text-muted">No hay elementos en el historial.</p>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Sección de recursos (opcional) -->
                <?php if (isset($show_resources) && $show_resources): ?>
                <div class="sidebar-section">
                    <div class="sidebar-header">
                        <i class="fas fa-folder"></i> Recursos
                    </div>
                    <div class="sidebar-content">
                        <div id="resourcesContainer">
                            <p class="text-muted">No hay recursos disponibles.</p>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </aside>

            <!-- Área de contenido -->
            <div class="tool-content">
                <!-- Toolbar -->
                <div class="tool-toolbar">
                    <!-- Botón para colapsar sidebar en móvil -->
                    <button class="btn btn-ghost d-md-none" onclick="toggleSidebar()">
                        <i class="fas fa-bars"></i>
                    </button>
                    
                    <!-- Controles de la toolbar específicos de cada herramienta -->
                    <div class="flex-1 flex items-center gap-sm">
                        <?php 
                        if (isset($toolbar_content)) {
                            echo $toolbar_content;
                        }
                        ?>
                    </div>
                    
                    <!-- Acciones de la toolbar -->
                    <div class="flex items-center gap-sm">
                        <?php if (isset($show_save_button) && $show_save_button): ?>
                        <button class="btn btn-outline" onclick="saveWork()">
                            <i class="fas fa-save"></i> Guardar
                        </button>
                        <?php endif; ?>
                        
                        <?php if (isset($show_export_button) && $show_export_button): ?>
                        <button class="btn btn-accent" onclick="exportWork()">
                            <i class="fas fa-download"></i> Exportar
                        </button>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Área de trabajo principal -->
                <div class="tool-workspace">
                    <?php
                    // Aquí se incluye el contenido específico de cada herramienta
                    if (isset($main_content)) {
                        echo $main_content;
                    } else {
                        // Contenido por defecto
                        ?>
                        <div class="tool-form">
                            <div class="form-section">
                                <div class="form-section-title">
                                    <i class="fas fa-edit"></i>
                                    Entrada
                                </div>
                                
                                <div class="prompt-input-container">
                                    <textarea 
                                        class="prompt-input" 
                                        placeholder="Describe lo que quieres crear..."
                                        id="mainPrompt"
                                        maxlength="1000"
                                    ></textarea>
                                    <div class="prompt-counter">
                                        <span id="charCount">0</span>/1000
                                    </div>
                                </div>
                                
                                <div class="flex gap-md">
                                    <button class="btn btn-primary flex-1" onclick="generateContent()">
                                        <i class="fas fa-magic"></i>
                                        Generar
                                    </button>
                                    <button class="btn btn-secondary" onclick="clearForm()">
                                        <i class="fas fa-trash"></i>
                                        Limpiar
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Área de resultados -->
                        <div class="results-container" id="resultsContainer" style="display: none;">
                            <div class="results-header">
                                <div class="results-title">
                                    <i class="fas fa-star"></i>
                                    Resultados
                                </div>
                                <div class="results-actions">
                                    <button class="btn btn-sm btn-outline" onclick="regenerate()">
                                        <i class="fas fa-redo"></i>
                                        Regenerar
                                    </button>
                                </div>
                            </div>
                            <div class="results-body" id="resultsBody">
                                <!-- Los resultados se mostrarán aquí -->
                            </div>
                        </div>
                        <?php
                    }
                    ?>
                </div>
            </div>
        </main>
    </div>

    <!-- Loading overlay -->
    <div class="processing-overlay" id="loadingOverlay" style="display: none;">
        <div class="processing-spinner"></div>
        <div class="processing-text">Generando contenido...</div>
        <div class="processing-subtext">Esto puede tomar unos momentos</div>
    </div>

    <!-- Modal de ayuda -->
    <div class="modal" id="helpModal" style="display: none;">
        <div class="modal-overlay"></div>
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-question-circle"></i> Ayuda</h3>
                <button class="btn btn-ghost" onclick="toggleHelp()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <?php if (isset($help_content)): ?>
                    <?php echo $help_content; ?>
                <?php else: ?>
                    <p>Información de ayuda para <?php echo htmlspecialchars($tool_name ?? 'esta herramienta'); ?>.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- JavaScript base -->
    <script>
        // Variables globales
        window.toolConfig = {
            name: '<?php echo addslashes($tool_name ?? 'Herramienta IA'); ?>',
            slug: '<?php echo addslashes($tool_slug ?? ''); ?>',
            isPremium: <?php echo isset($is_premium) && $is_premium ? 'true' : 'false'; ?>
        };

        // Funciones base
        function toggleSidebar() {
            const sidebar = document.getElementById('toolSidebar');
            sidebar.classList.toggle('open');
        }

        function toggleHelp() {
            const modal = document.getElementById('helpModal');
            const isVisible = modal.style.display !== 'none';
            modal.style.display = isVisible ? 'none' : 'flex';
        }

        function toggleSettings() {
            // Implementar según necesidades específicas
            console.log('Settings toggle');
        }

        function showLoading(message = 'Generando contenido...') {
            const overlay = document.getElementById('loadingOverlay');
            const text = overlay.querySelector('.processing-text');
            text.textContent = message;
            overlay.style.display = 'flex';
        }

        function hideLoading() {
            const overlay = document.getElementById('loadingOverlay');
            overlay.style.display = 'none';
        }

        function showResults(content) {
            const container = document.getElementById('resultsContainer');
            const body = document.getElementById('resultsBody');
            body.innerHTML = content;
            container.style.display = 'block';
            container.scrollIntoView({ behavior: 'smooth' });
        }

        function clearForm() {
            const inputs = document.querySelectorAll('input, textarea, select');
            inputs.forEach(input => {
                if (input.type === 'checkbox' || input.type === 'radio') {
                    input.checked = false;
                } else {
                    input.value = '';
                }
            });
            updateCharCount();
        }

        function updateCharCount() {
            const textarea = document.getElementById('mainPrompt');
            const counter = document.getElementById('charCount');
            if (textarea && counter) {
                counter.textContent = textarea.value.length;
            }
        }

        // Event listeners
        document.addEventListener('DOMContentLoaded', function() {
            // Character counter
            const mainPrompt = document.getElementById('mainPrompt');
            if (mainPrompt) {
                mainPrompt.addEventListener('input', updateCharCount);
            }

            // Cerrar modal con escape
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') {
                    const helpModal = document.getElementById('helpModal');
                    if (helpModal.style.display !== 'none') {
                        toggleHelp();
                    }
                }
            });

            // Responsive sidebar
            function handleResize() {
                const sidebar = document.getElementById('toolSidebar');
                if (window.innerWidth >= 768) {
                    sidebar.classList.remove('open');
                }
            }
            
            window.addEventListener('resize', handleResize);
        });

        // Funciones que deben ser implementadas por cada herramienta
        function generateContent() {
            console.log('generateContent() debe ser implementada por la herramienta específica');
        }

        function regenerate() {
            console.log('regenerate() debe ser implementada por la herramienta específica');
        }

        function saveWork() {
            console.log('saveWork() debe ser implementada por la herramienta específica');
        }

        function exportWork() {
            console.log('exportWork() debe ser implementada por la herramienta específica');
        }
    </script>

    <!-- JavaScript específico de la herramienta -->
    <?php if (isset($additional_js)): ?>
        <?php foreach ($additional_js as $js_file): ?>
            <script src="<?php echo \ObelisIA\Router\MainRouter::url($js_file); ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>

    <!-- JavaScript inline específico -->
    <?php if (isset($inline_js)): ?>
        <script><?php echo $inline_js; ?></script>
    <?php endif; ?>
</body>
</html>
