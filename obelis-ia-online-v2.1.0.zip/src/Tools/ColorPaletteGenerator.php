<?php
// src/Tools/ColorPaletteGenerator.php


$result_data = null;

if (!empty($_POST)) {
    $tool_name = 'Generador de Paletas de Colores';
    // Logging centralizado: usar log_user_activity() desde backend si es necesario
}

if (isset($_FILES['inputFile'])) {
    // 1. Usar nuestra clase Uploader para manejar la subida.
    $uploader = new \ObelisIA\Utils\Uploader();
    $uploader->allowedExtensions = ['jpg', 'jpeg', 'png'];
    $uploadResult = $uploader->handleUpload('inputFile', 'palette-original');

    if (!$uploadResult['success']) {
        $result_data = ['error' => $uploadResult['error']];
    } else {
        try {
            $source_path = realpath(__DIR__ . '/../../' . $uploadResult['filePath']);

            // --- INICIO DEL ALGORITMO DE EXTRACCIÓN DE COLORES ---

            // Cargar la imagen en memoria
            $extension = strtolower(pathinfo($source_path, PATHINFO_EXTENSION));
            $image = null;
            if ($extension === 'jpg' || $extension === 'jpeg') {
                $image = imagecreatefromjpeg($source_path);
            } elseif ($extension === 'png') {
                $image = imagecreatefrompng($source_path);
            }

            if (!$image) {
                throw new Exception("No se pudo cargar la imagen para procesarla.");
            }

            // Para un rendimiento óptimo, redimensionamos la imagen a un tamaño pequeño
            $width = imagesx($image);
            $height = imagesy($image);
            $thumb_size = 150;
            $thumb = imagecreatetruecolor($thumb_size, $thumb_size);
            imagecopyresampled($thumb, $image, 0, 0, 0, 0, $thumb_size, $thumb_size, $width, $height);

            $colors = [];
            // Recorremos cada píxel de la imagen redimensionada
            for ($x = 0; $x < $thumb_size; $x++) {
                for ($y = 0; $y < $thumb_size; $y++) {
                    $rgb = imagecolorat($thumb, $x, $y);
                    $r = ($rgb >> 16) & 0xFF;
                    $g = ($rgb >> 8) & 0xFF;
                    $b = $rgb & 0xFF;
                    
                    // Agrupamos colores similares para encontrar los dominantes.
                    // Redondeamos cada componente a su múltiplo de 16 más cercano.
                    $hex = sprintf('%02x%02x%02x', round($r / 16) * 16, round($g / 16) * 16, round($b / 16) * 16);
                    
                    if (!isset($colors[$hex])) {
                        $colors[$hex] = 0;
                    }
                    $colors[$hex]++;
                }
            }

            // Liberar memoria
            imagedestroy($image);
            imagedestroy($thumb);

            // Ordenar los colores por frecuencia
            arsort($colors);

            // Tomar los 7 colores más dominantes
            $palette = array_slice(array_keys($colors), 0, 7);

            // --- FIN DEL ALGORITMO ---

            $result_data = [
                'originalImageUrl' => $uploadResult['filePath'],
                'colors' => $palette,
                'message' => 'Paleta de colores extraída exitosamente.'
            ];

        } catch (Exception $e) {
            $result_data = ['error' => $e->getMessage()];
        }
    }
}
?>