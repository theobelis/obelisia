<?php
// src/Tools/BackgroundRemover.php


$result_data = null;

if (!empty($_POST)) {
    $tool_name = 'Removedor de Fondo';
    // Logging centralizado: usar log_user_activity() desde backend si es necesario
}

if (isset($_FILES['inputFile'])) {
    $uploader = new \ObelisIA\Utils\Uploader();
    $uploader->allowedExtensions = ['jpg', 'jpeg', 'png'];
    $uploadResult = $uploader->handleUpload('inputFile', 'bg-original');

    if (!$uploadResult['success']) {
        $result_data = ['error' => $uploadResult['error']];
    } else {
        try {
            $source_path = realpath(__DIR__ . '/../../' . $uploadResult['filePath']);
            $tolerance = (int)($_POST['tolerance'] ?? 30);

            $extension = strtolower(pathinfo($source_path, PATHINFO_EXTENSION));
            $image = null;
            if ($extension === 'jpg' || $extension === 'jpeg') {
                $image = imagecreatefromjpeg($source_path);
            } elseif ($extension === 'png') {
                $image = imagecreatefrompng($source_path);
            }

            if (!$image) throw new Exception("No se pudo cargar la imagen.");

            imagealphablending($image, false);
            imagesavealpha($image, true);

            $backgroundColor = imagecolorat($image, 0, 0);
            $transparentColor = imagecolorallocatealpha($image, 0, 0, 0, 127);

            floodFill($image, 0, 0, $transparentColor, $backgroundColor, $tolerance);

            $newFileName = 'bg-removed-' . uniqid() . '.png';
            $destination_path = realpath(__DIR__ . '/../../uploads/') . '/' . $newFileName;
            imagepng($image, $destination_path);
            imagedestroy($image);

            $result_data = [
                'originalImageUrl' => $uploadResult['filePath'],
                'processedImageUrl' => 'uploads/' . $newFileName,
                'message' => '¡Fondo eliminado exitosamente!'
            ];
        } catch (Exception $e) {
            $result_data = ['error' => $e->getMessage()];
        }
    }
}

function floodFill($image, $x, $y, $fillColor, $targetColor, $tolerance) {
    $width = imagesx($image);
    $height = imagesy($image);
    $targetRGB = imagecolorsforindex($image, $targetColor);
    $queue = new SplQueue();
    $queue->enqueue([$x, $y]);
    $visited = [];

    while (!$queue->isEmpty()) {
        list($px, $py) = $queue->dequeue();

        if ($px < 0 || $px >= $width || $py < 0 || $py >= $height || isset($visited[$px . '-' . $py])) {
            continue;
        }

        $currentRGB = imagecolorsforindex($image, imagecolorat($image, $px, $py));
        $colorDistance = (abs($targetRGB['red'] - $currentRGB['red']) + abs($targetRGB['green'] - $currentRGB['green']) + abs($targetRGB['blue'] - $currentRGB['blue'])) / 3;
        $toleranceValue = (255 * $tolerance) / 100;

        if ($colorDistance <= $toleranceValue) {
            imagesetpixel($image, $px, $py, $fillColor);
            $visited[$px . '-' . $py] = true;
            $queue->enqueue([$px + 1, $py]);
            $queue->enqueue([$px - 1, $py]);
            $queue->enqueue([$px, $py + 1]);
            $queue->enqueue([$px, $py - 1]);
        }
    }
}
?>