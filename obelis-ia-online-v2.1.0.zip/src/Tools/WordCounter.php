<?php
// src/Tools/WordCounter.php

// Esta variable contendrá los datos del formulario que envíe el usuario
$inputText = $_POST['inputText'] ?? '';
$result_data = null; // Variable para guardar el resultado

// Solo ejecutamos la lógica si el usuario ha enviado texto
if (!empty($inputText)) {
    $wordCount = str_word_count($inputText);
    $characterCount = strlen($inputText);

    // Contamos párrafos basándonos en los saltos de línea
    $paragraphCount = count(array_filter(explode("\n", $inputText)));

    // Guardamos los resultados en un array
    $result_data = [
        'wordCount' => $wordCount,
        'characterCount' => $characterCount,
        'paragraphCount' => $paragraphCount
    ];
}
?>