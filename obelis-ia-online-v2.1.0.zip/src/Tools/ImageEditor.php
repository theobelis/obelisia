<?php
// src/Tools/ImageEditor.php


$result_data = null;

if (!empty($_POST)) {
    $tool_name = 'Editor de Imágenes';
    // Logging centralizado: usar log_user_activity() desde backend si es necesario
}

// La lógica de esta herramienta es principalmente del lado del cliente (JavaScript).
// El backend de PHP solo necesita manejar la subida inicial del archivo.
// No procesamos la imagen aquí, solo la ponemos a disposición del editor en el frontend.

if (isset($_FILES['inputFile'])) {
    
    // 1. Usamos nuestra utilidad Uploader para manejar la subida.
    $uploader = new \ObelisIA\Utils\Uploader();
    $uploadResult = $uploader->handleUpload('inputFile', 'edit-original');

    // 2. Preparamos el resultado para la vista.
    if ($uploadResult['success']) {
        // Si la subida fue exitosa, pasamos la URL de la imagen a la vista.
        // El JavaScript del editor la cargará desde esta URL.
        $result_data = [
            'imageUrlToEdit' => $uploadResult['filePath'],
            'message' => 'Imagen cargada. Ahora puedes comenzar a editar.'
        ];
    } else {
        // Si hubo un error, se lo comunicamos al usuario.
        $result_data = ['error' => $uploadResult['error']];
    }
}
?>