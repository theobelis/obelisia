<?php
/**
 * Element Manager - Gestión de elementos multimedia del Studio
 */

namespace ObelisIA\ObelisStudio;

require_once __DIR__ . '/../../helpers/db.php';
require_once __DIR__ . '/../Database/Database.php';

class ElementManager {
    
    private $db;
    private $user_id;
    
    public function __construct($user_id = null) {
        // Usar PDO directamente
        $database = new \ObelisIA\Database\Database();
        $this->db = $database->getConnection();
        $this->user_id = $user_id;
    }
    
    /**
     * Obtiene todas las creaciones del usuario para la biblioteca
     */
    public function getUserLibrary() {
        if (!$this->user_id) {
            return [];
        }
        
        $stmt = $this->db->prepare("
            SELECT 
                id,
                title,
                type,
                content,
                description,
                created_at,
                file_path,
                CASE 
                    WHEN type = 'image' THEN file_path
                    WHEN type = 'text' THEN 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAiIGhlaWdodD0iNjAiPjxyZWN0IHdpZHRoPSIxMDAiIGhlaWdodD0iNjAiIGZpbGw9IiNmMGYwZjAiLz48dGV4dCB4PSI1MCIgeT0iMzUiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtc2l6ZT0iMTAiPvCfk4QgVGV4dG88L3RleHQ+PC9zdmc+'
                    WHEN type = 'music' THEN 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAiIGhlaWdodD0iNjAiPjxyZWN0IHdpZHRoPSIxMDAiIGhlaWdodD0iNjAiIGZpbGw9IiNlOGY1ZTgiLz48dGV4dCB4PSI1MCIgeT0iMzUiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtc2l6ZT0iMTAiPvCfjbUgQXVkaW88L3RleHQ+PC9zdmc+'
                    ELSE 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAiIGhlaWdodD0iNjAiPjxyZWN0IHdpZHRoPSIxMDAiIGhlaWdodD0iNjAiIGZpbGw9IiNmNWY1ZjUiLz48dGV4dCB4PSI1MCIgeT0iMzUiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtc2l6ZT0iMTAiPvCfk4EgQXJjaGl2bzwvdGV4dD48L3N2Zz4='
                END as thumbnail
            FROM user_creations 
            WHERE user_id = :user_id AND status = 'completed'
            ORDER BY created_at DESC
        ");
        
        $stmt->bindParam(':user_id', $this->user_id, \PDO::PARAM_INT);
        $stmt->execute();
        $creations = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        
        // Procesar y normalizar datos
        foreach ($creations as &$creation) {
            // Normalizar tipo music a audio para compatibilidad con el frontend
            if ($creation['type'] === 'music') {
                $creation['type'] = 'audio';
            }
            
            // Asegurar que hay metadata vacía si no existe
            if (!isset($creation['metadata'])) {
                $creation['metadata'] = [];
            }
        }
        
        return $creations;
    }
    
    /**
     * Añade un elemento a un proyecto
     */
    public function addElementToProject($project_id, $element_type, $element_id, $position = null, $settings = []) {
        if (!$this->user_id) {
            return ['success' => false, 'message' => 'Usuario no autenticado'];
        }
        
        // Verificar que el proyecto pertenece al usuario
        $stmt = $this->db->prepare("SELECT id FROM obelis_studio_projects WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $project_id, $this->user_id);
        $stmt->execute();
        
        if (!$stmt->get_result()->fetch_assoc()) {
            return ['success' => false, 'message' => 'Proyecto no encontrado o sin permisos'];
        }
        
        // Verificar que el elemento pertenece al usuario (si aplica)
        if ($element_id && in_array($element_type, ['image', 'text', 'audio'])) {
            $stmt = $this->db->prepare("SELECT id FROM user_creations WHERE id = ? AND user_id = ?");
            $stmt->bind_param("ii", $element_id, $this->user_id);
            $stmt->execute();
            
            if (!$stmt->get_result()->fetch_assoc()) {
                return ['success' => false, 'message' => 'Elemento no encontrado o sin permisos'];
            }
        }
        
        // Determinar posición si no se especifica
        if ($position === null) {
            $stmt = $this->db->prepare("SELECT COALESCE(MAX(position_order), 0) + 1 as next_position FROM obelis_studio_elements WHERE project_id = ?");
            $stmt->bind_param("i", $project_id);
            $stmt->execute();
            $position = $stmt->get_result()->fetch_assoc()['next_position'];
        }
        
        // Configuraciones por defecto según tipo
        $default_settings = $this->getDefaultSettings($element_type);
        $final_settings = array_merge($default_settings, $settings);
        
        $stmt = $this->db->prepare("
            INSERT INTO obelis_studio_elements 
            (project_id, element_type, element_id, position_order, settings) 
            VALUES (?, ?, ?, ?, ?)
        ");
        
        $settings_json = json_encode($final_settings);
        $stmt->bind_param("issis", $project_id, $element_type, $element_id, $position, $settings_json);
        
        if ($stmt->execute()) {
            return [
                'success' => true, 
                'element_id' => $this->db->insert_id,
                'message' => 'Elemento añadido exitosamente'
            ];
        }
        
        return ['success' => false, 'message' => 'Error al añadir el elemento'];
    }
    
    /**
     * Actualiza la configuración de un elemento
     */
    public function updateElementSettings($element_id, $settings) {
        if (!$this->user_id) {
            return ['success' => false, 'message' => 'Usuario no autenticado'];
        }
        
        // Verificar que el elemento pertenece a un proyecto del usuario
        $stmt = $this->db->prepare("
            SELECT se.id 
            FROM obelis_studio_elements se
            JOIN obelis_studio_projects sp ON se.project_id = sp.id
            WHERE se.id = ? AND sp.user_id = ?
        ");
        
        $stmt->bind_param("ii", $element_id, $this->user_id);
        $stmt->execute();
        
        if (!$stmt->get_result()->fetch_assoc()) {
            return ['success' => false, 'message' => 'Elemento no encontrado o sin permisos'];
        }
        
        $stmt = $this->db->prepare("UPDATE obelis_studio_elements SET settings = ? WHERE id = ?");
        $settings_json = json_encode($settings);
        $stmt->bind_param("si", $settings_json, $element_id);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Configuración actualizada exitosamente'];
        }
        
        return ['success' => false, 'message' => 'Error al actualizar la configuración'];
    }
    
    /**
     * Reordena elementos en un proyecto
     */
    public function reorderElements($project_id, $element_orders) {
        if (!$this->user_id) {
            return ['success' => false, 'message' => 'Usuario no autenticado'];
        }
        
        // Verificar que el proyecto pertenece al usuario
        $stmt = $this->db->prepare("SELECT id FROM obelis_studio_projects WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $project_id, $this->user_id);
        $stmt->execute();
        
        if (!$stmt->get_result()->fetch_assoc()) {
            return ['success' => false, 'message' => 'Proyecto no encontrado o sin permisos'];
        }
        
        // Actualizar posiciones
        $this->db->autocommit(false);
        
        try {
            foreach ($element_orders as $element_id => $position) {
                $stmt = $this->db->prepare("
                    UPDATE obelis_studio_elements 
                    SET position_order = ? 
                    WHERE id = ? AND project_id = ?
                ");
                $stmt->bind_param("iii", $position, $element_id, $project_id);
                $stmt->execute();
            }
            
            $this->db->commit();
            $this->db->autocommit(true);
            
            return ['success' => true, 'message' => 'Elementos reordenados exitosamente'];
            
        } catch (Exception $e) {
            $this->db->rollback();
            $this->db->autocommit(true);
            return ['success' => false, 'message' => 'Error al reordenar elementos'];
        }
    }
    
    /**
     * Elimina un elemento de un proyecto
     */
    public function removeElementFromProject($element_id) {
        if (!$this->user_id) {
            return ['success' => false, 'message' => 'Usuario no autenticado'];
        }
        
        // Verificar que el elemento pertenece a un proyecto del usuario
        $stmt = $this->db->prepare("
            SELECT se.id 
            FROM obelis_studio_elements se
            JOIN obelis_studio_projects sp ON se.project_id = sp.id
            WHERE se.id = ? AND sp.user_id = ?
        ");
        
        $stmt->bind_param("ii", $element_id, $this->user_id);
        $stmt->execute();
        
        if (!$stmt->get_result()->fetch_assoc()) {
            return ['success' => false, 'message' => 'Elemento no encontrado o sin permisos'];
        }
        
        $stmt = $this->db->prepare("DELETE FROM obelis_studio_elements WHERE id = ?");
        $stmt->bind_param("i", $element_id);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Elemento eliminado exitosamente'];
        }
        
        return ['success' => false, 'message' => 'Error al eliminar el elemento'];
    }
    
    /**
     * Obtiene configuraciones por defecto según tipo de elemento
     */
    private function getDefaultSettings($element_type) {
        switch ($element_type) {
            case 'image':
                return [
                    'width' => '100%',
                    'height' => 'auto',
                    'alignment' => 'center',
                    'border_radius' => '0px',
                    'shadow' => false,
                    'caption' => ''
                ];
                
            case 'text':
                return [
                    'font_size' => '16px',
                    'font_family' => 'Arial, sans-serif',
                    'color' => '#333333',
                    'alignment' => 'left',
                    'line_height' => '1.6',
                    'margin_bottom' => '20px'
                ];
                
            case 'audio':
                return [
                    'controls' => true,
                    'autoplay' => false,
                    'loop' => false,
                    'width' => '100%',
                    'show_title' => true
                ];
                
            case 'video':
                return [
                    'width' => '100%',
                    'height' => '315px',
                    'autoplay' => false,
                    'controls' => true,
                    'responsive' => true
                ];
                
            default:
                return [];
        }
    }
    
    /**
     * Obtiene información detallada de un elemento
     */
    public function getElementDetails($element_id, $element_type) {
        if (!in_array($element_type, ['image', 'text', 'audio'])) {
            return null;
        }
        
        $stmt = $this->db->prepare("
            SELECT * FROM user_creations 
            WHERE id = ? AND type = ? AND user_id = ?
        ");
        
        $stmt->bind_param("isi", $element_id, $element_type, $this->user_id);
        $stmt->execute();
        $element = $stmt->get_result()->fetch_assoc();
        
        if ($element && $element['metadata']) {
            $element['metadata'] = json_decode($element['metadata'], true);
        }
        
        return $element;
    }
}
?>
