<?php
/**
 * Obelis Studio - Editor Visual de Proyectos
 * Sistema independiente para crear proyectos multimedia interactivos
 */

namespace ObelisIA\ObelisStudio;

require_once __DIR__ . '/../../helpers/db.php';
require_once __DIR__ . '/../Database/Database.php';

class ObelisStudio {
    
    private $db;
    private $user_id;
    
    public function __construct($user_id = null) {
        // Usar PDO directamente
        $database = new \ObelisIA\Database\Database();
        $this->db = $database->getConnection();
        $this->user_id = $user_id;
    }
    
    /**
     * Obtiene la configuración del Studio
     */
    public static function getConfig() {
        return [
            'name' => 'Obelis Studio',
            'description' => 'Editor visual de proyectos multimedia',
            'version' => '1.0.0',
            'author' => 'ObelisIA',
            'features' => [
                'drag_drop' => true,
                'wysiwyg_editor' => true,
                'multimedia_support' => true,
                'templates' => true,
                'auto_save' => true,
                'export_html' => true,
                'export_pdf' => true,
                'collaboration' => false // Para futuras versiones
            ],
            'limits' => [
                'max_elements_per_project' => 100,
                'max_projects_per_user' => 50,
                'auto_save_interval' => 30 // segundos
            ],
            'supported_elements' => [
                'image' => 'Imágenes generadas por IA',
                'text' => 'Textos generados por IA', 
                'audio' => 'Audios generados por IA',
                'video' => 'Videos embebidos',
                'custom' => 'Elementos personalizados'
            ]
        ];
    }
    
    /**
     * Verifica si el usuario tiene acceso al Studio
     */
    public function hasAccess() {
        if (!$this->user_id) {
            return false;
        }
        
        // Aquí puedes añadir lógica adicional de permisos
        // Por ejemplo, verificar suscripciones, planes, etc.
        return true;
    }
    
    /**
     * Obtiene estadísticas del usuario en el Studio
     */
    public function getUserStats() {
        if (!$this->user_id) {
            return null;
        }
        
        $stmt = $this->db->prepare("
            SELECT 
                COUNT(*) as total_projects,
                COUNT(CASE WHEN status = 'published' THEN 1 END) as published_projects,
                COUNT(CASE WHEN status = 'draft' THEN 1 END) as draft_projects,
                MAX(updated_at) as last_activity
            FROM obelis_studio_projects 
            WHERE user_id = :user_id
        ");
        
        $stmt->bindParam(':user_id', $this->user_id, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetch(\PDO::FETCH_ASSOC);
    }
    
    /**
     * Crea un nuevo proyecto
     */
    public function createProject($title, $description = '') {
        if (!$this->user_id) {
            return ['success' => false, 'message' => 'Usuario no autenticado'];
        }
        
        $stmt = $this->db->prepare("
            INSERT INTO obelis_studio_projects 
            (user_id, title, description, content, status) 
            VALUES (:user_id, :title, :description, '{}', 'draft')
        ");
        
        $stmt->bindParam(':user_id', $this->user_id, \PDO::PARAM_INT);
        $stmt->bindParam(':title', $title, \PDO::PARAM_STR);
        $stmt->bindParam(':description', $description, \PDO::PARAM_STR);
        
        if ($stmt->execute()) {
            $project_id = $this->db->lastInsertId();
            return [
                'success' => true, 
                'project_id' => $project_id,
                'message' => 'Proyecto creado exitosamente'
            ];
        }
        
        return ['success' => false, 'message' => 'Error al crear el proyecto'];
    }
    
    /**
     * Obtiene los proyectos del usuario
     */
    public function getUserProjects($status = null) {
        if (!$this->user_id) {
            return [];
        }
        
        $sql = "SELECT * FROM obelis_studio_projects WHERE user_id = ?";
        $params = [$this->user_id];
        
        if ($status) {
            $sql .= " AND status = ?";
            $params[] = $status;
        }
        
        $sql .= " ORDER BY updated_at DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }
    
    /**
     * Obtiene proyectos públicos para la comunidad
     */
    public function getPublicProjects($limit = 20, $offset = 0) {
        $stmt = $this->db->prepare("
            SELECT p.*, u.username, u.profile_pic 
            FROM obelis_studio_projects p
            JOIN users u ON p.user_id = u.id
            WHERE p.is_public = 1 AND p.status = 'published'
            ORDER BY p.updated_at DESC
            LIMIT ? OFFSET ?
        ");
        
        $stmt->execute([$limit, $offset]);
        
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }
}
?>
