<?php
/**
 * Project Manager - Gestión avanzada de proyectos del Studio
 */

namespace ObelisIA\ObelisStudio;

require_once __DIR__ . '/../../helpers/db.php';
require_once __DIR__ . '/../Database/Database.php';

class ProjectManager {
    
    private $db;
    private $user_id;
    
    public function __construct($user_id = null) {
        // Usar PDO directamente
        $database = new \ObelisIA\Database\Database();
        $this->db = $database->getConnection();
        $this->user_id = $user_id;
    }
    
    /**
     * Obtiene un proyecto específico
     */
    public function getProject($project_id) {
        $stmt = $this->db->prepare("
            SELECT * FROM obelis_studio_projects 
            WHERE id = :project_id AND (user_id = :user_id OR is_public = 1)
        ");
        
        $stmt->bindParam(':project_id', $project_id, \PDO::PARAM_INT);
        $stmt->bindParam(':user_id', $this->user_id, \PDO::PARAM_INT);
        $stmt->execute();
        $project = $stmt->fetch(\PDO::FETCH_ASSOC);
        
        if ($project) {
            // Obtener elementos del proyecto
            $project['elements'] = $this->getProjectElements($project_id);
            // Decodificar contenido JSON
            $project['content'] = json_decode($project['content'], true);
        }
        
        return $project;
    }
    
    /**
     * Guarda un proyecto (auto-guardado o manual)
     */
    public function saveProject($project_id, $data) {
        if (!$this->user_id) {
            return ['success' => false, 'message' => 'Usuario no autenticado'];
        }
        
        // Verificar que el proyecto pertenece al usuario
        $stmt = $this->db->prepare("SELECT id FROM obelis_studio_projects WHERE id = :project_id AND user_id = :user_id");
        $stmt->bindParam(':project_id', $project_id, \PDO::PARAM_INT);
        $stmt->bindParam(':user_id', $this->user_id, \PDO::PARAM_INT);
        $stmt->execute();
        
        if (!$stmt->fetch(\PDO::FETCH_ASSOC)) {
            return ['success' => false, 'message' => 'Proyecto no encontrado o sin permisos'];
        }
        
        // Preparar datos para actualizar
        $content = isset($data['content']) ? json_encode($data['content']) : null;
        $title = $data['title'] ?? null;
        $description = $data['description'] ?? null;
        
        $updates = [];
        $params = [':project_id' => $project_id, ':user_id' => $this->user_id];
        
        if ($content !== null) {
            $updates[] = "content = :content";
            $params[':content'] = $content;
        }
        
        if ($title !== null) {
            $updates[] = "title = :title";
            $params[':title'] = $title;
        }
        
        if ($description !== null) {
            $updates[] = "description = :description";
            $params[':description'] = $description;
        }
        
        if (empty($updates)) {
            return ['success' => false, 'message' => 'No hay datos para actualizar'];
        }
        
        $updates[] = "updated_at = NOW()";
        
        $sql = "UPDATE obelis_studio_projects SET " . implode(', ', $updates) . " WHERE id = :project_id AND user_id = :user_id";
        $stmt = $this->db->prepare($sql);
        
        // Bind parameters
        foreach ($params as $key => $value) {
            if ($key === ':project_id' || $key === ':user_id') {
                $stmt->bindValue($key, $value, \PDO::PARAM_INT);
            } else {
                $stmt->bindValue($key, $value, \PDO::PARAM_STR);
            }
        }
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Proyecto guardado exitosamente'];
        }
        
        return ['success' => false, 'message' => 'Error al guardar el proyecto'];
    }
    
    /**
     * Publica un proyecto
     */
    public function publishProject($project_id, $is_public = true) {
        if (!$this->user_id) {
            return ['success' => false, 'message' => 'Usuario no autenticado'];
        }
        
        $stmt = $this->db->prepare("
            UPDATE obelis_studio_projects 
            SET is_public = ?, status = 'published', updated_at = NOW()
            WHERE id = ? AND user_id = ?
        ");
        
        $public_flag = $is_public ? 1 : 0;
        $stmt->bind_param("iii", $public_flag, $project_id, $this->user_id);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Proyecto publicado exitosamente'];
        }
        
        return ['success' => false, 'message' => 'Error al publicar el proyecto'];
    }
    
    /**
     * Elimina un proyecto
     */
    public function deleteProject($project_id) {
        if (!$this->user_id) {
            return ['success' => false, 'message' => 'Usuario no autenticado'];
        }
        
        $this->db->begin_transaction();
        
        try {
            // Primero eliminar elementos relacionados
            $stmt = $this->db->prepare("DELETE FROM obelis_studio_elements WHERE project_id = ?");
            $stmt->bind_param("i", $project_id);
            $stmt->execute();
            
            // LÓGICA MANUAL: Eliminar estadísticas del proyecto (reemplaza TRIGGER)
            $stmt = $this->db->prepare("DELETE FROM project_stats_cache WHERE project_id = ?");
            $stmt->bind_param("i", $project_id);
            $stmt->execute();
            
            // Luego eliminar el proyecto (esto eliminará automáticamente likes, comentarios y favoritos por CASCADE)
            $stmt = $this->db->prepare("DELETE FROM obelis_studio_projects WHERE id = ? AND user_id = ?");
            $stmt->bind_param("ii", $project_id, $this->user_id);
            
            if ($stmt->execute() && $stmt->affected_rows > 0) {
                $this->db->commit();
                return ['success' => true, 'message' => 'Proyecto eliminado exitosamente'];
            } else {
                $this->db->rollback();
                return ['success' => false, 'message' => 'Proyecto no encontrado o no tienes permisos'];
            }
        } catch (Exception $e) {
            $this->db->rollback();
            return ['success' => false, 'message' => 'Error al eliminar el proyecto: ' . $e->getMessage()];
        }
    }
    
    /**
     * Duplica un proyecto
     */
    public function duplicateProject($project_id) {
        if (!$this->user_id) {
            return ['success' => false, 'message' => 'Usuario no autenticado'];
        }
        
        $original = $this->getProject($project_id);
        if (!$original) {
            return ['success' => false, 'message' => 'Proyecto no encontrado'];
        }
        
        // Crear copia
        $new_title = $original['title'] . ' (Copia)';
        $content = json_encode($original['content']);
        
        $stmt = $this->db->prepare("
            INSERT INTO obelis_studio_projects 
            (user_id, title, description, content, status) 
            VALUES (?, ?, ?, ?, 'draft')
        ");
        
        $stmt->bind_param("isss", $this->user_id, $new_title, $original['description'], $content);
        
        if ($stmt->execute()) {
            $new_project_id = $this->db->insert_id;
            
            // Copiar elementos si existen
            if (!empty($original['elements'])) {
                $this->duplicateProjectElements($project_id, $new_project_id);
            }
            
            return [
                'success' => true, 
                'project_id' => $new_project_id,
                'message' => 'Proyecto duplicado exitosamente'
            ];
        }
        
        return ['success' => false, 'message' => 'Error al duplicar el proyecto'];
    }
    
    /**
     * Obtiene elementos de un proyecto
     */
    private function getProjectElements($project_id) {
        $stmt = $this->db->prepare("
            SELECT * FROM obelis_studio_elements 
            WHERE project_id = :project_id 
            ORDER BY position_order ASC
        ");
        
        $stmt->bindParam(':project_id', $project_id, \PDO::PARAM_INT);
        $stmt->execute();
        $elements = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        
        // Decodificar settings JSON
        foreach ($elements as &$element) {
            $element['settings'] = json_decode($element['settings'], true);
        }
        
        return $elements;
    }
    
    /**
     * Duplica elementos de un proyecto
     */
    private function duplicateProjectElements($original_project_id, $new_project_id) {
        $stmt = $this->db->prepare("
            INSERT INTO obelis_studio_elements 
            (project_id, element_type, element_id, position_order, settings)
            SELECT :new_project_id, element_type, element_id, position_order, settings
            FROM obelis_studio_elements 
            WHERE project_id = :original_project_id
        ");
        
        $stmt->bindParam(':new_project_id', $new_project_id, \PDO::PARAM_INT);
        $stmt->bindParam(':original_project_id', $original_project_id, \PDO::PARAM_INT);
        return $stmt->execute();
    }
    
    /**
     * Obtiene todos los proyectos del usuario
     */
    public function getUserProjects($limit = null, $status = null) {
        if (!$this->user_id) {
            return [];
        }

        $sql = "SELECT * FROM obelis_studio_projects WHERE user_id = :user_id";
        $params = [':user_id' => $this->user_id];

        if ($status) {
            $sql .= " AND status = :status";
            $params[':status'] = $status;
        }

        $sql .= " ORDER BY updated_at DESC";

        if ($limit) {
            $sql .= " LIMIT :limit";
            $params[':limit'] = $limit;
        }

        $stmt = $this->db->prepare($sql);
        
        // Bind parameters
        foreach ($params as $key => $value) {
            if ($key === ':user_id' || $key === ':limit') {
                $stmt->bindValue($key, $value, \PDO::PARAM_INT);
            } else {
                $stmt->bindValue($key, $value, \PDO::PARAM_STR);
            }
        }
        
        $stmt->execute();
        
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    /**
     * Genera thumbnail automático del proyecto
     */
    public function generateThumbnail($project_id) {
        // Esta función puede implementarse más tarde
        // Podría capturar una imagen del proyecto o usar la primera imagen
        return null;
    }
}
?>
