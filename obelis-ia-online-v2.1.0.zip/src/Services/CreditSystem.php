<?php

/**
 * Sistema de Créditos y Límites de Obelis
 * Gestiona créditos, límites por plan, experiencia y gamificación
 */

class CreditSystem {
    private $db;
    private $user_id;
    
    // Configuración de créditos por herramienta
    const TOOL_COSTS = [
        'text_generation' => 1,
        'image_generation' => 3,
        'audio_generation' => 5,
        'video_generation' => 10,
        'translation' => 1,
        'text_improvement' => 2,
        'seo_optimization' => 2,
        'voice_synthesis' => 4,
        'background_removal' => 2,
        'image_upscale' => 3
    ];
    
    // Experiencia otorgada por herramienta
    const TOOL_EXPERIENCE = [
        'text_generation' => 10,
        'image_generation' => 25,
        'audio_generation' => 40,
        'video_generation' => 75,
        'translation' => 5,
        'text_improvement' => 15,
        'seo_optimization' => 20,
        'voice_synthesis' => 30,
        'background_removal' => 15,
        'image_upscale' => 20
    ];
    
    // Límites mensuales por plan
    const PLAN_LIMITS = [
        'free' => [
            'monthly_generations' => 50,
            'daily_generations' => 5,
            'requires_ads' => true,
            'credits_per_month' => 0
        ],
        'premium' => [
            'monthly_generations' => 5000,
            'daily_generations' => 200,
            'requires_ads' => false,
            'credits_per_month' => 1000
        ]
    ];
    
    public function __construct($db, $user_id) {
        $this->db = $db;
        $this->user_id = $user_id;
    }
    
    /**
     * Verificar si el usuario puede realizar una generación
     */
    public function canGenerate($tool_type) {
        $user_data = $this->getUserData();
        $cost = self::TOOL_COSTS[$tool_type] ?? 1;
        
        // Verificar plan y límites
        $plan_limits = self::PLAN_LIMITS[$user_data['subscription_type']] ?? self::PLAN_LIMITS['free'];
        
        // Verificar límites diarios y mensuales
        if (!$this->checkDailyLimit($plan_limits['daily_generations'])) {
            return [
                'can_generate' => false,
                'reason' => 'daily_limit_exceeded',
                'message' => 'Has alcanzado tu límite diario de generaciones'
            ];
        }
        
        if (!$this->checkMonthlyLimit($plan_limits['monthly_generations'])) {
            return [
                'can_generate' => false,
                'reason' => 'monthly_limit_exceeded',
                'message' => 'Has alcanzado tu límite mensual de generaciones'
            ];
        }
        
        // Verificar créditos si es necesario
        if ($user_data['subscription_type'] === 'free' || $user_data['credits'] < $cost) {
            if ($user_data['credits'] < $cost) {
                return [
                    'can_generate' => false,
                    'reason' => 'insufficient_credits',
                    'message' => "Necesitas {$cost} créditos para usar esta herramienta",
                    'required_credits' => $cost,
                    'current_credits' => $user_data['credits']
                ];
            }
        }
        
        return [
            'can_generate' => true,
            'cost' => $cost,
            'requires_ad' => $plan_limits['requires_ads'],
            'current_credits' => $user_data['credits']
        ];
    }
    
    /**
     * Procesar generación exitosa
     */
    public function processGeneration($tool_type, $generation_data = []) {
        $cost = self::TOOL_COSTS[$tool_type] ?? 1;
        $experience = self::TOOL_EXPERIENCE[$tool_type] ?? 10;
        
        $this->db->beginTransaction();
        
        try {
            // Descontar créditos
            $this->deductCredits($cost);
            
            // Otorgar experiencia
            $this->awardExperience($experience);
            
            // Registrar generación
            $this->logGeneration($tool_type, $cost, $experience, $generation_data);
            
            // Verificar logros y recompensas
            $achievements = $this->checkAchievements();
            
            $this->db->commit();
            
            return [
                'success' => true,
                'credits_used' => $cost,
                'experience_gained' => $experience,
                'new_achievements' => $achievements,
                'remaining_credits' => $this->getUserCredits()
            ];
            
        } catch (Exception $e) {
            $this->db->rollback();
            throw $e;
        }
    }
    
    /**
     * Obtener datos del usuario
     */
    private function getUserData() {
        $stmt = $this->db->prepare("
            SELECT subscription_type, credits, level, total_experience, 
                   total_generations, daily_generations, monthly_generations,
                   last_generation_date, last_monthly_reset
            FROM users 
            WHERE id = ?
        ");
        $stmt->execute([$this->user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$user) {
            throw new Exception('Usuario no encontrado');
        }
        
        // Resetear contadores si es necesario
        $this->resetCountersIfNeeded($user);
        
        return $user;
    }
    
    /**
     * Resetear contadores diarios/mensuales si es necesario
     */
    private function resetCountersIfNeeded($user) {
        $today = date('Y-m-d');
        $this_month = date('Y-m');
        
        $updates = [];
        $params = [];
        
        // Reset diario
        if ($user['last_generation_date'] !== $today) {
            $updates[] = "daily_generations = 0, last_generation_date = ?";
            $params[] = $today;
        }
        
        // Reset mensual
        if (substr($user['last_monthly_reset'], 0, 7) !== $this_month) {
            $updates[] = "monthly_generations = 0, last_monthly_reset = ?";
            $params[] = $today;
            
            // Otorgar créditos mensuales para premium
            if ($user['subscription_type'] === 'premium') {
                $monthly_credits = self::PLAN_LIMITS['premium']['credits_per_month'];
                $updates[] = "credits = credits + ?";
                $params[] = $monthly_credits;
            }
        }
        
        if (!empty($updates)) {
            $params[] = $this->user_id;
            $stmt = $this->db->prepare("
                UPDATE users 
                SET " . implode(', ', $updates) . "
                WHERE id = ?
            ");
            $stmt->execute($params);
        }
    }
    
    /**
     * Verificar límite diario
     */
    private function checkDailyLimit($limit) {
        $stmt = $this->db->prepare("
            SELECT daily_generations 
            FROM users 
            WHERE id = ? AND last_generation_date = CURDATE()
        ");
        $stmt->execute([$this->user_id]);
        $result = $stmt->fetch();
        
        return !$result || $result['daily_generations'] < $limit;
    }
    
    /**
     * Verificar límite mensual
     */
    private function checkMonthlyLimit($limit) {
        $stmt = $this->db->prepare("
            SELECT monthly_generations 
            FROM users 
            WHERE id = ? AND DATE_FORMAT(last_monthly_reset, '%Y-%m') = DATE_FORMAT(NOW(), '%Y-%m')
        ");
        $stmt->execute([$this->user_id]);
        $result = $stmt->fetch();
        
        return !$result || $result['monthly_generations'] < $limit;
    }
    
    /**
     * Descontar créditos
     */
    private function deductCredits($amount) {
        $stmt = $this->db->prepare("
            UPDATE users 
            SET credits = GREATEST(0, credits - ?),
                daily_generations = daily_generations + 1,
                monthly_generations = monthly_generations + 1,
                total_generations = total_generations + 1
            WHERE id = ?
        ");
        $stmt->execute([$amount, $this->user_id]);
    }
    
    /**
     * Otorgar experiencia
     */
    private function awardExperience($amount) {
        $stmt = $this->db->prepare("
            UPDATE users 
            SET total_experience = total_experience + ?
            WHERE id = ?
        ");
        $stmt->execute([$amount, $this->user_id]);
        
        // Calcular nuevo nivel
        $this->updateUserLevel();
    }
    
    /**
     * Actualizar nivel del usuario
     */
    private function updateUserLevel() {
        $stmt = $this->db->prepare("
            SELECT total_experience, level 
            FROM users 
            WHERE id = ?
        ");
        $stmt->execute([$this->user_id]);
        $user = $stmt->fetch();
        
        $new_level = $this->calculateLevel($user['total_experience']);
        
        if ($new_level > $user['level']) {
            $stmt = $this->db->prepare("
                UPDATE users 
                SET level = ?
                WHERE id = ?
            ");
            $stmt->execute([$new_level, $this->user_id]);
            
            // Otorgar recompensas por subir de nivel
            $this->awardLevelRewards($new_level);
        }
    }
    
    /**
     * Calcular nivel basado en experiencia
     */
    private function calculateLevel($experience) {
        // Fórmula: nivel = sqrt(experiencia / 100)
        return floor(sqrt($experience / 100)) + 1;
    }
    
    /**
     * Otorgar recompensas por nivel
     */
    private function awardLevelRewards($level) {
        $credits_reward = $level * 10; // 10 créditos por nivel
        
        $stmt = $this->db->prepare("
            UPDATE users 
            SET credits = credits + ?
            WHERE id = ?
        ");
        $stmt->execute([$credits_reward, $this->user_id]);
        
        // Registrar logro
        $this->unlockAchievement('level_up', [
            'level' => $level,
            'credits_earned' => $credits_reward
        ]);
    }
    
    /**
     * Registrar generación
     */
    private function logGeneration($tool_type, $cost, $experience, $data) {
        $stmt = $this->db->prepare("
            INSERT INTO generation_logs (
                user_id, tool_type, credits_cost, experience_gained, 
                generation_data, created_at
            ) VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $this->user_id,
            $tool_type,
            $cost,
            $experience,
            json_encode($data)
        ]);
    }
    
    /**
     * Verificar logros
     */
    private function checkAchievements() {
        $achievements = [];
        $user_data = $this->getUserData();
        
        // Logro por primera generación
        if ($user_data['total_generations'] === 1) {
            $achievements[] = $this->unlockAchievement('first_generation');
        }
        
        // Logros por cantidad de generaciones
        $generation_milestones = [10, 50, 100, 500, 1000];
        foreach ($generation_milestones as $milestone) {
            if ($user_data['total_generations'] === $milestone) {
                $achievements[] = $this->unlockAchievement('generation_milestone', ['count' => $milestone]);
            }
        }
        
        // Logros por nivel
        $level_milestones = [5, 10, 25, 50, 100];
        foreach ($level_milestones as $milestone) {
            if ($user_data['level'] === $milestone) {
                $achievements[] = $this->unlockAchievement('level_milestone', ['level' => $milestone]);
            }
        }
        
        return $achievements;
    }
    
    /**
     * Desbloquear logro
     */
    private function unlockAchievement($achievement_type, $data = []) {
        // Verificar si ya tiene el logro
        $stmt = $this->db->prepare("
            SELECT id FROM user_achievements 
            WHERE user_id = ? AND achievement_type = ?
        ");
        $stmt->execute([$this->user_id, $achievement_type]);
        
        if ($stmt->fetch()) {
            return null; // Ya tiene el logro
        }
        
        // Definir recompensas por logro
        $achievement_rewards = [
            'first_generation' => ['credits' => 50, 'title' => 'Primer Creador'],
            'generation_milestone' => ['credits' => 100, 'title' => 'Generador Prolífico'],
            'level_milestone' => ['credits' => 200, 'title' => 'Maestro Creator'],
            'level_up' => ['credits' => 0, 'title' => 'Subida de Nivel']
        ];
        
        $reward = $achievement_rewards[$achievement_type] ?? ['credits' => 0, 'title' => 'Logro Desbloqueado'];
        
        // Registrar logro
        $stmt = $this->db->prepare("
            INSERT INTO user_achievements (
                user_id, achievement_type, achievement_data, 
                credits_reward, created_at
            ) VALUES (?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $this->user_id,
            $achievement_type,
            json_encode($data),
            $reward['credits']
        ]);
        
        // Otorgar créditos de recompensa
        if ($reward['credits'] > 0) {
            $stmt = $this->db->prepare("
                UPDATE users 
                SET credits = credits + ?
                WHERE id = ?
            ");
            $stmt->execute([$reward['credits'], $this->user_id]);
        }
        
        return [
            'type' => $achievement_type,
            'title' => $reward['title'],
            'credits_reward' => $reward['credits'],
            'data' => $data
        ];
    }
    
    /**
     * Obtener créditos actuales del usuario
     */
    public function getUserCredits() {
        $stmt = $this->db->prepare("SELECT credits FROM users WHERE id = ?");
        $stmt->execute([$this->user_id]);
        $result = $stmt->fetch();
        return $result ? $result['credits'] : 0;
    }
    
    /**
     * Añadir créditos a un usuario de forma segura
     */
    public function addCredits($user_id, $credits_amount, $transaction_type = 'purchase', $description = null, $reference_id = null, $reference_type = null) {
        try {
            $this->db->beginTransaction();
            
            // Obtener créditos actuales con lock
            $stmt = $this->db->prepare("SELECT credits FROM users WHERE id = ? FOR UPDATE");
            $stmt->execute([$user_id]);
            $current_credits = $stmt->fetchColumn();
            
            if ($current_credits === false) {
                throw new Exception('Usuario no encontrado');
            }
            
            $new_credits = $current_credits + $credits_amount;
            
            // Validar que no sea negativo (excepto para ajustes administrativos)
            if ($new_credits < 0 && $transaction_type !== 'adjustment') {
                throw new Exception('Créditos insuficientes');
            }
            
            // Actualizar créditos del usuario
            $stmt = $this->db->prepare("
                UPDATE users 
                SET credits = ?, updated_at = CURRENT_TIMESTAMP 
                WHERE id = ?
            ");
            $stmt->execute([$new_credits, $user_id]);
            
            // Verificar si la tabla credit_transactions existe antes de usarla
            try {
                $stmt = $this->db->prepare("
                    INSERT INTO credit_transactions (
                        user_id, transaction_type, credits_amount, 
                        credits_before, credits_after, description,
                        reference_id, reference_type
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");
                
                $stmt->execute([
                    $user_id, $transaction_type, $credits_amount,
                    $current_credits, $new_credits, $description,
                    $reference_id, $reference_type
                ]);
            } catch (Exception $e) {
                // Si no existe la tabla, continuar sin el log
                error_log("Warning: credit_transactions table not found: " . $e->getMessage());
            }
            
            $this->db->commit();
            return $new_credits;
            
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log("Error añadiendo créditos: " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * Obtener estadísticas del usuario
     */
    public function getUserStats() {
        $stmt = $this->db->prepare("
            SELECT level, total_experience, total_generations, credits,
                   daily_generations, monthly_generations
            FROM users 
            WHERE id = ?
        ");
        $stmt->execute([$this->user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Calcular experiencia necesaria para siguiente nivel
        $current_level_exp = pow($user['level'] - 1, 2) * 100;
        $next_level_exp = pow($user['level'], 2) * 100;
        $exp_for_next = $next_level_exp - $user['total_experience'];
        
        return [
            'level' => $user['level'],
            'total_experience' => $user['total_experience'],
            'experience_for_next_level' => $exp_for_next,
            'total_generations' => $user['total_generations'],
            'credits' => $user['credits'],
            'daily_generations' => $user['daily_generations'],
            'monthly_generations' => $user['monthly_generations']
        ];
    }
}
?>
