<?php

/**
 * Sistema de Anuncios para Usuarios Gratuitos
 * Gestiona la visualización de anuncios antes de usar herramientas
 */

class AdSystem {
    private $db;
    private $user_id;
    
    // Configuración de anuncios
    const AD_PROVIDERS = [
        'google_adsense' => [
            'enabled' => true,
            'slot_id' => 'ca-pub-9956937945939380/f08c47fec0942fa0',
            'format' => 'auto'
        ],
        'media_net' => [
            'enabled' => false,
            'customer_id' => 'XXXXXXXX',
            'slot_id' => 'XXXXXXXX'
        ]
    ];
    
    // Tiempo mínimo de visualización (segundos)
    const MIN_VIEW_TIME = 15;
    
    public function __construct($db, $user_id) {
        $this->db = $db;
        $this->user_id = $user_id;
    }
    
    /**
     * Verificar si el usuario necesita ver anuncio
     */
    public function needsToWatchAd($tool_type) {
        // Obtener datos del usuario
        $stmt = $this->db->prepare("SELECT subscription_type FROM users WHERE id = ?");
        $stmt->execute([$this->user_id]);
        $user = $stmt->fetch();
        
        if (!$user || $user['subscription_type'] === 'premium') {
            return false;
        }
        
        // Verificar si ya vio un anuncio recientemente
        $stmt = $this->db->prepare("
            SELECT created_at 
            FROM ad_views 
            WHERE user_id = ? 
            AND created_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE)
            ORDER BY created_at DESC 
            LIMIT 1
        ");
        $stmt->execute([$this->user_id]);
        $recent_ad = $stmt->fetch();
        
        // Si vio un anuncio en los últimos 5 minutos, no necesita ver otro
        return !$recent_ad;
    }
    
    /**
     * Generar código HTML del anuncio
     */
    public function generateAdHTML($tool_type) {
        $ad_data = [
            'ad_id' => uniqid('ad_'),
            'tool_type' => $tool_type,
            'user_id' => $this->user_id,
            'min_view_time' => self::MIN_VIEW_TIME
        ];
        
        return [
            'ad_id' => $ad_data['ad_id'],
            'html' => $this->getAdHTML($ad_data),
            'min_view_time' => self::MIN_VIEW_TIME
        ];
    }
    
    /**
     * Obtener HTML del anuncio
     */
    private function getAdHTML($ad_data) {
        return '
        <div id="ad-modal-' . $ad_data['ad_id'] . '" class="ad-modal">
            <div class="ad-modal-content">
                <div class="ad-header">
                    <h4><i class="fas fa-gift me-2"></i>Anuncio - Obelis Gratuito</h4>
                    <div class="ad-timer">
                        <i class="fas fa-clock me-1"></i>
                        <span id="ad-timer-' . $ad_data['ad_id'] . '">' . self::MIN_VIEW_TIME . '</span>s
                    </div>
                </div>
                
                <div class="ad-body">
                    ' . $this->getAdContent() . '
                </div>
                
                <div class="ad-footer">
                    <button id="ad-skip-btn-' . $ad_data['ad_id'] . '" class="btn btn-primary" disabled>
                        <i class="fas fa-forward me-1"></i>
                        Continuar (<span id="skip-countdown-' . $ad_data['ad_id'] . '">' . self::MIN_VIEW_TIME . '</span>s)
                    </button>
                    
                    <div class="ad-upgrade-hint mt-3">
                        <small class="text-muted">
                            💎 <a href="/checkout">Actualiza a Premium</a> para eliminar anuncios
                        </small>
                    </div>
                </div>
            </div>
        </div>
        
        <style>
        .ad-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
        }
        
        .ad-modal-content {
            background: white;
            border-radius: 15px;
            max-width: 600px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
        }
        
        .ad-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 15px 15px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .ad-timer {
            background: rgba(255,255,255,0.2);
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: bold;
        }
        
        .ad-body {
            padding: 30px;
            text-align: center;
            min-height: 300px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .ad-footer {
            padding: 20px 30px;
            text-align: center;
            border-top: 1px solid #e9ecef;
        }
        
        .ad-content {
            width: 100%;
        }
        </style>
        
        <script>
        (function() {
            let timeLeft = ' . self::MIN_VIEW_TIME . ';
            const adId = "' . $ad_data['ad_id'] . '";
            const timerElement = document.getElementById("ad-timer-" + adId);
            const skipBtn = document.getElementById("ad-skip-btn-" + adId);
            const countdownElement = document.getElementById("skip-countdown-" + adId);
            
            const countdown = setInterval(() => {
                timeLeft--;
                timerElement.textContent = timeLeft;
                countdownElement.textContent = timeLeft;
                
                if (timeLeft <= 0) {
                    clearInterval(countdown);
                    skipBtn.disabled = false;
                    skipBtn.innerHTML = "<i class=\"fas fa-forward me-1\"></i>Continuar";
                    skipBtn.classList.add("btn-success");
                    skipBtn.classList.remove("btn-primary");
                }
            }, 1000);
            
            skipBtn.addEventListener("click", function() {
                if (timeLeft <= 0) {
                    // Registrar visualización del anuncio
                    fetch("/api/tools/log_ad_view.php", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            ad_id: adId,
                            tool_type: "' . $ad_data['tool_type'] . '",
                            view_duration: ' . self::MIN_VIEW_TIME . '
                        })
                    });
                    
                    // Cerrar modal
                    document.getElementById("ad-modal-" + adId).remove();
                    
                    // Callback eliminado - ya no se usa unified-tools.js
                }
            });
        })();
        </script>';
    }
    
    /**
     * Obtener contenido del anuncio
     */
    private function getAdContent() {
        // Aquí puedes integrar diferentes proveedores de anuncios
        $ads = [
            '<div class="ad-content">
                <h3>🚀 ¡Potencia tu creatividad!</h3>
                <p>Descubre las herramientas más avanzadas de IA para crear contenido increíble.</p>
                <div class="premium-features mt-4">
                    <div class="row">
                        <div class="col-md-6">
                            ✨ Generación ilimitada<br>
                            🎨 Herramientas avanzadas<br>
                            ☁️ Almacenamiento ampliado
                        </div>
                        <div class="col-md-6">
                            🚀 Sin anuncios<br>
                            💎 Soporte prioritario<br>
                            🔥 Funciones exclusivas
                        </div>
                    </div>
                </div>
            </div>',
            
            '<div class="ad-content">
                <h3>💡 ¿Sabías que...?</h3>
                <p>Los usuarios Premium de Obelis crean 10x más contenido que los usuarios gratuitos.</p>
                <div class="stats mt-4">
                    <div class="row text-center">
                        <div class="col-4">
                            <h2 class="text-primary">5000+</h2>
                            <small>Generaciones/mes</small>
                        </div>
                        <div class="col-4">
                            <h2 class="text-success">24/7</h2>
                            <small>Soporte</small>
                        </div>
                        <div class="col-4">
                            <h2 class="text-warning">∞</h2>
                            <small>Proyectos</small>
                        </div>
                    </div>
                </div>
            </div>',
            
            '<div class="ad-content">
                <h3>🎯 Únete a más de 10,000 creadores</h3>
                <p>Descubre por qué profesionales y creativos eligen Obelis Premium.</p>
                <div class="testimonial mt-4 p-3" style="background: #f8f9fa; border-radius: 8px;">
                    <p class="mb-2">"Obelis Premium transformó mi flujo de trabajo. Ahora creo contenido 5x más rápido."</p>
                    <small class="text-muted">- María García, Diseñadora</small>
                </div>
            </div>'
        ];
        
        return $ads[array_rand($ads)];
    }
    
    /**
     * Registrar visualización de anuncio
     */
    public function logAdView($ad_id, $tool_type, $view_duration) {
        $stmt = $this->db->prepare("
            INSERT INTO ad_views (
                user_id, ad_id, tool_type, view_duration, created_at
            ) VALUES (?, ?, ?, ?, NOW())
        ");
        $stmt->execute([$this->user_id, $ad_id, $tool_type, $view_duration]);
        
        return true;
    }
    
    /**
     * Obtener estadísticas de anuncios
     */
    public function getAdStats($period = '30 days') {
        $stmt = $this->db->prepare("
            SELECT 
                COUNT(*) as total_views,
                AVG(view_duration) as avg_duration,
                COUNT(DISTINCT user_id) as unique_users
            FROM ad_views 
            WHERE created_at > DATE_SUB(NOW(), INTERVAL ? DAY)
        ");
        $stmt->execute([intval($period)]);
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
?>
