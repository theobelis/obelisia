<?php
namespace ObelisIA\Services;

// Es posible que necesites incluir tu archivo de configuración si GEMINI_API_KEY no está globalmente accesible
// Por ejemplo, si config.php define una constante global.
// require_once __DIR__ . '/../Config/config.php'; 

class MetaTagGenerator
{
    private string $geminiApiKey;
    private string $geminiApiEndpoint;
    private string $geminiModel;

    public function __construct()
    {
        // Asegúrate de que GEMINI_API_KEY esté definida en tu config.php
        // Y que config.php sea accesible (ej. incluido en tu bootstrap o en index.php)
        if (!defined('GEMINI_API_KEY')) {
            throw new \Exception("GEMINI_API_KEY no está definida. Asegúrate de que config.php esté cargado.");
        }
        $this->geminiApiKey = GEMINI_API_KEY;
        
        // Define el endpoint y el modelo que ya usas en tu proxy
        // Puedes poner esto en config.php también para centralizar.
        $this->geminiApiEndpoint = 'https://generativelanguage.googleapis.com/v1beta/models/';
        $this->geminiModel = 'gemini-2.0-flash'; // O 'gemini-pro' si prefieres ese modelo
    }

    /**
     * Envía un prompt a Gemini para generar meta etiquetas.
     *
     * @param string $pageContent El contenido principal y relevante de la página.
     * @param string $pageRoute La ruta amigable de la página (ej. 'herramientas/removedor-fondo') para dar contexto a la IA.
     * @return array|false Retorna un array con 'title', 'description', 'keywords' si tiene éxito, o false si hay un error.
     */
    public function generate(string $pageContent, string $pageRoute = '')
    {
        // Limita el contenido para evitar exceder el límite de tokens de la API
        // El modelo gemini-2.0-flash tiene un contexto de 1 millón de tokens, pero es mejor ser conciso.
        // Unos 4000-8000 caracteres del contenido más relevante suelen ser suficientes.

        $truncatedContent = substr($pageContent, 0, 8000);
        $prompt = "Dado el siguiente contenido de una página web, genera un título SEO conciso (máximo 60 caracteres), una meta descripción atractiva (máximo 160 caracteres) y hasta 5 palabras clave relevantes, separadas por comas. El tema general o la ruta de la página es: \"{$pageRoute}\"\n\nResponde únicamente con un objeto JSON en el siguiente formato: {\"title\": \"\", \"description\": \"\", \"keywords\": \"\"}\n\nContenido de la página:\n\"\"\"\n" . $truncatedContent . "\n\"\"\"";

        $requestData = [
            'contents' => [
                [
                    'parts' => [
                        ['text' => $prompt]
                    ]
                ]
            ],
            'generationConfig' => [
                'temperature' => 0.2,
                'maxOutputTokens' => 200,
            ],
        ];

        $fullApiUrl = $this->geminiApiEndpoint . $this->geminiModel . ':generateContent?key=' . $this->geminiApiKey;



        $options = [
            'http' => [
                'header'  => "Content-Type: application/json\r\n",
                'method'  => 'POST',
                'content' => json_encode($requestData),
                'timeout' => 30
            ]
        ];
        $context  = stream_context_create($options);
        $result = @file_get_contents($fullApiUrl, false, $context);

        if ($result === false) {
            $error = error_get_last();
            error_log("Error al llamar a la API de Gemini: " . ($error ? $error['message'] : 'Desconocido'));
            return false;
        }

        $responseData = json_decode($result, true);

        // Debugging: Puedes descomentar esto para ver la respuesta cruda de Gemini
        // error_log("Respuesta cruda de Gemini: " . print_r($responseData, true));

        // Analizar la respuesta de Gemini para extraer el texto generado
        // La estructura es 'candidates[0].content.parts[0].text'
        if (isset($responseData['candidates'][0]['content']['parts'][0]['text'])) {
            $geminiOutput = $responseData['candidates'][0]['content']['parts'][0]['text'];

            // LIMPIEZA: Elimina bloque markdown ```json ... ``` si existe
            $geminiOutput = preg_replace('/^```json|^```/m', '', $geminiOutput); // quita inicio bloque
            $geminiOutput = preg_replace('/```$/m', '', $geminiOutput); // quita fin bloque
            $geminiOutput = trim($geminiOutput);

            // Intentar decodificar el JSON que pedimos a Gemini
            $parsedMeta = json_decode($geminiOutput, true);

            if (json_last_error() === JSON_ERROR_NONE && 
                isset($parsedMeta['title']) && 
                isset($parsedMeta['description']) && 
                isset($parsedMeta['keywords'])) {
                return [
                    'title' => substr($parsedMeta['title'], 0, 60),
                    'description' => substr($parsedMeta['description'], 0, 160),
                    'keywords' => $parsedMeta['keywords']
                ];
            } else {
                error_log("Respuesta de Gemini no tiene el formato JSON esperado o es inválido: " . $geminiOutput);
            }
        } else {
            error_log("La respuesta de Gemini no contiene el texto esperado o está vacía. Estructura: " . json_encode($responseData));
        }
        return false;
    }
}