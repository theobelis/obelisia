<?php
/**
 * Controlador para Obelis Studio
 * Maneja todas las funcionalidades del editor visual
 */

namespace ObelisIA\Controllers;

use ObelisIA\ObelisStudio\ObelisStudio;
use ObelisIA\ObelisStudio\ProjectManager;
use ObelisIA\ObelisStudio\ElementManager;

class StudioController {
    
    private $studio;
    private $projectManager;
    private $elementManager;
    private $user_id;
    
    public function __construct() {
        // Verificar autenticación
        if (!isset($_SESSION['user_id'])) {
            header('Location: /acceso');
            exit;
        }
        
        $this->user_id = $_SESSION['user_id'];
        $this->studio = new ObelisStudio($this->user_id);
        $this->projectManager = new ProjectManager($this->user_id);
        $this->elementManager = new ElementManager($this->user_id);
        
        // Verificar acceso al Studio
        if (!$this->studio->hasAccess()) {
            header('Location: /panel?error=no_studio_access');
            exit;
        }
    }
    
    /**
     * Página principal del Studio
     */
    public function index() {
        // Obtener estadísticas y proyectos del usuario
        $stats = $this->studio->getUserStats();
        $projects = $this->projectManager->getUserProjects();
        
        // Datos para la vista
        $data = [
            'page_title' => 'Obelis Studio',
            'page_description' => 'Editor visual de proyectos multimedia',
            'studio_stats' => $stats,
            'user_projects' => $projects,
            'studio_config' => ObelisStudio::getConfig()
        ];
        
        return $this->render('studio/index', $data);
    }
    
    /**
     * Editor visual de proyectos
     */
    public function editor() {
        $project_id = $_GET['id'] ?? null;
        
        if (!$project_id) {
            header('Location: /studio');
            exit;
        }
        
        // Cargar proyecto
        $project = $this->projectManager->getProject($project_id);
        
        if (!$project) {
            header('Location: /studio?error=project_not_found');
            exit;
        }
        
        // Verificar permisos
        if ($project['user_id'] != $this->user_id) {
            header('Location: /studio?error=access_denied');
            exit;
        }
        
        // Obtener biblioteca del usuario
        $library = $this->elementManager->getUserLibrary();
        
        $data = [
            'page_title' => 'Editor - ' . $project['title'],
            'page_description' => 'Editando proyecto: ' . $project['title'],
            'project' => $project,
            'user_library' => $library,
            'editor_config' => [
                'project_id' => $project_id,
                'user_id' => $this->user_id,
                'auto_save' => true,
                'max_elements' => 100
            ]
        ];
        
        return $this->render('studio/editor', $data);
    }
    
    /**
     * Visor público de proyectos
     */
    public function viewer() {
        $project_id = $_GET['id'] ?? null;
        
        if (!$project_id) {
            header('Location: /studio');
            exit;
        }
        
        // Cargar proyecto
        $project = $this->projectManager->getProject($project_id);
        
        if (!$project) {
            header('Location: /studio?error=project_not_found');
            exit;
        }
        
        // Verificar si es público o si es del usuario actual
        $user_id = $_SESSION['user_id'] ?? null;
        if (!$project['is_public'] && $project['user_id'] != $user_id) {
            header('Location: /acceso?redirect=' . urlencode('/studio/viewer?id=' . $project_id));
            exit;
        }
        
        $data = [
            'page_title' => $project['title'],
            'page_description' => $project['description'] ?? 'Proyecto creado en Obelis Studio',
            'project' => $project,
            'is_owner' => ($project['user_id'] == $user_id),
            'viewer_config' => [
                'project_id' => $project_id,
                'user_id' => $user_id,
                'is_public' => $project['is_public']
            ]
        ];
        
        return $this->render('studio/viewer', $data);
    }
    
    /**
     * Galería pública de proyectos
     */
    public function gallery() {
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $search = $_GET['search'] ?? '';
        $category = $_GET['category'] ?? '';
        
        // Obtener proyectos públicos
        $projects = $this->studio->getPublicProjects($page, 12, $search, $category);
        
        $data = [
            'page_title' => 'Galería de Proyectos',
            'page_description' => 'Explora proyectos creativos de la comunidad',
            'projects' => $projects['projects'],
            'total_pages' => $projects['total_pages'],
            'current_page' => $page,
            'search_query' => $search,
            'selected_category' => $category,
            'categories' => $this->getCategories()
        ];
        
        return $this->render('studio/gallery', $data);
    }
    
    /**
     * Renderiza una vista
     */
    private function render($view, $data = []) {
        // Extraer variables para la vista
        extract($data);
        
        // Incluir header
        include_once __DIR__ . '/../../src/Utils/header.php';
        
        // Incluir la vista
        $view_file = __DIR__ . '/../../pages/' . $view . '.php';
        if (file_exists($view_file)) {
            include_once $view_file;
        } else {
            // Vista no encontrada
            http_response_code(404);
            include_once __DIR__ . '/../../pages/error/404.php';
        }
        
        // Incluir footer
        include_once __DIR__ . '/../../src/Utils/footer.php';
    }
    
    /**
     * Obtiene las categorías disponibles
     */
    private function getCategories() {
        return [
            'personal' => 'Personal',
            'education' => 'Educación',
            'business' => 'Negocios',
            'creative' => 'Creativo',
            'other' => 'Otro'
        ];
    }
}
