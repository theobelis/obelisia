<?php
// src/Config/config.php - Versión sin namespace para mayor compatibilidad

// Configuración de Mercado Pago
define('MERCADOPAGO_ACCESS_TOKEN', 'APP_USR-TU_ACCESS_TOKEN_AQUI');

// Configuración de PayPal
define('PAYPAL_CLIENT_ID', 'BAA5mtlTaZrnAvuuWU1ejnjk0g_UV35hu9FRfnHFkeeZdW7dmr8B2bmTqRYZRbfWuV2tunQlz9aWfieafg');

// GEMINI_API_KEY para uso en PHP (InfinityFree o cualquier hosting PHP)
define('GEMINI_API_KEY', 'AIzaSyClM7w1vGjSFkBkVe5AHMFEeV8kJarjhk4');

// REPLICATE_API_TOKEN para uso en JavaScript
define('REPLICATE_API_TOKEN', 'r8_7Itrr1uqmmyF9mceJgIEr25MsnNlR9n0ltLPD');

// Configuración general del sitio
define('SITE_NAME', 'ObelisIA');
define('SITE_URL', 'obelis.online');
define('SITE_DESCRIPTION', 'Portafolio de Herramientas de Inteligencia Artificial');

// Configuración de seguridad
define('SESSION_LIFETIME', 3600); // 1 hora
define('PASSWORD_MIN_LENGTH', 6);

// Configuración de email
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'theobeliscorp@gmail.com');
define('SMTP_PASSWORD', 'dswp meoy bibi gbkc');
define('FROM_EMAIL', 'theobeliscorp@gmail.com');
define('FROM_NAME', 'ObelisIA System');

// Configuración de uploads
define('UPLOAD_PATH', 'uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx']);

// Timezone
date_default_timezone_set('America/Lima');

// Configuración de debug
define('DEBUG_MODE', true);

// Configuración de logs
define('LOG_ERRORS', true);
define('LOG_PATH', __DIR__ . '/../../logs/');

// Función para logging
function writeLog($message, $level = 'INFO') {
    if (LOG_ERRORS) {
        $timestamp = date('Y-m-d H:i:s');
        $log_message = "[$timestamp] [$level] $message" . PHP_EOL;
        $log_file = LOG_PATH . 'app_' . date('Y-m-d') . '.log';
        
        // Verificar si el directorio existe, si no, intentar crearlo
        if (!is_dir(LOG_PATH)) {
            if (!mkdir(LOG_PATH, 0755, true)) {
                error_log("No se pudo crear el directorio de logs: " . LOG_PATH);
                return false;
            }
        }
        
        // Verificar permisos de escritura
        if (!is_writable(LOG_PATH)) {
            error_log("No se puede escribir en el directorio de logs: " . LOG_PATH);
            return false;
        }
        
        // Intentar escribir el log
        if (file_put_contents($log_file, $log_message, FILE_APPEND | LOCK_EX) === false) {
            error_log("No se pudo escribir en el archivo de log: " . $log_file);
            return false;
        }
        
        return true;
    }
    return false;
}
?>
