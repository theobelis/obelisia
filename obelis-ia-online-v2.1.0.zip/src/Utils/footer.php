<!-- Scripts de Terceros (jQuery debe cargarse primero) -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- Scripts del Tema Principal (Material Dashboard) -->
    <script src="https://demos.creative-tim.com/material-dashboard/assets/js/core/popper.min.js"></script>
    <script src="https://demos.creative-tim.com/material-dashboard/assets/js/core/bootstrap.min.js"></script>
    <script src="https://demos.creative-tim.com/material-dashboard/assets/js/plugins/perfect-scrollbar.min.js"></script>
    <script src="https://demos.creative-tim.com/material-dashboard/assets/js/plugins/smooth-scrollbar.min.js"></script>

    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

    <!-- Scripts personalizados del sitio -->
    <script src="/assets/js/general/darkmode.js"></script>
    <script src="/assets/js/general/cookies-modal.js"></script>
    <script src="/assets/js/general/debug.js"></script>

    <script>
        // Inicializar el sidebar de Material Dashboard
        const sidebar = document.querySelector('.sidenav');
        if (sidebar) {
            const scrollbar = new PerfectScrollbar(sidebar, {
                wheelSpeed: 1,
                wheelPropagation: true,
                minScrollbarLength: 20,
                swipeEasing: true
            });
        }
    </script>

    <!-- NOTA: Se ha eliminado la carga de custom.js para evitar conflictos en el panel de administración. -->
    <!-- Inicialización de DataTables (movido aquí para mejor organización) -->
    <script>
        $(document).ready(function() {
            // Solo inicializar si la tabla existe en la página actual
            if ($('#toolsTable').length) {
                $('#toolsTable').DataTable({
                    "language": {
                        "url": "https://cdn.datatables.net/plug-ins/1.13.6/i18n/Spanish.json"
                    },
                    "order": [[ 0, "asc" ]] // Ordenar por la primera columna (nombre)
                });
            }
        });
    </script>

<!-- MODALES -->

        <!-- Modal de Suscripción -->
    <div class="modal fade" id="subscriptionModal" tabindex="-1" aria-labelledby="subscriptionModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark text-light">
          <div class="modal-header border-secondary">
            <h1 class="modal-title fs-4 text-info" id="subscriptionModalLabel">¡Únete a nuestra comunidad!</h1>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <p class="text-secondary">
              Suscríbete a nuestro boletín para recibir las últimas novedades y herramientas de IA.
            </p>
            <input type="email" id="emailInput" placeholder="Tu correo electrónico" class="form-control mt-3 bg-dark text-light border-secondary" />
          </div>
          <div class="modal-footer border-secondary">
            <button id="noThanksButton" type="button" class="btn btn-secondary" data-bs-dismiss="modal">No, gracias</button>
            <button id="subscribeButton" type="button" class="btn btn-info">Suscribirse</button>
          </div>
        </div>
      </div>
    </div>
    

      <!-- Modal de Anuncio -->
    <div class="modal fade" id="adModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="adModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark text-light">
          <div class="modal-header border-secondary">
            <h1 class="modal-title fs-4 text-info" id="adModalLabel">¡Reproduciendo Anuncio!</h1>
          </div>
          <div class="modal-body text-center">
            <p class="text-secondary">
              Esto es un anuncio simulado. Por favor, espera...
            </p>
            <div class="spinner-border text-info my-3" role="status" style="width: 3rem; height: 3rem;">
              <span class="visually-hidden">Cargando...</span>
            </div>
            <p id="adTimer" class="mt-2 text-secondary-emphasis">Tiempo restante: 5 segundos</p>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal de Cookies - Diseño Moderno -->
    <div class="modal fade" id="cookieConsentModal" tabindex="-1" aria-labelledby="cookieConsentLabel" aria-hidden="true" data-bs-backdrop="static">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content modern-cookie-modal">
          <div class="modal-shimmer"></div>
          <div class="modal-body">
            <div class="cookie-modal-header">
              <div class="cookie-icon">
                <i class="fas fa-shield-alt"></i>
              </div>
              <h5 class="cookie-title">Respetamos tu privacidad</h5>
            </div>
            
            <div class="cookie-modal-content">
              <p class="cookie-description">
                Utilizamos cookies esenciales y tecnologías similares para garantizar el funcionamiento óptimo de nuestra plataforma de IA y mejorar tu experiencia de usuario.
              </p>
              
              <div class="cookie-benefits">
                <div class="benefit-item">
                  <i class="fas fa-check"></i>
                  <span>Funcionalidad esencial</span>
                </div>
                <div class="benefit-item">
                  <i class="fas fa-check"></i>
                  <span>Experiencia personalizada</span>
                </div>
                <div class="benefit-item">
                  <i class="fas fa-check"></i>
                  <span>Análisis de rendimiento</span>
                </div>
              </div>
            </div>
            
            <div class="cookie-modal-actions">
              <button type="button" class="btn-cookie-settings" data-bs-toggle="tooltip" title="Configurar preferencias">
                <i class="fas fa-cog"></i>
                <span>Configurar</span>
              </button>
              <button id="acceptCookiesButton" type="button" class="btn-cookie-accept" data-bs-dismiss="modal">
                <i class="fas fa-check"></i>
                <span>Aceptar todo</span>
              </button>
            </div>
            
            <div class="cookie-legal-links">
              <a href="<?php echo \ObelisIA\Router\MainRouter::url('legal/cookies'); ?>" target="_blank">Política de Cookies</a>
              <span>•</span>
              <a href="<?php echo \ObelisIA\Router\MainRouter::url('legal/privacidad'); ?>" target="_blank">Privacidad</a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal de Cargando -->
    <div class="modal fade" id="loadingOverlayModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="loadingOverlayModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark text-light">
          <div class="modal-shimmer"></div>
          <div class="modal-body text-center py-4">
            <div class="loading-animation-wrapper">
              <img id="pocoyoGifModal" src="#" alt="Pocoyo bailando" class="img-fluid" style="max-height: 150px;" onerror="this.classList.add('d-none'); document.getElementById('loadingSpinnerModal').classList.remove('d-none');" />
              <div id="loadingSpinnerModal" class="spinner-border text-info my-3 d-none" role="status" style="width: 3rem; height: 3rem;">
                <span class="visually-hidden">Cargando...</span>
              </div>
            </div>
            <p id="loadingMessageTextModal" class="fs-5 mt-3">Por favor espera...</p>
            <p id="loadingErrorTextModal" class="text-danger fw-semibold mt-2 d-none"></p>
            <button id="loadingModalCloseButton" class="btn btn-secondary mt-4 d-none">
              Cerrar
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal de Mensajes -->
    <div class="modal fade" id="messageModal" tabindex="-1" aria-labelledby="messageModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark text-light">
          <div class="modal-header border-secondary">
            <h1 class="modal-title fs-5" id="messageModalLabel">Notificación</h1>
            <button id="messageModalCloseButton" type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body text-center">
            <div id="messageModalIcon" class="fs-1 mb-3"></div> <p id="messageModalText" class="fs-5 fw-bold"></p>
          </div>
        </div>
      </div>
    </div>

    <!-- FIN MODALES  -->

<button class="toggle-darkmode-btn toggle-darkmode-btn-rounded" type="button" aria-label="Alternar modo oscuro">
  <i class="material-icons darkmode-icon darkmode-icon-rounded">dark_mode</i>
  <span class="darkmode-text darkmode-text-rounded text-muted">Modo Oscuro</span>
</button>


<footer class="professional-footer">
    <div class="container">
        <!-- Main Footer Content -->
        <div class="row footer-main">
            <!-- Company Info -->
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="footer-brand">
                    <div class="brand-logo">
                        <i class="material-icons">auto_awesome</i>
                        <span class="brand-name">ObelisIA</span>
                    </div>
                    <p class="brand-description">
                        Suite completa de herramientas de IA para crear, editar y transformar contenido digital. 
                        Potencia tu creatividad con tecnología de vanguardia.
                    </p>
                    <!-- Social Media -->
                    <div class="social-links">
                        <a href="#" class="social-link" aria-label="Facebook">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="#" class="social-link" aria-label="Twitter">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="#" class="social-link" aria-label="LinkedIn">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                        <a href="#" class="social-link" aria-label="Instagram">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a href="#" class="social-link" aria-label="YouTube">
                            <i class="fab fa-youtube"></i>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Quick Links -->
            <div class="col-lg-2 col-md-6 mb-4">
                <div class="footer-section">
                    <h6 class="footer-title">Herramientas</h6>
                    <ul class="footer-links">
                        <li><a href="<?php echo \ObelisIA\Router\MainRouter::url('herramientas/ia-texto'); ?>">Generador de Texto</a></li>
                        <li><a href="<?php echo \ObelisIA\Router\MainRouter::url('herramientas/ia-imagen'); ?>">Generador de Imágenes</a></li>
                        <li><a href="<?php echo \ObelisIA\Router\MainRouter::url('herramientas/ia-video'); ?>">Generador de Video</a></li>
                        <li><a href="<?php echo \ObelisIA\Router\MainRouter::url('herramientas/editor-unificado'); ?>">Editor Unificado</a></li>
                        <li><a href="<?php echo \ObelisIA\Router\MainRouter::url('herramientas'); ?>">Ver todas</a></li>
                    </ul>
                </div>
            </div>

            <!-- Support -->
            <div class="col-lg-2 col-md-6 mb-4">
                <div class="footer-section">
                    <h6 class="footer-title">Soporte</h6>
                    <ul class="footer-links">
                        <li><a href="<?php echo \ObelisIA\Router\MainRouter::url('soporte/faq'); ?>">FAQ</a></li>
                        <li><a href="<?php echo \ObelisIA\Router\MainRouter::url('soporte/contacto'); ?>">Contacto</a></li>
                        <li><a href="<?php echo \ObelisIA\Router\MainRouter::url('soporte/tutoriales'); ?>">Tutoriales</a></li>
                        <li><a href="<?php echo \ObelisIA\Router\MainRouter::url('soporte/documentacion'); ?>">Documentación</a></li>
                        <li><a href="<?php echo \ObelisIA\Router\MainRouter::url('soporte/estado'); ?>">Estado del Sistema</a></li>
                    </ul>
                </div>
            </div>

            <!-- Legal -->
            <div class="col-lg-2 col-md-6 mb-4">
                <div class="footer-section">
                    <h6 class="footer-title">Legal</h6>
                    <ul class="footer-links">
                        <li><a href="<?php echo \ObelisIA\Router\MainRouter::url('legal/privacidad'); ?>">Política de Privacidad</a></li>
                        <li><a href="<?php echo \ObelisIA\Router\MainRouter::url('legal/terminos'); ?>">Términos de Servicio</a></li>
                        <li><a href="<?php echo \ObelisIA\Router\MainRouter::url('legal/cookies'); ?>">Política de Cookies</a></li>
                        <li><a href="<?php echo \ObelisIA\Router\MainRouter::url('legal/ia'); ?>">Política de IA</a></li>
                        <li><a href="<?php echo \ObelisIA\Router\MainRouter::url('legal/gdpr'); ?>">GDPR</a></li>
                    </ul>
                </div>
            </div>

            <!-- Contact Info -->
            <div class="col-lg-2 col-md-6 mb-4">
                <div class="footer-section">
                    <h6 class="footer-title">Contacto</h6>
                    <div class="contact-info">
                        <div class="contact-item">
                            <i class="material-icons">email</i>
                            <span>info@obelis.online</span>
                        </div>
                        <div class="contact-item">
                            <i class="material-icons">location_on</i>
                            <span>España, Unión Europea</span>
                        </div>
                        <div class="contact-item">
                            <i class="material-icons">schedule</i>
                            <span>24/7 Soporte Online</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Security & Certifications -->
        <div class="footer-certifications">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="security-badges">
                        <!-- SSL Certificate -->
                        <div class="cert-badge">
                            <i class="fas fa-shield-alt cert-icon"></i>
                            <div class="cert-info">
                                <strong>SSL Seguro</strong>
                                <small>Conexión Cifrada</small>
                            </div>
                        </div>

                        <!-- GDPR Compliance -->
                        <div class="cert-badge">
                            <i class="fas fa-user-shield cert-icon"></i>
                            <div class="cert-info">
                                <strong>GDPR</strong>
                                <small>Cumplimiento UE</small>
                            </div>
                        </div>

                        <!-- ISO Certification -->
                        <div class="cert-badge">
                            <i class="fas fa-certificate cert-icon"></i>
                            <div class="cert-info">
                                <strong>ISO 27001</strong>
                                <small>Seguridad Certificada</small>
                            </div>
                        </div>

                        <!-- AI Ethics -->
                        <div class="cert-badge">
                            <i class="fas fa-brain cert-icon"></i>
                            <div class="cert-info">
                                <strong>IA Ética</strong>
                                <small>Uso Responsable</small>
                            </div>
                        </div>

                        <!-- Data Protection -->
                        <div class="cert-badge">
                            <i class="fas fa-lock cert-icon"></i>
                            <div class="cert-info">
                                <strong>Datos Protegidos</strong>
                                <small>Cifrado AES-256</small>
                            </div>
                        </div>

                        <!-- Uptime Guarantee -->
                        <div class="cert-badge">
                            <i class="fas fa-server cert-icon"></i>
                            <div class="cert-info">
                                <strong>99.9% Uptime</strong>
                                <small>Disponibilidad Garantizada</small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 text-end">
                    <div class="trust-seals">
                        <div class="trust-seal">
                            <i class="fas fa-check-circle"></i>
                            <span>Verificado y Seguro</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer Bottom -->
        <div class="footer-bottom">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <p class="copyright">
                        &copy; <?php echo date('Y'); ?> ObelisIA. Todos los derechos reservados.
                        <span class="version">v2.1.0</span>
                    </p>
                </div>
                <div class="col-md-6 text-end">
                    <div class="footer-meta">
                        <span class="made-with">
                            Hecho con <i class="fas fa-heart text-danger"></i> usando IA responsable
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

</body>
</html>