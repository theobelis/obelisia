<?php
// src/Utils/Premium.php
// Lógica global reutilizable para verificar y aplicar beneficios premium

namespace ObelisIA\Utils;

class Premium {
    /**
     * Verifica si el usuario actual es premium
     * @return bool
     */
    public static function isPremium() {
        return isset($_SESSION['membership_type']) && $_SESSION['membership_type'] === 'premium';
    }

    /**
     * Devuelve el tipo de membresía del usuario actual
     * @return string 'premium' o 'free'
     */
    public static function getMembershipType() {
        return $_SESSION['membership_type'] ?? 'free';
    }

    /**
     * Devuelve los beneficios premium globales
     * @return array
     */
    public static function getPremiumBenefits() {
        return [
            'generaciones_ilimitadas' => true,
            'sin_marca_agua' => true,
            'maxima_resolucion' => true,
            'soporte_prioritario' => true,
            'acceso_api' => true,
            // Agrega más beneficios globales aquí
        ];
    }

    /**
     * Devuelve true si el usuario puede usar una herramienta premium
     * @param bool $toolIsPremium
     * @return bool
     */
    public static function canUseTool($toolIsPremium) {
        if (!$toolIsPremium) return true;
        return self::isPremium();
    }
}
