<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">

    <!-- Meta vi    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://demos.creative-tim.com/material-dashboard/assets/css/material-dashboard.css?v=3.0.0" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo \ObelisIA\Router\MainRouter::url('assets/css/general/main.css'); ?>">
    
    <?php
    // Agregar CSS específico para páginas de autenticación
    $currentRoute = $_SERVER['REQUEST_URI'] ?? '';
    if (strpos($currentRoute, '/login') !== false || 
        strpos($currentRoute, '/acceso') !== false || 
        strpos($currentRoute, '/registro') !== false || 
        strpos($currentRoute, '/recuperar') !== false) {
        echo '<link rel="stylesheet" href="' . \ObelisIA\Router\MainRouter::url('assets/css/auth-modern.css') . '">';
    }
    ?> para dispositivos móviles -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes">

<?php if (isset($blog_headline)): ?>
<!-- Datos estructurados BlogPosting para SEO (dinámico) -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BlogPosting",
  "headline": "<?php echo addslashes($blog_headline); ?>",
  "alternativeHeadline": "<?php echo addslashes($blog_alt_headline ?? $blog_headline); ?>",
  "image": [
    "<?php echo addslashes($blog_image ?? 'https://obelis.online/assets/img/social-share-default.jpg'); ?>"
  ],
  "editor": "<?php echo addslashes($blog_editor ?? 'ObelisIA Team'); ?>",
  "genre": "<?php echo addslashes($blog_genre ?? 'Tecnología, IA, Creatividad'); ?>",
  "keywords": "<?php echo addslashes($blog_keywords ?? 'IA, inteligencia artificial, herramientas, creatividad, blog'); ?>",
  "wordcount": "<?php echo addslashes($blog_wordcount ?? '800'); ?>",
  "url": "<?php echo addslashes($blog_url ?? 'https://obelis.online/blog'); ?>",
  "datePublished": "<?php echo addslashes($blog_date_published ?? date('Y-m-d')); ?>",
  "dateCreated": "<?php echo addslashes($blog_date_created ?? date('Y-m-d')); ?>",
  "dateModified": "<?php echo addslashes($blog_date_modified ?? date('Y-m-d')); ?>",
  "description": "<?php echo addslashes($blog_description ?? 'Descubre las nuevas herramientas de inteligencia artificial que ObelisIA pone a disposición de creadores y empresas para potenciar su creatividad.'); ?>",
  "author": {
    "@type": "Person",
    "name": "<?php echo addslashes($blog_author ?? 'Equipo ObelisIA'); ?>"
  },
  "publisher": {
    "@type": "Organization",
    "name": "ObelisIA",
    "logo": {
      "@type": "ImageObject",
      "url": "https://obelis.online/assets/img/logo.webp"
    }
  },
  "mainEntityOfPage": "<?php echo addslashes($blog_url ?? 'https://obelis.online/blog'); ?>"
}
</script>
<?php endif; ?>

    <title><?php echo isset($page_title) ? htmlspecialchars($page_title) : 'ObelisIA - Tu AI para la Creatividad'; ?></title>
    
    <meta name="description" content="<?php echo isset($page_description) ? htmlspecialchars($page_description) : 'Plataforma líder en herramientas de inteligencia artificial para diseño, texto y música. Impulsa tu creatividad con nuestras soluciones.'; ?>">
    
    <meta name="keywords" content="<?php echo isset($page_keywords) ? htmlspecialchars($page_keywords) : 'IA, inteligencia artificial, herramientas, creatividad, texto, imagen, música, ObelisIA'; ?>">
    
    <meta name="robots" content="<?php echo isset($meta_robots) ? htmlspecialchars($meta_robots) : 'index, follow'; ?>">
    
    <link rel="canonical" href="<?php echo \ObelisIA\Router\MainRouter::url($og_url_route ?? ''); ?>">

    <meta property="og:title" content="<?php echo isset($page_title) ? htmlspecialchars($page_title) : 'ObelisIA - Tu AI para la Creatividad'; ?>">
    <meta property="og:description" content="<?php echo isset($page_description) ? htmlspecialchars($page_description) : 'Plataforma líder en herramientas de inteligencia artificial para diseño, texto y música. Impulsa tu creatividad con nuestras soluciones.'; ?>">
    <meta property="og:url" content="<?php echo \ObelisIA\Router\MainRouter::url($og_url_route ?? ''); ?>">
    <meta property="og:type" content="website">
    <meta property="og:image" content="<?php echo \ObelisIA\Router\MainRouter::url($og_image ?? 'assets/img/social-share-default.jpg'); ?>">
    <meta property="og:image:alt" content="<?php echo isset($og_image_alt) ? htmlspecialchars($og_image_alt) : 'Logo de ObelisIA o imagen representativa'; ?>">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo isset($page_title) ? htmlspecialchars($page_title) : 'ObelisIA - Tu AI para la Creatividad'; ?>">
    <meta name="twitter:description" content="<?php echo isset($page_description) ? htmlspecialchars($page_description) : 'Plataforma líder en herramientas de inteligencia artificial para diseño, texto y música. Impulsa tu creatividad con nuestras soluciones.'; ?>">
    <meta name="twitter:image" content="<?php echo \ObelisIA\Router\MainRouter::url($og_image ?? 'assets/img/social-share-default.jpg'); ?>">


    <meta name="author" content="ObelisAI" />
    
    
    
    <link rel="shortcut icon" href="<?php echo \ObelisIA\Router\MainRouter::url('assets/img/favicon.ico'); ?>" type="image/x-icon">

<!-- Datos estructurados Organization para SEO -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "ObelisIA",
  "url": "https://obelis.online",
  "logo": "https://obelis.online/assets/img/logo.webp"
}
</script>

    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://demos.creative-tim.com/material-dashboard/assets/css/material-dashboard.css?v=3.0.0" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo \ObelisIA\Router\MainRouter::url('assets/css/general/main.css'); ?>">


    <script type="application/ld+json">
      {
        "@context": "https://schema.org",
        "@type": "SoftwareApplication",
        "name": "ObelisIA Tools AI",
        "applicationCategory": "Multimedia",
        "operatingSystem": "Web",
        "offers": {
          "@type": "Offer",
          "price": "10.00",
          "priceCurrency": "USD"
        },
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": "4.8",
          "ratingCount": "150"
        },
        "description": "ObelisIA es un Portafolio de Herramientas de IA.",
        "softwareHelp": {
          "@type": "CreativeWork",
          "url": "https://obelis.online"
        },
        "url": "https://obelis.online",
        "featureList": [
          "Generación de imágenes por IA",
          "Edición básica de imágenes",
          "Galería de imágenes guardadas",
          "Descarga de imágenes",
          "Sugerencias de prompts por IA",
          "Límite de generaciones con anuncios"
        ],
        "installUrl": "https://obelis.online",
        "screenshot": "https://placehold.co/800x600/2d3748/06b6d4?text=ObelisIA+Screenshot"
      }
    </script>

<!-- Datos estructurados FAQ para SEO -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "¿Qué es ObelisIA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "ObelisIA es una plataforma web que ofrece herramientas de inteligencia artificial para creadores, empresas y usuarios que buscan potenciar su creatividad en imagen, texto y música."
      }
    },
    {
      "@type": "Question",
      "name": "¿Qué tipo de herramientas incluye?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Incluye generadores de imágenes, editores de imagen, asistentes de texto, composición musical por IA y más."
      }
    },
    {
      "@type": "Question",
      "name": "¿ObelisIA es gratis?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "ObelisIA ofrece un plan gratuito con funciones limitadas y un plan premium con acceso completo a todas las herramientas."
      }
    },
    {
      "@type": "Question",
      "name": "¿Necesito instalar algo?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "No, todas las herramientas funcionan directamente desde el navegador web."
      }
    }
  ]
}
</script>

    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-9956937945939380"
     crossorigin="anonymous"></script>
     
    
</head>
<?php
$darkModeActive = false;
if (isset($_COOKIE['darkMode']) && $_COOKIE['darkMode'] === 'true') {
    $darkModeActive = true;
}
?>
<body class="<?php echo ($darkModeActive ? 'dark-mode' : ''); ?><?php echo isset($body_class) ? ' ' . $body_class : ''; ?>">

<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <!-- Logo mejorado -->
        <a class="navbar-brand d-flex align-items-center fw-bold" href="<?php echo \ObelisIA\Router\MainRouter::url('inicio'); ?>">
            <i class="material-icons me-2 text-primary" style="font-size: 2rem;">psychology</i>
            <span class="text-dark">Obelis</span><span class="text-primary">IA</span>
        </a>
        
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarNav">
            <!-- Menú principal -->
            <ul class="navbar-nav me-auto">
                <?php if ($auth->isLoggedIn()): ?>
                <!-- Para usuarios logueados -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle fw-semibold text-dark" href="#" id="toolsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="material-icons align-middle me-1">build</i>Herramientas IA
                    </a>
                    <ul class="dropdown-menu shadow border-0">
                        <li><h6 class="dropdown-header text-primary">Crear Contenido</h6></li>
                        <li><a class="dropdown-item" href="<?php echo \ObelisIA\Router\MainRouter::url('herramientas'); ?>">
                            <i class="material-icons me-2 text-info">palette</i>Generador de Imágenes
                        </a></li>
                        <li><a class="dropdown-item" href="<?php echo \ObelisIA\Router\MainRouter::url('herramientas'); ?>">
                            <i class="material-icons me-2 text-success">text_fields</i>Generador de Texto
                        </a></li>
                        <li><a class="dropdown-item" href="<?php echo \ObelisIA\Router\MainRouter::url('herramientas'); ?>">
                            <i class="material-icons me-2 text-warning">music_note</i>Generador de Audio
                        </a></li>
                        <li><a class="dropdown-item" href="<?php echo \ObelisIA\Router\MainRouter::url('herramientas'); ?>">
                            <i class="material-icons me-2 text-danger">videocam</i>Generador de Video
                        </a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item fw-semibold" href="<?php echo \ObelisIA\Router\MainRouter::url('herramientas'); ?>">
                            <i class="material-icons me-2 text-primary">explore</i>Ver Todas las Herramientas
                        </a></li>
                    </ul>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link fw-semibold text-dark" href="/studio/">
                        <i class="material-icons align-middle me-1 text-purple">auto_fix_high</i>Studio
                    </a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link fw-semibold text-dark" href="<?php echo \ObelisIA\Router\MainRouter::url('mis-creaciones'); ?>">
                        <i class="material-icons align-middle me-1 text-info">collections</i>Mis Creaciones
                    </a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link fw-semibold text-dark" href="<?php echo \ObelisIA\Router\MainRouter::url('comunidad'); ?>">
                        <i class="material-icons align-middle me-1 text-success">group</i>Comunidad
                    </a>
                </li>
                
                <?php else: ?>
                <!-- Para usuarios no logueados -->
                <li class="nav-item">
                    <a class="nav-link fw-semibold text-dark" href="<?php echo \ObelisIA\Router\MainRouter::url('herramientas'); ?>">
                        <i class="material-icons align-middle me-1">build</i>Herramientas IA
                    </a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link fw-semibold text-dark" href="<?php echo \ObelisIA\Router\MainRouter::url('caracteristicas'); ?>">
                        <i class="material-icons align-middle me-1">featured_play_list</i>Características
                    </a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link fw-semibold text-dark" href="<?php echo \ObelisIA\Router\MainRouter::url('precios'); ?>">
                        <i class="material-icons align-middle me-1">payments</i>Precios
                    </a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link fw-semibold text-dark" href="<?php echo \ObelisIA\Router\MainRouter::url('comunidad'); ?>">
                        <i class="material-icons align-middle me-1">group</i>Comunidad
                    </a>
                </li>
                <?php endif; ?>
            </ul>
            
            <!-- Menú de usuario/acciones -->
            <ul class="navbar-nav align-items-center">
                <?php if ($auth->isLoggedIn()): ?>
                    <!-- Indicador de créditos mejorado -->
                    <li class="nav-item me-3">
                        <a class="nav-link bg-light rounded-pill px-3 py-2 d-flex align-items-center text-decoration-none" 
                           href="<?php echo \ObelisIA\Router\MainRouter::url('creditos'); ?>" 
                           title="Mis créditos">
                            <i class="material-icons me-2 text-warning" style="font-size: 20px;">account_balance_wallet</i>
                            <span class="fw-bold text-dark">
                                <?php 
                                if (isset($_SESSION['user_id'])) {
                                    try {
                                        $stmt = $db->prepare("SELECT credits FROM users WHERE id = ?");
                                        $stmt->execute([$_SESSION['user_id']]);
                                        echo number_format($stmt->fetchColumn() ?: 0);
                                    } catch (Exception $e) {
                                        echo '0';
                                    }
                                } else {
                                    echo '0';
                                }
                                ?> créditos
                            </span>
                        </a>
                    </li>
                    
                    <!-- Menú de usuario mejorado -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center text-dark fw-semibold" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <div class="avatar me-2">
                                <?php
                                // Obtener imagen de perfil o generar placeholder
                                $user_data = $auth->getCurrentUser();
                                if (!empty($user_data['profile_image'])) {
                                    echo '<img src="' . htmlspecialchars($user_data['profile_image']) . '" alt="Avatar" class="rounded-circle" style="width: 32px; height: 32px; object-fit: cover;">';
                                } else {
                                    $initial = strtoupper(substr($user_data['full_name'], 0, 1));
                                    echo '<div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width: 32px; height: 32px; font-size: 14px;">' . $initial . '</div>';
                                }
                                ?>
                            </div>
                            <span class="d-none d-md-inline"><?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow border-0" style="min-width: 250px;">
                            <li class="dropdown-header py-3">
                                <div class="d-flex align-items-center">
                                    <div class="me-3">
                                        <?php
                                        if (!empty($user_data['profile_image'])) {
                                            echo '<img src="' . htmlspecialchars($user_data['profile_image']) . '" alt="Avatar" class="rounded-circle" style="width: 48px; height: 48px; object-fit: cover;">';
                                        } else {
                                            $initial = strtoupper(substr($user_data['full_name'], 0, 1));
                                            echo '<div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width: 48px; height: 48px; font-size: 20px;">' . $initial . '</div>';
                                        }
                                        ?>
                                    </div>
                                    <div>
                                        <div class="fw-bold"><?php echo htmlspecialchars($_SESSION['full_name']); ?></div>
                                        <small class="text-muted"><?php echo htmlspecialchars($_SESSION['email']); ?></small>
                                    </div>
                                </div>
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            
                            <li><h6 class="dropdown-header text-primary">Mi Cuenta</h6></li>
                            <li><a class="dropdown-item py-2" href="<?php echo \ObelisIA\Router\MainRouter::url('panel'); ?>">
                                <i class="material-icons me-3 text-primary">dashboard</i>Panel de Control
                            </a></li>
                            <li><a class="dropdown-item py-2" href="<?php echo \ObelisIA\Router\MainRouter::url('perfil'); ?>">
                                <i class="material-icons me-3 text-info">person</i>Mi Perfil
                            </a></li>
                            <li><a class="dropdown-item py-2" href="<?php echo \ObelisIA\Router\MainRouter::url('creditos'); ?>">
                                <i class="material-icons me-3 text-warning">monetization_on</i>Mis Créditos
                            </a></li>
                            
                            <li><hr class="dropdown-divider"></li>
                            <li><h6 class="dropdown-header text-primary">Contenido</h6></li>
                            <li><a class="dropdown-item py-2" href="<?php echo \ObelisIA\Router\MainRouter::url('mis-creaciones'); ?>">
                                <i class="material-icons me-3 text-info">collections</i>Mis Creaciones
                            </a></li>
                            <li><a class="dropdown-item py-2" href="/studio/">
                                <i class="material-icons me-3 text-purple">auto_fix_high</i>Obelis Studio
                            </a></li>
                            <li><a class="dropdown-item py-2" href="<?php echo \ObelisIA\Router\MainRouter::url('usuario'); ?>?id=<?php echo $_SESSION['user_id']; ?>">
                                <i class="material-icons me-3 text-success">public</i>Mi Perfil Público
                            </a></li>
                            
                            <?php if (($_SESSION['role'] ?? 'user') === 'admin'): ?>
                            <li><hr class="dropdown-divider"></li>
                            <li><h6 class="dropdown-header text-danger">Administración</h6></li>
                            <li><a class="dropdown-item py-2" href="<?php echo \ObelisIA\Router\MainRouter::url('admin'); ?>">
                                <i class="material-icons me-3 text-danger">admin_panel_settings</i>Panel de Admin
                            </a></li>
                            <?php endif; ?>
                            
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <button class="dropdown-item py-2 d-flex align-items-center toggle-darkmode-btn" type="button">
                                    <i class="material-icons me-3 darkmode-icon text-secondary">dark_mode</i>
                                    <span class="darkmode-text">Modo Oscuro</span>
                                </button>
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item py-2 text-danger" href="?logout=1">
                                <i class="material-icons me-3">logout</i>Cerrar Sesión
                            </a></li>
                        </ul>
                    </li>
                    
                <?php else: ?>
                    <!-- Botones para usuarios no logueados -->
                    <li class="nav-item me-2">
                        <a class="nav-link fw-semibold text-primary" href="<?php echo \ObelisIA\Router\MainRouter::url('acceso'); ?>">
                            <i class="material-icons align-middle me-1">login</i>Iniciar Sesión
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="btn btn-primary rounded-pill px-4" href="<?php echo \ObelisIA\Router\MainRouter::url('registro'); ?>">
                            <i class="material-icons align-middle me-1" style="font-size: 18px;">person_add</i>Comenzar Gratis
                        </a>
                    </li>
                <?php endif; ?>
                <!-- Notificaciones mejoradas -->
                    <li class="nav-item dropdown me-3">
                        <a class="nav-link position-relative p-2" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="material-icons text-muted">notifications</i>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" id="notificationBadge" style="display: none; font-size: 0.7rem;">
                                0
                            </span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end p-0 shadow border-0" aria-labelledby="notificationsDropdown" style="width: 350px; max-height: 400px; overflow-y: auto;">
                            <div class="dropdown-header bg-light d-flex justify-content-between align-items-center py-3">
                                <h6 class="mb-0 fw-bold">Notificaciones</h6>
                                <button class="btn btn-sm btn-outline-primary" id="markAllReadBtn" style="font-size: 0.75rem;">
                                    Marcar todas como leídas
                                </button>
                            </div>
                            <div id="notificationsList">
                                <div class="text-center py-4">
                                    <div class="spinner-border spinner-border-sm text-primary" role="status">
                                        <span class="visually-hidden">Cargando...</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
            </ul>
        </div>
    </div>
</nav>

<?php if ($auth->isLoggedIn()): ?>
<script>
// Sistema de notificaciones sociales
document.addEventListener('DOMContentLoaded', function() {
    let notificationsCache = [];
    let lastUpdateTime = 0;
    
    // Cargar notificaciones iniciales
    loadNotifications();
    
    // Actualizar notificaciones cada 30 segundos
    setInterval(loadNotifications, 30000);
    
    // Event listener para el dropdown de notificaciones
    const notificationsDropdown = document.getElementById('notificationsDropdown');
    if (notificationsDropdown) {
        notificationsDropdown.addEventListener('shown.bs.dropdown', function() {
            loadNotifications();
        });
    }

    async function loadNotifications() {
        try {
            const response = await fetch('/api/social/get_notifications.php');
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const data = await response.json();
            
            if (data.success) {
                notificationsCache = data.notifications;
                updateNotificationUI(data.notifications);
            } else {
                console.warn('API de notificaciones devolvió error:', data.message);
                // Mostrar UI vacía en caso de error
                updateNotificationUI([]);
            }
        } catch (error) {
            console.error('Error al cargar notificaciones:', error);
            // En caso de error, ocultar badge y mostrar mensaje de error en dropdown
            const badge = document.getElementById('notificationBadge');
            const list = document.getElementById('notificationsList');
            
            if (badge) badge.style.display = 'none';
            if (list) {
                list.innerHTML = `
                    <div class="text-center py-4 text-muted">
                        <i class="material-icons mb-2" style="font-size: 2rem;">error_outline</i>
                        <p class="mb-0">Error al cargar notificaciones</p>
                        <small>Intenta recargar la página</small>
                    </div>
                `;
            }
        }
    }

    function updateNotificationUI(allNotifications) {
        const badge = document.getElementById('notificationBadge');
        const list = document.getElementById('notificationsList');
        
        if (!badge || !list) return;
        
        // Separar notificaciones no leídas
        const unreadNotifications = allNotifications.filter(n => !n.is_read);
        const unreadCount = unreadNotifications.length;
        
        // Actualizar badge
        if (unreadCount > 0) {
            badge.style.display = 'block';
            badge.textContent = unreadCount > 99 ? '99+' : unreadCount;
        } else {
            badge.style.display = 'none';
        }
        
        // Actualizar lista - mostrar primero las no leídas, luego las leídas (máximo 10 total)
        const notificationsToShow = [
            ...unreadNotifications,
            ...allNotifications.filter(n => n.is_read)
        ].slice(0, 10);
        
        if (notificationsToShow.length === 0) {
            list.innerHTML = `
                <div class="text-center py-4 text-muted">
                    <i class="material-icons mb-2" style="font-size: 2rem;">notifications_none</i>
                    <p class="mb-0">No tienes notificaciones</p>
                </div>
            `;
            return;
        }
        
        list.innerHTML = notificationsToShow.map(notification => {
            const avatarHtml = notification.profile_image 
                ? `<img src="${notification.profile_image}" class="rounded-circle" width="40" height="40">`
                : `<div class="bg-primary rounded-circle d-flex align-items-center justify-content-center text-white" style="width: 40px; height: 40px; font-size: 1rem;">
                    ${notification.username ? notification.username.charAt(0).toUpperCase() : 'U'}
                </div>`;
            
            const iconType = {
                'like': 'favorite',
                'comment': 'chat_bubble',
                'follow': 'person_add'
            }[notification.type] || 'notifications';
            
            const iconColor = {
                'like': 'text-danger',
                'comment': 'text-info', 
                'follow': 'text-success'
            }[notification.type] || 'text-primary';
            
            const linkUrl = notification.creation_id 
                ? `/comunidad#creation-${notification.creation_id}`
                : `/usuario?id=${notification.username}`;
            
            const readClass = notification.is_read ? 'opacity-75' : '';
            const readIndicator = notification.is_read ? '' : '<div class="bg-primary rounded-circle" style="width: 8px; height: 8px; position: absolute; top: 8px; right: 8px;"></div>';
            
            return `
                <a href="${linkUrl}" class="dropdown-item notification-item p-3 border-bottom position-relative ${readClass}" data-notification-id="${notification.id}">
                    ${readIndicator}
                    <div class="d-flex align-items-start">
                        <div class="me-3 position-relative">
                            ${avatarHtml}
                            <div class="position-absolute bottom-0 end-0 bg-white rounded-circle p-1" style="transform: translate(25%, 25%);">
                                <i class="material-icons ${iconColor}" style="font-size: 1rem;">${iconType}</i>
                            </div>
                        </div>
                        <div class="flex-grow-1">
                            <p class="mb-1 small">
                                <strong>${notification.full_name || notification.username}</strong> ${notification.message}
                            </p>
                            <small class="text-muted">${notification.created_at_formatted}</small>
                        </div>
                    </div>
                </a>
            `;
        }).join('');
    }

    // Marcar notificación como leída al hacer clic
    document.addEventListener('click', function(e) {
        if (e.target.closest('.notification-item')) {
            const notificationId = e.target.closest('.notification-item').getAttribute('data-notification-id');
            if (notificationId) {
                markNotificationAsRead(notificationId);
            }
        }
    });

    async function markNotificationAsRead(notificationId) {
        try {
            await fetch('/api/social/mark_notification_read.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ notification_id: notificationId })
            });
        } catch (error) {
            console.error('Error al marcar notificación como leída:', error);
        }
    }
});
</script>
<?php endif; ?>
