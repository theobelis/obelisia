<?php
// src/Utils/Uploader.php

namespace ObelisIA\Utils;

/**
 * Clase Uploader para manejar la subida de archivos de forma centralizada.
 * Valida, genera un nombre único y mueve el archivo a la carpeta de uploads.
 */
class Uploader
{
    private $uploadPath;
    private $allowedExtensions;
    private $maxFileSize;

    /**
     * El constructor inicializa la configuración para la subida.
     * Utiliza las constantes definidas en src/Config/config.php como valores por defecto.
     */
    public function __construct()
    {
        // Definimos la ruta de subida basándonos en la ubicación de este archivo.
        $this->uploadPath = realpath(__DIR__ . '/../../') . '/' . UPLOAD_PATH;
        $this->allowedExtensions = ALLOWED_EXTENSIONS;
        $this->maxFileSize = MAX_FILE_SIZE;

        // Nos aseguramos de que el directorio de subida exista.
        if (!is_dir($this->uploadPath)) {
            mkdir($this->uploadPath, 0755, true);
        }
    }

    /**
     * Maneja la subida de un archivo del array $_FILES.
     *
     * @param string $fileInputName El nombre del campo input (ej. 'inputFile').
     * @param string $prefix Prefijo para el nuevo nombre de archivo (ej. 'edited').
     * @return array Un array con el resultado: ['success' => bool, 'data' => array|string].
     */
    public function handleUpload(string $fileInputName, string $prefix = 'file'): array
    {
        // 1. Verificar si el archivo existe y se subió sin errores.
        if (!isset($_FILES[$fileInputName]) || $_FILES[$fileInputName]['error'] !== UPLOAD_ERR_OK) {
            $errorMessage = $this->getUploadErrorMessage($_FILES[$fileInputName]['error'] ?? UPLOAD_ERR_NO_FILE);
            return ['success' => false, 'error' => $errorMessage];
        }

        $file = $_FILES[$fileInputName];

        // 2. Validar el tamaño del archivo.
        if ($file['size'] > $this->maxFileSize) {
            return ['success' => false, 'error' => 'El archivo excede el tamaño máximo permitido de ' . ($this->maxFileSize / 1024 / 1024) . 'MB.'];
        }

        // 3. Validar la extensión del archivo.
        $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($fileExtension, $this->allowedExtensions)) {
            return ['success' => false, 'error' => 'Tipo de archivo no permitido. Extensiones válidas: ' . implode(', ', $this->allowedExtensions)];
        }

        // 4. Generar un nombre de archivo único y seguro.
        $safeOriginalName = preg_replace("/[^a-zA-Z0-9\._-]/", '', basename($file['name']));
        $newFileName = $prefix . '-' . uniqid('', true) . '-' . $safeOriginalName;
        $destinationPath = $this->uploadPath . $newFileName;

        // 5. Mover el archivo a su destino final.
        if (move_uploaded_file($file['tmp_name'], $destinationPath)) {
            // Éxito: Devolvemos la información útil.
            return [
                'success' => true,
                'filePath' => UPLOAD_PATH . $newFileName, // Ruta relativa para usar en HTML/URL
                'fileName' => $newFileName,
                'originalName' => $file['name']
            ];
        } else {
            // Falla al mover el archivo.
            return ['success' => false, 'error' => 'Hubo un error interno al guardar el archivo.'];
        }
    }

    /**
     * Convierte los códigos de error de subida de PHP a mensajes legibles.
     */
    private function getUploadErrorMessage(int $errorCode): string
    {
        switch ($errorCode) {
            case UPLOAD_ERR_INI_SIZE:
                return 'El archivo excede el tamaño máximo definido en el servidor.';
            case UPLOAD_ERR_FORM_SIZE:
                return 'El archivo excede el tamaño máximo permitido en el formulario.';
            case UPLOAD_ERR_PARTIAL:
                return 'El archivo fue solo parcialmente subido.';
            case UPLOAD_ERR_NO_FILE:
                return 'No se seleccionó ningún archivo para subir.';
            case UPLOAD_ERR_NO_TMP_DIR:
                return 'Falta la carpeta temporal del servidor.';
            case UPLOAD_ERR_CANT_WRITE:
                return 'Error al escribir el archivo en el disco.';
            case UPLOAD_ERR_EXTENSION:
                return 'Una extensión de PHP detuvo la subida del archivo.';
            default:
                return 'Hubo un error desconocido al subir el archivo.';
        }
    }
}