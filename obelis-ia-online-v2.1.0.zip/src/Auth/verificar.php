<?php
// Handler global de errores y excepciones para mostrar página 500 personalizada
set_exception_handler(function($e) {
    http_response_code(500);
    include __DIR__ . '/../../pages/error/500.php';
    exit;
});
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    http_response_code(500);
    include __DIR__ . '/../../pages/error/500.php';
    exit;
});

require_once __DIR__ . '/../Config/config.php';
require_once __DIR__ . '/../Database/Database.php';
require_once __DIR__ . '/../Auth/Verify.php';

$token = $_GET['token'] ?? '';
$result = \ObelisIA\Auth\Verify::verifyToken($token);
$mensaje = $result['mensaje'];
$icono = $result['icono'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Verificación de cuenta - ObelisIA</title>
    <link rel="stylesheet" href="/assets/css/general/_variables.css">
    <link rel="stylesheet" href="/assets/css/general/main.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        body { background: #f7fafc; font-family: 'Segoe UI', Arial, sans-serif; }
        .container { max-width: 420px; margin: 60px auto; background: #fff; border-radius: 20px; box-shadow: 0 10px 15px -3px rgba(102,126,234,0.10), 0 4px 6px -2px rgba(118,75,162,0.08); padding: 36px 28px 28px 28px; border: 2px solid #e2e8f0; text-align: center; }
        .icon { font-size: 3rem; margin-bottom: 18px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; color: transparent; }
        h2 { font-weight: 700; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; color: transparent; margin-bottom: 10px; }
        .msg { color: #344767; font-size: 1.1rem; margin-bottom: 18px; }
        a.btn { display: inline-block; margin-top: 18px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; text-decoration: none; font-weight: 600; font-size: 16px; padding: 12px 32px; border-radius: 12px; box-shadow: 0 4px 12px rgba(102,126,234,0.10); transition: background 0.2s; }
        a.btn:hover { background: linear-gradient(135deg, #764ba2 0%, #667eea 100%); }
    </style>
</head>
<body>
    <div class="container">
        <span class="icon material-icons"><?php echo htmlspecialchars($icono); ?></span>
        <h2>Verificación de cuenta</h2>
        <div class="msg"><?php echo htmlspecialchars($mensaje); ?></div>
        <a href="/acceso" class="btn">Iniciar sesión</a>
    </div>
</body>
</html>
