<?php
namespace ObelisIA\Auth;

use ObelisIA\Database\Database;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class Register
{
    public static function checkAvailability($type, $value)
    {
        $dbClass = new Database();
        $db = $dbClass->getConnection();
        
        if ($type === 'username') {
            // Validar formato del username
            if (!preg_match('/^[a-zA-Z0-9_-]{3,20}$/', $value)) {
                return ["available" => false, "message" => "El usuario debe tener entre 3-20 caracteres, solo letras, números, guiones y guiones bajos"];
            }
            
            $stmt = $db->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
            $stmt->execute([$value]);
            
            if ($stmt->fetch()) {
                return ["available" => false, "message" => "Este usuario ya está en uso"];
            } else {
                return ["available" => true, "message" => "Usuario disponible"];
            }
        } else if ($type === 'email') {
            if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                return ["available" => false, "message" => "Email no válido"];
            }
            
            $stmt = $db->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
            $stmt->execute([$value]);
            
            if ($stmt->fetch()) {
                return ["available" => false, "message" => "Este email ya está registrado"];
            } else {
                return ["available" => true, "message" => "Email disponible"];
            }
        }
        
        return ["available" => false, "message" => "Tipo de verificación no válido"];
    }
    
    public static function registerUser($username, $email, $password, $full_name, $site_url)
    {
        $dbClass = new Database();
        $db = $dbClass->getConnection();
        
        // Verificar si el usuario o email ya existe
        $stmt = $db->prepare("SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1");
        $stmt->execute([$username, $email]);
        if ($stmt->fetch()) {
            return ["success" => false, "message" => "El usuario o email ya existe. Por favor, elija otro."];
        }
        
        // Generar token de verificación
        $token = bin2hex(random_bytes(32));
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
        
        // Guardar usuario como no verificado
        $stmt = $db->prepare("INSERT INTO users (username, email, password, full_name, email_verified, verification_token, created_at) VALUES (?, ?, ?, ?, 0, ?, NOW())");
        $stmt->execute([$username, $email, $password_hash, $full_name, $token]);
        
        // Enviar correo de verificación
        try {
            $verificationSent = self::sendVerificationEmail($email, $full_name, $token, $site_url);
            
            if ($verificationSent) {
                return ["success" => true, "message" => "Registro exitoso. Revisa tu correo para verificar tu cuenta."];
            } else {
                return ["success" => false, "message" => "Error al enviar el correo de verificación."];
            }
        } catch (Exception $e) {
            return ["success" => false, "message" => "No se pudo enviar el correo de verificación."];
        }
    }
    
    private static function sendVerificationEmail($email, $fullName, $token, $siteUrl)
    {
        $verificationLink = $siteUrl . '/pages/auth/verificar.php?token=' . urlencode($token);
        $subject = "Verifica tu cuenta - ObelisIA";
        $message = self::getVerificationEmailTemplate($fullName, $verificationLink);
        
        $headers = [
            'MIME-Version: 1.0',
            'Content-type: text/html; charset=UTF-8',
            'From: ObelisIA <noreply@obelisia.com>',
            'Reply-To: ObelisIA <noreply@obelisia.com>',
            'X-Mailer: PHP/' . phpversion()
        ];
        
        return mail($email, $subject, $message, implode("\r\n", $headers));
    }
    
    private static function getVerificationEmailTemplate($fullName, $verificationLink)
    {
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>Verificación de cuenta</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
                .button { display: inline-block; background: #667eea; color: #666; padding: 15px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; font-weight: bold; }
                .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
                .welcome-message { background: #e8f5e8; border-left: 4px solid #28a745; padding: 15px; margin: 20px 0; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>🎉 ¡Bienvenido a ObelisIA!</h1>
                    <p>Tu plataforma de creación con IA</p>
                </div>
                <div class='content'>
                    <h2>Hola, " . htmlspecialchars($fullName) . "</h2>
                    <div class='welcome-message'>
                        <p><strong>¡Gracias por unirte a nuestra comunidad!</strong></p>
                        <p>Estás a un paso de descubrir el poder de la inteligencia artificial para crear contenido increíble.</p>
                    </div>
                    <p>Para completar tu registro y activar tu cuenta, necesitamos verificar tu dirección de email.</p>
                    <p style='text-align: center;'>
                        <a href='" . htmlspecialchars($verificationLink) . "' class='button'>✅ Verificar mi cuenta</a>
                    </p>
                    <h3>¿Qué puedes hacer en ObelisIA?</h3>
                    <ul>
                        <li>🎨 Crear contenido único con IA</li>
                        <li>📝 Generar textos profesionales</li>
                        <li>🖼️ Diseñar imágenes increíbles</li>
                        <li>🤖 Interactuar con asistentes inteligentes</li>
                        <li>📊 Analizar y optimizar tu contenido</li>
                    </ul>
                    <p>Si el botón no funciona, puedes copiar y pegar este enlace en tu navegador:</p>
                    <p style='word-break: break-all; font-size: 12px; color: #666; background: #f0f0f0; padding: 10px; border-radius: 5px;'>" . htmlspecialchars($verificationLink) . "</p>
                    <p><strong>Este enlace expirará en 24 horas.</strong></p>
                </div>
                <div class='footer'>
                    <p>© " . date('Y') . " ObelisIA. Todos los derechos reservados.</p>
                    <p>Si no creaste esta cuenta, puedes ignorar este email.</p>
                    <p>Este es un email automático, por favor no respondas.</p>
                </div>
            </div>
        </body>
        </html>
        ";
    }
}
