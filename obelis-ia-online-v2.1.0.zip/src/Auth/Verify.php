<?php
namespace ObelisIA\Auth;

use ObelisIA\Database\Database;

class Verify
{
    public static function verifyToken($token)
    {
        $mensaje = '';
        $icono = '';
        if ($token) {
            $dbClass = new Database();
            $db = $dbClass->getConnection();
            $stmt = $db->prepare("SELECT id, email_verified FROM users WHERE verification_token = ? LIMIT 1");
            $stmt->execute([$token]);
            $user = $stmt->fetch();
            if ($user) {
                if ($user['email_verified']) {
                    $mensaje = 'Tu cuenta ya estaba verificada.';
                    $icono = 'info';
                } else {
                    $stmt = $db->prepare("UPDATE users SET email_verified = 1, verification_token = NULL WHERE id = ?");
                    $stmt->execute([$user['id']]);
                    $mensaje = '¡Cuenta verificada exitosamente! Ya puedes iniciar sesión.';
                    $icono = 'check_circle';
                }
            } else {
                $mensaje = 'El enlace de verificación no es válido o ya fue usado.';
                $icono = 'error';
            }
        } else {
            $mensaje = 'No se proporcionó un token de verificación.';
            $icono = 'error';
        }
        return ["mensaje" => $mensaje, "icono" => $icono];
    }
}
