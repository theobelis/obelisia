<?php
namespace ObelisIA\Auth;

use ObelisIA\Database\Database;

class Login
{
    public static function checkUserExists($usernameOrEmail)
    {
        try {
            $dbClass = new Database();
            $db = $dbClass->getConnection();
            
            if (!$db) {
                return ["success" => false, "message" => "Error de conexión a la base de datos"];
            }
            
            $stmt = $db->prepare("SELECT id, username, email, full_name, profile_image FROM users WHERE username = ? OR email = ? LIMIT 1");
            $stmt->execute([$usernameOrEmail, $usernameOrEmail]);
            $user = $stmt->fetch();
            
            if ($user) {
                // Construir URL de la imagen de perfil si existe
                if ($user['profile_image'] && !filter_var($user['profile_image'], FILTER_VALIDATE_URL)) {
                    $user['profile_image'] = SITE_URL . '/uploads/profiles/' . $user['profile_image'];
                }
                
                return [
                    "success" => true, 
                    "user" => [
                        'id' => $user['id'],
                        'username' => $user['username'],
                        'email' => $user['email'],
                        'full_name' => $user['full_name'],
                        'profile_image' => $user['profile_image']
                    ]
                ];
            }
            
            return ["success" => false, "message" => "Usuario no encontrado"];
        } catch (Exception $e) {
            return ["success" => false, "message" => "Error de conexión: " . $e->getMessage()];
        }
    }
    
    public static function loginUser($usernameOrEmail, $password)
    {
        $dbClass = new Database();
        $db = $dbClass->getConnection();
        $stmt = $db->prepare("SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1");
        $stmt->execute([$usernameOrEmail, $usernameOrEmail]);
        $user = $stmt->fetch();
        if ($user && password_verify($password, $user['password'])) {
            if (isset($user['email_verified']) && !$user['email_verified']) {
                return ["success" => false, "message" => "<div class='alert alert-warning alert-dismissible fade show alert-custom' role='alert'><i class='material-icons me-2'>info</i>Debes verificar tu correo antes de iniciar sesión.<button type='button' class='btn-close' data-bs-dismiss='alert'></button></div>"];
            }
            // Aquí deberías iniciar la sesión, etc.
            return ["success" => true, "user" => $user];
        }
        // Mensaje de error elegante para usuario/contraseña incorrectos
        return ["success" => false, "message" => "<div class='alert alert-danger alert-dismissible fade show alert-custom' role='alert'><i class='material-icons me-2'>error</i>Usuario o contraseña incorrectos.<button type='button' class='btn-close' data-bs-dismiss='alert'></button></div>"];
    }
}
