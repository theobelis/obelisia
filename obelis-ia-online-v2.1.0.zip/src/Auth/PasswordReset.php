<?php
namespace ObelisIA\Auth;

use ObelisIA\Database\Database;

class PasswordReset
{
    public static function requestReset($email)
    {
        $dbClass = new Database();
        $db = $dbClass->getConnection();
        
        // Verificar si el email existe
        $stmt = $db->prepare("SELECT id, username, full_name FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if (!$user) {
            return ["success" => false, "message" => "Email no encontrado en el sistema."];
        }
        
        // Generar token único
        $token = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        // Guardar token en la base de datos
        $stmt = $db->prepare("INSERT INTO password_reset_tokens (user_id, token, expires_at) VALUES (?, ?, ?) 
                             ON DUPLICATE KEY UPDATE token = ?, expires_at = ?");
        $stmt->execute([$user['id'], $token, $expires, $token, $expires]);
        
        // Enviar email
        $resetLink = SITE_URL . '/recuperar-password?token=' . $token;
        $emailSent = self::sendResetEmail($email, $user['full_name'], $resetLink);
        
        if ($emailSent) {
            return ["success" => true, "message" => "Se ha enviado un enlace de recuperación a tu email."];
        } else {
            return ["success" => false, "message" => "Error al enviar el email. Inténtalo de nuevo."];
        }
    }
    
    public static function resetPassword($token, $newPassword)
    {
        $dbClass = new Database();
        $db = $dbClass->getConnection();
        
        // Verificar token
        $stmt = $db->prepare("SELECT user_id FROM password_reset_tokens WHERE token = ? AND expires_at > NOW() LIMIT 1");
        $stmt->execute([$token]);
        $resetToken = $stmt->fetch();
        
        if (!$resetToken) {
            return ["success" => false, "message" => "Token inválido o expirado."];
        }
        
        // Actualizar contraseña
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $stmt = $db->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->execute([$hashedPassword, $resetToken['user_id']]);
        
        // Eliminar token usado
        $stmt = $db->prepare("DELETE FROM password_reset_tokens WHERE token = ?");
        $stmt->execute([$token]);
        
        return ["success" => true, "message" => "Contraseña actualizada correctamente. Serás redirigido al login."];
    }
    
    private static function sendResetEmail($email, $fullName, $resetLink)
    {
        $subject = "Recuperación de contraseña - ObelisIA";
        $message = self::getEmailTemplate($fullName, $resetLink);
        
        $headers = [
            'MIME-Version: 1.0',
            'Content-type: text/html; charset=UTF-8',
            'From: ObelisIA <noreply@obelisia.com>',
            'Reply-To: ObelisIA <noreply@obelisia.com>',
            'X-Mailer: PHP/' . phpversion()
        ];
        
        return mail($email, $subject, $message, implode("\r\n", $headers));
    }
    
    private static function getEmailTemplate($fullName, $resetLink)
    {
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>Recuperación de contraseña</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
                .button { display: inline-block; background: #667eea; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
                .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>🔐 Recuperación de contraseña</h1>
                    <p>ObelisIA</p>
                </div>
                <div class='content'>
                    <h2>Hola, " . htmlspecialchars($fullName) . "</h2>
                    <p>Hemos recibido una solicitud para restablecer tu contraseña en ObelisIA.</p>
                    <p>Si no realizaste esta solicitud, puedes ignorar este email.</p>
                    <p>Para restablecer tu contraseña, haz clic en el siguiente enlace:</p>
                    <p style='text-align: center;'>
                        <a href='" . htmlspecialchars($resetLink) . "' class='button'>Restablecer contraseña</a>
                    </p>
                    <p><strong>Este enlace expirará en 1 hora.</strong></p>
                    <p>Si el botón no funciona, puedes copiar y pegar este enlace en tu navegador:</p>
                    <p style='word-break: break-all; font-size: 12px; color: #666;'>" . htmlspecialchars($resetLink) . "</p>
                </div>
                <div class='footer'>
                    <p>© " . date('Y') . " ObelisIA. Todos los derechos reservados.</p>
                    <p>Este es un email automático, por favor no respondas.</p>
                </div>
            </div>
        </body>
        </html>
        ";
    }
}
