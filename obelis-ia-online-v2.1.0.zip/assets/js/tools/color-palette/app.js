document.addEventListener('DOMContentLoaded', () => {
    const imageUpload = document.getElementById('image-upload');
    const imageCanvas = document.getElementById('image-canvas');
    const ctx = imageCanvas.getContext('2d');
    const paletteContainer = document.getElementById('palette-container');
    const loadingState = document.getElementById('loading-state');
    const instructions = document.getElementById('instructions');

    // Opciones actuales
    let paletteOptions = {
        numColors: 6,
        colorFormat: 'hex',
        sortOrder: 'dominance',
        premium: false
    };
    // Actualizar opciones si existen en el form
    document.addEventListener('paletteOptionsChanged', e => {
        paletteOptions = { ...e.detail, premium: false };
        if (window._lastImageData) {
            extractColors(window._lastImageData);
        }
    });
    // Opciones premium
    document.addEventListener('palettePremiumOptionsChanged', e => {
        paletteOptions = { ...paletteOptions, ...e.detail };
        if (window._lastImageData) {
            extractColors(window._lastImageData);
        }
    });

    // Visualizar paleta del historial
    document.addEventListener('paletteHistorySelected', e => {
        const { palette, options } = e.detail;
        // Mostrar la paleta en la UI principal
        displayPalette(palette);
        // Si la imagen original está disponible, dibujar la paleta sobre el canvas
        if (window._lastImageData) {
            // Opcional: resaltar los colores en el canvas (por simplicidad, solo mostrar la paleta)
        }
        // Actualizar opciones visuales en el aside
        const numColorsInput = document.getElementById('numColors');
        const colorFormatSelect = document.getElementById('colorFormat');
        const sortOrderSelect = document.getElementById('sortOrder');
        if (numColorsInput && colorFormatSelect && sortOrderSelect) {
            numColorsInput.value = options.numColors;
            colorFormatSelect.value = options.colorFormat;
            sortOrderSelect.value = options.sortOrder;
        }
    });

            // --- Funciones de Conversión de Color (RGB -> HEX -> HSL) ---
            function rgbToHex({ r, g, b }) {
                const toHex = val => val.toString(16).padStart(2, '0');
                return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
            }
            
            function hexToRgb(hex) {
                let r = 0, g = 0, b = 0;
                if (hex.length == 7) {
                    r = parseInt(hex.slice(1, 3), 16);
                    g = parseInt(hex.slice(3, 5), 16);
                    b = parseInt(hex.slice(5, 7), 16);
                }
                return { r, g, b };
            }

            function rgbToHsl({r, g, b}) {
                r /= 255; g /= 255; b /= 255;
                const max = Math.max(r, g, b), min = Math.min(r, g, b);
                let h, s, l = (max + min) / 2;
                if (max === min) { h = s = 0; } 
                else {
                    const d = max - min;
                    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
                    switch (max) {
                        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
                        case g: h = (b - r) / d + 2; break;
                        case b: h = (r - g) / d + 4; break;
                    }
                    h /= 6;
                }
                return { h: h * 360, s: s * 100, l: l * 100 };
            }

            // --- Lógica de Extracción de Paleta ---
    // --- Utilidades de conversión para LAB y HSV ---
    function rgbToXyz(r, g, b) {
        // sRGB -> XYZ
        r = r / 255; g = g / 255; b = b / 255;
        r = r > 0.04045 ? Math.pow((r + 0.055) / 1.055, 2.4) : r / 12.92;
        g = g > 0.04045 ? Math.pow((g + 0.055) / 1.055, 2.4) : g / 12.92;
        b = b > 0.04045 ? Math.pow((b + 0.055) / 1.055, 2.4) : b / 12.92;
        let x = r * 0.4124 + g * 0.3576 + b * 0.1805;
        let y = r * 0.2126 + g * 0.7152 + b * 0.0722;
        let z = r * 0.0193 + g * 0.1192 + b * 0.9505;
        return [x * 100, y * 100, z * 100];
    }
    function xyzToLab(x, y, z) {
        // D65/2°
        let refX = 95.047, refY = 100.0, refZ = 108.883;
        x = x / refX; y = y / refY; z = z / refZ;
        x = x > 0.008856 ? Math.pow(x, 1/3) : (7.787 * x) + 16/116;
        y = y > 0.008856 ? Math.pow(y, 1/3) : (7.787 * y) + 16/116;
        z = z > 0.008856 ? Math.pow(z, 1/3) : (7.787 * z) + 16/116;
        let l = (116 * y) - 16;
        let a = 500 * (x - y);
        let b = 200 * (y - z);
        return [l, a, b];
    }
    function rgbToLab({r, g, b}) {
        const [x, y, z] = rgbToXyz(r, g, b);
        return xyzToLab(x, y, z);
    }
    function rgbToHsv({r, g, b}) {
        r /= 255; g /= 255; b /= 255;
        let max = Math.max(r, g, b), min = Math.min(r, g, b);
        let h, s, v = max;
        let d = max - min;
        s = max === 0 ? 0 : d / max;
        if (max === min) h = 0;
        else {
            switch (max) {
                case r: h = (g - b) / d + (g < b ? 6 : 0); break;
                case g: h = (b - r) / d + 2; break;
                case b: h = (r - g) / d + 4; break;
            }
            h /= 6;
        }
        return [h * 360, s * 100, v * 100];
    }

    function extractColors(imageData) {
        window._lastImageData = imageData;
        const pixelData = imageData.data;
        const colorCounts = {};
        // Premium: más precisión y opciones
        let binSize = paletteOptions.premium ? 12 : 24;
        let skip = paletteOptions.premium ? 2 : 5;
        let colorSpace = paletteOptions.premium && paletteOptions.colorSpace ? paletteOptions.colorSpace : 'rgb';
        for (let i = 0; i < pixelData.length; i += 4 * skip) {
            let r = pixelData[i];
            let g = pixelData[i + 1];
            let b = pixelData[i + 2];
            let a = pixelData[i + 3];
            // Premium: eliminar fondo blanco/negro
            if (paletteOptions.premium && paletteOptions.removeBackground && paletteOptions.removeBackground !== 'no') {
                if (paletteOptions.removeBackground === 'si' || paletteOptions.removeBackground === 'auto') {
                    if ((r > 240 && g > 240 && b > 240) || (r < 15 && g < 15 && b < 15)) continue;
                }
            } else {
                if (a < 128 || (r > 250 && g > 250 && b > 250) || (r < 10 && g < 10 && b < 10)) continue;
            }
            let key;
            if (paletteOptions.premium && colorSpace === 'lab') {
                const [l, aLab, bLab] = rgbToLab({r, g, b});
                // Bin LAB
                const binL = Math.round(l / 5) * 5;
                const binA = Math.round(aLab / 5) * 5;
                const binB = Math.round(bLab / 5) * 5;
                key = [binL, binA, binB].join(',');
            } else if (paletteOptions.premium && colorSpace === 'hsv') {
                const [h, s, v] = rgbToHsv({r, g, b});
                // Bin HSV
                const binH = Math.round(h / 10) * 10;
                const binS = Math.round(s / 10) * 10;
                const binV = Math.round(v / 10) * 10;
                key = [binH, binS, binV].join(',');
            } else {
                const binnedR = Math.round(r / binSize) * binSize;
                const binnedG = Math.round(g / binSize) * binSize;
                const binnedB = Math.round(b / binSize) * binSize;
                key = [binnedR, binnedG, binnedB].join(',');
            }
            colorCounts[key] = (colorCounts[key] || 0) + 1;
        }
        let sortedColors = Object.entries(colorCounts);
        // Ordenar según opción
        if (paletteOptions.sortOrder === 'dominance') {
            sortedColors.sort((a, b) => b[1] - a[1]);
        } else if (paletteOptions.sortOrder === 'hue' || paletteOptions.sortOrder === 'lightness') {
            sortedColors = sortedColors.map(item => {
                let r, g, b;
                if (paletteOptions.premium && colorSpace === 'lab') {
                    // No se puede convertir LAB a HSL fácilmente, usar RGB aproximado
                    [r, g, b] = [0, 0, 0];
                } else if (paletteOptions.premium && colorSpace === 'hsv') {
                    // No se puede convertir HSV a HSL fácilmente, usar RGB aproximado
                    [r, g, b] = [0, 0, 0];
                } else {
                    [r, g, b] = item[0].split(',').map(Number);
                }
                const hsl = rgbToHsl({ r, g, b });
                return { item, h: hsl.h, l: hsl.l };
            });
            if (paletteOptions.sortOrder === 'hue') {
                sortedColors.sort((a, b) => a.h - b.h);
            } else {
                sortedColors.sort((a, b) => a.l - b.l);
            }
            sortedColors = sortedColors.map(obj => obj.item);
        }
        let nColors = paletteOptions.premium && paletteOptions.numColors ? paletteOptions.numColors : paletteOptions.numColors;
        let colorFormat = paletteOptions.colorFormat;
        // Si es premium, buscar el valor actual del select premium (por si el form no actualizó bien el objeto)
        if (paletteOptions.premium) {
            const premiumColorFormat = document.getElementById('colorFormat');
            if (premiumColorFormat) colorFormat = premiumColorFormat.value;
        }
        let finalPalette = sortedColors.slice(0, nColors).map(item => {
            let r, g, b;
            if (paletteOptions.premium && colorSpace === 'lab') {
                // Convertir LAB a RGB para mostrar el color real
                const [l, aLab, bLab] = item[0].split(',').map(Number);
                function labToXyz(l, a, b) {
                    let y = (l + 16) / 116;
                    let x = a / 500 + y;
                    let z = y - b / 200;
                    let y3 = Math.pow(y, 3);
                    let x3 = Math.pow(x, 3);
                    let z3 = Math.pow(z, 3);
                    y = y3 > 0.008856 ? y3 : (y - 16/116) / 7.787;
                    x = x3 > 0.008856 ? x3 : (x - 16/116) / 7.787;
                    z = z3 > 0.008856 ? z3 : (z - 16/116) / 7.787;
                    // D65/2°
                    x *= 95.047;
                    y *= 100.0;
                    z *= 108.883;
                    return [x, y, z];
                }
                function xyzToRgb(x, y, z) {
                    x /= 100; y /= 100; z /= 100;
                    let r = x * 3.2406 + y * -1.5372 + z * -0.4986;
                    let g = x * -0.9689 + y * 1.8758 + z * 0.0415;
                    let b = x * 0.0557 + y * -0.2040 + z * 1.0570;
                    r = r > 0.0031308 ? 1.055 * Math.pow(r, 1/2.4) - 0.055 : 12.92 * r;
                    g = g > 0.0031308 ? 1.055 * Math.pow(g, 1/2.4) - 0.055 : 12.92 * g;
                    b = b > 0.0031308 ? 1.055 * Math.pow(b, 1/2.4) - 0.055 : 12.92 * b;
                    r = Math.min(Math.max(0, r), 1);
                    g = Math.min(Math.max(0, g), 1);
                    b = Math.min(Math.max(0, b), 1);
                    return {
                        r: Math.round(r * 255),
                        g: Math.round(g * 255),
                        b: Math.round(b * 255)
                    };
                }
                const [x, y, z] = labToXyz(l, aLab, bLab);
                const rgb = xyzToRgb(x, y, z);
                if (colorFormat === 'rgb') {
                    return `rgb(${rgb.r},${rgb.g},${rgb.b})`;
                } else {
                    return rgbToHex(rgb);
                }
            } else if (paletteOptions.premium && colorSpace === 'hsv') {
                // Convertir HSV a RGB para mostrar el color real
                const [h, s, v] = item[0].split(',').map(Number);
                function hsvToRgb(h, s, v) {
                    s /= 100; v /= 100;
                    let c = v * s;
                    let x = c * (1 - Math.abs((h / 60) % 2 - 1));
                    let m = v - c;
                    let r1, g1, b1;
                    if (h < 60) { r1 = c; g1 = x; b1 = 0; }
                    else if (h < 120) { r1 = x; g1 = c; b1 = 0; }
                    else if (h < 180) { r1 = 0; g1 = c; b1 = x; }
                    else if (h < 240) { r1 = 0; g1 = x; b1 = c; }
                    else if (h < 300) { r1 = x; g1 = 0; b1 = c; }
                    else { r1 = c; g1 = 0; b1 = x; }
                    let r = Math.round((r1 + m) * 255);
                    let g = Math.round((g1 + m) * 255);
                    let b = Math.round((b1 + m) * 255);
                    return { r, g, b };
                }
                const rgb = hsvToRgb(h, s, v);
                if (colorFormat === 'rgb') {
                    return `rgb(${rgb.r},${rgb.g},${rgb.b})`;
                } else {
                    return rgbToHex(rgb);
                }
            } else {
                [r, g, b] = item[0].split(',').map(Number);
                if (colorFormat === 'rgb') {
                    return `rgb(${r},${g},${b})`;
                } else {
                    return rgbToHex({ r, g, b });
                }
            }
        });
        // Registrar actividad en el backend
        fetch('/api/log_activity.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'Generación de paleta de colores',
                tool: 'color-palette',
                details: `Colores extraídos: ${finalPalette.length}${paletteOptions.premium ? ' (premium)' : ''}`
            })
        });
        displayPalette(finalPalette);
        if (window.addPaletteToHistory) {
            window.addPaletteToHistory(finalPalette, { ...paletteOptions });
            if (window.renderPaletteHistory) window.renderPaletteHistory();
            // Guardar también en la galería unificada (obelisiaGallery)
            if (!window.saveItemToGallery) {
                import('/../assets/js/tools/ia-img/galleryManager.js').then(module => {
                    window.saveItemToGallery = module.saveItemToGallery;
                    window.saveItemToGallery({
                        tipo: 'paleta',
                        data: { colors: finalPalette },
                        fecha: new Date().toISOString()
                    });
                }).catch(e => {
                    console.warn('No se pudo guardar la paleta en la galería unificada:', e);
                });
            } else {
                window.saveItemToGallery({
                    tipo: 'paleta',
                    data: { colors: finalPalette },
                    fecha: new Date().toISOString()
                });
            }
        }
    }

            // --- Actualización de la UI ---
    function displayPalette(colors) {
        paletteContainer.innerHTML = '';
        if (colors.length === 0) {
            instructions.innerHTML = `<p class="fs-5">No se pudieron extraer colores significativos. Intenta con otra imagen.</p>`;
            return;
        }
        instructions.innerHTML = `<p>Se encontraron <strong>${colors.length}</strong> colores. Haz clic en uno para copiarlo.</p>`;
        colors.forEach(color => {
            // Mejorar contraste visual para RGB
            let hexColor = color;
            if (color.startsWith('rgb')) {
                const rgb = color.match(/\d+/g).map(Number);
                hexColor = rgbToHex({ r: rgb[0], g: rgb[1], b: rgb[2] });
            }
            const { l: lightness } = rgbToHsl(hexToRgb(hexColor));
            const textColorClass = lightness > 60 ? 'text-dark' : 'text-white';
            const col = document.createElement('div');
            col.className = 'col';
            const card = document.createElement('div');
            card.className = `color-card d-flex align-items-center justify-content-center rounded shadow-sm ${textColorClass}`;
            card.style.backgroundColor = color;
            card.dataset.color = color;
            card.innerHTML = `
                <div class="overlay"></div>
                <span class="hex-code">${color}</span>
                <div class="copy-tooltip">Copiado!</div>
            `;
            col.appendChild(card);
            paletteContainer.appendChild(col);
        });
    }

            // --- Manejadores de Eventos ---
            function handleImageUpload(e) {
                const file = e.target.files[0];
                if (!file) return;

                loadingState.classList.remove('d-none');
                instructions.classList.add('d-none');
                paletteContainer.innerHTML = '';

                const reader = new FileReader();
                reader.onload = (event) => {
                    const img = new Image();
                    img.onload = () => {
                        const max_size = 200;
                        let width = img.width;
                        let height = img.height;

                        if (width > height) {
                            if (width > max_size) {
                                height *= max_size / width;
                                width = max_size;
                            }
                        } else {
                            if (height > max_size) {
                                width *= max_size / height;
                                height = max_size;
                            }
                        }
                        imageCanvas.width = width;
                        imageCanvas.height = height;
                        
                        ctx.drawImage(img, 0, 0, width, height);
                        const imageData = ctx.getImageData(0, 0, width, height);
                        
                        setTimeout(() => {
                           extractColors(imageData);
                           loadingState.classList.add('d-none');
                           instructions.classList.remove('d-none');
                        }, 50);
                    };
                    img.src = event.target.result;
                };
                reader.readAsDataURL(file);
            }

            function handlePaletteClick(e) {
                const card = e.target.closest('.color-card');
                if (!card) return;

                const color = card.dataset.color;
                navigator.clipboard.writeText(color).then(() => {
                    card.classList.add('copied');
                    setTimeout(() => card.classList.remove('copied'), 1500);
                }).catch(err => {
                    console.error('Error al copiar:', err);
                    const textArea = document.createElement("textarea");
                    textArea.value = color;
                    document.body.appendChild(textArea);
                    textArea.focus();
                    textArea.select();
                    try {
                        document.execCommand('copy');
                        card.classList.add('copied');
                        setTimeout(() => card.classList.remove('copied'), 1500);
                    } catch (err) {
                        console.error('Fallback de copia fallido:', err);
                    }
                    document.body.removeChild(textArea);
                });
            }

            // --- Inicialización ---
            imageUpload.addEventListener('change', handleImageUpload);
            paletteContainer.addEventListener('click', handlePaletteClick);
        });