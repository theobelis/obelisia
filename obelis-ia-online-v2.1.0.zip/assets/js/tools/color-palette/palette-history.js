// Historial y opciones para el generador de paletas
// Este script debe importarse DESPUÉS de app.js

document.addEventListener('DOMContentLoaded', () => {
    // --- Elementos de opciones ---
    const paletteOptionsForm = document.getElementById('paletteOptionsForm');
    const numColorsInput = document.getElementById('numColors');
    const colorFormatSelect = document.getElementById('colorFormat');
    const sortOrderSelect = document.getElementById('sortOrder');

    // --- Elementos de historial ---
    const paletteHistoryContainer = document.getElementById('paletteHistoryContainer');
    const clearPaletteHistoryButton = document.getElementById('clearPaletteHistoryButton');

    // --- Utilidades de almacenamiento ---
    function getPaletteHistory() {
        return JSON.parse(localStorage.getItem('paletteHistory') || '[]');
    }
    function savePaletteHistory(history) {
        localStorage.setItem('paletteHistory', JSON.stringify(history));
    }
    function addPaletteToHistory(palette, options) {
        const history = getPaletteHistory();
        history.unshift({ palette, options, date: new Date().toISOString() });
        if (history.length > 20) history.length = 20;
        savePaletteHistory(history);
    }
    function clearPaletteHistory() {
        savePaletteHistory([]);
        renderPaletteHistory();
    }

    // --- Renderizar historial ---
    function renderPaletteHistory() {
        const history = getPaletteHistory();
        paletteHistoryContainer.innerHTML = '';
        if (!history.length) {
            paletteHistoryContainer.innerHTML = '<p class="text-muted text-center">No hay paletas en el historial.</p>';
            return;
        }
        history.forEach((item, idx) => {
            const div = document.createElement('div');
            div.className = 'history-item mb-3 d-flex align-items-center justify-content-between p-2 rounded border bg-white shadow-sm';
            div.innerHTML = `
                <div class="d-flex align-items-center gap-1 flex-wrap">
                    ${item.palette.map(color => `<span style="display:inline-block;width:22px;height:22px;border-radius:4px;background:${color};border:1.5px solid #e0e0e0;box-shadow:0 1px 2px #0001;" title="${color}"></span>`).join('')}
                </div>
                <div class="d-flex flex-column align-items-end ms-2">
                    <span class="small text-muted">${new Date(item.date).toLocaleString()}</span>
                    <button class="btn btn-outline-primary btn-sm mt-1 copy-btn" title="Copiar paleta"><i class="fas fa-copy"></i></button>
                </div>
            `;
            div.querySelector('.copy-btn').addEventListener('click', (ev) => {
                ev.stopPropagation();
                navigator.clipboard.writeText(item.palette.join(', '));
            });
            div.title = 'Haz clic para visualizar esta paleta';
            div.style.cursor = 'pointer';
            div.addEventListener('click', () => {
                // Lanzar evento para que app.js la visualice
                document.dispatchEvent(new CustomEvent('paletteHistorySelected', { detail: item }));
            });
            paletteHistoryContainer.appendChild(div);
        });
    }

    // --- Opciones de paleta ---

    if (paletteOptionsForm) {
        paletteOptionsForm.addEventListener('submit', function(e) {
            e.preventDefault();
            // Lanzar evento personalizado para que app.js regenere la paleta
            const options = {
                numColors: parseInt(numColorsInput.value, 10),
                colorFormat: colorFormatSelect.value,
                sortOrder: sortOrderSelect.value
            };
            document.dispatchEvent(new CustomEvent('paletteOptionsChanged', { detail: options }));
        });
    }

    clearPaletteHistoryButton.addEventListener('click', clearPaletteHistory);

    // Exponer para que app.js pueda agregar al historial
    window.addPaletteToHistory = addPaletteToHistory;
    window.renderPaletteHistory = renderPaletteHistory;

    renderPaletteHistory();
});
