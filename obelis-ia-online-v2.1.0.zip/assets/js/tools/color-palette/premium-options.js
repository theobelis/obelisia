// premium-options.js
// Lógica avanzada para usuarios premium en el generador de paletas

document.addEventListener('DOMContentLoaded', () => {
    const premiumForm = document.getElementById('palettePremiumOptionsForm');
    if (!premiumForm) return;


    function dispatchPremiumOptions() {
        const numColors = parseInt(document.getElementById('premiumNumColors').value, 10);
        const colorSpace = document.getElementById('colorSpace').value;
        const removeBackground = document.getElementById('removeBackground').value;
        const colorFormat = document.getElementById('colorFormat').value;
        const sortOrder = document.getElementById('sortOrder').value;
        document.dispatchEvent(new CustomEvent('palettePremiumOptionsChanged', {
            detail: { numColors, colorSpace, removeBackground, colorFormat, sortOrder, premium: true }
        }));
    }

    premiumForm.addEventListener('submit', function(e) {
        e.preventDefault();
        dispatchPremiumOptions();
    });

    // Listeners para aplicar cambios al instante
    ['premiumNumColors','colorFormat','sortOrder','colorSpace','removeBackground'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('change', dispatchPremiumOptions);
    });
});
