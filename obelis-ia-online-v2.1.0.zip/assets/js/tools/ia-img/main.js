// Modal para pedir título y descripción antes de guardar
function showSaveCreationModal(onSave) {
  let modal = document.getElementById('saveCreationModal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'saveCreationModal';
    modal.className = 'modal fade';
    modal.tabIndex = -1;
    modal.innerHTML = `
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content shadow-lg border-0">
          <form id="saveCreationForm">
            <div class="modal-header border-0 pb-0">
              <h4 class="modal-title">Guardar Creación</h4>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body pt-2">
              <div class="mb-3">
                <label for="creationTitle" class="form-label">Título</label>
                <input type="text" class="form-control" id="creationTitle" maxlength="100" required placeholder="Ej: Retrato de dragón" autocomplete="off">
              </div>
              <div class="mb-3">
                <label for="creationDescription" class="form-label">Descripción</label>
                <textarea class="form-control" id="creationDescription" rows="2" maxlength="255" placeholder="Describe tu creación..." required></textarea>
              </div>
            </div>
            <div class="modal-footer border-0 pt-0">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
              <button type="submit" class="btn btn-info">Guardar</button>
            </div>
          </form>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
  }
  // Limpiar campos
  modal.querySelector('#creationTitle').value = '';
  modal.querySelector('#creationDescription').value = '';
  // Agregar selector de privacidad si no existe
  if (!modal.querySelector('#creationPrivacy')) {
    const privDiv = document.createElement('div');
    privDiv.className = 'mb-3';
    privDiv.innerHTML = `
      <label for="creationPrivacy" class="form-label">Privacidad</label>
      <select id="creationPrivacy" class="form-select">
        <option value="private">Privada (solo tú)</option>
        <option value="public">Pública (visible para todos)</option>
      </select>
    `;
    modal.querySelector('.modal-body').appendChild(privDiv);
  }
  // Evento submit
  const form = modal.querySelector('#saveCreationForm');
  form.onsubmit = function(e) {
    e.preventDefault();
    const title = modal.querySelector('#creationTitle').value.trim();
    const description = modal.querySelector('#creationDescription').value.trim();
    const privacy = modal.querySelector('#creationPrivacy').value;
    if (title && description) {
      if (onSave) onSave({ title, description, privacy });
      if (window.bootstrap) {
        bootstrap.Modal.getOrCreateInstance(modal).hide();
      } else {
        modal.style.display = 'none';
      }
    }
  };
  // Mostrar modal
  if (window.bootstrap) {
    const modalObj = bootstrap.Modal.getOrCreateInstance(modal);
    modalObj.show();
  } else {
    modal.style.display = 'block';
  }
}
// Muestra un modal de error moderno
function showErrorModal(message = 'Ocurrió un error inesperado.') {
  let modal = document.getElementById('errorModal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'errorModal';
    modal.className = 'modal fade';
    modal.tabIndex = -1;
    modal.innerHTML = `
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content shadow-lg border-0">
          <div class="modal-body text-center p-5">
            <div class="mb-3">
              <i class="fas fa-times-circle fa-3x text-danger"></i>
            </div>
            <h4 class="mb-2">Error</h4>
            <p class="mb-4" id="errorModalMessage"></p>
            <button type="button" class="btn btn-secondary w-50" data-bs-dismiss="modal">Cerrar</button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
  }
  document.getElementById('errorModalMessage').textContent = message;
  // Mostrar el modal usando Bootstrap 5
  if (window.bootstrap) {
    const modalObj = bootstrap.Modal.getOrCreateInstance(modal);
    modalObj.show();
  } else {
    // fallback simple
    modal.style.display = 'block';
    setTimeout(() => { modal.style.display = 'none'; }, 2500);
  }
}
// Muestra un modal de éxito moderno
function showSuccessModal(message = '¡Imagen guardada exitosamente!') {
  let modal = document.getElementById('successModal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'successModal';
    modal.className = 'modal fade';
    modal.tabIndex = -1;
    modal.innerHTML = `
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content shadow-lg border-0">
          <div class="modal-body text-center p-5">
            <div class="mb-3">
              <i class="fas fa-check-circle fa-3x text-success"></i>
            </div>
            <h4 class="mb-2">¡Éxito!</h4>
            <p class="mb-4" id="successModalMessage"></p>
            <button type="button" class="btn btn-info w-50" data-bs-dismiss="modal">Cerrar</button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
  }
  document.getElementById('successModalMessage').textContent = message;
  // Mostrar el modal usando Bootstrap 5
  if (window.bootstrap) {
    const modalObj = bootstrap.Modal.getOrCreateInstance(modal);
    modalObj.show();
  } else {
    // fallback simple
    modal.style.display = 'block';
    setTimeout(() => { modal.style.display = 'none'; }, 2500);
  }
}
// ia-img/js/main.js

import { DOMElements, downloadImage } from "/../assets/js/general/global.js";
import {
  generateImage,
  improvePrompt,
  generatePromptSuggestion,
  watchAdForGenerations,
} from "./aiService.js";
import {
  renderGallery,
  renderRecentGenerations,
  toggleSelectAllImages,
  downloadSelectedImages,
  clearSelection,
  deleteSelectedImagesFromGallery,
  closeLightbox,
  showNextImage,
  showPrevImage,
} from "./galleryManager.js";
import {
  closeImageEditor,
  saveEditedImage,
  addTextToCanvas,
  applyCrop,
} from "./editorManager.js";
import {
  updateGenerationCounterUI,
  showPromptSuggestionBox,
} from "./uiUpdater.js";
import { setFreeGenerationsLeft } from "./state.js";
import { CONFIG } from "./config.js";

export function initApp() {
  // Selectores específicos de esta página
  const pageSelectors = {
    // Generación Principal
    promptInput: "#promptInput",
    generateButton: "#generateButton",
    improvePromptButton: "#improvePromptButton",
    toneSelect: "#toneSelect",
    styleSelect: "#styleSelect",
    aspectRatioSelect: "#aspectRatioSelect",
    generationCounter: "#generationCounter",
    watchAdButton: "#watchAdButton",
    generatedImage: "#generatedImage",
    imagePlaceholderText: "#imagePlaceholderText",
    downloadMainImageButton: "#downloadMainImageButton",
    saveCreationButton: "#saveCreationButton",

    // Sugerencia de Prompt
    promptSuggestionBox: "#promptSuggestionBox",
    generatePromptSuggestionButton: "#generatePromptSuggestionButton",

    // Galería (compatibilidad con ambos ids)
    galleryContainer: "#galleryContainer, #gallery-localstorage",
    selectAllButton: "#selectAllButton",
    downloadSelectedButton: "#downloadSelectedButton",
    clearSelectionButton: "#clearSelectionButton",
    deleteSelectedButton: "#deleteSelectedButton",
    localStorageUsage: "#localStorageUsage",
    recentGenerationsGallery: "#recentGenerationsGallery",
    downloadLastGeneratedButton: "#downloadLastGeneratedButton",

    // Lightbox
    lightbox: "#lightbox",
    lightboxImage: "#lightboxImage",
    lightboxCloseButton: "#lightboxCloseButton",
    lightboxPrevButton: "#lightboxPrevButton",
    lightboxNextButton: "#lightboxNextButton",
    lightboxThumbnails: "#lightboxThumbnails",

    // Editor
    imageEditorModal: "#imageEditorModal",
    editorCanvas: "#editorCanvas",
    editorCloseButton: "#editorCloseButton",
    saveEditedImageButton: "#saveEditedImageButton",
    cancelEditButton: "#cancelEditButton",
    filterThumbnails: "#filterThumbnails",
    editorTextInput: "#editorTextInput",
    editorTextColor: "#editorTextColor",
    editorTextSize: "#editorTextSize",
    editorTextPosition: "#editorTextPosition",
    addTextToCanvasButton: "#addTextToCanvasButton",
    cropWidthInput: "#cropWidthInput",
    cropHeightInput: "#cropHeightInput",
    applyCropButton: "#applyCropButton",
  };

  // Pobla el objeto DOMElements compartido con los elementos de esta página
  for (const key in pageSelectors) {
    // Permitir múltiples selectores para compatibilidad
    const selector = pageSelectors[key];
    let element = null;
    if (selector.includes(",")) {
      // Buscar el primer elemento que exista de la lista
      selector.split(",").some(sel => {
        const el = document.querySelector(sel.trim());
        if (el) {
          element = el;
          return true;
        }
        return false;
      });
    } else {
      element = document.querySelector(selector);
    }
    if (element) {
      DOMElements[key] = element;
    }
  }

  if (!DOMElements.generateButton) {
    console.error(
      "Faltan elementos clave. La inicialización de la página se detiene."
    );
    return;
  }

  // --- INICIALIZACIÓN DE ESTADO Y UI ---
  const savedGenerations = localStorage.getItem("freeGenerationsLeft");
  setFreeGenerationsLeft(
    savedGenerations
      ? parseInt(savedGenerations, 10)
      : CONFIG.MAX_FREE_GENERATIONS
  );
  updateGenerationCounterUI();
  renderGallery();
  renderRecentGenerations();
  setTimeout(
    showPromptSuggestionBox,
    CONFIG.PROMPT_SUGGESTION_DELAY_SECONDS * 1000
  );

  // --- ASIGNACIÓN DE EVENT LISTENERS ---
  function assignListeners() {
    // Guardar creación
    if (DOMElements.saveCreationButton) {
      DOMElements.saveCreationButton.onclick = async () => {
        const imageUrl = DOMElements.generatedImage?.src;
        if (!imageUrl || imageUrl.includes('placehold.co')) {
          showErrorModal('No hay imagen generada para guardar.');
          return;
        }
          showSaveCreationModal(async ({ title, description, privacy }) => {
          let file_path = imageUrl;
          if (file_path.startsWith(window.location.origin)) {
            file_path = file_path.replace(window.location.origin, '');
          }
          // Recibe privacy correctamente del callback
          const payload = {
            file_path,
            tool_used: 'ia-img',
            title,
            description,
              privacy
          };
          try {
            const response = await fetch('/api/save_creation.php', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(payload)
            });
            const data = await response.json();
            if (data.status === 'ok' || data.status === 'success' || data.success) {
              showSuccessModal('¡Imagen guardada exitosamente!');
            } else {
              showErrorModal('Error al guardar la imagen: ' + (data.message || 'Desconocido'));
            }
          } catch (e) {
            showErrorModal('Error de red al guardar la imagen.');
          }
        });
      };
    }
    // Generación
    if (DOMElements.generateButton) DOMElements.generateButton.onclick = generateImage;
    if (DOMElements.improvePromptButton) DOMElements.improvePromptButton.onclick = improvePrompt;
    if (DOMElements.generatePromptSuggestionButton) DOMElements.generatePromptSuggestionButton.onclick = generatePromptSuggestion;
    if (DOMElements.watchAdButton) DOMElements.watchAdButton.onclick = watchAdForGenerations;
    if (DOMElements.downloadMainImageButton) {
      DOMElements.downloadMainImageButton.onclick = () => {
        const imageUrl = DOMElements.generatedImage.src;
        if (imageUrl && !imageUrl.includes("placehold.co")) {
          downloadImage(imageUrl, "imagen-generada.png");
        }
      };
    }

    // Galería
    if (DOMElements.selectAllButton) DOMElements.selectAllButton.onclick = toggleSelectAllImages;
    if (DOMElements.downloadSelectedButton) DOMElements.downloadSelectedButton.onclick = downloadSelectedImages;
    if (DOMElements.clearSelectionButton) DOMElements.clearSelectionButton.onclick = clearSelection;
    if (DOMElements.deleteSelectedButton) DOMElements.deleteSelectedButton.onclick = deleteSelectedImagesFromGallery;

    // Lightbox
    if (DOMElements.lightboxCloseButton) DOMElements.lightboxCloseButton.onclick = closeLightbox;
    if (DOMElements.lightboxNextButton) DOMElements.lightboxNextButton.onclick = showNextImage;
    if (DOMElements.lightboxPrevButton) DOMElements.lightboxPrevButton.onclick = showPrevImage;
    if (DOMElements.lightbox) {
      DOMElements.lightbox.onclick = (e) => {
        if (e.target === DOMElements.lightbox) closeLightbox();
      };
    }

    // Editor
    if (DOMElements.editorCloseButton) DOMElements.editorCloseButton.onclick = closeImageEditor;
    if (DOMElements.cancelEditButton) DOMElements.cancelEditButton.onclick = closeImageEditor;
    if (DOMElements.saveEditedImageButton) DOMElements.saveEditedImageButton.onclick = saveEditedImage;
    if (DOMElements.addTextToCanvasButton) DOMElements.addTextToCanvasButton.onclick = addTextToCanvas;
    if (DOMElements.applyCropButton) DOMElements.applyCropButton.onclick = applyCrop;
  }

  // Asegurar que el botón de guardar siempre esté visible
  if (DOMElements.saveCreationButton) {
    DOMElements.saveCreationButton.style.display = '';
  }
  assignListeners();

  // Reasignar listeners cuando se muestre el editor o el lightbox (por si Bootstrap destruye/recrea el DOM)
  if (DOMElements.imageEditorModal) {
    DOMElements.imageEditorModal.addEventListener('shown.bs.modal', assignListeners);
  }
  if (DOMElements.lightbox) {
    DOMElements.lightbox.addEventListener('shown.bs.modal', assignListeners);
  }
}
