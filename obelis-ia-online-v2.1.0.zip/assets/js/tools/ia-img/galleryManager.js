// ia-img/js/galleryManager.js

import {
  downloadImage,
  showCustomMessage,
  updateLocalStorageUsage,
} from "/../assets/js/general/global.js";
import { CONFIG } from "./config.js";
import {
  selectedGalleryImages,
  setSelectedGalleryImages,
  currentLightboxIndex,
  setCurrentLightboxIndex,
  originalEditorImage,
  setEditingImageUrl,
  setEditorCtx,
  setEditorCurrentFilter,
  setEditorTextData,
} from "./state.js";
import { redrawEditorCanvas, renderFilterThumbnails } from "./editorManager.js";

// --- Funciones de Gestión de Almacenamiento ---
/**
 * Guarda un ítem en la galería localStorage.
 * @param {Object} item { tipo: 'imagen'|'paleta'|'texto', data: {...}, fecha: ISOString }
 */
export function saveItemToGallery(item) {
  let items = JSON.parse(localStorage.getItem("obelisiaGallery")) || [];
  // Evitar duplicados para imágenes
  if (item.tipo === 'imagen' && items.some(i => i.tipo === 'imagen' && i.data.url === item.data.url)) return;
  // Evitar duplicados para paletas
  if (item.tipo === 'paleta' && items.some(i => i.tipo === 'paleta' && JSON.stringify(i.data.colors) === JSON.stringify(item.data.colors))) return;
  // Evitar duplicados para textos
  if (item.tipo === 'texto' && items.some(i => i.tipo === 'texto' && i.data.text === item.data.text)) return;
  items.unshift(item);
  if (items.length > CONFIG.MAX_GALLERY_IMAGES) {
    items = items.slice(0, CONFIG.MAX_GALLERY_IMAGES);
  }
  try {
    localStorage.setItem("obelisiaGallery", JSON.stringify(items));
    updateLocalStorageUsage();
  } catch (e) {
    showCustomMessage("¡Almacenamiento lleno!", "error");
  }
}

export function loadGalleryItems() {
  return JSON.parse(localStorage.getItem("obelisiaGallery")) || [];
}

// --- Funciones de Renderizado y UI ---
export function renderGallery() {
  // Permitir usar un contenedor específico si se pasa como argumento
  let container = (window.DOMElements && window.DOMElements.galleryContainer) || document.getElementById('gallery-localstorage');
  if (!container) return;
  const items = loadGalleryItems();
  container.innerHTML = "";

  if (items.length === 0) {
    container.innerHTML =
      '<p class="text-gray-500 col-span-full text-center p-4">La galería está vacía.</p>';
    return;
  }

  items.forEach((item) => {
    const itemWrapper = document.createElement("div");
    itemWrapper.className = "gallery-item-wrapper col mb-4 position-relative card shadow-sm p-0 border-0";
    itemWrapper.style.maxWidth = "220px";
    itemWrapper.dataset.tipo = item.tipo;
    itemWrapper.dataset.fecha = item.fecha;

    if (item.tipo === 'imagen') {
      const imgElement = document.createElement("img");
      imgElement.src = item.data.url;
      imgElement.alt = "Imagen de la galería";
      imgElement.className = "card-img-top img-fluid rounded cursor-pointer";
      imgElement.style.height = "160px";
      imgElement.style.objectFit = "cover";
      imgElement.loading = "lazy";
      imgElement.addEventListener("click", (e) => {
        if (!e.target.closest("input, button")) openLightbox(item.data.url);
      });
      itemWrapper.appendChild(imgElement);
    } else if (item.tipo === 'paleta') {
      const paletteDiv = document.createElement("div");
      paletteDiv.className = "d-flex flex-wrap justify-content-center align-items-center p-3";
      paletteDiv.style.height = "160px";
      paletteDiv.style.background = "#f8fafc";
      item.data.colors.forEach(color => {
        const colorBox = document.createElement("div");
        colorBox.style.background = color;
        colorBox.style.width = "32px";
        colorBox.style.height = "32px";
        colorBox.style.margin = "0 4px";
        colorBox.style.borderRadius = "6px";
        colorBox.title = color;
        paletteDiv.appendChild(colorBox);
      });
      itemWrapper.appendChild(paletteDiv);
    } else if (item.tipo === 'texto') {
      const textDiv = document.createElement("div");
      textDiv.className = "p-3 text-center";
      textDiv.style.height = "160px";
      textDiv.style.overflow = "auto";
      textDiv.innerHTML = `<span class='fw-bold'>Texto generado:</span><br><span>${item.data.text}</span>`;
      itemWrapper.appendChild(textDiv);
    }
    // Footer con fecha
    const footer = document.createElement("div");
    footer.className = "card-footer bg-light text-muted small text-center";
    footer.textContent = new Date(item.fecha).toLocaleString();
    itemWrapper.appendChild(footer);
    container.appendChild(itemWrapper);
  });
}

export function renderRecentGenerations() {
  const dom = window.DOMElements || {};
  if (!dom.recentGenerationsGallery || !dom.downloadLastGeneratedButton) return;
  const images = loadGalleryItems().filter(item => item.tipo === 'imagen');
  dom.recentGenerationsGallery.innerHTML = "";
  if (images.length === 0) {
    dom.recentGenerationsGallery.innerHTML =
      '<p class="text-gray-500 text-xs text-center col-span-2">No hay historial.</p>';
    dom.downloadLastGeneratedButton.disabled = true;
    dom.downloadLastGeneratedButton.classList.add(
      "opacity-50",
      "cursor-not-allowed"
    );
    return;
  }
  images.slice(0, 4).forEach((item) => {
    const imgElement = document.createElement("img");
    imgElement.src = item.data.url;
    imgElement.className = "img-thumbnail m-1 cursor-pointer border border-secondary";
    imgElement.style.height = "60px";
    imgElement.style.width = "60px";
    imgElement.style.objectFit = "cover";
    imgElement.addEventListener("click", () => openLightbox(item.data.url));
    dom.recentGenerationsGallery.appendChild(imgElement);
  });
  dom.downloadLastGeneratedButton.disabled = false;
  dom.downloadLastGeneratedButton.classList.remove(
    "opacity-50",
    "cursor-not-allowed"
  );
}

export function updateDownloadSelectedButtonState() {
  if (!DOMElements.downloadSelectedButton) return;
  const isDisabled = selectedGalleryImages.size === 0;
  const buttons = [
    DOMElements.downloadSelectedButton,
    DOMElements.clearSelectionButton,
    DOMElements.deleteSelectedButton,
  ];
  buttons.forEach((button) => {
    if (button) {
      button.disabled = isDisabled;
      button.classList.toggle("opacity-50", isDisabled);
      button.classList.toggle("cursor-not-allowed", isDisabled);
    }
  });
}

// --- Lógica de Acciones de Galería ---
export function toggleImageSelection(imageUrl, itemWrapper) {
  const checkbox = itemWrapper.querySelector('input[type="checkbox"]');
  if (selectedGalleryImages.has(imageUrl)) {
    selectedGalleryImages.delete(imageUrl);
    itemWrapper.classList.remove("selected");
    if (checkbox) checkbox.checked = false;
  } else {
    selectedGalleryImages.add(imageUrl);
    itemWrapper.classList.add("selected");
    if (checkbox) checkbox.checked = true;
  }
  updateDownloadSelectedButtonState();
}

export function clearSelection() {
  selectedGalleryImages.clear();
  if (DOMElements.galleryContainer) {
    DOMElements.galleryContainer
      .querySelectorAll(".gallery-item-wrapper.selected")
      .forEach((item) => {
        item.classList.remove("selected");
        const checkbox = item.querySelector('input[type="checkbox"]');
        if (checkbox) checkbox.checked = false;
      });
  }
  updateDownloadSelectedButtonState();
}

export function toggleSelectAllImages() {
  if (!DOMElements.galleryContainer) return;
  const allItems = loadGalleryItems().filter(item => item.tipo === 'imagen');
  const allAreSelected = selectedGalleryImages.size === allItems.length;

  allItems.forEach((item) => {
    const url = item.data.url;
    if (allAreSelected) {
      selectedGalleryImages.delete(url);
    } else {
      selectedGalleryImages.add(url);
    }
  });

  DOMElements.galleryContainer
    .querySelectorAll(".gallery-item-wrapper[data-tipo='imagen']")
    .forEach((itemWrapper) => {
      itemWrapper.classList.toggle("selected", !allAreSelected);
      const checkbox = itemWrapper.querySelector('input[type="checkbox"]');
      if (checkbox) checkbox.checked = !allAreSelected;
    });

  updateDownloadSelectedButtonState();
}

export async function downloadSelectedImages() {
  if (selectedGalleryImages.size === 0) return;
  showCustomMessage(
    `Descargando ${selectedGalleryImages.size} imágenes...`,
    "info"
  );
  for (const imageUrl of selectedGalleryImages) {
    await downloadImage(imageUrl, `obelisia_img_${Date.now()}.png`);
    await new Promise((res) => setTimeout(res, 200));
  }
  showCustomMessage("Descarga completada.", "success");
  clearSelection();
}

export function deleteImageFromGallery(imageUrl) {
  let items = loadGalleryItems();
  items = items.filter((item) => !(item.tipo === 'imagen' && item.data.url === imageUrl));
  localStorage.setItem("obelisiaGallery", JSON.stringify(items));
  renderGallery();
  renderRecentGenerations();
  showCustomMessage("Imagen eliminada.", "success");
}

export function deleteSelectedImagesFromGallery() {
  if (selectedGalleryImages.size === 0) return;
  let items = loadGalleryItems();
  const originalSize = items.length;
  items = items.filter((item) => {
    if (item.tipo !== 'imagen') return true;
    return !selectedGalleryImages.has(item.data.url);
  });
  localStorage.setItem("obelisiaGallery", JSON.stringify(items));
  showCustomMessage(
    `${originalSize - items.length} imágenes eliminadas.`,
    "success"
  );
  clearSelection();
  renderGallery();
  renderRecentGenerations();
}

// --- Lógica del Lightbox y Editor ---
export function openLightbox(imageUrl) {
  if (!DOMElements.lightbox) return;
  const galleryImages = loadGalleryItems().filter(item => item.tipo === 'imagen').map(item => item.data.url);
  setCurrentLightboxIndex(galleryImages.findIndex((img) => img === imageUrl));
  updateLightboxContent();
  DOMElements.lightbox.classList.add("show");
}

export function closeLightbox() {
  if (DOMElements.lightbox) DOMElements.lightbox.classList.remove("show");
}

export function updateLightboxContent() {
  if (!DOMElements.lightboxImage || !DOMElements.lightboxThumbnails) return;
  const galleryImages = loadGalleryItems().filter(item => item.tipo === 'imagen').map(item => item.data.url);
  if (galleryImages.length === 0 || currentLightboxIndex === -1) {
    closeLightbox();
    return;
  }
  if (currentLightboxIndex >= galleryImages.length) setCurrentLightboxIndex(0);
  if (currentLightboxIndex < 0)
    setCurrentLightboxIndex(galleryImages.length - 1);

  DOMElements.lightboxImage.src = galleryImages[currentLightboxIndex];

  DOMElements.lightboxThumbnails.innerHTML = "";
  galleryImages.forEach((url, index) => {
    const thumb = document.createElement("img");
    thumb.src = url;
    thumb.className = "lightbox-thumbnail-item";
    if (index === currentLightboxIndex) thumb.classList.add("active");
    thumb.addEventListener("click", () => {
      setCurrentLightboxIndex(index);
      updateLightboxContent();
    });
    DOMElements.lightboxThumbnails.appendChild(thumb);
  });
  const activeThumb = DOMElements.lightboxThumbnails.querySelector(".active");
  if (activeThumb)
    activeThumb.scrollIntoView({
      behavior: "smooth",
      block: "nearest",
      inline: "center",
    });
}

export function showNextImage() {
  setCurrentLightboxIndex(currentLightboxIndex + 1);
  updateLightboxContent();
}

export function showPrevImage() {
  setCurrentLightboxIndex(currentLightboxIndex - 1);
  updateLightboxContent();
}

export function openImageEditor(imageUrl) {
  if (!DOMElements.imageEditorModal || !DOMElements.editorCanvas) return;
  setEditingImageUrl(imageUrl);
  originalEditorImage.src = imageUrl;
  originalEditorImage.crossOrigin = "Anonymous";
  originalEditorImage.onload = () => {
    const editorCtx = DOMElements.editorCanvas.getContext("2d");
    if (!editorCtx) return;
    setEditorCtx(editorCtx);

    const maxCanvasHeight = window.innerHeight * 0.6;
    const maxCanvasWidth =
      DOMElements.editorCanvas.parentElement.clientWidth * 0.9;
    const aspectRatio =
      originalEditorImage.naturalWidth / originalEditorImage.naturalHeight;

    let newWidth = Math.min(originalEditorImage.naturalWidth, maxCanvasWidth);
    let newHeight = newWidth / aspectRatio;

    if (newHeight > maxCanvasHeight) {
      newHeight = maxCanvasHeight;
      newWidth = newHeight * aspectRatio;
    }

    DOMElements.editorCanvas.width = newWidth;
    DOMElements.editorCanvas.height = newHeight;

    redrawEditorCanvas();
    DOMElements.imageEditorModal.classList.add("show");
    renderFilterThumbnails();
  };
  setEditorCurrentFilter("none");
  setEditorTextData({
    content: "",
    color: "#FFFFFF",
    size: 30,
    position: "bottomRight",
  });
}
