/**
 * Creador de Creaciones - Editor tipo Word/Blog
 * Permite crear contenido rico con texto, imágenes, videos y más
 */

class ContentCreator {
    constructor() {
        this.quill = null;
        this.currentCreationId = null;
        this.isPublished = false;
        this.autoSaveInterval = null;
        this.userResources = [];
        
        this.init();
    }

    init() {
        this.initQuillEditor();
        this.setupEventListeners();
        this.loadUserResources();
        this.setupAutoSave();
        this.updateStats();
        
        // Cargar creación si hay ID en la URL
        const urlParams = new URLSearchParams(window.location.search);
        const creationId = urlParams.get('id');
        if (creationId) {
            this.loadCreation(creationId);
        }
    }

    initQuillEditor() {
        // Configuración de la toolbar de Quill
        const toolbarOptions = [
            [{ 'header': [1, 2, 3, false] }],
            ['bold', 'italic', 'underline', 'strike'],
            [{ 'color': [] }, { 'background': [] }],
            [{ 'font': [] }],
            [{ 'align': [] }],
            [{ 'list': 'ordered'}, { 'list': 'bullet' }],
            [{ 'indent': '-1'}, { 'indent': '+1' }],
            ['blockquote', 'code-block'],
            ['link', 'image', 'video'],
            ['clean']
        ];

        this.quill = new Quill('#editor-content', {
            modules: {
                toolbar: toolbarOptions,
                history: {
                    delay: 1000,
                    maxStack: 100,
                    userOnly: false
                }
            },
            placeholder: 'Comienza a escribir tu creación aquí...',
            theme: 'snow'
        });

        // Eventos del editor
        this.quill.on('text-change', () => {
            this.updateStats();
            this.markAsModified();
        });

        // Personalizar la inserción de imágenes
        this.quill.getModule('toolbar').addHandler('image', () => {
            this.showImageModal();
        });
    }

    setupEventListeners() {
        // Botones principales
        document.getElementById('saveBtn').addEventListener('click', () => this.saveCreation());
        document.getElementById('publishBtn').addEventListener('click', () => this.publishCreation());
        document.getElementById('previewBtn').addEventListener('click', () => this.showPreview());

        // Herramientas del sidebar
        document.getElementById('addHeadingBtn').addEventListener('click', () => this.insertHeading());
        document.getElementById('addImageBtn').addEventListener('click', () => this.showImageModal());
        document.getElementById('addVideoBtn').addEventListener('click', () => this.insertVideo());
        document.getElementById('addQuoteBtn').addEventListener('click', () => this.insertQuote());
        document.getElementById('addDividerBtn').addEventListener('click', () => this.insertDivider());
        document.getElementById('addGalleryBtn').addEventListener('click', () => this.insertGallery());

        // Selectores de estilo
        document.getElementById('themeSelector').addEventListener('change', (e) => this.changeTheme(e.target.value));
        document.getElementById('fontSelector').addEventListener('change', (e) => this.changeFont(e.target.value));

        // Upload de imágenes
        document.getElementById('imageUpload').addEventListener('change', (e) => this.handleImageUpload(e));
        this.setupDragAndDrop();

        // Modal eventos
        document.getElementById('publishFromPreview').addEventListener('click', () => this.publishCreation());

        // Atajos de teclado
        document.addEventListener('keydown', (e) => this.handleKeyboardShortcuts(e));
    }

    insertHeading() {
        const range = this.quill.getSelection();
        if (range) {
            this.quill.insertText(range.index, '\n\n', 'user');
            this.quill.formatText(range.index + 2, 0, 'header', 2);
            this.quill.insertText(range.index + 2, 'Nuevo título', 'user');
            this.quill.setSelection(range.index + 2, 12);
        }
    }

    insertQuote() {
        const range = this.quill.getSelection();
        if (range) {
            this.quill.insertText(range.index, '\n\n', 'user');
            this.quill.formatText(range.index + 2, 0, 'blockquote', true);
            this.quill.insertText(range.index + 2, 'Tu cita inspiradora aquí...', 'user');
            this.quill.setSelection(range.index + 2, 28);
        }
    }

    insertDivider() {
        const range = this.quill.getSelection();
        if (range) {
            this.quill.insertText(range.index, '\n\n───────────────────────────────\n\n', 'user');
            this.quill.setSelection(range.index + 35, 0);
        }
    }

    insertVideo() {
        const url = prompt('Ingresa la URL del video (YouTube, Vimeo, etc.):');
        if (url) {
            const range = this.quill.getSelection();
            if (range) {
                this.quill.insertEmbed(range.index, 'video', url);
            }
        }
    }

    insertGallery() {
        // Mostrar modal para seleccionar múltiples imágenes
        this.showImageModal(true); // true para modo galería
    }

    showImageModal(galleryMode = false) {
        const modal = new bootstrap.Modal(document.getElementById('imageModal'));
        modal.show();
        
        // Cargar imágenes del usuario
        this.loadUserImages();
    }

    async loadUserImages() {
        try {
            const response = await fetch('/api/get_user_images.php');
            const result = await response.json();
            
            const container = document.getElementById('userImages');
            container.innerHTML = '';
            
            if (result.success && result.images.length > 0) {
                result.images.forEach(image => {
                    const imageEl = document.createElement('div');
                    imageEl.className = 'user-image-item';
                    imageEl.innerHTML = `<img src="${image.url}" alt="${image.title}" loading="lazy">`;
                    imageEl.addEventListener('click', () => this.insertImageFromGallery(image.url));
                    container.appendChild(imageEl);
                });
            } else {
                container.innerHTML = '<p class="text-muted small">No tienes imágenes guardadas</p>';
            }
        } catch (error) {
            console.error('Error loading user images:', error);
        }
    }

    insertImageFromGallery(imageUrl) {
        const range = this.quill.getSelection();
        if (range) {
            this.quill.insertEmbed(range.index, 'image', imageUrl);
        }
        
        // Cerrar modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('imageModal'));
        modal.hide();
    }

    handleImageUpload(event) {
        const file = event.target.files[0];
        if (file && file.type.startsWith('image/')) {
            this.uploadImage(file);
        }
    }

    async uploadImage(file) {
        const formData = new FormData();
        formData.append('image', file);
        
        try {
            const response = await fetch('/api/upload_image.php', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.insertImageFromGallery(result.url);
                this.showNotification('Imagen subida exitosamente', 'success');
            } else {
                this.showNotification('Error al subir imagen: ' + result.message, 'error');
            }
        } catch (error) {
            this.showNotification('Error al subir imagen', 'error');
        }
    }

    setupDragAndDrop() {
        const uploadArea = document.getElementById('uploadArea');
        
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('dragover');
        });
        
        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('dragover');
        });
        
        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
            
            const files = e.dataTransfer.files;
            if (files.length > 0 && files[0].type.startsWith('image/')) {
                this.uploadImage(files[0]);
            }
        });
        
        uploadArea.addEventListener('click', () => {
            document.getElementById('imageUpload').click();
        });
    }

    changeTheme(theme) {
        const editorContent = document.querySelector('.editor-content');
        editorContent.className = editorContent.className.replace(/theme-\w+/g, '');
        if (theme !== 'default') {
            editorContent.classList.add(`theme-${theme}`);
        }
    }

    changeFont(font) {
        const editorContent = document.querySelector('.ql-editor');
        editorContent.style.fontFamily = font === 'default' ? '' : font;
    }

    updateStats() {
        const text = this.quill.getText();
        const words = text.trim() ? text.trim().split(/\s+/).length : 0;
        const chars = text.length;
        const readTime = Math.max(1, Math.ceil(words / 200)); // 200 palabras por minuto
        
        document.getElementById('wordCount').textContent = words;
        document.getElementById('charCount').textContent = chars;
        document.getElementById('readTime').textContent = readTime + ' min';
    }

    markAsModified() {
        const saveBtn = document.getElementById('saveBtn');
        if (!saveBtn.classList.contains('btn-warning')) {
            saveBtn.classList.remove('btn-success');
            saveBtn.classList.add('btn-warning');
            saveBtn.innerHTML = '<i class="fas fa-save me-1"></i>Guardar*';
        }
    }

    async saveCreation() {
        const title = document.getElementById('creationTitle').value.trim();
        if (!title) {
            this.showNotification('Por favor ingresa un título', 'warning');
            return;
        }

        const saveBtn = document.getElementById('saveBtn');
        const originalHtml = saveBtn.innerHTML;
        saveBtn.disabled = true;
        saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Guardando...';

        try {
            const content = this.quill.getContents();
            const htmlContent = this.quill.root.innerHTML;
            const visibility = document.querySelector('input[name="visibility"]:checked').value;
            
            const saveData = {
                id: this.currentCreationId,
                title: title,
                description: document.getElementById('creationDescription').value.trim(),
                tags: document.getElementById('creationTags').value.trim(),
                content: JSON.stringify(content),
                html_content: htmlContent,
                plain_text: this.quill.getText(),
                visibility: visibility,
                settings: {
                    theme: document.getElementById('themeSelector').value,
                    font: document.getElementById('fontSelector').value,
                    allow_comments: document.getElementById('enableComments').checked,
                    allow_sharing: document.getElementById('enableSharing').checked,
                    show_author: document.getElementById('showAuthor').checked
                }
            };

            const response = await fetch('/api/save_content_creation.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(saveData)
            });

            const result = await response.json();

            if (result.success) {
                this.currentCreationId = result.id;
                this.showNotification('Creación guardada exitosamente', 'success');
                
                saveBtn.classList.remove('btn-warning');
                saveBtn.classList.add('btn-success');
                saveBtn.innerHTML = '<i class="fas fa-check me-1"></i>Guardado';
                
                // Actualizar URL sin recargar
                const newUrl = window.location.pathname + '?id=' + result.id;
                window.history.replaceState({}, '', newUrl);
            } else {
                this.showNotification('Error al guardar: ' + result.message, 'error');
            }
        } catch (error) {
            this.showNotification('Error al guardar la creación', 'error');
        } finally {
            saveBtn.disabled = false;
            if (saveBtn.innerHTML.includes('Guardando')) {
                saveBtn.innerHTML = originalHtml;
            }
        }
    }

    async publishCreation() {
        if (!this.currentCreationId) {
            await this.saveCreation();
            if (!this.currentCreationId) return;
        }

        if (confirm('¿Estás seguro de que quieres publicar esta creación? Será visible públicamente.')) {
            try {
                const response = await fetch('/api/publish_content_creation.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: this.currentCreationId })
                });

                const result = await response.json();

                if (result.success) {
                    this.isPublished = true;
                    this.showNotification('Creación publicada exitosamente', 'success');
                    
                    // Mostrar enlace público
                    setTimeout(() => {
                        if (confirm('¿Quieres ver tu creación publicada?')) {
                            window.open(result.public_url, '_blank');
                        }
                    }, 1000);
                } else {
                    this.showNotification('Error al publicar: ' + result.message, 'error');
                }
            } catch (error) {
                this.showNotification('Error al publicar la creación', 'error');
            }
        }
    }

    showPreview() {
        const title = document.getElementById('creationTitle').value.trim() || 'Sin título';
        const description = document.getElementById('creationDescription').value.trim();
        const content = this.quill.root.innerHTML;
        const theme = document.getElementById('themeSelector').value;
        
        const previewContent = document.getElementById('previewContent');
        previewContent.className = `preview-content ${theme !== 'default' ? 'theme-' + theme : ''}`;
        
        previewContent.innerHTML = `
            <div class="preview-header mb-4">
                <h1 class="display-4 mb-3">${title}</h1>
                ${description ? `<p class="lead text-muted">${description}</p>` : ''}
                <hr>
            </div>
            <div class="preview-body">
                ${content}
            </div>
        `;
        
        const modal = new bootstrap.Modal(document.getElementById('previewModal'));
        modal.show();
    }

    async loadCreation(creationId) {
        try {
            const response = await fetch(`/api/get_content_creation.php?id=${creationId}`);
            const result = await response.json();
            
            if (result.success) {
                const creation = result.creation;
                
                // Cargar datos básicos
                document.getElementById('creationTitle').value = creation.title || '';
                document.getElementById('creationDescription').value = creation.description || '';
                document.getElementById('creationTags').value = creation.tags || '';
                
                // Cargar contenido
                if (creation.content) {
                    this.quill.setContents(JSON.parse(creation.content));
                }
                
                // Cargar configuraciones
                if (creation.settings) {
                    const settings = JSON.parse(creation.settings);
                    document.getElementById('themeSelector').value = settings.theme || 'default';
                    document.getElementById('fontSelector').value = settings.font || 'default';
                    document.getElementById('enableComments').checked = settings.allow_comments !== false;
                    document.getElementById('enableSharing').checked = settings.allow_sharing !== false;
                    document.getElementById('showAuthor').checked = settings.show_author !== false;
                }
                
                // Configurar visibilidad
                const visibilityRadio = document.querySelector(`input[name="visibility"][value="${creation.visibility}"]`);
                if (visibilityRadio) {
                    visibilityRadio.checked = true;
                }
                
                this.currentCreationId = creationId;
                this.isPublished = creation.is_published;
                
                this.updateStats();
            } else {
                this.showNotification('Error al cargar la creación', 'error');
            }
        } catch (error) {
            this.showNotification('Error al cargar la creación', 'error');
        }
    }

    async loadUserResources() {
        try {
            const response = await fetch('/api/get_user_resources.php');
            const result = await response.json();
            
            if (result.success) {
                this.userResources = result.resources;
                this.renderUserResources();
            }
        } catch (error) {
            console.error('Error loading user resources:', error);
        }
    }

    renderUserResources() {
        const container = document.getElementById('userResources');
        container.innerHTML = '';
        
        if (this.userResources.length === 0) {
            container.innerHTML = '<div class="text-muted small">No tienes recursos guardados</div>';
            return;
        }
        
        this.userResources.slice(0, 10).forEach(resource => {
            const item = document.createElement('div');
            item.className = 'resource-item';
            item.innerHTML = `
                <i class="fas fa-${this.getResourceIcon(resource.type)} me-2"></i>
                <span class="small">${resource.title}</span>
            `;
            item.addEventListener('click', () => this.insertResource(resource));
            container.appendChild(item);
        });
    }

    getResourceIcon(type) {
        const icons = {
            'image': 'image',
            'text': 'file-text',
            'audio': 'music',
            'video': 'video',
            'palette': 'palette'
        };
        return icons[type] || 'file';
    }

    insertResource(resource) {
        const range = this.quill.getSelection();
        if (!range) return;
        
        switch (resource.type) {
            case 'image':
                this.quill.insertEmbed(range.index, 'image', resource.url);
                break;
            case 'text':
                this.quill.insertText(range.index, resource.content);
                break;
            // Agregar más tipos según necesidad
        }
    }

    setupAutoSave() {
        this.autoSaveInterval = setInterval(() => {
            if (this.currentCreationId && document.getElementById('saveBtn').classList.contains('btn-warning')) {
                this.saveCreation();
            }
        }, 60000); // Auto-guardar cada minuto
    }

    handleKeyboardShortcuts(event) {
        if (event.ctrlKey || event.metaKey) {
            switch (event.key) {
                case 's':
                    event.preventDefault();
                    this.saveCreation();
                    break;
                case 'p':
                    event.preventDefault();
                    this.showPreview();
                    break;
            }
        }
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show position-fixed`;
        notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; max-width: 400px;';
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }

    destroy() {
        if (this.autoSaveInterval) {
            clearInterval(this.autoSaveInterval);
        }
    }
}

// Inicializar el editor cuando se carga la página
let contentCreator;

document.addEventListener('DOMContentLoaded', () => {
    contentCreator = new ContentCreator();
    
    // Exponer globalmente para debugging
    window.contentCreator = contentCreator;
    
    console.log('Content Creator initialized successfully');
});

// Limpiar al cerrar la página
window.addEventListener('beforeunload', () => {
    if (contentCreator) {
        contentCreator.destroy();
    }
});
