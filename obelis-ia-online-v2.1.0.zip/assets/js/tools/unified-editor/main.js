// Editor Unificado de Creaciones - JavaScript principal
// Permite combinar y editar múltiples tipos de contenido en un solo canvas

class UnifiedCreationEditor {
    constructor() {
        this.canvas = null;
        this.ctx = null;
        this.layers = [];
        this.activeLayerIndex = 0;
        this.zoom = 1;
        this.panX = 0;
        this.panY = 0;
        this.isDragging = false;
        this.dragStart = { x: 0, y: 0 };
        this.selectedTool = 'select';
        this.resources = [];
        this.history = [];
        this.historyIndex = -1;
        this.maxHistorySize = 50;
        
        this.init();
    }

    init() {
        this.setupCanvas();
        this.loadResources();
        this.setupEventListeners();
        this.addDefaultLayer();
        this.saveState();
    }

    setupCanvas() {
        this.canvas = document.getElementById('unifiedCanvas');
        this.ctx = this.canvas.getContext('2d');
        
        // Configurar canvas con alta resolución
        const dpr = window.devicePixelRatio || 1;
        const rect = this.canvas.getBoundingClientRect();
        
        this.canvas.width = rect.width * dpr;
        this.canvas.height = rect.height * dpr;
        this.ctx.scale(dpr, dpr);
        
        this.canvas.style.width = rect.width + 'px';
        this.canvas.style.height = rect.height + 'px';
        
        this.redraw();
    }

    loadResources() {
        // Cargar recursos de la galería unificada
        const galleryItems = JSON.parse(localStorage.getItem('obelisiaGallery') || '[]');
        
        this.resources = galleryItems.map(item => ({
            id: this.generateId(),
            type: item.tipo,
            data: item.data,
            fecha: item.fecha,
            thumbnail: this.generateThumbnail(item)
        }));

        this.renderResourcesList();
    }

    generateThumbnail(item) {
        switch(item.tipo) {
            case 'imagen':
                return item.data.url;
            case 'paleta':
                return this.generatePaletteThumbnail(item.data.colors);
            case 'texto':
                return this.generateTextThumbnail(item.data.text);
            default:
                return '';
        }
    }

    generatePaletteThumbnail(colors) {
        const canvas = document.createElement('canvas');
        canvas.width = 120;
        canvas.height = 30;
        const ctx = canvas.getContext('2d');
        
        const colorWidth = canvas.width / colors.length;
        colors.forEach((color, index) => {
            ctx.fillStyle = color;
            ctx.fillRect(index * colorWidth, 0, colorWidth, canvas.height);
        });
        
        return canvas.toDataURL();
    }

    generateTextThumbnail(text) {
        const canvas = document.createElement('canvas');
        canvas.width = 200;
        canvas.height = 50;
        const ctx = canvas.getContext('2d');
        
        ctx.fillStyle = '#f1f5f9';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        ctx.fillStyle = '#1e293b';
        ctx.font = '16px Inter, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        
        const truncatedText = text.length > 20 ? text.substring(0, 20) + '...' : text;
        ctx.fillText(truncatedText, canvas.width / 2, canvas.height / 2);
        
        return canvas.toDataURL();
    }

    renderResourcesList() {
        const container = document.getElementById('resourcesList');
        const filter = document.getElementById('resourceFilter').value;
        
        const filteredResources = filter === 'all' 
            ? this.resources 
            : this.resources.filter(r => r.type === filter);

        container.innerHTML = '';

        if (filteredResources.length === 0) {
            container.innerHTML = `
                <div class="text-center text-muted p-4">
                    <i class="fas fa-folder-open fa-2x mb-3"></i>
                    <p>No hay recursos ${filter !== 'all' ? 'de este tipo' : 'disponibles'}</p>
                    <small>Crea contenido con las herramientas de ObelisIA para usarlo aquí</small>
                </div>
            `;
            return;
        }

        filteredResources.forEach(resource => {
            const resourceElement = this.createResourceElement(resource);
            container.appendChild(resourceElement);
        });
    }

    createResourceElement(resource) {
        const div = document.createElement('div');
        div.className = 'resource-item';
        div.dataset.resourceId = resource.id;
        div.dataset.resourceType = resource.type;
        
        let content = '';
        
        switch(resource.type) {
            case 'imagen':
                content = `
                    <div class="d-flex align-items-center">
                        <img src="${resource.data.url}" alt="Imagen" class="image-preview me-3">
                        <div class="flex-grow-1">
                            <div class="fw-semibold">Imagen</div>
                            <small class="text-muted">${new Date(resource.fecha).toLocaleDateString()}</small>
                        </div>
                        <i class="fas fa-image text-primary"></i>
                    </div>
                `;
                break;
                
            case 'paleta':
                content = `
                    <div>
                        <div class="d-flex align-items-center justify-content-between mb-2">
                            <div class="fw-semibold">Paleta de Colores</div>
                            <i class="fas fa-palette text-warning"></i>
                        </div>
                        <div class="color-palette-preview">
                            ${resource.data.colors.map(color => 
                                `<div class="color-swatch" style="background-color: ${color}" title="${color}"></div>`
                            ).join('')}
                        </div>
                        <small class="text-muted d-block mt-2">${resource.data.colors.length} colores</small>
                    </div>
                `;
                break;
                
            case 'texto':
                content = `
                    <div>
                        <div class="d-flex align-items-center justify-content-between mb-2">
                            <div class="fw-semibold">Texto Generado</div>
                            <i class="fas fa-font text-info"></i>
                        </div>
                        <div class="text-preview">${resource.data.text || 'Texto sin contenido'}</div>
                        <small class="text-muted">${new Date(resource.fecha).toLocaleDateString()}</small>
                    </div>
                `;
                break;
        }
        
        div.innerHTML = content;
        
        // Hacer que el elemento sea arrastrable
        div.draggable = true;
        div.addEventListener('dragstart', (e) => this.handleDragStart(e, resource));
        div.addEventListener('click', () => this.selectResource(resource));
        
        return div;
    }

    handleDragStart(e, resource) {
        e.dataTransfer.setData('application/json', JSON.stringify(resource));
        e.dataTransfer.effectAllowed = 'copy';
        
        // Añadir clase visual durante el arrastre
        e.target.classList.add('dragging');
        setTimeout(() => e.target.classList.remove('dragging'), 0);
    }

    selectResource(resource) {
        // Remover selección anterior
        document.querySelectorAll('.resource-item').forEach(item => {
            item.classList.remove('selected');
        });
        
        // Seleccionar nuevo recurso
        const element = document.querySelector(`[data-resource-id="${resource.id}"]`);
        if (element) {
            element.classList.add('selected');
        }
    }

    addDefaultLayer() {
        const layer = {
            id: this.generateId(),
            name: 'Fondo',
            type: 'background',
            visible: true,
            opacity: 1,
            x: 0,
            y: 0,
            width: this.canvas.width,
            height: this.canvas.height,
            data: { color: '#ffffff' }
        };
        
        this.layers.push(layer);
        this.renderLayersList();
    }

    addLayer(type = 'empty', data = {}) {
        const layer = {
            id: this.generateId(),
            name: `Capa ${this.layers.length}`,
            type: type,
            visible: true,
            opacity: 1,
            x: 0,
            y: 0,
            width: 200,
            height: 200,
            data: data
        };
        
        this.layers.push(layer);
        this.activeLayerIndex = this.layers.length - 1;
        this.renderLayersList();
        this.redraw();
        this.saveState();
    }

    addResourceToCanvas(resource, x = null, y = null) {
        const centerX = x !== null ? x : this.canvas.width / 2;
        const centerY = y !== null ? y : this.canvas.height / 2;
        
        let layerData = {};
        
        switch(resource.type) {
            case 'imagen':
                layerData = {
                    type: 'image',
                    src: resource.data.url,
                    x: centerX - 100,
                    y: centerY - 100,
                    width: 200,
                    height: 200
                };
                break;
                
            case 'paleta':
                layerData = {
                    type: 'palette',
                    colors: resource.data.colors,
                    x: centerX - 150,
                    y: centerY - 25,
                    width: 300,
                    height: 50
                };
                break;
                
            case 'texto':
                layerData = {
                    type: 'text',
                    content: resource.data.text,
                    x: centerX - 100,
                    y: centerY - 25,
                    width: 200,
                    height: 50,
                    fontSize: 24,
                    fontFamily: 'Arial',
                    color: '#000000',
                    align: 'left'
                };
                break;
        }
        
        this.addLayer(layerData.type, layerData);
    }

    renderLayersList() {
        const container = document.getElementById('layersList');
        container.innerHTML = '';
        
        this.layers.forEach((layer, index) => {
            const layerElement = this.createLayerElement(layer, index);
            container.appendChild(layerElement);
        });
    }

    createLayerElement(layer, index) {
        const div = document.createElement('div');
        div.className = `layer-item ${index === this.activeLayerIndex ? 'active' : ''}`;
        div.dataset.layerIndex = index;
        
        const thumbnail = this.generateLayerThumbnail(layer);
        
        div.innerHTML = `
            <div class="d-flex align-items-center">
                <div class="layer-preview" style="background-image: url('${thumbnail}'); background-size: cover; background-position: center;"></div>
                <div class="flex-grow-1 ms-2">
                    <div class="fw-semibold">${layer.name}</div>
                    <small class="text-muted">${this.getLayerTypeLabel(layer.type)}</small>
                </div>
                <div class="d-flex flex-column gap-1">
                    <button class="btn btn-sm btn-outline-secondary" onclick="editor.toggleLayerVisibility(${index})" title="Mostrar/Ocultar">
                        <i class="fas fa-eye${layer.visible ? '' : '-slash'}"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger" onclick="editor.deleteLayer(${index})" title="Eliminar">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `;
        
        div.addEventListener('click', () => this.selectLayer(index));
        
        return div;
    }

    generateLayerThumbnail(layer) {
        const canvas = document.createElement('canvas');
        canvas.width = 40;
        canvas.height = 40;
        const ctx = canvas.getContext('2d');
        
        switch(layer.type) {
            case 'background':
                ctx.fillStyle = layer.data.color || '#ffffff';
                ctx.fillRect(0, 0, 40, 40);
                break;
                
            case 'image':
                // En una implementación real, cargarías la imagen
                ctx.fillStyle = '#e2e8f0';
                ctx.fillRect(0, 0, 40, 40);
                ctx.fillStyle = '#64748b';
                ctx.font = '20px Arial';
                ctx.textAlign = 'center';
                ctx.fillText('🖼️', 20, 25);
                break;
                
            case 'text':
                ctx.fillStyle = '#f1f5f9';
                ctx.fillRect(0, 0, 40, 40);
                ctx.fillStyle = '#1e293b';
                ctx.font = '8px Arial';
                ctx.textAlign = 'center';
                ctx.fillText('Aa', 20, 22);
                break;
                
            case 'palette':
                const colors = layer.data.colors || ['#000'];
                const colorWidth = 40 / colors.length;
                colors.forEach((color, i) => {
                    ctx.fillStyle = color;
                    ctx.fillRect(i * colorWidth, 0, colorWidth, 40);
                });
                break;
                
            default:
                ctx.fillStyle = '#cbd5e1';
                ctx.fillRect(0, 0, 40, 40);
        }
        
        return canvas.toDataURL();
    }

    getLayerTypeLabel(type) {
        const labels = {
            'background': 'Fondo',
            'image': 'Imagen',
            'text': 'Texto',
            'palette': 'Paleta',
            'shape': 'Forma',
            'drawing': 'Dibujo'
        };
        return labels[type] || 'Desconocido';
    }

    selectLayer(index) {
        this.activeLayerIndex = index;
        this.renderLayersList();
    }

    toggleLayerVisibility(index) {
        if (this.layers[index]) {
            this.layers[index].visible = !this.layers[index].visible;
            this.renderLayersList();
            this.redraw();
            this.saveState();
        }
    }

    deleteLayer(index) {
        if (this.layers.length > 1 && this.layers[index]) {
            this.layers.splice(index, 1);
            if (this.activeLayerIndex >= this.layers.length) {
                this.activeLayerIndex = this.layers.length - 1;
            }
            this.renderLayersList();
            this.redraw();
            this.saveState();
        }
    }

    redraw() {
        // Limpiar canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Aplicar transformaciones de zoom y pan
        this.ctx.save();
        this.ctx.scale(this.zoom, this.zoom);
        this.ctx.translate(this.panX, this.panY);
        
        // Dibujar cada capa
        this.layers.forEach(layer => {
            if (layer.visible) {
                this.drawLayer(layer);
            }
        });
        
        this.ctx.restore();
    }

    drawLayer(layer) {
        this.ctx.save();
        this.ctx.globalAlpha = layer.opacity;
        
        switch(layer.type) {
            case 'background':
                this.ctx.fillStyle = layer.data.color || '#ffffff';
                this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
                break;
                
            case 'image':
                this.drawImageLayer(layer);
                break;
                
            case 'text':
                this.drawTextLayer(layer);
                break;
                
            case 'palette':
                this.drawPaletteLayer(layer);
                break;
                
            case 'shape':
                this.drawShapeLayer(layer);
                break;
        }
        
        this.ctx.restore();
    }

    drawImageLayer(layer) {
        const img = new Image();
        img.onload = () => {
            this.ctx.drawImage(img, layer.x, layer.y, layer.width, layer.height);
        };
        img.src = layer.data.src;
    }

    drawTextLayer(layer) {
        this.ctx.fillStyle = layer.data.color || '#000000';
        this.ctx.font = `${layer.data.fontSize || 24}px ${layer.data.fontFamily || 'Arial'}`;
        this.ctx.textAlign = layer.data.align || 'left';
        this.ctx.textBaseline = 'top';
        
        const lines = (layer.data.content || '').split('\n');
        const lineHeight = (layer.data.fontSize || 24) * 1.2;
        
        lines.forEach((line, index) => {
            this.ctx.fillText(line, layer.x, layer.y + (index * lineHeight));
        });
    }

    drawPaletteLayer(layer) {
        const colors = layer.data.colors || [];
        const colorWidth = layer.width / colors.length;
        
        colors.forEach((color, index) => {
            this.ctx.fillStyle = color;
            this.ctx.fillRect(
                layer.x + (index * colorWidth),
                layer.y,
                colorWidth,
                layer.height
            );
        });
    }

    drawShapeLayer(layer) {
        this.ctx.fillStyle = layer.data.color || '#000000';
        this.ctx.strokeStyle = layer.data.strokeColor || '#000000';
        this.ctx.lineWidth = layer.data.strokeWidth || 1;
        
        switch(layer.data.shape) {
            case 'rectangle':
                if (layer.data.fill) this.ctx.fillRect(layer.x, layer.y, layer.width, layer.height);
                if (layer.data.stroke) this.ctx.strokeRect(layer.x, layer.y, layer.width, layer.height);
                break;
                
            case 'circle':
                this.ctx.beginPath();
                this.ctx.arc(
                    layer.x + layer.width / 2,
                    layer.y + layer.height / 2,
                    Math.min(layer.width, layer.height) / 2,
                    0,
                    2 * Math.PI
                );
                if (layer.data.fill) this.ctx.fill();
                if (layer.data.stroke) this.ctx.stroke();
                break;
        }
    }

    setupEventListeners() {
        // Filtro de recursos
        document.getElementById('resourceFilter').addEventListener('change', () => {
            this.renderResourcesList();
        });
        
        // Canvas drag and drop
        this.canvas.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'copy';
            this.canvas.classList.add('drag-over');
        });
        
        this.canvas.addEventListener('dragleave', () => {
            this.canvas.classList.remove('drag-over');
        });
        
        this.canvas.addEventListener('drop', (e) => {
            e.preventDefault();
            this.canvas.classList.remove('drag-over');
            
            try {
                const resource = JSON.parse(e.dataTransfer.getData('application/json'));
                const rect = this.canvas.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                
                this.addResourceToCanvas(resource, x, y);
            } catch (error) {
                console.error('Error al procesar el recurso arrastrado:', error);
            }
        });
        
        // Herramientas
        document.getElementById('addTextTool').addEventListener('click', () => {
            this.showAddTextModal();
        });
        
        document.getElementById('addLayerBtn').addEventListener('click', () => {
            this.addLayer();
        });
        
        // Zoom y pan
        document.getElementById('zoomInBtn').addEventListener('click', () => {
            this.zoom = Math.min(this.zoom * 1.2, 5);
            this.updateZoomDisplay();
            this.redraw();
        });
        
        document.getElementById('zoomOutBtn').addEventListener('click', () => {
            this.zoom = Math.max(this.zoom / 1.2, 0.1);
            this.updateZoomDisplay();
            this.redraw();
        });
        
        document.getElementById('fitToScreenBtn').addEventListener('click', () => {
            this.zoom = 1;
            this.panX = 0;
            this.panY = 0;
            this.updateZoomDisplay();
            this.redraw();
        });
        
        // Redimensionar canvas
        document.getElementById('resizeCanvasBtn').addEventListener('click', () => {
            this.resizeCanvas();
        });
        
        // Botones principales
        document.getElementById('saveCreationBtn').addEventListener('click', () => {
            this.saveCreation();
        });
        
        document.getElementById('exportCreationBtn').addEventListener('click', () => {
            this.showExportModal();
        });
        
        // Historial
        document.getElementById('undoBtn').addEventListener('click', () => {
            this.undo();
        });
        
        document.getElementById('redoBtn').addEventListener('click', () => {
            this.redo();
        });
        
        // Modal de texto
        document.getElementById('addTextBtn').addEventListener('click', () => {
            this.addTextFromModal();
        });
        
        document.getElementById('textSize').addEventListener('input', (e) => {
            document.getElementById('textSizeValue').textContent = e.target.value;
        });
        
        // Modal de exportación
        document.getElementById('downloadBtn').addEventListener('click', () => {
            this.exportCreation();
        });
        
        document.getElementById('useCanvasSizeBtn').addEventListener('click', () => {
            document.getElementById('exportWidth').value = this.canvas.width;
            document.getElementById('exportHeight').value = this.canvas.height;
        });
        
        document.getElementById('exportQuality').addEventListener('input', (e) => {
            document.getElementById('exportQualityValue').textContent = e.target.value;
        });
    }

    showAddTextModal() {
        const modal = new bootstrap.Modal(document.getElementById('addTextModal'));
        modal.show();
    }

    addTextFromModal() {
        const content = document.getElementById('textContent').value;
        const font = document.getElementById('textFont').value;
        const size = parseInt(document.getElementById('textSize').value);
        const color = document.getElementById('textColor').value;
        
        if (!content.trim()) {
            alert('Por favor, ingresa el contenido del texto');
            return;
        }
        
        const textData = {
            type: 'text',
            content: content,
            fontFamily: font,
            fontSize: size,
            color: color,
            x: this.canvas.width / 2 - 100,
            y: this.canvas.height / 2 - 25,
            width: 200,
            height: 50
        };
        
        this.addLayer('text', textData);
        
        // Cerrar modal y limpiar
        const modal = bootstrap.Modal.getInstance(document.getElementById('addTextModal'));
        modal.hide();
        document.getElementById('textContent').value = '';
    }

    showExportModal() {
        const modal = new bootstrap.Modal(document.getElementById('exportModal'));
        document.getElementById('exportWidth').value = this.canvas.width;
        document.getElementById('exportHeight').value = this.canvas.height;
        modal.show();
    }

    exportCreation() {
        const format = document.getElementById('exportFormat').value;
        const quality = parseInt(document.getElementById('exportQuality').value) / 100;
        const width = parseInt(document.getElementById('exportWidth').value);
        const height = parseInt(document.getElementById('exportHeight').value);
        
        // Crear canvas temporal para exportación
        const exportCanvas = document.createElement('canvas');
        exportCanvas.width = width;
        exportCanvas.height = height;
        const exportCtx = exportCanvas.getContext('2d');
        
        // Dibujar el contenido escalado
        exportCtx.drawImage(this.canvas, 0, 0, width, height);
        
        // Exportar según el formato
        let mimeType = 'image/png';
        let extension = 'png';
        
        switch(format) {
            case 'jpeg':
                mimeType = 'image/jpeg';
                extension = 'jpg';
                break;
            case 'webp':
                mimeType = 'image/webp';
                extension = 'webp';
                break;
        }
        
        exportCanvas.toBlob((blob) => {
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `creacion-${Date.now()}.${extension}`;
            link.click();
            URL.revokeObjectURL(url);
        }, mimeType, quality);
        
        // Cerrar modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('exportModal'));
        modal.hide();
    }

    resizeCanvas() {
        const width = parseInt(document.getElementById('canvasWidth').value);
        const height = parseInt(document.getElementById('canvasHeight').value);
        
        if (width > 0 && height > 0 && width <= 4096 && height <= 4096) {
            this.canvas.width = width;
            this.canvas.height = height;
            this.redraw();
            this.saveState();
        }
    }

    updateZoomDisplay() {
        document.getElementById('zoomLevel').textContent = Math.round(this.zoom * 100) + '%';
    }

    async saveCreation() {
        const title = prompt('Título de la creación:');
        if (!title) return;
        
        const description = prompt('Descripción (opcional):') || '';
        const isPublic = confirm('¿Hacer pública esta creación?');
        
        try {
            // Mostrar indicador de carga
            this.showLoading('Guardando creación...');
            
            // Generar imagen del canvas
            const canvasData = this.canvas.toDataURL('image/png', 0.9);
            
            // Preparar datos para enviar
            const saveData = {
                title: title,
                description: description,
                canvasData: canvasData,
                canvasWidth: this.canvas.width,
                canvasHeight: this.canvas.height,
                layers: this.layers.map(layer => ({
                    id: layer.id,
                    name: layer.name,
                    type: layer.type,
                    visible: layer.visible,
                    opacity: layer.opacity,
                    x: layer.x,
                    y: layer.y,
                    width: layer.width,
                    height: layer.height,
                    data: layer.data || null
                })),
                resourcesUsed: this.usedResources,
                isPublic: isPublic
            };
            
            // Enviar a la API
            const response = await fetch('/api/save_unified_creation.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(saveData)
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.showSuccessMessage('Creación guardada exitosamente');
                
                // También guardar en localStorage para acceso rápido
                const galleryItems = JSON.parse(localStorage.getItem('obelisiaGallery') || '[]');
                galleryItems.unshift({
                    tipo: 'composite',
                    data: {
                        url: canvasData,
                        layers: this.layers,
                        width: this.canvas.width,
                        height: this.canvas.height,
                        title: title,
                        id: result.data.id
                    },
                    fecha: new Date().toISOString()
                });
                localStorage.setItem('obelisiaGallery', JSON.stringify(galleryItems));
                
                // Opcional: redirigir a mis creaciones
                setTimeout(() => {
                    if (confirm('¿Ir a ver tus creaciones?')) {
                        window.location.href = '/mis-creaciones';
                    }
                }, 1500);
            } else {
                throw new Error(result.message || 'Error al guardar la creación');
            }
            
        } catch (error) {
            console.error('Error al guardar:', error);
            this.showErrorMessage('Error al guardar la creación: ' + error.message);
            
            // Fallback: guardar solo localmente
            const galleryItems = JSON.parse(localStorage.getItem('obelisiaGallery') || '[]');
            galleryItems.unshift({
                tipo: 'composite',
                data: {
                    url: this.canvas.toDataURL('image/jpeg', 0.3),
                    layers: this.layers,
                    width: this.canvas.width,
                    height: this.canvas.height,
                    title: title,
                    saved_locally: true
                },
                fecha: new Date().toISOString()
            });
            localStorage.setItem('obelisiaGallery', JSON.stringify(galleryItems));
            this.showSuccessMessage('Creación guardada localmente');
        } finally {
            this.hideLoading();
        }
    }

    showSuccessMessage(message) {
        // Crear y mostrar mensaje de éxito
        const alert = document.createElement('div');
        alert.className = 'alert alert-success alert-dismissible fade show position-fixed';
        alert.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
        alert.innerHTML = `
            <i class="fas fa-check-circle me-2"></i>
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(alert);
        
        // Auto-remover después de 5 segundos
        setTimeout(() => {
            if (alert.parentNode) {
                alert.parentNode.removeChild(alert);
            }
        }, 5000);
    }

    saveState() {
        const state = {
            layers: JSON.parse(JSON.stringify(this.layers)),
            activeLayerIndex: this.activeLayerIndex,
            zoom: this.zoom,
            panX: this.panX,
            panY: this.panY,
            canvasWidth: this.canvas.width,
            canvasHeight: this.canvas.height
        };
        
        // Mantener solo las últimas N entradas
        if (this.history.length >= this.maxHistorySize) {
            this.history.shift();
        } else {
            this.historyIndex++;
        }
        
        // Eliminar estados futuros si estamos en el medio del historial
        this.history = this.history.slice(0, this.historyIndex + 1);
        this.history.push(state);
    }

    undo() {
        if (this.historyIndex > 0) {
            this.historyIndex--;
            this.restoreState(this.history[this.historyIndex]);
        }
    }

    redo() {
        if (this.historyIndex < this.history.length - 1) {
            this.historyIndex++;
            this.restoreState(this.history[this.historyIndex]);
        }
    }

    restoreState(state) {
        this.layers = JSON.parse(JSON.stringify(state.layers));
        this.activeLayerIndex = state.activeLayerIndex;
        this.zoom = state.zoom;
        this.panX = state.panX;
        this.panY = state.panY;
        
        if (state.canvasWidth && state.canvasHeight) {
            this.canvas.width = state.canvasWidth;
            this.canvas.height = state.canvasHeight;
            document.getElementById('canvasWidth').value = state.canvasWidth;
            document.getElementById('canvasHeight').value = state.canvasHeight;
        }
        
        this.updateZoomDisplay();
        this.renderLayersList();
        this.redraw();
    }

    generateId() {
        return 'layer_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    showLoading(message = 'Cargando...') {
        // Crear o mostrar overlay de carga
        let loadingOverlay = document.getElementById('loadingOverlay');
        if (!loadingOverlay) {
            loadingOverlay = document.createElement('div');
            loadingOverlay.id = 'loadingOverlay';
            loadingOverlay.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.8);
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 9999;
                color: white;
                font-size: 18px;
            `;
            document.body.appendChild(loadingOverlay);
        }
        
        loadingOverlay.innerHTML = `
            <div style="text-align: center;">
                <div style="border: 4px solid #f3f3f3; border-radius: 50%; border-top: 4px solid #3498db; width: 40px; height: 40px; animation: spin 2s linear infinite; margin: 0 auto 20px;"></div>
                <div>${message}</div>
            </div>
        `;
        loadingOverlay.style.display = 'flex';
        
        // Agregar animación de spin si no existe
        if (!document.getElementById('spinAnimation')) {
            const style = document.createElement('style');
            style.id = 'spinAnimation';
            style.textContent = `
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            `;
            document.head.appendChild(style);
        }
    }

    hideLoading() {
        const loadingOverlay = document.getElementById('loadingOverlay');
        if (loadingOverlay) {
            loadingOverlay.style.display = 'none';
        }
    }

    showErrorMessage(message) {
        // Crear notification de error
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #dc3545;
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            z-index: 10000;
            max-width: 400px;
            font-size: 14px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        `;
        notification.textContent = message;
        document.body.appendChild(notification);
        
        // Auto-remover después de 5 segundos
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 5000);
    }
}

// Inicializar el editor cuando se carga la página
let editor;

document.addEventListener('DOMContentLoaded', () => {
    editor = new UnifiedCreationEditor();
    
    // Exponer el editor globalmente para uso en HTML
    window.editor = editor;
    
    console.log('Editor Unificado de Creaciones iniciado correctamente');
});
