// edit-img/js/utils/constants.js
export const CONFIG = {
  MAX_FREE_DOWNLOADS: 5,
  DOWNLOADS_PER_AD_WATCH: 3,
};
