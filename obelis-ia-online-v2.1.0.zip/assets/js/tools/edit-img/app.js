// edit-img/js/app.js

import { initGlobalApp } from "/../assets/js/general/global.js";
import { initApp as initEditorApp } from "./main.js";

document.addEventListener("DOMContentLoaded", () => {
  initGlobalApp();
  initEditorApp();
});
