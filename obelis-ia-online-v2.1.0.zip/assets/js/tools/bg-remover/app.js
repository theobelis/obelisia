// --- DOM Elements ---
        const imageLoader = document.getElementById('imageLoader');
        const originalCanvas = document.getElementById('originalCanvas');
        const resultCanvas = document.getElementById('resultCanvas');
        const removeBgBtn = document.getElementById('removeBgBtn');
        const downloadBtn = document.getElementById('downloadBtn');
        const toleranceSlider = document.getElementById('tolerance');
        const toleranceValueSpan = document.getElementById('toleranceValue');
        const colorPreview = document.getElementById('colorPreview');
        const colorHelp = document.getElementById('colorHelp');

        const originalCtx = originalCanvas.getContext('2d');
        const resultCtx = resultCanvas.getContext('2d');
        
        let originalImage = null;
        let selectedColor = null;

        // --- Web Worker Initialization ---
        // Create a worker from the script tag
        const workerBlob = new Blob([document.getElementById('worker').textContent], { type: "text/javascript" });
        const worker = new Worker(window.URL.createObjectURL(workerBlob));
        
        // --- Event Listeners ---

        // Handle image file selection
        imageLoader.addEventListener('change', (e) => {
            const reader = new FileReader();
            reader.onload = (event) => {
                originalImage = new Image();
                originalImage.onload = () => {
                    // Resize canvas to match image
                    originalCanvas.width = resultCanvas.width = originalImage.width;
                    originalCanvas.height = resultCanvas.height = originalImage.height;
                    
                    // Draw image on original canvas
                    originalCtx.drawImage(originalImage, 0, 0);
                    
                    // Reset UI state
                    removeBgBtn.disabled = true; // Disabled until a color is picked
                    downloadBtn.disabled = true;
                    resultCtx.clearRect(0, 0, resultCanvas.width, resultCanvas.height);
                    selectedColor = null;
                    colorPreview.style.backgroundColor = '#e9ecef';
                    colorHelp.textContent = 'Haz clic en la imagen original';
                };
                originalImage.src = event.target.result;
            };
            if (e.target.files[0]) {
                reader.readAsDataURL(e.target.files[0]);
            }
        });

        // Handle color picking from original canvas
        originalCanvas.addEventListener('click', (e) => {
            if (!originalImage) return;

            // Get coordinates of the click relative to the canvas
            const rect = originalCanvas.getBoundingClientRect();
            const scaleX = originalCanvas.width / rect.width;
            const scaleY = originalCanvas.height / rect.height;
            const x = (e.clientX - rect.left) * scaleX;
            const y = (e.clientY - rect.top) * scaleY;
            
            // Get the color data of the clicked pixel
            const pixel = originalCtx.getImageData(x, y, 1, 1).data;
            selectedColor = { r: pixel[0], g: pixel[1], b: pixel[2] };
            
            // Update the UI with the selected color
            const colorHex = `rgb(${pixel[0]}, ${pixel[1]}, ${pixel[2]})`;
            colorPreview.style.backgroundColor = colorHex;
            colorHelp.textContent = '¡Color elegido!';
            removeBgBtn.disabled = false;
        });
        
        // Update tolerance value display
        toleranceSlider.addEventListener('input', (e) => {
            toleranceValueSpan.textContent = e.target.value;
        });

        // Trigger background removal
        removeBgBtn.addEventListener('click', () => {
            if (!originalImage) {
                alert("Por favor, carga una imagen primero.");
                return;
            }
            if (!selectedColor) {
                alert("Por favor, selecciona un color de fondo haciendo clic en la imagen original.");
                return;
            }
            processImageWithWorker();
        });

        // Handle message from the worker
        worker.onmessage = (e) => {
            const processedImageData = e.data;
            resultCtx.putImageData(processedImageData, 0, 0);
            
            // Re-enable UI after processing
            toggleProcessingState(false);
            downloadBtn.disabled = false;
        };
        
        // Handle download
        downloadBtn.addEventListener('click', () => {
            const link = document.createElement('a');
            link.download = 'resultado_sin_fondo.png';
            link.href = resultCanvas.toDataURL('image/png');
            link.click();

            // Registrar actividad en el backend
            fetch('/api/log_activity.php', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                action: 'Descarga de imagen sin fondo',
                tool: 'bg-remover',
                details: 'Descarga de imagen procesada sin fondo'
              })
            });
        });

        // --- Core Functions ---

        /**
         * Sends the image data to the web worker for processing.
         */
        function processImageWithWorker() {
            toggleProcessingState(true);
            const imageData = originalCtx.getImageData(0, 0, originalCanvas.width, originalCanvas.height);
            const tolerance = parseInt(toleranceSlider.value, 10);
            
            // Post data to the worker. The worker will handle the heavy lifting.
            worker.postMessage({
                imageData,
                targetColor: selectedColor,
                tolerance
            });
        }

        /**
         * Manages the UI state during processing.
         * @param {boolean} isProcessing - True if processing has started.
         */
        function toggleProcessingState(isProcessing) {
            const buttonText = removeBgBtn.querySelector('.button-text');
            const spinner = removeBgBtn.querySelector('.spinner-border');

            if (isProcessing) {
                removeBgBtn.disabled = true;
                buttonText.textContent = 'Procesando...';
                spinner.classList.remove('d-none');
            } else {
                removeBgBtn.disabled = false;
                buttonText.textContent = 'Quitar Fondo';
                spinner.classList.add('d-none');
            }
        }