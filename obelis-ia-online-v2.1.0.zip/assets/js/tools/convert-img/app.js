// convert-img/js/app.js

// 1. Importa el inicializador global desde la carpeta raíz de JS.
import { initGlobalApp } from "/assets/js/general/global.js";

// 2. Importa el inicializador específico de la página del convertidor.
import { initApp as initConverterApp } from "./main.js";

// 3. Espera a que el DOM esté listo y ejecuta todo en orden.
document.addEventListener("DOMContentLoaded", () => {
  initGlobalApp(); // Primero siempre lo global (navbar, modales, etc.).
  initConverterApp(); // Luego la lógica específica del convertidor.

  // Mostrar imagen seleccionada en el canvas
  const imageUpload = document.getElementById('imageUpload');
  const imageCanvas = document.getElementById('imageCanvas');
  const placeholderText = document.getElementById('placeholderText');
  const imgDropArea = document.getElementById('imgDropArea');
  const imgConvWorkArea = document.getElementById('imgConvWorkArea');
  const fileName = document.getElementById('fileName');
  const convertBtn = document.getElementById('convertBtn');
  const downloadBtn = document.getElementById('downloadBtn');

  let lastImageFile = null;
  let lastImageDataUrl = null;

  function showImageOnCanvas(file) {
    if (!file || !imageCanvas) return;
    const ctx = imageCanvas.getContext('2d');
    const img = new window.Image();
    const url = URL.createObjectURL(file);
    img.onload = function() {
      // Definir tamaño máximo visible para el canvas
      const maxW = 480;
      const maxH = 340;
      let drawW = img.width;
      let drawH = img.height;
      // Escalado proporcional
      if (drawW > maxW || drawH > maxH) {
        const ratio = Math.min(maxW / drawW, maxH / drawH);
        drawW = Math.round(drawW * ratio);
        drawH = Math.round(drawH * ratio);
      }
      imageCanvas.width = drawW;
      imageCanvas.height = drawH;
      ctx.clearRect(0, 0, drawW, drawH);
      ctx.drawImage(img, 0, 0, drawW, drawH);
      // Centrar el canvas visualmente
      imageCanvas.style.display = 'block';
      imageCanvas.style.maxWidth = maxW + 'px';
      imageCanvas.style.maxHeight = maxH + 'px';
      imageCanvas.style.margin = '0 auto';
      placeholderText.style.display = 'none';
      if (imgDropArea) imgDropArea.classList.add('d-none');
      if (imgConvWorkArea) imgConvWorkArea.classList.remove('d-none');
      URL.revokeObjectURL(url);
      lastImageFile = file;
      // Guardar una miniatura base64 para el historial
      lastImageDataUrl = imageCanvas.toDataURL('image/png', 0.7);
    };
    img.onerror = function() {
      placeholderText.textContent = 'No se pudo cargar la imagen.';
      placeholderText.style.display = 'block';
      imageCanvas.style.display = 'none';
    };
    img.src = url;
  }

  if (imageUpload) {
    imageUpload.addEventListener('change', function(e) {
      const file = e.target.files && e.target.files[0];
      if (file && file.type.startsWith('image/')) {
        if (fileName) fileName.textContent = file.name;
        showImageOnCanvas(file);
      }
    });
  }

  // Soporte para arrastrar y soltar
  if (imgDropArea) {
    imgDropArea.addEventListener('dragover', function(e) {
      e.preventDefault();
      imgDropArea.classList.add('border-primary');
    });
    imgDropArea.addEventListener('dragleave', function(e) {
      imgDropArea.classList.remove('border-primary');
    });
    imgDropArea.addEventListener('drop', function(e) {
      e.preventDefault();
      imgDropArea.classList.remove('border-primary');
      const file = e.dataTransfer.files && e.dataTransfer.files[0];
      if (file && file.type.startsWith('image/')) {
        if (fileName) fileName.textContent = file.name;
        showImageOnCanvas(file);
      }
    });
  }

  // Guardar en historial después de la conversión
  if (convertBtn && downloadBtn) {
    convertBtn.addEventListener('click', function(e) {
      e.preventDefault();
      // Simular conversión y guardado en historial
      if (!lastImageFile || !lastImageDataUrl) return;
      // Obtener formato seleccionado
      const formatSel = document.getElementById('outputFormat');
      const format = formatSel ? formatSel.value : lastImageFile.type;
      // Obtener nombre
      const name = lastImageFile.name;
      // Obtener tamaño legible
      const size = (lastImageFile.size/1024).toFixed(1) + ' KB';
      // Fecha
      const date = new Date().toLocaleString();
      // Miniatura
      const thumb = lastImageDataUrl;
      // Simular URL de descarga (descargar el canvas actual)
      const downloadUrl = imageCanvas.toDataURL(format);
      // Guardar en historial
      const item = { name, format, size, date, thumb, downloadUrl };
      let history = JSON.parse(localStorage.getItem('imgconvHistory') || '[]');
      history.unshift(item);
      if (history.length > 20) history.length = 20;
      localStorage.setItem('imgconvHistory', JSON.stringify(history));
      // Actualizar historial en UI
      if (typeof renderImgconvHistory === 'function') renderImgconvHistory();
    });
  }
});
