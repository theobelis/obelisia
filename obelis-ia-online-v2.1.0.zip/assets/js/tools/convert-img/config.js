// convert-img/js/config.js

export const CONFIG = {
  MAX_FREE_CONVERSIONS: 5,
  CONVERSIONS_PER_AD_WATCH: 3,
  AD_VIEW_DURATION_SECONDS: 5,
  MAX_ADS_PER_DAY: 2,
};
