// Lógica específica para el dashboard (gráficos).
