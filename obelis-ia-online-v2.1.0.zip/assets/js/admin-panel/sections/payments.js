// Lógica para la sección de pagos.
