// Lógica para la sección de herramientas.
