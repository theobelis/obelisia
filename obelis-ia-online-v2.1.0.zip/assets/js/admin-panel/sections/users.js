// assets/js/admin-panel/sections/users.js

import { state } from '../state.js';
import * as api from '../api.js';
import * as ui from '../ui.js';
import { debounce } from '../main.js';

// --- CARGA Y RENDERIZADO DE DATOS ---

/**
 * Carga los usuarios desde la API aplicando los filtros actuales.
 */
export async function load() {
    try {
        const data = await api.fetchData('/admin/ajax/users/get_list.php', state.filters.users);
        if (data) {
            renderTable(data.data);
            ui.renderPagination('users-pagination', data.pagination, (page) => {
                state.filters.users.page = page;
                load();
            });
            updateCount(data.pagination);
        }
    } catch (error) {
        ui.showAlert('error', error.message);
        document.querySelector('#users-table tbody').innerHTML = `<tr><td colspan="11" class="text-center text-danger">Error al cargar usuarios: ${error.message}</td></tr>`;
    }
}

/**
 * Renderiza la tabla de usuarios en el DOM.
 * @param {Array} users - El array de objetos de usuario.
 */
function renderTable(users) {
    const tbody = document.querySelector('#users-table tbody');
    if (!tbody) return;

    if (users.length === 0) {
        tbody.innerHTML = '<tr><td colspan="11" class="text-center">No se encontraron usuarios con los filtros aplicados.</td></tr>';
        return;
    }

    tbody.innerHTML = users.map(user => `
        <tr>
            <td><input type="checkbox" name="selectedUsers" value="${user.id}" class="form-check-input"></td>
            <td>${user.id}</td>
            <td>
                <div class="d-flex align-items-center">
                    <div>
                        <div class="fw-bold">${user.username}</div>
                        <small class="text-muted">${user.email_verified ? '<i class="fas fa-check-circle text-success"></i> Verificado' : '<i class="fas fa-exclamation-circle text-warning"></i> No Verificado'}</small>
                    </div>
                </div>
            </td>
            <td>${user.email}</td>
            <td>${user.full_name}</td>
            <td>${user.membership_badge}</td>
            <td><span class="badge bg-info">${user.credits_remaining}</span></td>
            <td>${user.status_badge}</td>
            <td><small class="text-muted">${user.last_login_formatted}</small></td>
            <td><small class="text-muted">${user.created_at_formatted}</small></td>
            <td>
                <div class="btn-group btn-group-sm">
                    <button class="btn btn-outline-primary" onclick="adminPanel.users.edit(${user.id})" title="Editar"><i class="fas fa-edit"></i></button>
                    <button class="btn btn-outline-danger" onclick="adminPanel.users.del(${user.id})" title="Eliminar"><i class="fas fa-trash"></i></button>
                </div>
            </td>
        </tr>
    `).join('');
}

/**
 * Actualiza el contador de usuarios mostrados.
 * @param {object} pagination - El objeto de paginación.
 */
function updateCount(pagination) {
    const countElement = document.getElementById('userCount');
    if (countElement) {
        countElement.textContent = pagination.total_records;
    }
}

// --- MANEJO DE FILTROS Y EVENTOS ---

/**
 * Actualiza el objeto de estado con los valores actuales de los filtros.
 */
function updateFilters() {
    state.filters.users.membership = document.getElementById('userMembershipFilter')?.value || 'all';
    state.filters.users.status = document.getElementById('userStatusFilter')?.value || 'all';
    state.filters.users.orderBy = document.getElementById('userOrderBy')?.value || 'created_at';
    state.filters.users.orderDir = document.getElementById('userOrderDir')?.value || 'DESC';
    state.filters.users.page = 1;
}

/**
 * Configura los event listeners para los controles de filtro de la sección.
 */
export function setup() {
    document.getElementById('userSearch')?.addEventListener('input', debounce(() => {
        state.filters.users.search = document.getElementById('userSearch').value;
        state.filters.users.page = 1;
        load();
    }, 300));

    ['userMembershipFilter', 'userStatusFilter', 'userOrderBy', 'userOrderDir'].forEach(id => {
        document.getElementById(id)?.addEventListener('change', () => {
            updateFilters();
            load();
        });
    });
}


// --- ACCIONES (MODALES, GUARDADO, BORRADO) ---

/**
 * Abre el modal para añadir un nuevo usuario.
 */
export function showAddModal() {
    document.getElementById('userModalTitle').textContent = 'Nuevo Usuario';
    document.getElementById('userForm').reset();
    document.getElementById('userId').value = '';
    document.getElementById('passwordSection').style.display = 'block';
    
    new bootstrap.Modal(document.getElementById('userModal')).show();
}

/**
 * Guarda un usuario (nuevo o existente).
 */
export async function save() {
    const form = document.getElementById('userForm');
    const submitButton = document.querySelector('#userModal button[onclick="adminPanel.users.save()"]');
    
    submitButton.disabled = true;
    submitButton.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Guardando...';

    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());
    data.action = 'save';
    
    try {
        const result = await api.postData('/admin/ajax/users/actions.php', data);
        ui.showAlert(result.success ? 'success' : 'error', result.message);
        if (result.success) {
            bootstrap.Modal.getInstance(document.getElementById('userModal'))?.hide();
            load(); // Recargar la tabla
        }
    } catch (error) {
        ui.showAlert('error', error.message);
    } finally {
        submitButton.disabled = false;
        submitButton.innerHTML = 'Guardar';
    }
}

/**
 * Obtiene los datos de un usuario y abre el modal para editarlo.
 * @param {number} id - El ID del usuario.
 */
export async function edit(id) {
    try {
        const data = await api.fetchData('/admin/ajax/users/actions.php', { action: 'get_details', id: id });
        if (data && data.user) {
            const user = data.user;
            const form = document.getElementById('userForm');
            form.reset();
            
            document.getElementById('userModalTitle').textContent = `Editar Usuario: ${user.username}`;
            document.getElementById('userId').value = user.id;
            document.getElementById('username').value = user.username;
            document.getElementById('email').value = user.email;
            document.getElementById('full_name').value = user.full_name;
            document.getElementById('membership_type').value = user.membership_type;
            document.getElementById('status').value = user.status;
            document.getElementById('credits_remaining').value = user.credits_remaining;
            document.getElementById('notes').value = user.notes;
            
            document.getElementById('passwordSection').style.display = 'block';
            document.querySelector('#passwordSection .form-text').textContent = 'Dejar vacío para mantener contraseña actual';

            new bootstrap.Modal(document.getElementById('userModal')).show();
        }
    } catch(error) {
        ui.showAlert('error', error.message);
    }
}

/**
 * Elimina un usuario (borrado lógico).
 * @param {number} id - El ID del usuario.
 */
export async function del(id) {
    if (!confirm(`¿Estás seguro de que quieres eliminar al usuario con ID ${id}? Esta acción lo moverá a la papelera.`)) return;

    try {
        const result = await api.postData('/admin/ajax/users/actions.php', { action: 'delete', id: id });
        ui.showAlert(result.success ? 'success' : 'error', result.message);
        if (result.success) {
            load();
        }
    } catch (error) {
        ui.showAlert('error', error.message);
    }
}