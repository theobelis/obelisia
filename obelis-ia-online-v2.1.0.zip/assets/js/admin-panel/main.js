// assets/js/admin-panel/main.js

import { state } from './state.js';
import * as ui from './ui.js';
import * as dashboard from './sections/dashboard.js';
import * as users from './sections/users.js';
import * as tools from './sections/tools.js';
import * as payments from './sections/payments.js';

/**
 * El objeto global `adminPanel` actúa como un puente entre nuestro código modular
 * y las llamadas `onclick` en el HTML. Cada módulo de sección se adjunta aquí.
 */
window.adminPanel = {
    dashboard,
    users,
    tools,
    payments,
    // Puedes añadir más módulos aquí a medida que los crees
};

/**
 * Función central que actúa como un "router".
 * Decide qué función de carga de datos ejecutar según la sección activa.
 * @param {string} sectionName - El nombre de la sección a cargar.
 */
export function loadSectionData(sectionName) {
    state.currentSection = sectionName;
    switch (sectionName) {
        case 'dashboard':
            dashboard.load();
            break;
        case 'users':
            users.load();
            break;
        case 'tools':
            tools.load();
            break;
        case 'payments':
            payments.load();
            break;
        case 'settings':
            // settings.load(); // Descomentar cuando crees settings.js
            break;
    }
}

/**
 * Función de utilidad para evitar llamadas excesivas en eventos como 'input'.
 * @param {function} func - La función a ejecutar después del retardo.
 * @param {number} wait - El tiempo de espera en milisegundos.
 */
export function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}


/**
 * Función de inicialización principal de la aplicación del panel.
 */
function init() {
    console.log("Admin Panel Inicializado.");

    // 1. Configurar la navegación principal
    document.querySelectorAll('.nav-link[data-section]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const section = link.getAttribute('data-section');
            ui.showSection(section);
        });
    });

    // 2. Inicializar los filtros y eventos de cada sección
    users.setup();
    tools.setup();
    payments.setup();
    dashboard.setup();

    // 3. Cargar la sección inicial que está definida en el estado
    ui.showSection(state.currentSection);
}

// Iniciar la aplicación cuando el DOM esté completamente cargado.
document.addEventListener('DOMContentLoaded', init);