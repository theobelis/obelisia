// Módulo para interacciones generales con la interfaz (alertas, modales, navegación).
import { loadSectionData } from './main.js'; // Importamos el router principal

/**
 * Muestra una alerta flotante en la esquina de la pantalla.
 * @param {'success'|'error'} type - El tipo de alerta.
 * @param {string} message - El mensaje a mostrar.
 */
export function showAlert(type, message) {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type === 'error' ? 'danger' : 'success'} alert-dismissible fade show position-fixed`;
    alertDiv.style.cssText = 'top: 20px; right: 20px; z-index: 9999; max-width: 400px;';
    alertDiv.innerHTML = `${message}<button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;
    document.body.appendChild(alertDiv);
    setTimeout(() => alertDiv.remove(), 5000);
}

/**
 * Muestra una sección del panel y oculta las demás.
 * @param {string} sectionName - El nombre de la sección a mostrar (ej. 'users').
 */
export function showSection(sectionName) {
    document.querySelectorAll('.admin-section').forEach(section => section.classList.remove('active'));
    document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));

    const targetSection = document.getElementById(`${sectionName}-section`);
    if (targetSection) targetSection.classList.add('active');

    const targetNav = document.querySelector(`[data-section="${sectionName}"]`);
    if (targetNav) targetNav.classList.add('active');

    loadSectionData(sectionName); // Llama al router para cargar los datos de la nueva sección.
}

/**
 * Renderiza los controles de paginación de forma genérica.
 * @param {string} containerId - El ID del contenedor donde se renderizará la paginación.
 * @param {object} pagination - El objeto de paginación devuelto por la API.
 * @param {function} onPageClick - La función a ejecutar cuando se hace clic en una página.
 */
export function renderPagination(containerId, pagination, onPageClick) {
    const container = document.getElementById(containerId);
    if (!container) return;

    const { current_page, total_pages, has_prev, has_next } = pagination;
    if (total_pages <= 1) {
        container.innerHTML = '';
        return;
    }

    let paginationHtml = '<ul class="pagination justify-content-end">';
    paginationHtml += `<li class="page-item ${!has_prev ? 'disabled' : ''}"><a class="page-link" href="#" data-page="${current_page - 1}">Anterior</a></li>`;
    
    for (let i = 1; i <= total_pages; i++) {
        paginationHtml += `<li class="page-item ${i === current_page ? 'active' : ''}"><a class="page-link" href="#" data-page="${i}">${i}</a></li>`;
    }

    paginationHtml += `<li class="page-item ${!has_next ? 'disabled' : ''}"><a class="page-link" href="#" data-page="${current_page + 1}">Siguiente</a></li>`;
    paginationHtml += '</ul>';
    container.innerHTML = paginationHtml;

    container.querySelectorAll('.page-link[data-page]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            onPageClick(parseInt(link.getAttribute('data-page')));
        });
    });
}