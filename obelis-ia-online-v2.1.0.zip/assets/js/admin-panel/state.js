// Contiene el estado compartido de la aplicación del panel de administración.

export const state = {
    currentSection: 'dashboard',
    charts: {},
    tables: {},
    filters: {
        users: { page: 1, limit: 20, search: '', membership: 'all', status: 'all', orderBy: 'created_at', orderDir: 'DESC' },
        tools: { search: '', category: 'all', status: 'all', orderBy: 'name', orderDir: 'ASC', view: 'grid' },
        payments: { type: 'all', status: 'all', method: 'all', dateFrom: '', dateTo: '', page: 1 }
    }
};