// Módulo para centralizar todas las peticiones fetch (API) al backend.

/**
 * Realiza una petición GET al endpoint especificado.
 * @param {string} endpoint - La URL del API.
 * @param {object} params - Un objeto con los parámetros para la URL.
 * @returns {Promise<object|null>} Los datos de la respuesta o null si hay un error.
 */
export async function fetchData(endpoint, params = {}) {
    try {
        const query = new URLSearchParams(params).toString();
        const response = await fetch(`${endpoint}?${query}`);
        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }
        const data = await response.json();
        if (!data.success) {
            throw new Error(data.message || 'La API devolvió un error.');
        }
        return data;
    } catch (error) {
        console.error(`Error al obtener datos de ${endpoint}:`, error);
        // La alerta ahora se manejará en el módulo UI para separar responsabilidades.
        throw error; // Lanzamos el error para que el llamador lo capture.
    }
}

/**
 * Realiza una petición POST al endpoint especificado.
 * @param {string} endpoint - La URL del API.
 * @param {object} body - El cuerpo de la petición.
 * @returns {Promise<object|null>} La respuesta del servidor o null si hay un error.
 */
export async function postData(endpoint, body = {}) {
    try {
        // El token CSRF debe estar disponible en el HTML en una meta etiqueta.
        // <meta name="csrf-token" content="TUTOKEN">
        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
        if (!csrfToken) {
            throw new Error('Token CSRF no encontrado. Recarga la página.');
        }
        body.csrf_token = csrfToken;

        const response = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || `Error HTTP: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error(`Error al enviar datos a ${endpoint}:`, error);
        throw error; // Lanzamos el error.
    }
}