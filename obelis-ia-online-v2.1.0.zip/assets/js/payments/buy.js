document.addEventListener('DOMContentLoaded', function() {
    const mpButton = document.getElementById('mp-button');
    const errorMessageDiv = document.getElementById('payment-error-message');

    mpButton.addEventListener('click', function() {
        mpButton.disabled = true;
        mpButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Creando pago...';

        fetch('/ajax/payments/create_mp_preference.php', {
            method: 'POST'
        })
        .then(response => response.json())
        .then(preference => {
            if (preference.init_point) {
                // Redirigir al checkout de Mercado Pago
                window.location.href = preference.init_point;
            } else {
                throw new Error(preference.error || 'No se pudo crear la preferencia de pago.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            errorMessageDiv.textContent = 'Hubo un error inesperado. Por favor, intenta de nuevo.';
            errorMessageDiv.classList.remove('d-none');
            mpButton.disabled = false;
            mpButton.innerHTML = '<i class="fas fa-credit-card me-2"></i>Pagar con Tarjeta';
        });
    });
});


// El siguiente bloque debe ir en el HTML, no en el JS:
// <script src="https://www.paypal.com/sdk/js?client-id=TU_CLIENT_ID&currency=USD"></script>

if (typeof paypal !== 'undefined') {
    paypal.Buttons({
        // Configurar la transacción
        createOrder: function(data, actions) {
            return actions.order.create({
                purchase_units: [{
                    description: 'Suscripción ObelisIA Premium (Mensual)',
                    amount: {
                        value: '19.00' // Asegúrate que el precio coincida
                    }
                }]
            });
        },
        // Finalizar la transacción
        onApprove: function(data, actions) {
            return actions.order.capture().then(function(details) {
                // LLAMADA AL BACKEND PARA VERIFICAR Y ACTUALIZAR
                fetch('/ajax/payments/paypal_capture_order.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        orderID: data.orderID,
                        payerID: details.payer.payer_id
                    })
                })
                .then(res => res.json())
                .then(result => {
                    if(result.success) {
                        alert('¡Pago completado! Tu cuenta ha sido actualizada.');
                        window.location.href = '/suscripcion';
                    } else {
                        alert('Error: ' + result.message);
                    }
                });
            });
        },
        onError: function(err) {
            console.error('Error en el pago con PayPal:', err);
            document.getElementById('payment-error-message').textContent = 'Ocurrió un error con PayPal. Por favor, intenta de nuevo.';
            document.getElementById('payment-error-message').classList.remove('d-none');
        }
    }).render('#paypal-button-container');
}