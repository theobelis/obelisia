// darkmode.js - Sistema de modo oscuro mejorado
document.addEventListener("DOMContentLoaded", function () {
  console.log('DarkMode script cargado'); // Debug
  
  // Obtener todos los botones de modo oscuro
  const darkModeButtons = document.querySelectorAll(".toggle-darkmode-btn");
  const darkModeIcons = document.querySelectorAll(".darkmode-icon");
  const darkModeTexts = document.querySelectorAll(".darkmode-text");

  console.log(`Encontrados ${darkModeButtons.length} botones de modo oscuro`); // Debug

  function setDarkMode(enabled) {
    console.log('Estableciendo modo oscuro:', enabled); // Debug
    
    if (enabled) {
      document.body.classList.add("dark-mode");
      document.documentElement.setAttribute('data-theme', 'dark');
      
      // Actualizar iconos y textos
      darkModeIcons.forEach(icon => {
        if (icon.classList.contains('material-icons')) {
          icon.textContent = "light_mode";
        } else if (icon.classList.contains('fas')) {
          icon.classList.remove('fa-moon');
          icon.classList.add('fa-sun');
        }
      });
      
      darkModeTexts.forEach(text => text.textContent = "Modo Claro");
      
      // Actualizar botones redondeados
      darkModeButtons.forEach(btn => {
        if (btn.classList.contains('toggle-darkmode-btn-rounded')) {
          btn.classList.add('dark');
        }
      });
      
    } else {
      document.body.classList.remove("dark-mode");
      document.documentElement.setAttribute('data-theme', 'light');
      
      // Actualizar iconos y textos
      darkModeIcons.forEach(icon => {
        if (icon.classList.contains('material-icons')) {
          icon.textContent = "dark_mode";
        } else if (icon.classList.contains('fas')) {
          icon.classList.remove('fa-sun');
          icon.classList.add('fa-moon');
        }
      });
      
      darkModeTexts.forEach(text => text.textContent = "Modo Oscuro");
      
      // Actualizar botones redondeados
      darkModeButtons.forEach(btn => {
        btn.classList.remove('dark');
      });
    }
    
    // Guardar preferencia
    localStorage.setItem("darkMode", enabled.toString()); 
    document.cookie = "darkMode=" + enabled + ";path=/;max-age=31536000";
    
    console.log('Modo oscuro actualizado:', enabled); // Debug
  }

  // Cargar preferencia guardada al inicio
  let darkPref = false;
  
  // Primero intentar localStorage
  const storedPref = localStorage.getItem("darkMode");
  if (storedPref !== null) {
    darkPref = storedPref === "true";
  } else {
    // Si no hay localStorage, revisar cookies
    const cookieValue = document.cookie
      .split('; ')
      .find(row => row.startsWith('darkMode='));
    if (cookieValue) {
      darkPref = cookieValue.split('=')[1] === "true";
    }
  }
  
  console.log('Preferencia cargada:', darkPref); // Debug
  setDarkMode(darkPref);

  // Agregar event listeners a todos los botones
  darkModeButtons.forEach((button, index) => {
    console.log(`Configurando botón ${index + 1}`); // Debug
    
    button.addEventListener("click", function (e) {
      e.preventDefault();
      console.log('Botón de modo oscuro clickeado'); // Debug
      
      const currentDark = document.body.classList.contains("dark-mode");
      const newDarkMode = !currentDark;
      
      setDarkMode(newDarkMode);
    });
  });
  
  // Verificar si hay botones disponibles
  if (darkModeButtons.length === 0) {
    console.warn('No se encontraron botones de modo oscuro en la página');
  }
});