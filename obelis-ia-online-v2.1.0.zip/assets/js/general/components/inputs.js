/**
 * ========================================
 * SISTEMA DE INPUTS GLOBAL - JAVASCRIPT
 * Funcionalidad para inputs modernos y drag & drop
 * ========================================
 */

class InputsSystem {
    constructor() {
        this.init();
    }

    init() {
        this.setupFileInputs();
        this.setupPasswordToggles();
        this.setupInputAnimations();
        console.log('✅ Sistema de Inputs inicializado');
    }

    /**
     * Configurar todos los inputs de archivo con drag and drop
     */
    setupFileInputs() {
        // Buscar todos los inputs de archivo
        const fileInputs = document.querySelectorAll('input[type="file"]');
        
        fileInputs.forEach(input => {
            this.createFileUploadContainer(input);
        });

        // Observer para nuevos inputs de archivo agregados dinámicamente
        this.observeNewFileInputs();
    }

    /**
     * Crear contenedor de drag and drop para un input de archivo
     */
    createFileUploadContainer(input) {
        // Si ya tiene contenedor, skip
        if (input.closest('.file-upload-container')) return;

        // Crear contenedor
        const container = document.createElement('div');
        container.className = 'file-upload-container';
        
        // Crear contenido del contenedor
        container.innerHTML = `
            <div class="file-upload-icon">
                <i class="fas fa-cloud-upload-alt"></i>
            </div>
            <div class="file-upload-text">
                Arrastra archivos aquí o haz clic para seleccionar
            </div>
            <div class="file-upload-hint">
                Formatos soportados: ${this.getAcceptedFormats(input)}
            </div>
            <div class="file-preview" style="display: none;"></div>
        `;

        // Insertar contenedor antes del input
        input.parentNode.insertBefore(container, input);
        container.appendChild(input);

        // Configurar eventos
        this.setupFileEvents(container, input);
    }

    /**
     * Configurar eventos de drag and drop y upload
     */
    setupFileEvents(container, input) {
        const preview = container.querySelector('.file-preview');

        // Eventos de click
        container.addEventListener('click', (e) => {
            if (!e.target.classList.contains('file-remove-btn')) {
                input.click();
            }
        });

        // Eventos de drag and drop
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            container.addEventListener(eventName, this.preventDefaults, false);
        });

        ['dragenter', 'dragover'].forEach(eventName => {
            container.addEventListener(eventName, () => {
                container.classList.add('drag-over');
            }, false);
        });

        ['dragleave', 'drop'].forEach(eventName => {
            container.addEventListener(eventName, () => {
                container.classList.remove('drag-over');
            }, false);
        });

        // Evento de drop
        container.addEventListener('drop', (e) => {
            const files = e.dataTransfer.files;
            this.handleFiles(files, input, preview);
        }, false);

        // Evento de selección de archivo
        input.addEventListener('change', (e) => {
            this.handleFiles(e.target.files, input, preview);
        });
    }

    /**
     * Prevenir comportamientos por defecto
     */
    preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    /**
     * Manejar archivos seleccionados o arrastrados
     */
    handleFiles(files, input, preview) {
        if (files.length === 0) return;

        const fileArray = Array.from(files);
        
        // Si el input acepta múltiples archivos
        if (input.multiple) {
            this.displayMultipleFiles(fileArray, preview, input);
        } else {
            // Solo tomar el primer archivo
            this.displaySingleFile(fileArray[0], preview, input);
        }

        // Actualizar el input con los archivos
        this.updateInputFiles(input, fileArray);
    }

    /**
     * Mostrar vista previa de un solo archivo
     */
    displaySingleFile(file, preview, input) {
        preview.style.display = 'block';
        preview.innerHTML = `
            <div class="file-preview-item">
                <div>
                    <i class="fas fa-file"></i>
                    <span>${file.name}</span>
                    <small>(${this.formatFileSize(file.size)})</small>
                </div>
                <button type="button" class="file-remove-btn" onclick="inputsSystem.removeFile(this, '${input.id}')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
    }

    /**
     * Mostrar vista previa de múltiples archivos
     */
    displayMultipleFiles(files, preview, input) {
        preview.style.display = 'block';
        preview.innerHTML = files.map((file, index) => `
            <div class="file-preview-item" data-file-index="${index}">
                <div>
                    <i class="fas fa-file"></i>
                    <span>${file.name}</span>
                    <small>(${this.formatFileSize(file.size)})</small>
                </div>
                <button type="button" class="file-remove-btn" onclick="inputsSystem.removeFileFromMultiple(this, '${input.id}', ${index})">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `).join('');
    }

    /**
     * Remover archivo (input simple)
     */
    removeFile(button, inputId) {
        const input = document.getElementById(inputId);
        const container = input.closest('.file-upload-container');
        const preview = container.querySelector('.file-preview');
        
        input.value = '';
        preview.style.display = 'none';
        preview.innerHTML = '';
    }

    /**
     * Remover archivo de input múltiple
     */
    removeFileFromMultiple(button, inputId, fileIndex) {
        const input = document.getElementById(inputId);
        const container = input.closest('.file-upload-container');
        const preview = container.querySelector('.file-preview');
        
        // Remover elemento de la vista
        button.closest('.file-preview-item').remove();
        
        // Si no quedan archivos, ocultar preview
        if (preview.children.length === 0) {
            preview.style.display = 'none';
        }

        // Actualizar input (esto es más complejo con FileList)
        this.updateMultipleFileInput(input, fileIndex);
    }

    /**
     * Actualizar input con archivos (para inputs múltiples)
     */
    updateMultipleFileInput(input, removeIndex) {
        // Crear un nuevo FileList sin el archivo removido
        const dt = new DataTransfer();
        const files = Array.from(input.files);
        
        files.forEach((file, index) => {
            if (index !== removeIndex) {
                dt.items.add(file);
            }
        });
        
        input.files = dt.files;
    }

    /**
     * Actualizar archivos del input
     */
    updateInputFiles(input, files) {
        const dt = new DataTransfer();
        
        if (input.multiple) {
            files.forEach(file => dt.items.add(file));
        } else {
            if (files.length > 0) {
                dt.items.add(files[0]);
            }
        }
        
        input.files = dt.files;
    }

    /**
     * Formatear tamaño de archivo
     */
    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    /**
     * Obtener formatos aceptados del input
     */
    getAcceptedFormats(input) {
        const accept = input.getAttribute('accept');
        if (!accept) return 'Todos los archivos';
        
        return accept.split(',').map(format => format.trim()).join(', ');
    }

    /**
     * Observer para nuevos inputs de archivo
     */
    observeNewFileInputs() {
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                mutation.addedNodes.forEach((node) => {
                    if (node.nodeType === 1) { // Element node
                        // Buscar inputs de archivo en el nodo agregado
                        const fileInputs = node.querySelectorAll ? 
                            node.querySelectorAll('input[type="file"]') : [];
                        
                        fileInputs.forEach(input => {
                            this.createFileUploadContainer(input);
                        });

                        // Si el nodo mismo es un input de archivo
                        if (node.tagName === 'INPUT' && node.type === 'file') {
                            this.createFileUploadContainer(node);
                        }
                    }
                });
            });
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    /**
     * Configurar toggles de contraseña
     */
    setupPasswordToggles() {
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('password-toggle-icon') || 
                e.target.closest('.password-toggle-icon')) {
                
                const icon = e.target.classList.contains('password-toggle-icon') ? 
                    e.target : e.target.closest('.password-toggle-icon');
                
                const input = icon.previousElementSibling;
                
                if (input && input.type === 'password') {
                    input.type = 'text';
                    icon.innerHTML = '<i class="fas fa-eye-slash"></i>';
                } else if (input && input.type === 'text') {
                    input.type = 'password';
                    icon.innerHTML = '<i class="fas fa-eye"></i>';
                }
            }
        });
    }

    /**
     * Configurar animaciones de inputs
     */
    setupInputAnimations() {
        document.addEventListener('focus', (e) => {
            if (this.isStyledInput(e.target)) {
                e.target.style.animationPlayState = 'paused';
            }
        }, true);

        document.addEventListener('blur', (e) => {
            if (this.isStyledInput(e.target)) {
                e.target.style.animationPlayState = 'running';
            }
        }, true);
    }

    /**
     * Verificar si es un input con estilo
     */
    isStyledInput(element) {
        return element.tagName === 'INPUT' && 
               !element.type.match(/file|checkbox|radio/) ||
               element.tagName === 'SELECT' ||
               element.tagName === 'TEXTAREA' ||
               element.classList.contains('form-control');
    }
}

// Inicializar sistema cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    window.inputsSystem = new InputsSystem();
});

// Exportar para uso modular si es necesario
if (typeof module !== 'undefined' && module.exports) {
    module.exports = InputsSystem;
}
