document.addEventListener("DOMContentLoaded", function() {
    const section = document.querySelector('.floating-elements-section');
    if (!section) return;
    const elements = Array.from(section.querySelectorAll('.floating-element'));
    const sectionRect = () => section.getBoundingClientRect();

    // Inicializar posiciones y velocidades
    const balls = elements.map((el, i) => {
        // Tamaño
        const w = el.offsetWidth;
        const h = el.offsetHeight;
        // Posición inicial aleatoria dentro del contenedor
        const secRect = sectionRect();
        let x = Math.random() * (secRect.width - w);
        let y = Math.random() * (secRect.height - h);
        // Velocidad aleatoria
        let dx = (Math.random() - 0.5) * 1.5;
        let dy = (Math.random() - 0.5) * 1.5;
        // Asignar posición inicial
        el.style.left = x + "px";
        el.style.top = y + "px";
        el.style.right = "";
        el.style.bottom = "";
        el.style.transition = "none";
        return {el, x, y, dx, dy, w, h};
    });

    function animate() {
        const secRect = sectionRect();
        // Mover cada bola
        for (let i = 0; i < balls.length; i++) {
            let b = balls[i];
            b.x += b.dx;
            b.y += b.dy;

            // Rebote en bordes
            if (b.x <= 0 || b.x + b.w >= secRect.width) b.dx *= -1;
            if (b.y <= 0 || b.y + b.h >= secRect.height) b.dy *= -1;

            // Colisiones con otras bolas
            for (let j = i + 1; j < balls.length; j++) {
                let b2 = balls[j];
                let dx = (b.x + b.w/2) - (b2.x + b2.w/2);
                let dy = (b.y + b.h/2) - (b2.y + b2.h/2);
                let dist = Math.sqrt(dx*dx + dy*dy);
                let minDist = (b.w + b2.w) / 2 * 0.9; // 0.9 para que no se peguen
                if (dist < minDist) {
                    // Intercambiar velocidades (rebote simple)
                    let tempDx = b.dx;
                    let tempDy = b.dy;
                    b.dx = b2.dx;
                    b.dy = b2.dy;
                    b2.dx = tempDx;
                    b2.dy = tempDy;
                    // Separar un poco para evitar que se queden pegados
                    let angle = Math.atan2(dy, dx);
                    let overlap = minDist - dist;
                    b.x += Math.cos(angle) * (overlap/2);
                    b.y += Math.sin(angle) * (overlap/2);
                    b2.x -= Math.cos(angle) * (overlap/2);
                    b2.y -= Math.sin(angle) * (overlap/2);
                }
            }

            // Aplicar nueva posición
            b.el.style.left = b.x + "px";
            b.el.style.top = b.y + "px";
        }
        requestAnimationFrame(animate);
    }
    animate();
});