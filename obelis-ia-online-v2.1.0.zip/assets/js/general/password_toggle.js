// assets/js/general/password_toggle.js

document.addEventListener("DOMContentLoaded", function() {
    // Selecciona todos los iconos de alternancia de contraseña
    const togglePasswordIcons = document.querySelectorAll(".password-toggle-icon");

    togglePasswordIcons.forEach(icon => {
        icon.addEventListener("click", function() {
            // Obtiene el ID del input al que este icono está asociado
            const targetInputId = this.dataset.target;
            const passwordInput = document.getElementById(targetInputId);

            if (passwordInput) {
                // Cambia el tipo de input entre 'password' y 'text'
                const type = passwordInput.getAttribute("type") === "password" ? "text" : "password";
                passwordInput.setAttribute("type", type);

                // Cambia el icono visible (visibility/visibility_off)
                this.textContent = (type === "password") ? "visibility" : "visibility_off";
            }
        });
    });
});