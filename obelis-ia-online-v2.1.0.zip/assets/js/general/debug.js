console.log('=== TEST DE FUNCIONALIDADES ===');

// Test 1: Verificar carga de Bootstrap
setTimeout(() => {
  if (typeof bootstrap !== 'undefined') {
    console.log('✅ Bootstrap cargado correctamente');
  } else {
    console.error('❌ Bootstrap no está disponible');
  }
}, 1000);

// Test 2: Verificar botones de modo oscuro
setTimeout(() => {
  const darkModeButtons = document.querySelectorAll('.toggle-darkmode-btn');
  console.log(`✅ Encontrados ${darkModeButtons.length} botones de modo oscuro`);
  
  if (darkModeButtons.length > 0) {
    darkModeButtons.forEach((btn, index) => {
      console.log(`  - Botón ${index + 1}: ${btn.className}`);
    });
  }
}, 1500);

// Test 3: Verificar modal de cookies
setTimeout(() => {
  const cookieModal = document.getElementById('cookieConsentModal');
  if (cookieModal) {
    console.log('✅ Modal de cookies encontrado');
    
    const acceptBtn = document.getElementById('acceptCookiesButton');
    if (acceptBtn) {
      console.log('✅ Botón de aceptar cookies encontrado');
    } else {
      console.error('❌ Botón de aceptar cookies no encontrado');
    }
  } else {
    console.error('❌ Modal de cookies no encontrado');
  }
}, 2000);

// Test 4: Verificar estado de localStorage
setTimeout(() => {
  const darkMode = localStorage.getItem('darkMode');
  const cookiesAccepted = localStorage.getItem('cookieAccepted');
  
  console.log('📊 Estado del localStorage:');
  console.log(`  - Modo oscuro: ${darkMode}`);
  console.log(`  - Cookies aceptadas: ${cookiesAccepted}`);
}, 2500);

// Test 5: Simular click en modo oscuro (solo para testing)
window.testDarkMode = function() {
  console.log('🧪 Probando modo oscuro...');
  const btn = document.querySelector('.toggle-darkmode-btn');
  if (btn) {
    btn.click();
    console.log('✅ Click simulado en modo oscuro');
  } else {
    console.error('❌ No se pudo encontrar botón de modo oscuro');
  }
};

// Test 6: Resetear cookies para testing
window.resetCookies = function() {
  console.log('🧪 Reseteando cookies...');
  if (window.CookieModal) {
    window.CookieModal.reset();
  } else {
    localStorage.removeItem('cookieAccepted');
    localStorage.removeItem('cookieSettings');
    console.log('✅ Cookies reseteadas - recarga la página para ver el modal');
  }
};

// Test 7: Mostrar modal de cookies manualmente
window.showCookieModal = function() {
  console.log('🧪 Mostrando modal de cookies...');
  if (window.CookieModal) {
    window.CookieModal.show();
  } else {
    console.error('❌ CookieModal no está disponible');
  }
};

// Test 8: Verificar estado de cookies
window.checkCookieStatus = function() {
  console.log('🧪 Verificando estado de cookies...');
  if (window.CookieModal) {
    window.CookieModal.status();
  } else {
    const accepted = localStorage.getItem('cookieAccepted');
    const settings = localStorage.getItem('cookieSettings');
    console.log('🍪 Estado actual:', {
      accepted: accepted,
      settings: settings ? JSON.parse(settings) : null
    });
  }
};

console.log('=== COMANDOS DE TESTING DISPONIBLES ===');
console.log('- testDarkMode() - Probar modo oscuro');
console.log('- resetCookies() - Resetear cookies y mostrar modal');
console.log('- showCookieModal() - Mostrar modal de cookies manualmente');
console.log('- checkCookieStatus() - Verificar estado actual de cookies');
console.log('==========================================');
