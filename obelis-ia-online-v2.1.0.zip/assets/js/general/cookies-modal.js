// cookies-modal.js - Sistema de modal de cookies
(function() {
    'use strict';
    
    console.log('🍪 Cookie Modal System cargado');
    
    // Configuración
    const CONFIG = {
        modalId: 'cookieConsentModal',
        acceptButtonId: 'acceptCookiesButton',
        settingsButtonClass: 'btn-cookie-settings',
        storageKey: 'cookieAccepted',
        settingsKey: 'cookieSettings'
    };
    
    // Estado
    let modal = null;
    let modalElement = null;
    
    // Inicialización cuando el DOM esté listo
    function init() {
        console.log('🍪 Inicializando sistema de cookies...');
        
        // Verificar dependencias
        if (!checkDependencies()) {
            return;
        }
        
        // Obtener elementos
        if (!getElements()) {
            return;
        }
        
        // Configurar eventos
        setupEvents();
        
        // Mostrar modal si es necesario
        showModalIfNeeded();
        
        console.log('🍪 Sistema de cookies inicializado correctamente');
    }
    
    // Verificar que Bootstrap esté disponible
    function checkDependencies() {
        if (typeof bootstrap === 'undefined') {
            console.error('❌ Bootstrap no está disponible para el modal de cookies');
            return false;
        }
        console.log('✅ Bootstrap disponible');
        return true;
    }
    
    // Obtener elementos del DOM
    function getElements() {
        modalElement = document.getElementById(CONFIG.modalId);
        if (!modalElement) {
            console.error(`❌ Modal de cookies no encontrado: #${CONFIG.modalId}`);
            return false;
        }
        
        console.log('✅ Modal de cookies encontrado');
        return true;
    }
    
    // Configurar eventos de los botones
    function setupEvents() {
        // Botón de aceptar
        const acceptBtn = document.getElementById(CONFIG.acceptButtonId);
        if (acceptBtn) {
            acceptBtn.addEventListener('click', handleAcceptCookies);
            console.log('✅ Evento del botón "Aceptar" configurado');
        } else {
            console.error(`❌ Botón de aceptar no encontrado: #${CONFIG.acceptButtonId}`);
        }
        
        // Botón de configuración
        const settingsBtn = document.querySelector(`.${CONFIG.settingsButtonClass}`);
        if (settingsBtn) {
            settingsBtn.addEventListener('click', handleConfigureCookies);
            console.log('✅ Evento del botón "Configurar" configurado');
        } else {
            console.error(`❌ Botón de configurar no encontrado: .${CONFIG.settingsButtonClass}`);
        }
    }
    
    // Verificar si se debe mostrar el modal
    function showModalIfNeeded() {
        const hasAccepted = localStorage.getItem(CONFIG.storageKey);
        console.log('🍪 ¿Cookies ya aceptadas?', hasAccepted);
        
        if (!hasAccepted) {
            showModal();
        } else {
            console.log('🍪 Cookies ya aceptadas, no se muestra el modal');
        }
    }
    
    // Mostrar el modal
    function showModal() {
        try {
            modal = new bootstrap.Modal(modalElement, {
                backdrop: 'static',
                keyboard: false
            });
            
            console.log('🍪 Mostrando modal de cookies...');
            modal.show();
            
            // Evento cuando se muestre el modal
            modalElement.addEventListener('shown.bs.modal', function() {
                console.log('🍪 Modal de cookies mostrado correctamente');
            });
            
        } catch (error) {
            console.error('❌ Error al mostrar modal de cookies:', error);
        }
    }
    
    // Ocultar el modal
    function hideModal() {
        if (modal) {
            modal.hide();
        } else {
            // Intentar obtener instancia existente
            const existingModal = bootstrap.Modal.getInstance(modalElement);
            if (existingModal) {
                existingModal.hide();
            }
        }
    }
    
    // Manejar aceptación de todas las cookies
    function handleAcceptCookies() {
        console.log('🍪 Usuario aceptó todas las cookies');
        
        // Guardar configuración
        localStorage.setItem(CONFIG.storageKey, 'true');
        localStorage.setItem(CONFIG.settingsKey, JSON.stringify({
            essential: true,
            analytics: true,
            marketing: true,
            functional: true
        }));
        
        // Cerrar modal
        hideModal();
        
        // Notificación opcional
        showNotification('Cookies aceptadas', 'success');
        
        console.log('🍪 Configuración guardada: Todas las categorías activadas');
    }
    
    // Manejar configuración personalizada de cookies
    function handleConfigureCookies(e) {
        e.preventDefault();
        console.log('🍪 Usuario seleccionó configuración personalizada');
        
        // Configurar solo cookies esenciales
        localStorage.setItem(CONFIG.storageKey, 'true');
        localStorage.setItem(CONFIG.settingsKey, JSON.stringify({
            essential: true,
            analytics: false,
            marketing: false,
            functional: false
        }));
        
        // Cerrar modal
        hideModal();
        
        // Notificación opcional
        showNotification('Configuración guardada - Solo cookies esenciales', 'info');
        
        console.log('🍪 Configuración guardada: Solo cookies esenciales');
    }
    
    // Función de notificación opcional
    function showNotification(message, type) {
        if (typeof window.showNotification === 'function') {
            window.showNotification(message, type);
        } else {
            // Fallback: mostrar en consola
            console.log(`📢 ${type.toUpperCase()}: ${message}`);
        }
    }
    
    // Funciones públicas para debugging
    window.CookieModal = {
        // Resetear cookies para testing
        reset: function() {
            localStorage.removeItem(CONFIG.storageKey);
            localStorage.removeItem(CONFIG.settingsKey);
            console.log('🍪 Cookies reseteadas - recarga la página para ver el modal');
        },
        
        // Mostrar modal manualmente
        show: function() {
            showModal();
        },
        
        // Verificar estado
        status: function() {
            const accepted = localStorage.getItem(CONFIG.storageKey);
            const settings = localStorage.getItem(CONFIG.settingsKey);
            console.log('🍪 Estado actual:', {
                accepted: accepted,
                settings: settings ? JSON.parse(settings) : null
            });
        }
    };
    
    // Inicializar cuando el DOM esté listo
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
    
})();
