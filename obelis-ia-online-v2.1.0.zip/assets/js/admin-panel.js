/**
 * Admin Panel Professional JavaScript
 * Funcionalidades completas para el panel de administración
 */

class AdminPanel {
    constructor() {
        this.currentSection = 'dashboard';
        this.charts = {};
        this.tables = {};
        this.filters = {
            users: { page: 1, search: '', membership: 'all', status: 'all', orderBy: 'created_at', orderDir: 'DESC' },
            tools: { search: '', category: 'all', status: 'all', orderBy: 'name', orderDir: 'ASC', view: 'grid' },
            payments: { type: 'all', status: 'all', method: 'all', dateFrom: '', dateTo: '', page: 1 }
        };
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadDashboard();
        this.setupCharts();
        this.startRealTimeUpdates();
        // this.initializeFilters(); // Se inicializan en los setup específicos
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-link[data-section]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = link.getAttribute('data-section');
                this.showSection(section);
            });
        });

        // User filters
        this.setupUserFilters();
        
        // Tool filters
        this.setupToolFilters();
        
        // Payment filters
        this.setupPaymentFilters();
        
        // Modal events
        // Form submissions
        const userForm = document.getElementById('userForm');
        if (userForm) {
            userForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.saveUser();
            });
        }
    }

    setupUserFilters() {
        const userSearch = document.getElementById('userSearch');
        const userMembershipFilter = document.getElementById('userMembershipFilter');
        const userStatusFilter = document.getElementById('userStatusFilter');
        const userOrderBy = document.getElementById('userOrderBy');
        const userOrderDir = document.getElementById('userOrderDir');

        if (userSearch) {
            userSearch.addEventListener('input', debounce(() => {
                this.filters.users.search = userSearch.value;
                this.filters.users.page = 1;
                this.loadUsers();
            }, 300));
        }

        [userMembershipFilter, userStatusFilter, userOrderBy, userOrderDir].forEach(element => {
            if (element) {
                element.addEventListener('change', () => {
                    this.updateUserFilters();
                    this.loadUsers();
                });
            }
        });

        // Select all users checkbox
        const selectAllUsers = document.getElementById('selectAllUsers');
        if (selectAllUsers) {
            selectAllUsers.addEventListener('change', (e) => {
                const checkboxes = document.querySelectorAll('input[name="selectedUsers"]');
                checkboxes.forEach(cb => cb.checked = e.target.checked);
            });
        }
    }

    setupToolFilters() {
        const toolSearch = document.getElementById('toolSearch');
        const toolCategoryFilter = document.getElementById('toolCategoryFilter');
        const toolStatusFilter = document.getElementById('toolStatusFilter');
        const toolOrderBy = document.getElementById('toolOrderBy');

        if (toolSearch) {
            toolSearch.addEventListener('input', debounce(() => {
                this.filters.tools.search = toolSearch.value;
                this.loadTools();
            }, 300));
        }

        [toolCategoryFilter, toolStatusFilter, toolOrderBy].forEach(element => {
            if (element) {
                element.addEventListener('change', () => {
                    this.updateToolFilters();
                    this.loadTools();
                });
            }
        });

        // Tool view toggle
        const toolViewInputs = document.querySelectorAll('input[name="toolView"]');
        toolViewInputs.forEach(input => {
            input.addEventListener('change', (e) => {
                this.filters.tools.view = e.target.value;
                this.toggleToolView(e.target.value);
                this.loadTools();
            });
        });
    }

    setupPaymentFilters() {
        const paymentTypeFilter = document.getElementById('paymentTypeFilter');
        const paymentStatusFilter = document.getElementById('paymentStatusFilter');
        const paymentMethodFilter = document.getElementById('paymentMethodFilter');
        const paymentDateFrom = document.getElementById('paymentDateFrom');
        const paymentDateTo = document.getElementById('paymentDateTo');

        [paymentTypeFilter, paymentStatusFilter, paymentMethodFilter].forEach(element => {
            if (element) {
                element.addEventListener('change', () => {
                    this.updatePaymentFilters();
                    this.loadPayments();
                });
            }
        });

        [paymentDateFrom, paymentDateTo].forEach(element => {
            if (element) {
                element.addEventListener('change', () => {
                    this.updatePaymentFilters();
                    this.loadPayments();
                });
            }
        });
    }

    updateUserFilters() {
        this.filters.users.membership = document.getElementById('userMembershipFilter')?.value || 'all';
        this.filters.users.status = document.getElementById('userStatusFilter')?.value || 'all';
        this.filters.users.orderBy = document.getElementById('userOrderBy')?.value || 'created_at';
        this.filters.users.orderDir = document.getElementById('userOrderDir')?.value || 'DESC';
        this.filters.users.page = 1;
    }

    updateToolFilters() {
        this.filters.tools.category = document.getElementById('toolCategoryFilter')?.value || 'all';
        this.filters.tools.status = document.getElementById('toolStatusFilter')?.value || 'all';
        this.filters.tools.orderBy = document.getElementById('toolOrderBy')?.value || 'name';
    }

    updatePaymentFilters() {
        this.filters.payments.type = document.getElementById('paymentTypeFilter')?.value || 'all';
        this.filters.payments.status = document.getElementById('paymentStatusFilter')?.value || 'all';
        this.filters.payments.method = document.getElementById('paymentMethodFilter')?.value || 'all';
        this.filters.payments.dateFrom = document.getElementById('paymentDateFrom')?.value || '';
        this.filters.payments.dateTo = document.getElementById('paymentDateTo')?.value || '';
        this.filters.payments.page = 1;
    }

    showSection(sectionName) {
        // Hide all sections
        document.querySelectorAll('.admin-section').forEach(section => {
            section.classList.remove('active');
        });

        // Remove active from nav links
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });

        // Show selected section
        const targetSection = document.getElementById(`${sectionName}-section`);
        if (targetSection) {
            targetSection.classList.add('active');
        }

        // Add active to nav link
        const targetNav = document.querySelector(`[data-section="${sectionName}"]`);
        if (targetNav) {
            targetNav.classList.add('active');
        }

        // Load section data
        this.loadSectionData(sectionName);
        this.currentSection = sectionName;
    }

    loadSectionData(section) {
        switch (section) {
            case 'dashboard':
                this.loadDashboard();
                break;
            case 'users':
                this.loadUsers();
                break;
            case 'tools':
                this.loadTools();
                break;
            case 'payments':
                this.loadPayments();
                this.loadFinancialData();
                break;
            case 'settings':
                this.loadSettings();
                break;
        }
    }

    async loadDashboard() {
        try {
            // Esta es la lógica del script simple, ahora en el lugar correcto.
            const response = await fetch('/admin/ajax/dashboard/index.php');
            const data = await response.json();

            if (data.success) {
                const stats = data.stats;
                document.getElementById('total-users').textContent = stats.totalUsers || stats.total_users || '0';
                document.getElementById('total-payments').textContent = stats.totalPayments || stats.total_payments || '0';
                document.getElementById('total-tools').textContent = stats.totalTools || stats.total_tools || '0';
                document.getElementById('total-revenue').textContent = '$' + (stats.monthlyRevenue || stats.total_revenue || '0');
            } else {
                console.error('Error en la respuesta del servidor:', data.message);
                this.showAlert('error', 'No se pudieron cargar las estadísticas del dashboard.');
            }
        } catch (error) {
            console.error('Error de red o JSON al cargar las estadísticas:', error);
            this.showAlert('error', 'Fallo de conexión al cargar estadísticas.');
            document.getElementById('total-users').textContent = 'Error';
            document.getElementById('total-payments').textContent = 'Error';
            document.getElementById('total-tools').textContent = 'Error';
            document.getElementById('total-revenue').textContent = 'Error';
        }
    }

    async loadUsers() {
        try {
            const params = new URLSearchParams(this.filters.users);
            const response = await fetch(`/admin/ajax/users/?${params}`);
            const data = await response.json();

            if (data.success) {
                this.renderUsersTable(data.data);
                this.renderUserPagination(data.pagination);
                this.updateUserCount(data.pagination.total_records);
            } else {
                this.showAlert('error', data.message);
            }
        } catch (error) {
            console.error('Error loading users:', error);
            this.showAlert('error', 'Error al cargar usuarios');
        }
    }

    renderUsersTable(users) {
        const tbody = document.querySelector('#users-table tbody');
        if (!tbody) return;

        tbody.innerHTML = users.map(user => `
            <tr>
                <td><input type="checkbox" name="selectedUsers" value="${user.id}" class="form-check-input"></td>
                <td>${user.id}</td>
                <td>
                    <div class="d-flex align-items-center">
                        <div class="avatar-sm bg-primary rounded-circle d-flex align-items-center justify-content-center me-2">
                            <i class="fas fa-user text-white"></i>
                        </div>
                        <div>
                            <div class="fw-bold">${user.username}</div>
                            <small class="text-muted">${user.email_verified ? '<i class="fas fa-check-circle text-success"></i>' : '<i class="fas fa-exclamation-circle text-warning"></i>'}</small>
                        </div>
                    </div>
                </td>
                <td>${user.email}</td>
                <td>${user.full_name}</td>
                <td>${user.membership_badge}</td>
                <td>
                    <span class="badge bg-info">${user.credits_remaining}</span>
                    <div class="progress mt-1" style="height: 3px;">
                        <div class="progress-bar" style="width: ${Math.min((user.credits_remaining / 1000) * 100, 100)}%"></div>
                    </div>
                </td>
                <td>${user.status_badge}</td>
                <td>
                    <small class="text-muted">${user.last_login_formatted}</small>
                </td>
                <td>
                    <small class="text-muted">${user.created_at_formatted}</small>
                </td>
                <td>
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-primary" onclick="adminPanel.editUser(${user.id})" title="Editar">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-outline-info" onclick="adminPanel.viewUserStats(${user.id})" title="Estadísticas">
                            <i class="fas fa-chart-line"></i>
                        </button>
                        <button class="btn btn-outline-${user.status === 'active' ? 'warning' : 'success'}" 
                                onclick="adminPanel.toggleUserStatus(${user.id}, '${user.status}')" 
                                title="${user.status === 'active' ? 'Suspender' : 'Activar'}">
                            <i class="fas fa-${user.status === 'active' ? 'ban' : 'check'}"></i>
                        </button>
                        <button class="btn btn-outline-danger" onclick="adminPanel.deleteUser(${user.id})" title="Eliminar">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    updateUserCount(total) {
        const countElement = document.getElementById('user-count-display');
        if (countElement) {
            const { page, limit } = this.filters.users;
            const start = total > 0 ? (page - 1) * limit + 1 : 0;
            const end = Math.min(page * limit, total);
            countElement.textContent = total > 0 ? `Mostrando ${start}-${end} de ${total} usuarios` : 'No se encontraron usuarios.';
        }
    }

    renderUserPagination(pagination) {
        const container = document.getElementById('users-pagination');
        if (!container) return;

        const { current_page, total_pages, has_prev, has_next } = pagination;

        if (total_pages <= 1) {
            container.innerHTML = '';
            return;
        }

        let paginationHtml = '<ul class="pagination justify-content-end">';

        // Previous button
        paginationHtml += `<li class="page-item ${!has_prev ? 'disabled' : ''}">
            <a class="page-link" href="#" data-page="${current_page - 1}">Anterior</a>
        </li>`;

        // Page numbers
        for (let i = 1; i <= total_pages; i++) {
            if (i === current_page) {
                paginationHtml += `<li class="page-item active"><span class="page-link">${i}</span></li>`;
            } else {
                paginationHtml += `<li class="page-item"><a class="page-link" href="#" data-page="${i}">${i}</a></li>`;
            }
        }

        // Next button
        paginationHtml += `<li class="page-item ${!has_next ? 'disabled' : ''}">
            <a class="page-link" href="#" data-page="${current_page + 1}">Siguiente</a>
        </li>`;

        paginationHtml += '</ul>';
        container.innerHTML = paginationHtml;

        // Add event listeners to new pagination links
        container.querySelectorAll('.page-link[data-page]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const page = parseInt(link.getAttribute('data-page'));
                if (page !== this.filters.users.page) {
                    this.filters.users.page = page;
                    this.loadUsers();
                }
            });
        });
    }

    async loadTools() {
        try {
            const params = new URLSearchParams(this.filters.tools);
            const response = await fetch(`/admin/ajax/tools/index.php?${params}`);
            const data = await response.json();

            if (data.success) {
                if (this.filters.tools.view === 'grid') {
                    this.renderToolsGrid(data.data);
                } else {
                    this.renderToolsList(data.data);
                }
                this.updateToolCount(data.stats.total_tools);
            } else {
                this.showAlert('error', data.message);
            }
        } catch (error) {
            console.error('Error loading tools:', error);
            this.showAlert('error', 'Error al cargar herramientas');
        }
    }

    renderToolsList(tools) {
        // Placeholder implementation for list view
        const container = document.getElementById('tools-container');
        if (!container) return;
        container.innerHTML = `<div class="alert alert-info">La vista de lista aún no está implementada.</div>`;
    }

    updateToolCount(total) {
        const countElement = document.getElementById('tool-count-display');
        if (countElement) countElement.textContent = `Mostrando ${total} herramientas`;
    }

    renderToolsGrid(tools) {
        const container = document.getElementById('tools-container');
        if (!container) return;

        container.innerHTML = tools.map(tool => `
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card tool-card h-100" style="border-left: 4px solid ${tool.color}">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <div class="d-flex align-items-center">
                                <div class="tool-icon me-3" style="color: ${tool.color}">
                                    <i class="${tool.icon} fa-2x"></i>
                                </div>
                                <div>
                                    <h6 class="card-title mb-1">${tool.name}</h6>
                                    ${tool.category_badge}
                                </div>
                            </div>
                            <div class="dropdown">
                                <button class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">
                                    <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="#" onclick="adminPanel.editTool(${tool.id})">
                                        <i class="fas fa-edit me-2"></i>Editar
                                    </a></li>
                                    <li><a class="dropdown-item" href="#" onclick="adminPanel.toggleTool(${tool.id})">
                                        <i class="fas fa-toggle-on me-2"></i>Toggle Estado
                                    </a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item text-danger" href="#" onclick="adminPanel.deleteTool(${tool.id})">
                                        <i class="fas fa-trash me-2"></i>Eliminar
                                    </a></li>
                                </ul>
                            </div>
                        </div>
                        <p class="card-text text-muted small">${tool.description}</p>
                        <div class="row text-center mt-3">
                            <div class="col-4">
                                <div class="fw-bold">${tool.total_uses}</div>
                                <small class="text-muted">Total</small>
                            </div>
                            <div class="col-4">
                                <div class="fw-bold">${tool.monthly_uses}</div>
                                <small class="text-muted">Mes</small>
                            </div>
                            <div class="col-4">
                                <div class="fw-bold">${tool.credits_required}</div>
                                <small class="text-muted">Créditos</small>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="d-flex justify-content-between align-items-center">
                            ${tool.status_badge}
                            <div class="d-flex align-items-center">
                                <div class="me-2">
                                    ${[...Array(5)].map((_, i) => 
                                        `<i class="fas fa-star ${i < Math.floor(tool.avg_rating) ? 'text-warning' : 'text-muted'}" style="font-size: 0.8rem;"></i>`
                                    ).join('')}
                                </div>
                                <small class="text-muted">(${tool.rating_count})</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `).join('');
    }

    async loadPayments() {
        try {
            const params = new URLSearchParams(this.filters.payments);
            const response = await fetch(`/admin/ajax/payments/index.php?${params}`);
            const data = await response.json();

            if (data.success) {
                this.renderPaymentsTable(data.data);
                this.renderPaymentPagination(data.pagination);
                this.updatePaymentStats(data.stats);
            } else {
                this.showAlert('error', data.message);
            }
        } catch (error) {
            console.error('Error loading payments:', error);
            this.showAlert('error', 'Error al cargar pagos');
        }
    }

    renderPaymentsTable(payments) {
        const tbody = document.querySelector('#payments-table tbody');
        if (!tbody) return;
        tbody.innerHTML = `<tr><td colspan="8" class="text-center">Funcionalidad de pagos no implementada.</td></tr>`;
    }

    renderPaymentPagination(pagination) {
        const container = document.getElementById('payments-pagination');
        if (!container) return;
        container.innerHTML = ''; // Placeholder
    }

    updatePaymentStats(stats) {
        // Placeholder
        console.log('Updating payment stats:', stats);
    }


    async loadFinancialData() {
        try {
            // Cargar resumen financiero
            const summaryResponse = await fetch('/admin/ajax/financial/index.php?endpoint=summary');
            const summaryData = await summaryResponse.json();
            
            if (summaryData.success) {
                this.updateFinancialSummary(summaryData.summary);
            }

            // Cargar flujo de caja
            const cashFlowResponse = await fetch('/admin/ajax/financial/index.php?endpoint=cash_flow&period=6months');
            const cashFlowData = await cashFlowResponse.json();
            
            if (cashFlowData.success) {
                this.updateCashFlowChart(cashFlowData.cash_flow);
            }

            // Cargar distribución de ingresos
            const revenueResponse = await fetch('/admin/ajax/financial/index.php?endpoint=revenue_distribution');
            const revenueData = await revenueResponse.json();
            
            if (revenueData.success) {
                this.updateRevenueChart(revenueData.revenue_distribution);
            }

        } catch (error) {
            console.error('Error loading financial data:', error);
        }
    }

    updateFinancialSummary(summary) {
        document.getElementById('total-income').textContent = `$${summary.total_income?.toLocaleString() || '0'}`;
        document.getElementById('total-expenses').textContent = `$${summary.total_expenses?.toLocaleString() || '0'}`;
        document.getElementById('net-profit').textContent = `$${summary.net_profit?.toLocaleString() || '0'}`;
        document.getElementById('active-subscriptions').textContent = summary.active_subscriptions || '0';
        
        document.getElementById('income-growth').textContent = `${summary.income_growth > 0 ? '+' : ''}${summary.income_growth}% este mes`;
        document.getElementById('profit-margin').textContent = `${summary.profit_margin}% margen`;
    }

    updateCashFlowChart(data) {
        console.log("Updating cash flow chart with data:", data);
        // Placeholder for chart implementation
    }

    updateRevenueChart(data) {
        console.log("Updating revenue chart with data:", data);
        // Placeholder for chart implementation
    }

    async loadSettings() {
        console.log("Loading settings...");
        // Placeholder for loading settings
    }

    // Modal functions
    showAddUserModal() {
        document.getElementById('userModalTitle').textContent = 'Nuevo Usuario';
        document.getElementById('userForm').reset();
        document.getElementById('userId').value = '';
        document.getElementById('passwordSection').style.display = 'block';
        document.getElementById('userStatsCard').style.display = 'none';
        document.getElementById('sendWelcomeEmail').style.display = 'none';
        
        new bootstrap.Modal(document.getElementById('userModal')).show();
    }

    showAddToolModal() {
        document.getElementById('toolModalTitle').textContent = 'Nueva Herramienta';
        document.getElementById('toolForm').reset();
        document.getElementById('toolId').value = '';

        new bootstrap.Modal(document.getElementById('toolModal')).show();
    }

    async saveUser() {
        const form = document.getElementById('userForm');
        const formData = new FormData(form); // El botón submit está dentro del form, no necesitamos buscarlo por separado
        const submitButton = form.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        submitButton.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Guardando...';

        // Obtenemos el token CSRF de la meta etiqueta para mayor consistencia.
        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
        const data = Object.fromEntries(formData.entries());
        data.action = 'save'; // Acción para el switch en actions.php
        data.csrf_token = csrfToken; // Añadimos el token a los datos que se enviarán.

        if (!csrfToken) {
            this.showAlert('error', 'Token de seguridad no encontrado. Por favor, recarga la página.');
            submitButton.disabled = false;
            submitButton.innerHTML = 'Guardar Cambios';
            return;
        }
 
        try {
            const response = await fetch('/admin/ajax/users/', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            const result = await response.json();
            this.showAlert(result.success ? 'success' : 'error', result.message);

            if (result.success) {
                // Corregimos cómo se oculta el modal
                const modalEl = document.getElementById('userModal');
                const modalInstance = bootstrap.Modal.getInstance(modalEl);
                if (modalInstance) {
                    modalInstance.hide();
                }
                this.loadUsers();
            }
        } catch (error) {
            this.showAlert('error', 'Error de conexión al guardar el usuario.');
        } finally {
            submitButton.disabled = false;
            submitButton.innerHTML = 'Guardar Cambios';
        }
    }

    showPremiumPriceModal() {
        this.loadPremiumSettings();
        if (this.modals.premiumPrice) this.modals.premiumPrice.show();
    }

    async loadPremiumSettings() {
        try {
            const response = await fetch('/admin/ajax/settings/index.php');
            const data = await response.json();
            
            if (data.success) {
                const settings = data.settings;
                document.getElementById('monthlyPrice').value = settings.monthly_price;
                document.getElementById('yearlyPrice').value = settings.yearly_price;
                document.getElementById('premiumCredits').value = settings.premium_credits;
                document.getElementById('enterprisePrice').value = settings.enterprise_price;
                document.getElementById('premiumFeatures').value = settings.premium_features;
                document.getElementById('enableTrial').checked = settings.enable_trial;
                document.getElementById('trialDays').value = settings.trial_days;
            }
        } catch (error) {
            console.error('Error loading premium settings:', error);
        }
    }

    async savePremiumPrices() {
        try {
            const formData = new FormData(document.getElementById('premiumPriceForm'));
            const data = Object.fromEntries(formData.entries());
            
            if (document.getElementById('enableTrial').checked) {
                data.enable_trial = true;
            }

            const response = await fetch('/admin/ajax/settings/index.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });

            const result = await response.json();
            
            if (result.success) {
                this.showAlert('success', result.message);
                bootstrap.Modal.getInstance(document.getElementById('premiumPriceModal')).hide();
            } else {
                this.showAlert('error', result.message);
            }
        } catch (error) {
            console.error('Error saving premium prices:', error);
            this.showAlert('error', 'Error al guardar configuración');
        }
    }

    // Utility functions
    showAlert(type, message) {
        // Implementation for showing alerts
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type === 'error' ? 'danger' : 'success'} alert-dismissible fade show position-fixed`;
        alertDiv.style.cssText = 'top: 20px; right: 20px; z-index: 9999; max-width: 400px;';
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        document.body.appendChild(alertDiv);
        
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.parentNode.removeChild(alertDiv);
            }
        }, 5000);
    }

    toggleToolView(view) {
        const gridView = document.getElementById('tools-grid-view');
        const listView = document.getElementById('tools-list-view');
        
        if (view === 'grid') {
            gridView.style.display = 'block';
            listView.style.display = 'none';
        } else {
            gridView.style.display = 'none';
            listView.style.display = 'block';
        }
    }

    // Placeholder functions for additional features
    resetUserFilters() { /* Implementation */ }
    resetToolFilters() { console.log('Resetting tool filters'); }
    
    async editUser(id) { 
        try {
            const response = await fetch(`/admin/ajax/users/?action=get_details&id=${id}`);
            const result = await response.json();
            if (!result.success) {
                this.showAlert('error', result.message);
                return;
            }
            const user = result.user;
            
            // Populate and show modal
            document.getElementById('userModalTitle').textContent = `Editar Usuario: ${user.username}`;
            document.getElementById('userForm').reset();
            document.getElementById('userId').value = user.id;
            document.getElementById('username').value = user.username;
            document.getElementById('email').value = user.email;
            document.getElementById('full_name').value = user.full_name;
            document.getElementById('membership_type').value = user.membership_type;
            document.getElementById('status').value = user.status;
            document.getElementById('credits_remaining').value = user.credits_remaining;
            document.getElementById('notes').value = user.notes;
            
            document.getElementById('passwordSection').style.display = 'block';
            document.querySelector('#passwordSection label').textContent = 'Nueva Contraseña (dejar en blanco para no cambiar)';

            new bootstrap.Modal(document.getElementById('userModal')).show();

        } catch (error) {
            this.showAlert('error', 'No se pudieron cargar los datos del usuario.');
        }
    }

    viewUserStats(id) {
        console.log(`Viewing stats for user ${id}`);
        this.showAlert('info', `La vista de estadísticas individuales aún no está implementada.`);
    }

    async toggleUserStatus(id, currentStatus) {
        const newStatus = currentStatus === 'active' ? 'suspender' : 'activar';
        if (!confirm(`¿Estás seguro de que quieres ${newStatus} a este usuario?`)) return;

        try {
            // Asumimos que el token CSRF está en una meta tag: <meta name="csrf-token" content="...">
            const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
            const data = {
                action: 'toggle_status',
                id: id,
                current_status: currentStatus,
                csrf_token: csrfToken
            };

            const response = await fetch('/admin/ajax/users/', { 
                method: 'POST', 
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            const result = await response.json();
            this.showAlert(result.success ? 'success' : 'error', result.message);
            if (result.success) this.loadUsers();
        } catch (error) {
            this.showAlert('error', 'Error de conexión al cambiar el estado.');
        }
    }

    async deleteUser(id) { 
        if (confirm(`¿Estás seguro de que quieres ELIMINAR al usuario ${id}? Esta acción no se puede deshacer y los datos del usuario serán anonimizados.`)) {
            try {
                // Asumimos que el token CSRF está en una meta tag: <meta name="csrf-token" content="...">
                const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
                const data = {
                    action: 'delete',
                    id: id,
                    csrf_token: csrfToken
                };

                const response = await fetch('/admin/ajax/users/', { 
                    method: 'POST', 
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                const result = await response.json();
                this.showAlert(result.success ? 'success' : 'error', result.message);
                if (result.success) this.loadUsers();
            } catch (error) {
                this.showAlert('error', 'Error de conexión al eliminar el usuario.');
            }
        }
    }

    editTool(id) { 
        console.log(`Editing tool ${id}`);
        this.showAlert('info', `Funcionalidad 'Editar Herramienta ${id}' no implementada.`);
    }

    toggleTool(id) {
        console.log(`Toggling status for tool ${id}`);
        this.showAlert('info', `Funcionalidad 'Cambiar Estado de Herramienta ${id}' no implementada.`);
    }

    deleteTool(id) { 
        console.log(`Deleting tool ${id}`);
        if (confirm(`¿Estás seguro de que quieres eliminar la herramienta ${id}?`)) {
            this.showAlert('warning', `Funcionalidad 'Eliminar Herramienta ${id}' no implementada.`);
        }
    }

    addExpense() { console.log('Adding expense'); }
    addIncome() { console.log('Adding income'); }
    setupCharts() { console.log('Setting up charts'); }
    startRealTimeUpdates() { console.log('Starting real-time updates'); }

    
    // Additional methods would be implemented here...
}

// Utility function for debouncing
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.adminPanel = new AdminPanel();
});

// Export for global access
window.AdminPanel = AdminPanel;
