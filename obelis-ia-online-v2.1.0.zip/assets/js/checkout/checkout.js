/**
 * Checkout JavaScript - ObelisIA
 * Sistema completo de procesamiento de pagos
 */

document.addEventListener('DOMContentLoaded', function() {
    initializeCheckout();
});

/**
 * Inicializar checkout
 */
function initializeCheckout() {
    console.log('🛒 Inicializando sistema de checkout');
    
    // Configurar event listeners
    setupPaymentMethodSelection();
    setupFormValidation();
    setupCardFormatting();
    setupPaymentProcessing();
    
    // Inicializar PayPal si está disponible
    if (typeof paypal !== 'undefined' && CHECKOUT_CONFIG) {
        initializePayPal();
    }
    
    // Validar formularios iniciales
    validateForms();
}

/**
 * Configurar selección de métodos de pago
 */
function setupPaymentMethodSelection() {
    const paymentMethods = document.querySelectorAll('.payment-method');
    const paymentRadios = document.querySelectorAll('input[name="payment_method"]');
    
    paymentMethods.forEach(method => {
        method.addEventListener('click', function() {
            const methodType = this.dataset.method;
            const radio = this.querySelector('input[type="radio"]');
            
            // Desactivar todos los métodos
            paymentMethods.forEach(m => m.classList.remove('active'));
            document.querySelectorAll('.payment-method-content').forEach(content => {
                content.style.display = 'none';
            });
            
            // Activar método seleccionado
            this.classList.add('active');
            radio.checked = true;
            
            const content = this.querySelector('.payment-method-content');
            if (content) {
                content.style.display = 'block';
            }
            
            // Validar formularios
            validateForms();
        });
    });
    
    // Seleccionar método por defecto
    const defaultMethod = document.querySelector('input[name="payment_method"]:checked');
    if (defaultMethod) {
        const methodContainer = defaultMethod.closest('.payment-method');
        methodContainer.classList.add('active');
        const content = methodContainer.querySelector('.payment-method-content');
        if (content) {
            content.style.display = 'block';
        }
    }
}

/**
 * Configurar validación de formularios
 */
function setupFormValidation() {
    const inputs = document.querySelectorAll('input[required], select[required]');
    
    inputs.forEach(input => {
        input.addEventListener('input', validateForms);
        input.addEventListener('blur', validateField);
    });
}

/**
 * Validar campo individual
 */
function validateField(event) {
    const field = event.target;
    const value = field.value.trim();
    
    // Remover clases de validación previas
    field.classList.remove('is-valid', 'is-invalid');
    
    let isValid = true;
    let errorMessage = '';
    
    // Validaciones específicas
    switch (field.id) {
        case 'card_number':
            isValid = validateCardNumber(value);
            errorMessage = 'Número de tarjeta inválido';
            break;
        case 'card_expiry':
            isValid = validateExpiryDate(value);
            errorMessage = 'Fecha de vencimiento inválida';
            break;
        case 'card_cvc':
            isValid = validateCVC(value);
            errorMessage = 'CVC inválido';
            break;
        case 'billing_email':
            isValid = validateEmail(value);
            errorMessage = 'Email inválido';
            break;
        default:
            isValid = value.length > 0;
            errorMessage = 'Este campo es requerido';
    }
    
    // Aplicar clases de validación
    if (isValid) {
        field.classList.add('is-valid');
    } else if (value.length > 0) {
        field.classList.add('is-invalid');
        showFieldError(field, errorMessage);
    }
}

/**
 * Mostrar error en campo
 */
function showFieldError(field, message) {
    let feedback = field.parentNode.querySelector('.invalid-feedback');
    if (!feedback) {
        feedback = document.createElement('div');
        feedback.className = 'invalid-feedback';
        field.parentNode.appendChild(feedback);
    }
    feedback.textContent = message;
}

/**
 * Configurar formateo de tarjetas
 */
function setupCardFormatting() {
    const cardNumber = document.getElementById('card_number');
    const cardExpiry = document.getElementById('card_expiry');
    const cardCVC = document.getElementById('card_cvc');
    
    if (cardNumber) {
        cardNumber.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            value = value.substring(0, 16);
            value = value.replace(/(\d{4})(?=\d)/g, '$1 ');
            e.target.value = value;
        });
    }
    
    if (cardExpiry) {
        cardExpiry.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length >= 2) {
                value = value.substring(0, 2) + '/' + value.substring(2, 4);
            }
            e.target.value = value;
        });
    }
    
    if (cardCVC) {
        cardCVC.addEventListener('input', function(e) {
            e.target.value = e.target.value.replace(/\D/g, '').substring(0, 4);
        });
    }
}

/**
 * Validar todos los formularios
 */
function validateForms() {
    const selectedMethod = document.querySelector('input[name="payment_method"]:checked').value;
    const processButton = document.getElementById('process-payment');
    
    let isValid = true;
    
    // Validar información de facturación
    const billingFields = ['billing_email', 'billing_address', 'billing_city', 'billing_country', 'billing_zip'];
    billingFields.forEach(fieldId => {
        const field = document.getElementById(fieldId);
        if (field && !field.value.trim()) {
            isValid = false;
        }
    });
    
    // Validar método de pago específico
    if (selectedMethod === 'card') {
        const cardFields = ['card_number', 'card_expiry', 'card_cvc', 'card_name'];
        cardFields.forEach(fieldId => {
            const field = document.getElementById(fieldId);
            if (field && !field.value.trim()) {
                isValid = false;
            }
        });
        
        // Validaciones específicas de tarjeta
        const cardNumber = document.getElementById('card_number').value.replace(/\s/g, '');
        const cardExpiry = document.getElementById('card_expiry').value;
        const cardCVC = document.getElementById('card_cvc').value;
        
        if (!validateCardNumber(cardNumber) || !validateExpiryDate(cardExpiry) || !validateCVC(cardCVC)) {
            isValid = false;
        }
    }
    
    // Habilitar/deshabilitar botón de pago
    processButton.disabled = !isValid;
}

/**
 * Validaciones específicas
 */
function validateCardNumber(number) {
    const cleaned = number.replace(/\s/g, '');
    return cleaned.length >= 13 && cleaned.length <= 19 && /^\d+$/.test(cleaned);
}

function validateExpiryDate(expiry) {
    if (!/^\d{2}\/\d{2}$/.test(expiry)) return false;
    
    const [month, year] = expiry.split('/').map(num => parseInt(num));
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear() % 100;
    const currentMonth = currentDate.getMonth() + 1;
    
    if (month < 1 || month > 12) return false;
    if (year < currentYear || (year === currentYear && month < currentMonth)) return false;
    
    return true;
}

function validateCVC(cvc) {
    return /^\d{3,4}$/.test(cvc);
}

function validateEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

/**
 * Configurar procesamiento de pagos
 */
function setupPaymentProcessing() {
    const processButton = document.getElementById('process-payment');
    
    processButton.addEventListener('click', function() {
        const selectedMethod = document.querySelector('input[name="payment_method"]:checked').value;
        
        if (selectedMethod === 'card') {
            processCardPayment();
        }
        // PayPal se maneja directamente con su SDK
    });
}

/**
 * Procesar pago con tarjeta
 */
async function processCardPayment() {
    showLoading(true);
    
    try {
        // Recopilar datos del formulario
        const paymentData = {
            method: 'card',
            plan: CHECKOUT_CONFIG.plan,
            billing: CHECKOUT_CONFIG.billing,
            amount: CHECKOUT_CONFIG.amount,
            currency: CHECKOUT_CONFIG.currency,
            card: {
                number: document.getElementById('card_number').value.replace(/\s/g, ''),
                expiry: document.getElementById('card_expiry').value,
                cvc: document.getElementById('card_cvc').value,
                name: document.getElementById('card_name').value
            },
            billing: {
                email: document.getElementById('billing_email').value,
                phone: document.getElementById('billing_phone').value,
                address: document.getElementById('billing_address').value,
                city: document.getElementById('billing_city').value,
                country: document.getElementById('billing_country').value,
                zip: document.getElementById('billing_zip').value
            }
        };
        
        // Enviar datos al servidor
        const response = await fetch('/ajax/payments/process_card_payment.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(paymentData)
        });
        
        const result = await response.json();
        
        if (result.success) {
            showSuccess('¡Pago procesado exitosamente! Redirigiendo...');
            setTimeout(() => {
                window.location.href = `/checkout/success?payment_id=${result.transaction_id}`;
            }, 2000);
        } else {
            throw new Error(result.message || 'Error al procesar el pago');
        }
        
    } catch (error) {
        console.error('Error en el pago:', error);
        showError(error.message || 'Error al procesar el pago. Por favor, intenta de nuevo.');
    } finally {
        showLoading(false);
    }
}

/**
 * Inicializar PayPal
 */
function initializePayPal() {
    paypal.Buttons({
        style: {
            color: 'blue',
            shape: 'pill',
            label: 'pay',
            height: 50
        },
        
        createOrder: function(data, actions) {
            return actions.order.create({
                purchase_units: [{
                    amount: {
                        value: CHECKOUT_CONFIG.amount.toString(),
                        currency_code: CHECKOUT_CONFIG.currency
                    },
                    description: `ObelisIA Premium - ${CHECKOUT_CONFIG.billing}`
                }]
            });
        },
        
        onApprove: function(data, actions) {
            showLoading(true);
            
            return actions.order.capture().then(function(details) {
                return processPayPalPayment(details);
            });
        },
        
        onError: function(err) {
            console.error('Error de PayPal:', err);
            showError('Error al procesar el pago con PayPal. Por favor, intenta de nuevo.');
            showLoading(false);
        },
        
        onCancel: function(data) {
            showError('Pago cancelado por el usuario.');
        }
        
    }).render('#paypal-button-container');
}

/**
 * Procesar pago de PayPal
 */
async function processPayPalPayment(details) {
    try {
        const paymentData = {
            method: 'paypal',
            plan: CHECKOUT_CONFIG.plan,
            billing: CHECKOUT_CONFIG.billing,
            paypal_order_id: details.id,
            paypal_payer_id: details.payer.payer_id,
            amount: CHECKOUT_CONFIG.amount,
            currency: CHECKOUT_CONFIG.currency,
            billing: {
                email: document.getElementById('billing_email').value,
                phone: document.getElementById('billing_phone').value,
                address: document.getElementById('billing_address').value,
                city: document.getElementById('billing_city').value,
                country: document.getElementById('billing_country').value,
                zip: document.getElementById('billing_zip').value
            }
        };
        
        const response = await fetch('/ajax/payments/process_paypal_payment.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(paymentData)
        });
        
        const result = await response.json();
        
        if (result.success) {
            showSuccess('¡Pago con PayPal procesado exitosamente! Redirigiendo...');
            setTimeout(() => {
                window.location.href = `/checkout/success?payment_id=${result.transaction_id}`;
            }, 2000);
        } else {
            throw new Error(result.message || 'Error al verificar el pago con PayPal');
        }
        
    } catch (error) {
        console.error('Error al procesar PayPal:', error);
        showError(error.message || 'Error al verificar el pago con PayPal');
    } finally {
        showLoading(false);
    }
}

/**
 * Funciones de UI
 */
function showLoading(show) {
    const button = document.getElementById('process-payment');
    const buttonText = document.getElementById('payment-button-text');
    const loadingSpinner = document.getElementById('payment-loading');
    
    if (show) {
        button.disabled = true;
        buttonText.style.display = 'none';
        loadingSpinner.style.display = 'flex';
    } else {
        button.disabled = false;
        buttonText.style.display = 'flex';
        loadingSpinner.style.display = 'none';
    }
}

function showError(message) {
    const errorDiv = document.getElementById('error-message');
    const successDiv = document.getElementById('success-message');
    
    successDiv.classList.add('d-none');
    errorDiv.textContent = message;
    errorDiv.classList.remove('d-none');
    
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function showSuccess(message) {
    const errorDiv = document.getElementById('error-message');
    const successDiv = document.getElementById('success-message');
    
    errorDiv.classList.add('d-none');
    successDiv.textContent = message;
    successDiv.classList.remove('d-none');
    
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

/**
 * Detectar tipo de tarjeta
 */
function detectCardType(number) {
    const patterns = {
        visa: /^4/,
        mastercard: /^5[1-5]/,
        amex: /^3[47]/,
        discover: /^6(?:011|5)/
    };
    
    for (const [type, pattern] of Object.entries(patterns)) {
        if (pattern.test(number)) {
            return type;
        }
    }
    
    return 'unknown';
}
