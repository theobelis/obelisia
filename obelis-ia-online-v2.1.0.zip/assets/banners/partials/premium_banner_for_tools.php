<?php
use ObelisIA\Utils\Premium;
$isPremium = Premium::isPremium();
?>
<script>
window.isPremiumUser = <?php echo $isPremium ? 'true' : 'false'; ?>;
</script>
<?php if ($isPremium): ?>
<div class="premium-banner d-flex align-items-center gap-3 mb-4 rounded-4 px-4 py-3 shadow-sm" style="background:linear-gradient(90deg,#e0ffd4 0%,#b2f2bb 100%);color:#256029;border:1.5px solid #b2f2bb;">
    <span class="fs-2"><i class="fas fa-crown"></i></span>
    <span class="flex-grow-1 premium-banner-text fw-medium" style="font-size:1.08rem;">
        <strong>¡Eres usuario Premium!</strong> Disfruta de <?php echo isset($premiumMessage) ? htmlspecialchars($premiumMessage) : 'generaciones ilimitadas, sin límites y acceso prioritario.'; ?>
    </span>
</div>
<?php else: ?>
<div class="premium-banner d-flex align-items-center gap-3 mb-4 rounded-4 px-4 py-3 shadow-sm" style="background:linear-gradient(90deg,#ffe082 0%,#ffd54f 100%);color:#6d4c00;border:1.5px solid #ffe082;">
    <span class="fs-2"><i class="fas fa-gem"></i></span>
    <span class="flex-grow-1 premium-banner-text fw-medium" style="font-size:1.08rem;">
        <strong>Beneficios Premium:</strong> <?php echo isset($premiumMessage) ? htmlspecialchars($premiumMessage) : 'Generaciones ilimitadas, sin límites de caracteres, sin anuncios, acceso prioritario y más.'; ?>
    </span>
    <a href="/pages/precios.php" class="btn btn-warning btn-sm fw-bold shadow-sm px-3 py-1 me-2" style="white-space:nowrap;"><i class="fas fa-crown me-1"></i> Hazte Premium</a>
</div>
<?php endif; ?>
