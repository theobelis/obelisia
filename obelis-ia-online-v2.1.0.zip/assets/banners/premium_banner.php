<?php
use ObelisIA\Utils\Premium;
$isPremium = Premium::isPremium();
?>
<script>
window.isPremiumUser = <?php echo $isPremium ? 'true' : 'false'; ?>;
</script>
<?php if ($isPremium): ?>
<div class="alert alert-success text-center mb-4">
    <i class="fas fa-crown me-2"></i>
    <strong>¡Eres usuario Premium!</strong> Disfruta de generaciones ilimitadas, sin límites y acceso prioritario.
</div>
<?php else: ?>
<div class="alert bg-light text-center">
    <i class="fas fa-gem me-2"></i>
    <strong>Beneficios Premium:</strong> Generaciones ilimitadas, sin límites de caracteres, sin anuncios, acceso prioritario y más.<br>
    <a href="buy" class="btn btn-warning btn-sm mt-2"><i class="fas fa-crown me-1"></i> Hazte Premium</a>
</div>
<?php endif; ?>
