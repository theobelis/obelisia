<?php
use ObelisIA\Utils\Premium;
$isPremium = Premium::isPremium();
?>
<script>
window.isPremiumUser = <?php echo $isPremium ? 'true' : 'false'; ?>;
</script>
<?php if ($isPremium): ?>
<div class="alert alert-success text-center mb-4">
    <i class="fas fa-crown me-2"></i>
    <strong>¡Eres usuario Premium!</strong> Disfruta de todos los beneficios exclusivos.
</div>
<?php else: ?>
<div class="alert alert-info text-center mb-4">
    <i class="fas fa-gem me-2"></i>
    <strong>¿Quieres más ventajas?</strong> Hazte Premium y desbloquea funciones avanzadas.<br>
    <a href="premium" class="btn btn-warning btn-sm mt-2"><i class="fas fa-crown me-1"></i> Ver planes</a>
</div>
<?php endif; ?>
