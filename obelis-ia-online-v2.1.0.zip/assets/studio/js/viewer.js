/**
 * Obelis Studio - Visor JavaScript
 * Funcionalidades del visor de proyectos
 */

let viewerState = {
    project: null,
    isLiked: false,
    likeCount: 0,
    commentCount: 0,
    viewCount: 0
};

// Inicialización
document.addEventListener('DOMContentLoaded', function() {
    initializeViewer();
    loadProjectContent();
    loadProjectStats();
    loadRelatedProjects();
});

/**
 * Inicializa el visor
 */
function initializeViewer() {
    console.log('🎬 Inicializando Obelis Studio Viewer');
    
    if (window.ViewerConfig) {
        viewerState.project = window.ViewerConfig.projectData;
        console.log('📁 Proyecto cargado:', viewerState.project.title);
    }
    
    // Registrar visualización si es proyecto público
    if (viewerState.project && viewerState.project.is_public) {
        registerView();
    }
    
    // Configurar tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

/**
 * Carga el contenido del proyecto
 */
async function loadProjectContent() {
    const contentContainer = document.getElementById('projectContent');
    
    try {
        const response = await fetch(`/api/studio/get_project.php?id=${viewerState.project.id}`);
        const result = await response.json();
        
        if (result.success) {
            const project = result.project;
            
            if (project.content && project.content.elements && project.content.elements.length > 0) {
                // Renderizar elementos del proyecto
                const contentHTML = renderProjectElements(project.content.elements);
                contentContainer.innerHTML = contentHTML;
            } else {
                // Proyecto vacío
                contentContainer.innerHTML = `
                    <div class="empty-project text-center py-5">
                        <i class="fas fa-file-alt fa-4x text-muted mb-3"></i>
                        <h4 class="text-muted">Proyecto en construcción</h4>
                        <p class="text-muted">Este proyecto aún no tiene contenido.</p>
                    </div>
                `;
            }
        } else {
            throw new Error(result.error || 'Error al cargar el proyecto');
        }
        
    } catch (error) {
        console.error('Error al cargar contenido:', error);
        contentContainer.innerHTML = `
            <div class="error-state text-center py-5">
                <i class="fas fa-exclamation-triangle fa-4x text-danger mb-3"></i>
                <h4 class="text-danger">Error al cargar el proyecto</h4>
                <p class="text-muted">${error.message}</p>
                <button class="btn btn-primary" onclick="loadProjectContent()">
                    <i class="fas fa-redo me-2"></i>Reintentar
                </button>
            </div>
        `;
    }
}

/**
 * Renderiza los elementos del proyecto
 */
function renderProjectElements(elements) {
    if (!elements || elements.length === 0) {
        return '<p class="text-muted">No hay elementos en este proyecto.</p>';
    }
    
    // Ordenar elementos por posición
    const sortedElements = elements.sort((a, b) => (a.position || 0) - (b.position || 0));
    
    let html = '';
    
    sortedElements.forEach(element => {
        html += renderViewerElement(element);
    });
    
    return html;
}

/**
 * Renderiza un elemento individual para el visor
 */
function renderViewerElement(element) {
    let content = '';
    
    switch (element.type) {
        case 'image':
            content = renderViewerImage(element);
            break;
        case 'text':
            content = renderViewerText(element);
            break;
        case 'audio':
            content = renderViewerAudio(element);
            break;
        case 'heading':
            content = renderViewerHeading(element);
            break;
        case 'paragraph':
            content = renderViewerParagraph(element);
            break;
        case 'divider':
            content = renderViewerDivider(element);
            break;
        case 'video':
            content = renderViewerVideo(element);
            break;
        default:
            content = `<p class="text-muted">Elemento no soportado: ${element.type}</p>`;
    }
    
    return `<div class="viewer-element element-${element.type}" data-element-type="${element.type}">${content}</div>`;
}

/**
 * Renderiza elemento imagen para visor
 */
function renderViewerImage(element) {
    const settings = element.settings || {};
    const content = element.content || {};
    
    let style = '';
    if (settings.width) style += `width: ${settings.width}; `;
    if (settings.border_radius) style += `border-radius: ${settings.border_radius}; `;
    
    let html = `
        <div class="image-container" style="text-align: ${settings.alignment || 'center'};">
            <img src="${content.file_path}" 
                 alt="${content.title || 'Imagen'}"
                 style="${style}"
                 loading="lazy">
    `;
    
    if (settings.caption) {
        html += `<div class="image-caption">${settings.caption}</div>`;
    }
    
    html += '</div>';
    return html;
}

/**
 * Renderiza elemento texto para visor
 */
function renderViewerText(element) {
    const settings = element.settings || {};
    const content = element.content || {};
    
    let style = '';
    if (settings.font_size) style += `font-size: ${settings.font_size}; `;
    if (settings.font_family) style += `font-family: ${settings.font_family}; `;
    if (settings.color) style += `color: ${settings.color}; `;
    if (settings.alignment) style += `text-align: ${settings.alignment}; `;
    if (settings.line_height) style += `line-height: ${settings.line_height}; `;
    
    const textContent = content.content || content.text || content.title || 'Sin contenido';
    
    return `<div style="${style}">${textContent}</div>`;
}

/**
 * Renderiza elemento audio para visor
 */
function renderViewerAudio(element) {
    const settings = element.settings || {};
    const content = element.content || {};
    
    let html = '';
    
    if (settings.show_title && content.title) {
        html += `<h5>${content.title}</h5>`;
    }
    
    html += `
        <audio ${settings.controls ? 'controls' : ''} 
               ${settings.autoplay ? 'autoplay' : ''} 
               ${settings.loop ? 'loop' : ''}
               style="width: ${settings.width || '100%'};">
            <source src="${content.file_path}" type="audio/mpeg">
            Tu navegador no soporta el elemento audio.
        </audio>
    `;
    
    return html;
}

/**
 * Renderiza elemento título para visor
 */
function renderViewerHeading(element) {
    const settings = element.settings || {};
    const content = element.content || {};
    const level = settings.level || 2;
    const text = content.text || 'Título';
    
    let style = '';
    if (settings.color) style += `color: ${settings.color}; `;
    if (settings.alignment) style += `text-align: ${settings.alignment}; `;
    
    return `<h${level} style="${style}">${text}</h${level}>`;
}

/**
 * Renderiza elemento párrafo para visor
 */
function renderViewerParagraph(element) {
    const content = element.content || {};
    const text = content.text || 'Párrafo';
    
    return `<p>${text}</p>`;
}

/**
 * Renderiza separador para visor
 */
function renderViewerDivider(element) {
    return '<hr>';
}

/**
 * Renderiza elemento video para visor
 */
function renderViewerVideo(element) {
    const settings = element.settings || {};
    const content = element.content || {};
    const url = content.url || '';
    
    if (!url) {
        return '<p class="text-muted">URL de video no válida</p>';
    }
    
    // Detectar tipo de video
    let embedCode = '';
    if (url.includes('youtube.com') || url.includes('youtu.be')) {
        const videoId = extractYouTubeId(url);
        if (videoId) {
            embedCode = `
                <iframe width="${settings.width || '100%'}" height="${settings.height || '315'}"
                        src="https://www.youtube.com/embed/${videoId}${settings.autoplay ? '?autoplay=1' : ''}"
                        frameborder="0" ${settings.controls ? 'allowfullscreen' : ''}></iframe>
            `;
        }
    } else if (url.includes('vimeo.com')) {
        const videoId = extractVimeoId(url);
        if (videoId) {
            embedCode = `
                <iframe width="${settings.width || '100%'}" height="${settings.height || '315'}"
                        src="https://player.vimeo.com/video/${videoId}${settings.autoplay ? '?autoplay=1' : ''}"
                        frameborder="0" ${settings.controls ? 'allowfullscreen' : ''}></iframe>
            `;
        }
    }
    
    return embedCode || '<p class="text-muted">URL de video no soportada</p>';
}

/**
 * Carga estadísticas del proyecto
 */
async function loadProjectStats() {
    if (!viewerState.project.is_public) return;
    
    try {
        const response = await fetch(`/api/studio/get_project_stats.php?id=${viewerState.project.id}`);
        const result = await response.json();
        
        if (result.success) {
            viewerState.viewCount = result.stats.views || 0;
            viewerState.likeCount = result.stats.likes || 0;
            viewerState.commentCount = result.stats.comments || 0;
            viewerState.isLiked = result.stats.user_liked || false;
            
            updateStatsDisplay();
        }
        
    } catch (error) {
        console.error('Error al cargar estadísticas:', error);
    }
}

/**
 * Actualiza la visualización de estadísticas
 */
function updateStatsDisplay() {
    // Actualizar contador de visualizaciones
    const viewCountEl = document.getElementById('viewCount');
    if (viewCountEl) {
        viewCountEl.textContent = formatNumber(viewerState.viewCount);
    }
    
    // Actualizar botón de like
    const likeBtn = document.getElementById('likeBtn');
    const likeText = document.getElementById('likeText');
    const likeCount = document.getElementById('likeCount');
    
    if (likeBtn && likeText && likeCount) {
        likeCount.textContent = formatNumber(viewerState.likeCount);
        
        if (viewerState.isLiked) {
            likeBtn.classList.remove('btn-outline-primary');
            likeBtn.classList.add('btn-primary');
            likeText.textContent = 'Te gusta';
            likeBtn.querySelector('i').className = 'fas fa-heart me-2';
        } else {
            likeBtn.classList.remove('btn-primary');
            likeBtn.classList.add('btn-outline-primary');
            likeText.textContent = 'Me gusta';
            likeBtn.querySelector('i').className = 'far fa-heart me-2';
        }
    }
    
    // Actualizar contador de comentarios
    const commentCount = document.getElementById('commentCount');
    if (commentCount) {
        commentCount.textContent = formatNumber(viewerState.commentCount);
    }
}

/**
 * Registra una visualización del proyecto
 */
async function registerView() {
    try {
        await fetch('/api/studio/register_view.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ project_id: viewerState.project.id })
        });
    } catch (error) {
        console.error('Error al registrar visualización:', error);
    }
}

/**
 * Carga proyectos relacionados
 */
async function loadRelatedProjects() {
    if (!viewerState.project.is_public) return;
    
    const relatedContainer = document.getElementById('relatedProjects');
    if (!relatedContainer) return;
    
    try {
        const response = await fetch(`/api/studio/get_related_projects.php?id=${viewerState.project.id}`);
        const result = await response.json();
        
        if (result.success && result.projects.length > 0) {
            let html = '';
            result.projects.forEach(project => {
                html += `
                    <div class="col-md-4 mb-4">
                        <div class="card related-project-card h-100">
                            ${project.thumbnail ? 
                                `<img src="${project.thumbnail}" class="card-img-top" alt="${project.title}">` :
                                `<div class="card-img-top bg-light d-flex align-items-center justify-content-center" style="height: 180px;">
                                    <i class="fas fa-image fa-3x text-muted"></i>
                                </div>`
                            }
                            <div class="card-body">
                                <h5 class="card-title">${project.title}</h5>
                                <p class="card-text">${project.description ? project.description.substring(0, 100) + '...' : 'Sin descripción'}</p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <small class="text-muted">Por ${project.username}</small>
                                    <a href="/studio/viewer?id=${project.id}" class="btn btn-primary btn-sm">Ver</a>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            });
            relatedContainer.innerHTML = html;
        } else {
            relatedContainer.closest('.related-projects').style.display = 'none';
        }
        
    } catch (error) {
        console.error('Error al cargar proyectos relacionados:', error);
        relatedContainer.closest('.related-projects').style.display = 'none';
    }
}

/**
 * Toggle like del proyecto
 */
async function toggleLike() {
    if (!window.ViewerConfig.userId) {
        showNotification('Debes iniciar sesión para dar like', 'warning');
        return;
    }
    
    try {
        const response = await fetch('/api/studio/toggle_like.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ project_id: viewerState.project.id })
        });
        
        const result = await response.json();
        
        if (result.success) {
            viewerState.isLiked = result.liked;
            viewerState.likeCount = result.like_count;
            updateStatsDisplay();
            
            showNotification(
                viewerState.isLiked ? '¡Te gusta este proyecto!' : 'Like removido',
                'success'
            );
        }
        
    } catch (error) {
        console.error('Error al procesar like:', error);
        showNotification('Error al procesar like', 'error');
    }
}

/**
 * Muestra sección de comentarios
 */
function showComments() {
    const commentsSection = document.getElementById('commentsSection');
    if (commentsSection) {
        commentsSection.style.display = commentsSection.style.display === 'none' ? 'block' : 'none';
        
        if (commentsSection.style.display === 'block') {
            loadComments();
        }
    }
}

/**
 * Funciones de compartir
 */
function shareOnSocial(platform) {
    const url = encodeURIComponent(window.location.href);
    const title = encodeURIComponent(viewerState.project.title);
    const description = encodeURIComponent(viewerState.project.description || '');
    
    let shareUrl = '';
    
    switch (platform) {
        case 'twitter':
            shareUrl = `https://twitter.com/intent/tweet?url=${url}&text=${title}`;
            break;
        case 'facebook':
            shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${url}`;
            break;
        case 'linkedin':
            shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${url}`;
            break;
        case 'whatsapp':
            shareUrl = `https://wa.me/?text=${title}%20${url}`;
            break;
    }
    
    if (shareUrl) {
        window.open(shareUrl, '_blank', 'width=600,height=400');
    }
}

function copyProjectLink() {
    navigator.clipboard.writeText(window.location.href).then(() => {
        showNotification('Enlace copiado al portapapeles', 'success');
    }).catch(err => {
        console.error('Error al copiar enlace:', err);
        showNotification('Error al copiar enlace', 'error');
    });
}

/**
 * Funciones de utilidad
 */
function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
}

function extractYouTubeId(url) {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
}

function extractVimeoId(url) {
    const regExp = /(?:vimeo)\.com.*(?:videos|video|channels|)\/([\d]+)/i;
    const match = url.match(regExp);
    return match ? match[1] : null;
}

function showNotification(message, type = 'info', duration = 5000) {
    // Implementación de notificaciones (reutilizar de studio.js)
    const notification = document.createElement('div');
    notification.className = `alert alert-${getBootstrapAlertClass(type)} alert-dismissible fade show position-fixed`;
    notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    
    const icon = getNotificationIcon(type);
    
    notification.innerHTML = `
        <i class="${icon} me-2"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        if (notification.parentNode) {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 150);
        }
    }, duration);
}

function getBootstrapAlertClass(type) {
    const classMap = {
        'success': 'success',
        'error': 'danger',
        'warning': 'warning',
        'info': 'info'
    };
    return classMap[type] || 'info';
}

function getNotificationIcon(type) {
    const iconMap = {
        'success': 'fas fa-check-circle',
        'error': 'fas fa-exclamation-circle',
        'warning': 'fas fa-exclamation-triangle',
        'info': 'fas fa-info-circle'
    };
    return iconMap[type] || 'fas fa-info-circle';
}

console.log('✅ Viewer JavaScript cargado');
