/**
 * Obelis Studio - JavaScript principal
 * Funcionalidades de la página principal del Studio
 */

// Variables globales
let projects = [];
let currentFilter = 'all';

// Inicialización
document.addEventListener('DOMContentLoaded', function() {
    initializeStudio();
    setupEventListeners();
    loadProjects();
});

/**
 * Inicializa el Studio
 */
function initializeStudio() {
    console.log('🎨 Obelis Studio iniciado');
    
    // Configurar tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Configurar popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
}

/**
 * Configura los event listeners
 */
function setupEventListeners() {
    // Filtros de proyectos
    document.querySelectorAll('[data-filter]').forEach(button => {
        button.addEventListener('click', function() {
            const filter = this.dataset.filter;
            filterProjects(filter);
            updateFilterButtons(this);
        });
    });
    
    // Form de crear proyecto
    const createForm = document.getElementById('createProjectForm');
    if (createForm) {
        createForm.addEventListener('submit', function(e) {
            e.preventDefault();
            submitCreateProject();
        });
    }
    
    // Enter key en el modal de crear proyecto
    document.getElementById('projectTitle')?.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            submitCreateProject();
        }
    });
    
    // Teclado shortcuts
    document.addEventListener('keydown', function(e) {
        // Ctrl/Cmd + N = Nuevo proyecto
        if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
            e.preventDefault();
            createNewProject();
        }
        
        // Escape = Cerrar modales
        if (e.key === 'Escape') {
            const modal = bootstrap.Modal.getInstance(document.querySelector('.modal.show'));
            if (modal) {
                modal.hide();
            }
        }
    });
}

/**
 * Carga los proyectos del usuario
 */
async function loadProjects() {
    try {
        // Los proyectos ya están cargados desde PHP, pero podemos refrescarlos aquí si es necesario
        console.log('📁 Proyectos cargados');
    } catch (error) {
        console.error('Error al cargar proyectos:', error);
        showNotification('Error al cargar los proyectos', 'error');
    }
}

/**
 * Muestra el modal para crear nuevo proyecto
 */
function createNewProject() {
    const modal = new bootstrap.Modal(document.getElementById('createProjectModal'));
    modal.show();
    
    // Focus en el campo título
    setTimeout(() => {
        document.getElementById('projectTitle').focus();
    }, 300);
}

/**
 * Envía el formulario de crear proyecto
 */
async function submitCreateProject() {
    const title = document.getElementById('projectTitle').value.trim();
    const description = document.getElementById('projectDescription').value.trim();
    
    if (!title) {
        showNotification('El título es requerido', 'error');
        document.getElementById('projectTitle').focus();
        return;
    }
    
    const button = document.querySelector('#createProjectModal .btn-primary');
    const originalText = button.innerHTML;
    
    try {
        // Mostrar loading
        button.innerHTML = '<span class="spinner me-2"></span>Creando...';
        button.disabled = true;
        
        const response = await fetch('/api/studio/create_project.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                title: title,
                description: description
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Cerrar modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('createProjectModal'));
            modal.hide();
            
            // Limpiar formulario
            document.getElementById('createProjectForm').reset();
            
            showNotification('Proyecto creado exitosamente', 'success');
            
            // Redirigir al editor
            setTimeout(() => {
                window.location.href = `/studio/editor.php?id=${result.project_id}`;
            }, 1000);
            
        } else {
            throw new Error(result.error || 'Error al crear el proyecto');
        }
        
    } catch (error) {
        console.error('Error al crear proyecto:', error);
        showNotification(error.message, 'error');
        
    } finally {
        // Restaurar botón
        button.innerHTML = originalText;
        button.disabled = false;
    }
}

/**
 * Filtra los proyectos por estado
 */
function filterProjects(filter) {
    currentFilter = filter;
    
    const projectItems = document.querySelectorAll('.project-item');
    
    projectItems.forEach(item => {
        const status = item.dataset.status;
        let show = false;
        
        switch (filter) {
            case 'all':
                show = true;
                break;
            case 'published':
                show = status === 'published';
                break;
            case 'draft':
                show = status === 'draft';
                break;
        }
        
        if (show) {
            item.style.display = 'block';
            item.classList.add('animate__animated', 'animate__fadeIn');
        } else {
            item.style.display = 'none';
        }
    });
    
    // Actualizar contador
    updateProjectCounter();
}

/**
 * Actualiza los botones de filtro
 */
function updateFilterButtons(activeButton) {
    document.querySelectorAll('[data-filter]').forEach(button => {
        button.classList.remove('active');
    });
    activeButton.classList.add('active');
}

/**
 * Actualiza el contador de proyectos
 */
function updateProjectCounter() {
    const visibleProjects = document.querySelectorAll('.project-item[style*="block"], .project-item:not([style*="none"])');
    const count = visibleProjects.length;
    
    // Actualizar título si existe un elemento contador
    const counter = document.getElementById('projectCounter');
    if (counter) {
        counter.textContent = `(${count})`;
    }
}

/**
 * Duplica un proyecto
 */
async function duplicateProject(projectId) {
    if (!confirm('¿Estás seguro de que quieres duplicar este proyecto?')) {
        return;
    }
    
    try {
        showNotification('Duplicando proyecto...', 'info');
        
        const response = await fetch('/api/studio/duplicate_project.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                project_id: projectId
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showNotification('Proyecto duplicado exitosamente', 'success');
            
            // Recargar la página para mostrar el nuevo proyecto
            setTimeout(() => {
                window.location.reload();
            }, 1000);
            
        } else {
            throw new Error(result.error || 'Error al duplicar el proyecto');
        }
        
    } catch (error) {
        console.error('Error al duplicar proyecto:', error);
        showNotification(error.message, 'error');
    }
}

/**
 * Elimina un proyecto
 */
async function deleteProject(projectId) {
    if (!confirm('¿Estás seguro de que quieres eliminar este proyecto? Esta acción no se puede deshacer.')) {
        return;
    }
    
    // Confirmar nuevamente para proyectos importantes
    if (!confirm('⚠️ CONFIRMACIÓN FINAL: El proyecto será eliminado permanentemente.')) {
        return;
    }
    
    try {
        showNotification('Eliminando proyecto...', 'info');
        
        const response = await fetch('/api/studio/delete_project.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                project_id: projectId
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showNotification('Proyecto eliminado exitosamente', 'success');
            
            // Remover el elemento del DOM con animación
            const projectElement = document.querySelector(`[onclick*="${projectId}"]`).closest('.project-item');
            if (projectElement) {
                projectElement.classList.add('animate__animated', 'animate__fadeOut');
                setTimeout(() => {
                    projectElement.remove();
                    updateProjectCounter();
                }, 500);
            }
            
        } else {
            throw new Error(result.error || 'Error al eliminar el proyecto');
        }
        
    } catch (error) {
        console.error('Error al eliminar proyecto:', error);
        showNotification(error.message, 'error');
    }
}

/**
 * Muestra el tutorial del Studio
 */
function showTutorial() {
    // Esta función se puede expandir más tarde con un tutorial interactivo
    const tutorialSteps = [
        {
            title: 'Bienvenido a Obelis Studio',
            content: 'Crea proyectos multimedia combinando todas tus creaciones de IA en un editor visual intuitivo.'
        },
        {
            title: 'Biblioteca Personal',
            content: 'Accede a todas tus imágenes, textos y audios generados por IA desde un solo lugar.'
        },
        {
            title: 'Editor Drag & Drop',
            content: 'Arrastra y suelta elementos para crear proyectos visualmente atractivos.'
        },
        {
            title: 'Publicación',
            content: 'Publica tus proyectos para compartirlos con la comunidad o mantenlos privados.'
        }
    ];
    
    showNotification('Tutorial próximamente disponible', 'info');
    console.log('📚 Tutorial:', tutorialSteps);
}

/**
 * Muestra notificaciones al usuario
 */
function showNotification(message, type = 'info', duration = 5000) {
    // Crear elemento de notificación
    const notification = document.createElement('div');
    notification.className = `alert alert-${getBootstrapAlertClass(type)} alert-dismissible fade show position-fixed`;
    notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    
    const icon = getNotificationIcon(type);
    
    notification.innerHTML = `
        <i class="${icon} me-2"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto-remover después del tiempo especificado
    setTimeout(() => {
        if (notification.parentNode) {
            notification.classList.remove('show');
            setTimeout(() => {
                notification.remove();
            }, 150);
        }
    }, duration);
}

/**
 * Convierte tipos de notificación a clases de Bootstrap
 */
function getBootstrapAlertClass(type) {
    const classMap = {
        'success': 'success',
        'error': 'danger',
        'warning': 'warning',
        'info': 'info'
    };
    return classMap[type] || 'info';
}

/**
 * Obtiene iconos para notificaciones
 */
function getNotificationIcon(type) {
    const iconMap = {
        'success': 'fas fa-check-circle',
        'error': 'fas fa-exclamation-circle',
        'warning': 'fas fa-exclamation-triangle',
        'info': 'fas fa-info-circle'
    };
    return iconMap[type] || 'fas fa-info-circle';
}

/**
 * Utilidades de formateo
 */
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-ES', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * Manejo de errores globales
 */
window.addEventListener('error', function(e) {
    console.error('Error global:', e.error);
    showNotification('Ha ocurrido un error inesperado', 'error');
});

window.addEventListener('unhandledrejection', function(e) {
    console.error('Promise rechazada:', e.reason);
    showNotification('Error de conexión', 'error');
});

// Exportar funciones para uso global
window.StudioApp = {
    createNewProject,
    duplicateProject,
    deleteProject,
    filterProjects,
    showNotification,
    showTutorial
};
