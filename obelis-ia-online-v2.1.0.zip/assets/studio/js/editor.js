/**
 * Obelis Studio - Editor Visual JavaScript
 * Funcionalidad principal del editor drag & drop
 */

// Variables globales del editor
let editorState = {
    project: null,
    elements: [],
    selectedElement: null,
    isDirty: false,
    autoSaveTimer: null,
    undoStack: [],
    redoStack: [],
    draggedElement: null
};

// Configuración del editor
const EDITOR_CONFIG = {
    maxUndoSteps: 50,
    autoSaveInterval: 30000, // 30 segundos
    maxElements: 100,
    allowedFileTypes: ['image/jpeg', 'image/png', 'image/gif', 'image/webp']
};

// Inicialización del editor
document.addEventListener('DOMContentLoaded', function() {
    initializeEditor();
    setupEventListeners();
    setupDragAndDrop();
    loadProjectData();
    startAutoSave();
});

/**
 * Inicializa el editor
 */
function initializeEditor() {
    console.log('🎨 Inicializando Obelis Studio Editor');
    
    // Cargar configuración del proyecto
    if (window.EditorConfig) {
        editorState.project = window.EditorConfig.projectData;
        console.log('📁 Proyecto cargado:', editorState.project.title);
    }
    
    // Configurar Quill editor para elementos de texto
    initializeQuill();
    
    // Configurar Sortable para reordenar elementos
    initializeSortable();
    
    // Configurar tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[title]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

/**
 * Configura los event listeners principales
 */
function setupEventListeners() {
    // Toolbar buttons
    document.getElementById('saveBtn')?.addEventListener('click', saveProject);
    document.getElementById('publishBtn')?.addEventListener('click', togglePublish);
    document.getElementById('previewBtn')?.addEventListener('click', showPreview);
    document.getElementById('undoBtn')?.addEventListener('click', undo);
    document.getElementById('redoBtn')?.addEventListener('click', redo);
    document.getElementById('fullscreenBtn')?.addEventListener('click', toggleFullscreen);
    
    // Sidebar toggles
    document.getElementById('toggleLibraryBtn')?.addEventListener('click', toggleLibrarySidebar);
    document.getElementById('togglePropertiesBtn')?.addEventListener('click', togglePropertiesSidebar);
    
    // Canvas title and description
    document.getElementById('canvasTitle')?.addEventListener('input', updateProjectTitle);
    document.getElementById('canvasDescription')?.addEventListener('input', updateProjectDescription);
    
    // Search in library
    document.getElementById('searchImages')?.addEventListener('input', (e) => filterLibrary('images', e.target.value));
    document.getElementById('searchTexts')?.addEventListener('input', (e) => filterLibrary('texts', e.target.value));
    document.getElementById('searchAudios')?.addEventListener('input', (e) => filterLibrary('audios', e.target.value));
    
    // Keyboard shortcuts
    document.addEventListener('keydown', handleKeyboardShortcuts);
    
    // Prevent page unload with unsaved changes
    window.addEventListener('beforeunload', function(e) {
        if (editorState.isDirty) {
            e.preventDefault();
            e.returnValue = '¿Estás seguro de que quieres salir? Tienes cambios sin guardar.';
        }
    });
    
    // Click outside to deselect
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.editor-element') && !e.target.closest('.sidebar-right')) {
            deselectElement();
        }
    });
}

/**
 * Configura el sistema drag & drop
 */
function setupDragAndDrop() {
    const dropZone = document.getElementById('dropZone');
    const editorContent = document.getElementById('editorContent');
    
    // Library items drag
    document.querySelectorAll('.library-item').forEach(item => {
        item.addEventListener('dragstart', handleLibraryDragStart);
        item.addEventListener('dragend', handleLibraryDragEnd);
    });
    
    // Palette items drag
    document.querySelectorAll('.palette-item').forEach(item => {
        item.addEventListener('dragstart', handlePaletteDragStart);
        item.addEventListener('dragend', handlePaletteDragEnd);
    });
    
    // Drop zone events
    dropZone.addEventListener('dragover', handleDragOver);
    dropZone.addEventListener('drop', handleDrop);
    dropZone.addEventListener('dragenter', handleDragEnter);
    dropZone.addEventListener('dragleave', handleDragLeave);
    
    // También manejar drops de creaciones externas
    dropZone.addEventListener('drop', handleCreationDrop);
    
    // Editor content events
    editorContent.addEventListener('dragover', handleDragOver);
    editorContent.addEventListener('drop', handleDrop);
}

/**
 * Maneja el inicio de arrastre desde la biblioteca
 */
function handleLibraryDragStart(e) {
    const item = e.target.closest('.library-item');
    const elementType = item.dataset.type;
    const elementId = item.dataset.id;
    
    editorState.draggedElement = {
        source: 'library',
        type: elementType,
        id: elementId,
        data: getLibraryItemData(elementId, elementType)
    };
    
    item.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'copy';
    e.dataTransfer.setData('text/plain', ''); // Para compatibilidad
}

/**
 * Maneja el inicio de arrastre desde la paleta
 */
function handlePaletteDragStart(e) {
    const item = e.target.closest('.palette-item');
    const elementType = item.dataset.type;
    
    editorState.draggedElement = {
        source: 'palette',
        type: elementType,
        data: getDefaultElementData(elementType)
    };
    
    item.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'copy';
    e.dataTransfer.setData('text/plain', '');
}

/**
 * Maneja el fin de arrastre
 */
function handleLibraryDragEnd(e) {
    e.target.closest('.library-item').classList.remove('dragging');
}

function handlePaletteDragEnd(e) {
    e.target.closest('.palette-item').classList.remove('dragging');
}

/**
 * Maneja el evento dragover
 */
function handleDragOver(e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
}

/**
 * Maneja el evento dragenter
 */
function handleDragEnter(e) {
    e.preventDefault();
    if (e.target.id === 'dropZone') {
        e.target.classList.add('drag-over');
    }
}

/**
 * Maneja el evento dragleave
 */
function handleDragLeave(e) {
    if (e.target.id === 'dropZone') {
        e.target.classList.remove('drag-over');
    }
}

/**
 * Maneja el evento drop
 */
function handleDrop(e) {
    e.preventDefault();
    
    if (e.target.id === 'dropZone') {
        e.target.classList.remove('drag-over');
    }
    
    if (!editorState.draggedElement) {
        return;
    }
    
    // Verificar límite de elementos
    if (editorState.elements.length >= EDITOR_CONFIG.maxElements) {
        showNotification('Has alcanzado el límite máximo de elementos por proyecto', 'warning');
        return;
    }
    
    // Crear elemento en el editor
    createEditorElement(editorState.draggedElement);
    
    // Limpiar estado de arrastre
    editorState.draggedElement = null;
}

/**
 * Crea un elemento en el editor
 */
function createEditorElement(draggedElement) {
    const elementId = generateElementId();
    const elementData = {
        id: elementId,
        type: draggedElement.type,
        sourceId: draggedElement.id || null,
        content: draggedElement.data,
        settings: getDefaultElementSettings(draggedElement.type),
        position: editorState.elements.length
    };
    
    // Agregar al estado
    editorState.elements.push(elementData);
    
    // Crear elemento DOM
    const elementDOM = createElementDOM(elementData);
    
    // Agregar al editor
    const editorContent = document.getElementById('editorContent');
    const dropZone = document.getElementById('dropZone');
    
    // Ocultar drop zone si es el primer elemento
    if (editorState.elements.length === 1) {
        dropZone.style.display = 'none';
    }
    
    editorContent.appendChild(elementDOM);
    
    // Animar aparición
    elementDOM.classList.add('newly-added');
    setTimeout(() => {
        elementDOM.classList.remove('newly-added');
    }, 300);
    
    // Marcar como modificado
    markAsModified();
    
    // Seleccionar elemento
    selectElement(elementId);
    
    showNotification('Elemento agregado exitosamente', 'success');
}

/**
 * Crea el DOM de un elemento
 */
function createElementDOM(elementData) {
    const wrapper = document.createElement('div');
    wrapper.className = 'editor-element';
    wrapper.dataset.elementId = elementData.id;
    wrapper.dataset.elementType = elementData.type;
    
    // Contenido según tipo
    let content = '';
    switch (elementData.type) {
        case 'image':
            content = createImageElementHTML(elementData);
            break;
        case 'text':
            content = createTextElementHTML(elementData);
            break;
        case 'audio':
            content = createAudioElementHTML(elementData);
            break;
        case 'heading':
            content = createHeadingElementHTML(elementData);
            break;
        case 'paragraph':
            content = createParagraphElementHTML(elementData);
            break;
        case 'divider':
            content = createDividerElementHTML(elementData);
            break;
        case 'video':
            content = createVideoElementHTML(elementData);
            break;
        default:
            content = `<p>Elemento no soportado: ${elementData.type}</p>`;
    }
    
    // Controles del elemento
    const controls = `
        <div class="element-controls">
            <button class="btn btn-sm btn-outline-primary" onclick="editElement('${elementData.id}')" title="Editar">
                <i class="fas fa-edit"></i>
            </button>
            <button class="btn btn-sm btn-outline-secondary" onclick="duplicateElement('${elementData.id}')" title="Duplicar">
                <i class="fas fa-copy"></i>
            </button>
            <button class="btn btn-sm btn-outline-danger" onclick="deleteElement('${elementData.id}')" title="Eliminar">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `;
    
    wrapper.innerHTML = content + controls;
    
    // Event listeners
    wrapper.addEventListener('click', (e) => {
        e.stopPropagation();
        selectElement(elementData.id);
    });
    
    return wrapper;
}

/**
 * Crea HTML para elemento imagen
 */
function createImageElementHTML(elementData) {
    const settings = elementData.settings;
    return `
        <div class="element-image">
            <img src="${elementData.content.file_path}" 
                 alt="${elementData.content.title || 'Imagen'}"
                 style="width: ${settings.width}; height: ${settings.height}; border-radius: ${settings.border_radius};">
            ${settings.caption ? `<div class="image-caption mt-2">${settings.caption}</div>` : ''}
        </div>
    `;
}

/**
 * Crea HTML para elemento texto
 */
function createTextElementHTML(elementData) {
    const settings = elementData.settings;
    return `
        <div class="element-text" style="
            font-size: ${settings.font_size};
            font-family: ${settings.font_family};
            color: ${settings.color};
            text-align: ${settings.alignment};
            line-height: ${settings.line_height};
            margin-bottom: ${settings.margin_bottom};
        ">
            ${elementData.content.content || elementData.content.title || 'Texto sin contenido'}
        </div>
    `;
}

/**
 * Crea HTML para elemento audio
 */
function createAudioElementHTML(elementData) {
    const settings = elementData.settings;
    return `
        <div class="element-audio">
            ${settings.show_title ? `<h5 class="mb-3">${elementData.content.title}</h5>` : ''}
            <audio ${settings.controls ? 'controls' : ''} 
                   ${settings.autoplay ? 'autoplay' : ''} 
                   ${settings.loop ? 'loop' : ''}
                   style="width: ${settings.width};">
                <source src="${elementData.content.file_path}" type="audio/mpeg">
                Tu navegador no soporta el elemento audio.
            </audio>
        </div>
    `;
}

/**
 * Crea HTML para elemento título
 */
function createHeadingElementHTML(elementData) {
    const level = elementData.settings.level || 2;
    const text = elementData.content.text || 'Nuevo Título';
    return `
        <div class="element-heading">
            <h${level}>${text}</h${level}>
        </div>
    `;
}

/**
 * Crea HTML para elemento párrafo
 */
function createParagraphElementHTML(elementData) {
    const text = elementData.content.text || 'Nuevo párrafo. Haz clic para editar.';
    return `
        <div class="element-paragraph">
            <p>${text}</p>
        </div>
    `;
}

/**
 * Crea HTML para elemento separador
 */
function createDividerElementHTML(elementData) {
    return `
        <div class="element-divider">
            <hr>
        </div>
    `;
}

/**
 * Crea HTML para elemento video
 */
function createVideoElementHTML(elementData) {
    const settings = elementData.settings;
    const url = elementData.content.url || '';
    
    // Detectar tipo de video (YouTube, Vimeo, etc.)
    let embedCode = '';
    if (url.includes('youtube.com') || url.includes('youtu.be')) {
        const videoId = extractYouTubeId(url);
        embedCode = `
            <iframe width="${settings.width}" height="${settings.height}"
                    src="https://www.youtube.com/embed/${videoId}${settings.autoplay ? '?autoplay=1' : ''}"
                    frameborder="0" ${settings.controls ? 'allowfullscreen' : ''}></iframe>
        `;
    } else if (url.includes('vimeo.com')) {
        const videoId = extractVimeoId(url);
        embedCode = `
            <iframe width="${settings.width}" height="${settings.height}"
                    src="https://player.vimeo.com/video/${videoId}${settings.autoplay ? '?autoplay=1' : ''}"
                    frameborder="0" ${settings.controls ? 'allowfullscreen' : ''}></iframe>
        `;
    } else {
        embedCode = `<p>URL de video no válida o no soportada</p>`;
    }
    
    return `
        <div class="element-video text-center">
            ${embedCode}
        </div>
    `;
}

/**
 * Selecciona un elemento
 */
function selectElement(elementId) {
    // Deseleccionar elemento anterior
    document.querySelectorAll('.editor-element.selected').forEach(el => {
        el.classList.remove('selected');
    });
    
    // Seleccionar nuevo elemento
    const element = document.querySelector(`[data-element-id="${elementId}"]`);
    if (element) {
        element.classList.add('selected');
        editorState.selectedElement = elementId;
        
        // Actualizar panel de propiedades
        updatePropertiesPanel(elementId);
    }
}

/**
 * Deselecciona elemento actual
 */
function deselectElement() {
    document.querySelectorAll('.editor-element.selected').forEach(el => {
        el.classList.remove('selected');
    });
    
    editorState.selectedElement = null;
    
    // Limpiar panel de propiedades
    const propertiesContent = document.getElementById('propertiesContent');
    propertiesContent.innerHTML = `
        <div class="no-selection-message">
            <i class="fas fa-mouse-pointer fa-2x mb-3"></i>
            <p>Selecciona un elemento para ver sus propiedades</p>
        </div>
    `;
}

/**
 * Actualiza el panel de propiedades
 */
function updatePropertiesPanel(elementId) {
    const elementData = editorState.elements.find(el => el.id === elementId);
    if (!elementData) return;
    
    const propertiesContent = document.getElementById('propertiesContent');
    propertiesContent.innerHTML = generatePropertiesHTML(elementData);
    
    // Configurar event listeners para los controles
    setupPropertyControls(elementId);
}

/**
 * Genera HTML para las propiedades
 */
function generatePropertiesHTML(elementData) {
    // Esta función será muy larga, la implementaremos en la siguiente parte
    return `
        <div class="property-group">
            <h6>Elemento ${elementData.type}</h6>
            <p>Panel de propiedades en desarrollo...</p>
        </div>
    `;
}

/**
 * Maneja shortcuts de teclado
 */
function handleKeyboardShortcuts(e) {
    if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
            case 's':
                e.preventDefault();
                saveProject();
                break;
            case 'z':
                e.preventDefault();
                if (e.shiftKey) {
                    redo();
                } else {
                    undo();
                }
                break;
            case 'y':
                e.preventDefault();
                redo();
                break;
        }
    }
    
    // Delete key para eliminar elemento seleccionado
    if (e.key === 'Delete' && editorState.selectedElement) {
        deleteElement(editorState.selectedElement);
    }
}

/**
 * Guarda el proyecto
 */
async function saveProject() {
    if (!editorState.isDirty) {
        showNotification('No hay cambios para guardar', 'info');
        return;
    }
    
    const saveBtn = document.getElementById('saveBtn');
    const saveStatus = document.getElementById('saveStatus');
    const originalText = saveBtn.innerHTML;
    
    try {
        // Mostrar estado de guardado
        saveBtn.innerHTML = '<span class="spinner me-2"></span>Guardando...';
        saveBtn.disabled = true;
        saveStatus.innerHTML = '<i class="fas fa-sync fa-spin"></i> Guardando...';
        saveStatus.className = 'badge bg-warning';
        
        const projectData = {
            title: document.getElementById('canvasTitle').value,
            description: document.getElementById('canvasDescription').value,
            content: {
                elements: editorState.elements,
                lastModified: new Date().toISOString()
            }
        };
        
        const response = await fetch('/api/studio/save_project.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                project_id: editorState.project.id,
                project_data: projectData
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            editorState.isDirty = false;
            saveStatus.innerHTML = '<i class="fas fa-check"></i> Guardado';
            saveStatus.className = 'badge bg-success';
            
            // Actualizar timestamp
            document.getElementById('lastSavedTime').textContent = 'Hace un momento';
            
            showNotification('Proyecto guardado exitosamente', 'success');
        } else {
            throw new Error(result.error || 'Error al guardar');
        }
        
    } catch (error) {
        console.error('Error al guardar:', error);
        saveStatus.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Error';
        saveStatus.className = 'badge bg-danger';
        showNotification(error.message, 'error');
        
    } finally {
        saveBtn.innerHTML = originalText;
        saveBtn.disabled = false;
    }
}

/**
 * Marca el proyecto como modificado
 */
function markAsModified() {
    editorState.isDirty = true;
    const saveStatus = document.getElementById('saveStatus');
    saveStatus.innerHTML = '<i class="fas fa-circle"></i> Sin guardar';
    saveStatus.className = 'badge bg-secondary';
}

/**
 * Inicia el auto-guardado
 */
function startAutoSave() {
    editorState.autoSaveTimer = setInterval(() => {
        if (editorState.isDirty) {
            saveProject();
        }
    }, EDITOR_CONFIG.autoSaveInterval);
}

/**
 * Utilitades
 */
function generateElementId() {
    return 'elem_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

function getLibraryItemData(elementId, elementType) {
    const library = window.EditorConfig.libraryData;
    return library.find(item => item.id == elementId && item.type === elementType);
}

function getDefaultElementData(elementType) {
    const defaults = {
        heading: { text: 'Nuevo Título' },
        paragraph: { text: 'Nuevo párrafo. Haz clic para editar.' },
        divider: {},
        video: { url: '' },
        gallery: { images: [] },
        columns: { count: 2 },
        spacer: { height: '2rem' }
    };
    
    return defaults[elementType] || {};
}

function getDefaultElementSettings(elementType) {
    // Configuraciones por defecto según el tipo de elemento
    const defaults = {
        image: {
            width: '100%',
            height: 'auto',
            alignment: 'center',
            border_radius: '0.5rem',
            shadow: true,
            caption: ''
        },
        text: {
            font_size: '16px',
            font_family: 'Arial, sans-serif',
            color: '#333333',
            alignment: 'left',
            line_height: '1.6',
            margin_bottom: '20px'
        },
        audio: {
            controls: true,
            autoplay: false,
            loop: false,
            width: '100%',
            show_title: true
        },
        heading: {
            level: 2,
            color: '#212529',
            alignment: 'left'
        },
        video: {
            width: '100%',
            height: '315px',
            autoplay: false,
            controls: true,
            responsive: true
        }
    };
    
    return defaults[elementType] || {};
}

function extractYouTubeId(url) {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
}

function extractVimeoId(url) {
    const regExp = /(?:vimeo)\.com.*(?:videos|video|channels|)\/([\d]+)/i;
    const match = url.match(regExp);
    return match ? match[1] : null;
}

/**
 * Funciones del editor (continuarán en los siguientes archivos)
 */

// Exportar funciones globales
window.EditorApp = {
    selectElement,
    deselectElement,
    saveProject,
    markAsModified,
    createEditorElement
};

// Funciones globales para onclick
window.editElement = function(elementId) {
    console.log('Editar elemento:', elementId);
    // Implementar en siguiente fase
};

window.duplicateElement = function(elementId) {
    console.log('Duplicar elemento:', elementId);
    // Implementar en siguiente fase
};

window.deleteElement = function(elementId) {
    if (confirm('¿Estás seguro de que quieres eliminar este elemento?')) {
        const elementIndex = editorState.elements.findIndex(el => el.id === elementId);
        if (elementIndex > -1) {
            editorState.elements.splice(elementIndex, 1);
            document.querySelector(`[data-element-id="${elementId}"]`).remove();
            markAsModified();
            deselectElement();
            showNotification('Elemento eliminado', 'success');
            
            // Mostrar drop zone si no hay elementos
            if (editorState.elements.length === 0) {
                document.getElementById('dropZone').style.display = 'flex';
            }
        }
    }
};

/**
 * Carga los datos del proyecto desde el servidor
 */
async function loadProjectData() {
    if (!editorState.project?.id) {
        console.log('📝 Nuevo proyecto - sin datos que cargar');
        return;
    }
    
    try {
        console.log('📁 Cargando datos del proyecto:', editorState.project.id);
        
        const response = await fetch(`/api/studio/get_project.php?id=${editorState.project.id}`);
        const result = await response.json();
        
        if (result.success) {
            const project = result.project;
            
            // Actualizar estado del proyecto
            editorState.project = project;
            
            // Cargar elementos del proyecto
            if (project.content && project.content.elements) {
                editorState.elements = project.content.elements;
                renderProjectElements();
                console.log(`📦 ${editorState.elements.length} elementos cargados`);
            } else {
                console.log('📦 Proyecto sin elementos');
            }
            
            // Actualizar información del proyecto en la interfaz
            updateProjectInfo();
            
        } else {
            throw new Error(result.error || 'Error al cargar el proyecto');
        }
        
    } catch (error) {
        console.error('❌ Error al cargar proyecto:', error);
        showNotification('Error al cargar el proyecto: ' + error.message, 'error');
    }
}

/**
 * Renderiza los elementos del proyecto en el editor
 */
function renderProjectElements() {
    const editorContent = document.getElementById('editorContent');
    const dropZone = document.getElementById('dropZone');
    
    // Limpiar contenido actual
    editorContent.innerHTML = '';
    
    if (editorState.elements.length === 0) {
        dropZone.style.display = 'flex';
        return;
    }
    
    // Ocultar drop zone
    dropZone.style.display = 'none';
    
    // Ordenar elementos por posición
    const sortedElements = [...editorState.elements].sort((a, b) => (a.position || 0) - (b.position || 0));
    
    // Renderizar cada elemento
    sortedElements.forEach(element => {
        const elementHTML = renderEditorElement(element);
        editorContent.appendChild(elementHTML);
    });
    
    // Reinicializar Sortable después de renderizar
    initializeSortable();
}

/**
 * Actualiza la información del proyecto en la interfaz
 */
function updateProjectInfo() {
    if (!editorState.project) return;
    
    // Actualizar título en la barra superior si existe
    const titleElement = document.querySelector('.project-title');
    if (titleElement) {
        titleElement.textContent = editorState.project.title;
    }
    
    // Actualizar estado de publicación
    const statusElement = document.querySelector('.project-status');
    if (statusElement) {
        statusElement.innerHTML = editorState.project.is_public ? 
            '<i class="fas fa-globe text-success"></i> Público' : 
            '<i class="fas fa-lock text-warning"></i> Privado';
    }
    
    // Actualizar última modificación
    const lastModifiedElement = document.querySelector('.last-modified');
    if (lastModifiedElement) {
        const date = new Date(editorState.project.updated_at);
        lastModifiedElement.textContent = `Última modificación: ${formatDate(date)}`;
    }
}

/**
 * Formatea una fecha para mostrar
 */
function formatDate(date) {
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 1) return 'Ahora mismo';
    if (diffMins < 60) return `Hace ${diffMins} minutos`;
    if (diffHours < 24) return `Hace ${diffHours} horas`;
    if (diffDays < 7) return `Hace ${diffDays} días`;
    
    return date.toLocaleDateString('es-ES', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

console.log('✅ Editor JavaScript cargado');
