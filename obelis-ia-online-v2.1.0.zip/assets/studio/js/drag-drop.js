/**
 * Obelis Studio - Drag & Drop functionality
 * Funcionalidades avanzadas de arrastrar y soltar
 */

/**
 * Inicializa Sortable.js para reordenar elementos
 */
function initializeSortable() {
    const editorContent = document.getElementById('editorContent');
    
    new Sortable(editorContent, {
        animation: 150,
        ghostClass: 'element-ghost',
        chosenClass: 'element-chosen',
        dragClass: 'element-drag',
        filter: '#dropZone, .element-controls',
        preventOnFilter: false,
        onStart: function(evt) {
            evt.item.classList.add('dragging');
        },
        onEnd: function(evt) {
            evt.item.classList.remove('dragging');
            
            // Actualizar orden en el estado
            updateElementOrder();
            markAsModified();
        }
    });
}

/**
 * Actualiza el orden de los elementos después del reordenamiento
 */
function updateElementOrder() {
    const elementDOMs = document.querySelectorAll('.editor-element');
    const newOrder = [];
    
    elementDOMs.forEach((elementDOM, index) => {
        const elementId = elementDOM.dataset.elementId;
        const elementData = editorState.elements.find(el => el.id === elementId);
        
        if (elementData) {
            elementData.position = index;
            newOrder.push(elementData);
        }
    });
    
    editorState.elements = newOrder;
}

/**
 * Maneja el arrastre de archivos externos
 */
function setupFileDropHandler() {
    const dropZone = document.getElementById('dropZone');
    const editorContent = document.getElementById('editorContent');
    
    [dropZone, editorContent].forEach(zone => {
        zone.addEventListener('dragover', handleFileDragOver);
        zone.addEventListener('drop', handleFileDrop);
        // Agregar soporte para elementos de creaciones IA
        zone.addEventListener('dragover', handleCreationDragOver);
        zone.addEventListener('drop', handleCreationDrop);
    });
}

/**
 * Maneja dragover para elementos de creaciones IA
 */
function handleCreationDragOver(e) {
    e.preventDefault();
    e.stopPropagation();
    
    // Verificar si es un elemento de creación IA
    const creationData = e.dataTransfer.getData('text/plain');
    if (creationData) {
        try {
            const data = JSON.parse(creationData);
            if (data.id && data.type) {
                e.dataTransfer.dropEffect = 'copy';
                e.target.classList.add('creation-drag-over');
                showInsertIndicator(getInsertPosition(e));
            }
        } catch (ex) {
            // No es un elemento de creación válido
        }
    }
}

/**
 * Maneja drop de elementos de creaciones IA
 */
function handleCreationDrop(e) {
    e.preventDefault();
    e.stopPropagation();
    e.target.classList.remove('creation-drag-over');
    removeInsertIndicator();
    
    console.log('Drop event received:', e.dataTransfer.types);
    
    // Intentar obtener datos en diferentes formatos
    let creationData = e.dataTransfer.getData('application/json');
    if (!creationData) {
        creationData = e.dataTransfer.getData('text/plain');
    }
    
    console.log('Creation data:', creationData);
    
    if (!creationData) return;
    
    try {
        // Si es solo el texto "creation", significa que viene de una creación pero sin datos
        if (creationData === 'creation') {
            console.log('Received creation indicator but no data');
            return;
        }
        
        const data = JSON.parse(creationData);
        console.log('Parsed creation data:', data);
        
        if (data.id && data.type) {
            addCreationToProject(data);
        }
    } catch (ex) {
        console.error('Error al procesar elemento arrastrado:', ex);
        showNotification('Error al procesar el elemento arrastrado', 'error');
    }
}

/**
 * Añade una creación IA al proyecto del Studio
 */
async function addCreationToProject(creationData) {
    try {
        showNotification('Añadiendo elemento al proyecto...', 'info');
        
        // Obtener datos completos de la creación
        const response = await fetch('/api/get_content_creation.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ creation_id: creationData.id })
        });
        
        const result = await response.json();
        
        if (result.success) {
            const creation = result.creation;
            
            // Crear elemento para el editor según el tipo
            const elementData = {
                source: 'creation',
                type: creation.type,
                id: creation.id,
                data: {
                    id: creation.id,
                    title: creation.title,
                    description: creation.description,
                    file_path: creation.file_path,
                    type: creation.type,
                    tool_used: creation.tool_used,
                    content: creation.content || creation.generated_content
                }
            };
            
            createEditorElement(elementData);
            showNotification(`${creation.title} añadido al proyecto`, 'success');
            
        } else {
            throw new Error(result.error || 'Error al obtener la creación');
        }
        
    } catch (error) {
        console.error('Error al añadir creación:', error);
        showNotification(error.message, 'error');
    }
}

/**
 * Maneja dragover para archivos
 */
function handleFileDragOver(e) {
    e.preventDefault();
    e.stopPropagation();
    
    // Solo permitir si hay archivos
    if (e.dataTransfer.types.includes('Files')) {
        e.dataTransfer.dropEffect = 'copy';
        e.target.classList.add('file-drag-over');
    }
}

/**
 * Maneja drop de archivos
 */
function handleFileDrop(e) {
    e.preventDefault();
    e.stopPropagation();
    e.target.classList.remove('file-drag-over');
    
    const files = Array.from(e.dataTransfer.files);
    
    if (files.length === 0) return;
    
    // Filtrar solo imágenes permitidas
    const imageFiles = files.filter(file => 
        EDITOR_CONFIG.allowedFileTypes.includes(file.type)
    );
    
    if (imageFiles.length === 0) {
        showNotification('Solo se permiten archivos de imagen (JPG, PNG, GIF, WebP)', 'warning');
        return;
    }
    
    // Procesar cada archivo
    imageFiles.forEach(file => {
        uploadAndCreateImageElement(file);
    });
}

/**
 * Sube un archivo y crea un elemento imagen
 */
async function uploadAndCreateImageElement(file) {
    try {
        showNotification('Subiendo imagen...', 'info');
        
        const formData = new FormData();
        formData.append('image', file);
        formData.append('title', file.name.replace(/\.[^/.]+$/, ""));
        
        const response = await fetch('/api/ia-img/upload-direct.php', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Crear elemento con la imagen subida
            const draggedElement = {
                source: 'upload',
                type: 'image',
                id: result.creation_id,
                data: {
                    id: result.creation_id,
                    title: result.title,
                    file_path: result.file_path,
                    type: 'image'
                }
            };
            
            createEditorElement(draggedElement);
            showNotification('Imagen subida y agregada exitosamente', 'success');
            
        } else {
            throw new Error(result.error || 'Error al subir la imagen');
        }
        
    } catch (error) {
        console.error('Error al subir imagen:', error);
        showNotification(error.message, 'error');
    }
}

/**
 * Crea una vista previa del arrastre
 */
function createDragPreview(element, offset = { x: 0, y: 0 }) {
    const preview = element.cloneNode(true);
    preview.style.position = 'absolute';
    preview.style.top = '-1000px';
    preview.style.left = '-1000px';
    preview.style.width = '200px';
    preview.style.opacity = '0.8';
    preview.style.transform = 'rotate(5deg)';
    preview.style.pointerEvents = 'none';
    preview.style.zIndex = '9999';
    
    document.body.appendChild(preview);
    
    return preview;
}

/**
 * Detecta la posición de inserción durante el arrastre
 */
function getInsertPosition(e) {
    const editorContent = document.getElementById('editorContent');
    const elements = Array.from(editorContent.querySelectorAll('.editor-element'));
    
    if (elements.length === 0) {
        return 0;
    }
    
    const y = e.clientY;
    let insertPosition = elements.length;
    
    for (let i = 0; i < elements.length; i++) {
        const rect = elements[i].getBoundingClientRect();
        const elementCenter = rect.top + rect.height / 2;
        
        if (y < elementCenter) {
            insertPosition = i;
            break;
        }
    }
    
    return insertPosition;
}

/**
 * Muestra indicador de posición de inserción
 */
function showInsertIndicator(position) {
    removeInsertIndicator();
    
    const indicator = document.createElement('div');
    indicator.className = 'insert-indicator';
    indicator.innerHTML = '<div class="insert-line"></div>';
    
    const editorContent = document.getElementById('editorContent');
    const elements = editorContent.querySelectorAll('.editor-element');
    
    if (position === 0 && elements.length > 0) {
        // Insertar al inicio
        editorContent.insertBefore(indicator, elements[0]);
    } else if (position < elements.length) {
        // Insertar entre elementos
        editorContent.insertBefore(indicator, elements[position]);
    } else {
        // Insertar al final
        editorContent.appendChild(indicator);
    }
}

/**
 * Remueve el indicador de inserción
 */
function removeInsertIndicator() {
    const indicator = document.querySelector('.insert-indicator');
    if (indicator) {
        indicator.remove();
    }
}

/**
 * Maneja el arrastre dentro del editor para reordenar
 */
function setupInternalDragDrop() {
    const editorContent = document.getElementById('editorContent');
    
    editorContent.addEventListener('dragstart', function(e) {
        if (e.target.closest('.editor-element')) {
            const element = e.target.closest('.editor-element');
            element.classList.add('dragging');
            e.dataTransfer.effectAllowed = 'move';
            e.dataTransfer.setData('text/plain', element.dataset.elementId);
        }
    });
    
    editorContent.addEventListener('dragend', function(e) {
        if (e.target.closest('.editor-element')) {
            e.target.closest('.editor-element').classList.remove('dragging');
            removeInsertIndicator();
        }
    });
    
    editorContent.addEventListener('dragover', function(e) {
        e.preventDefault();
        
        const draggingElement = editorContent.querySelector('.editor-element.dragging');
        if (draggingElement) {
            const position = getInsertPosition(e);
            showInsertIndicator(position);
        }
    });
}

/**
 * Funciones de utilidad para drag & drop
 */
const DragDropUtils = {
    
    /**
     * Verifica si un elemento se puede arrastrar
     */
    canDrag: function(element) {
        return element.draggable && !element.classList.contains('disabled');
    },
    
    /**
     * Obtiene datos del elemento arrastrado
     */
    getElementData: function(element) {
        return {
            id: element.dataset.elementId,
            type: element.dataset.elementType,
            source: element.dataset.source || 'library'
        };
    },
    
    /**
     * Verifica si el drop es válido
     */
    isValidDrop: function(dragData, dropTarget) {
        // Verificar límites
        if (editorState.elements.length >= EDITOR_CONFIG.maxElements) {
            return false;
        }
        
        // Verificar zona de drop válida
        const validZones = ['dropZone', 'editorContent'];
        return validZones.some(zone => 
            dropTarget.id === zone || dropTarget.closest(`#${zone}`)
        );
    },
    
    /**
     * Maneja errores de drag & drop
     */
    handleError: function(error, context = '') {
        console.error(`Error en drag & drop ${context}:`, error);
        showNotification(`Error: ${error.message}`, 'error');
    }
};

// Inicializar funcionalidades adicionales
document.addEventListener('DOMContentLoaded', function() {
    setupFileDropHandler();
    setupInternalDragDrop();
});

// CSS para drag & drop (se añadirá dinámicamente)
const dragDropStyles = `
    .element-ghost {
        opacity: 0.3;
        background: #f0f0f0;
    }
    
    .element-chosen {
        transform: scale(1.02);
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }
    
    .element-drag {
        transform: rotate(5deg);
        opacity: 0.8;
    }
    
    .file-drag-over {
        border-color: #28a745 !important;
        background-color: #d4edda !important;
    }
    
    .insert-indicator {
        height: 4px;
        margin: 8px 0;
        position: relative;
    }
    
    .insert-line {
        height: 100%;
        background: linear-gradient(90deg, transparent, #6f42c1, transparent);
        border-radius: 2px;
        animation: insertPulse 1s ease-in-out infinite;
    }
    
    @keyframes insertPulse {
        0%, 100% { opacity: 0.6; }
        50% { opacity: 1; }
    }
`;

// Inyectar estilos
const styleSheet = document.createElement('style');
styleSheet.textContent = dragDropStyles;
document.head.appendChild(styleSheet);

console.log('✅ Drag & Drop JavaScript cargado');
