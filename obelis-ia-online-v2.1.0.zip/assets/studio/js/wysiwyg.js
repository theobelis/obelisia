/**
 * Obelis Studio - WYSIWYG functionality
 * Editor de texto enriquecido y funcionalidades avanzadas
 */

let quillInstances = new Map();

/**
 * Inicializa Quill.js para edición de texto
 */
function initializeQuill() {
    // Configuración global de Quill
    const quillOptions = {
        theme: 'snow',
        modules: {
            toolbar: [
                [{ 'header': [1, 2, 3, false] }],
                ['bold', 'italic', 'underline', 'strike'],
                [{ 'color': [] }, { 'background': [] }],
                [{ 'align': [] }],
                [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                ['blockquote', 'code-block'],
                ['link', 'image'],
                ['clean']
            ]
        },
        placeholder: 'Escribe tu contenido aquí...'
    };
    
    window.QuillConfig = quillOptions;
}

/**
 * Crea un editor Quill para un elemento específico
 */
function createQuillEditor(elementId, content = '') {
    const container = document.createElement('div');
    container.className = 'quill-editor';
    container.innerHTML = content;
    
    const quill = new Quill(container, window.QuillConfig);
    
    // Guardar instancia
    quillInstances.set(elementId, quill);
    
    // Event listeners
    quill.on('text-change', function() {
        updateElementContent(elementId, quill.root.innerHTML);
        markAsModified();
    });
    
    return container;
}

/**
 * Obtiene el contenido de un editor Quill
 */
function getQuillContent(elementId) {
    const quill = quillInstances.get(elementId);
    return quill ? quill.root.innerHTML : '';
}

/**
 * Actualiza el contenido de un elemento
 */
function updateElementContent(elementId, content) {
    const elementData = editorState.elements.find(el => el.id === elementId);
    if (elementData) {
        if (!elementData.content) {
            elementData.content = {};
        }
        elementData.content.text = content;
    }
}

/**
 * Activa el modo de edición para un elemento
 */
function activateEditMode(elementId) {
    const element = document.querySelector(`[data-element-id="${elementId}"]`);
    const elementData = editorState.elements.find(el => el.id === elementId);
    
    if (!element || !elementData) return;
    
    // Diferentes modos de edición según el tipo
    switch (elementData.type) {
        case 'text':
        case 'paragraph':
            activateTextEdit(elementId, element, elementData);
            break;
        case 'heading':
            activateHeadingEdit(elementId, element, elementData);
            break;
        case 'image':
            showImageEditModal(elementId, elementData);
            break;
        case 'audio':
            showAudioEditModal(elementId, elementData);
            break;
        case 'video':
            showVideoEditModal(elementId, elementData);
            break;
        default:
            showElementSettingsModal(elementId, elementData);
    }
}

/**
 * Activa edición de texto
 */
function activateTextEdit(elementId, element, elementData) {
    const textContainer = element.querySelector('.element-text, .element-paragraph');
    if (!textContainer) return;
    
    // Guardar contenido original
    const originalContent = textContainer.innerHTML;
    
    // Crear editor Quill
    const editorContainer = createQuillEditor(elementId, originalContent);
    
    // Reemplazar contenido
    textContainer.style.display = 'none';
    element.insertBefore(editorContainer, textContainer.nextSibling);
    
    // Crear botones de acción
    const actionButtons = document.createElement('div');
    actionButtons.className = 'edit-actions mt-2';
    actionButtons.innerHTML = `
        <button class="btn btn-sm btn-success me-2" onclick="saveTextEdit('${elementId}')">
            <i class="fas fa-check"></i> Guardar
        </button>
        <button class="btn btn-sm btn-secondary" onclick="cancelTextEdit('${elementId}')">
            <i class="fas fa-times"></i> Cancelar
        </button>
    `;
    
    element.appendChild(actionButtons);
    
    // Foco en el editor
    const quill = quillInstances.get(elementId);
    if (quill) {
        quill.focus();
    }
}

/**
 * Activa edición de título
 */
function activateHeadingEdit(elementId, element, elementData) {
    const headingElement = element.querySelector('h1, h2, h3, h4, h5, h6');
    if (!headingElement) return;
    
    const originalText = headingElement.textContent;
    const level = headingElement.tagName.toLowerCase();
    
    // Crear input de edición
    const editContainer = document.createElement('div');
    editContainer.className = 'heading-edit';
    editContainer.innerHTML = `
        <div class="row">
            <div class="col-8">
                <input type="text" class="form-control" value="${originalText}" id="headingInput_${elementId}">
            </div>
            <div class="col-4">
                <select class="form-select" id="headingLevel_${elementId}">
                    <option value="h1" ${level === 'h1' ? 'selected' : ''}>H1</option>
                    <option value="h2" ${level === 'h2' ? 'selected' : ''}>H2</option>
                    <option value="h3" ${level === 'h3' ? 'selected' : ''}>H3</option>
                    <option value="h4" ${level === 'h4' ? 'selected' : ''}>H4</option>
                    <option value="h5" ${level === 'h5' ? 'selected' : ''}>H5</option>
                    <option value="h6" ${level === 'h6' ? 'selected' : ''}>H6</option>
                </select>
            </div>
        </div>
        <div class="edit-actions mt-2">
            <button class="btn btn-sm btn-success me-2" onclick="saveHeadingEdit('${elementId}')">
                <i class="fas fa-check"></i> Guardar
            </button>
            <button class="btn btn-sm btn-secondary" onclick="cancelHeadingEdit('${elementId}')">
                <i class="fas fa-times"></i> Cancelar
            </button>
        </div>
    `;
    
    // Ocultar título original y mostrar editor
    headingElement.style.display = 'none';
    element.appendChild(editContainer);
    
    // Foco en el input
    document.getElementById(`headingInput_${elementId}`).focus();
}

/**
 * Guarda la edición de texto
 */
window.saveTextEdit = function(elementId) {
    const quill = quillInstances.get(elementId);
    const element = document.querySelector(`[data-element-id="${elementId}"]`);
    
    if (!quill || !element) return;
    
    // Obtener contenido del editor
    const newContent = quill.root.innerHTML;
    
    // Actualizar elemento visual
    const textContainer = element.querySelector('.element-text, .element-paragraph');
    textContainer.innerHTML = newContent;
    textContainer.style.display = 'block';
    
    // Limpiar editor
    element.querySelector('.quill-editor').remove();
    element.querySelector('.edit-actions').remove();
    quillInstances.delete(elementId);
    
    // Actualizar datos
    updateElementContent(elementId, newContent);
    markAsModified();
    
    showNotification('Texto actualizado', 'success');
};

/**
 * Cancela la edición de texto
 */
window.cancelTextEdit = function(elementId) {
    const element = document.querySelector(`[data-element-id="${elementId}"]`);
    
    if (!element) return;
    
    // Restaurar contenido original
    const textContainer = element.querySelector('.element-text, .element-paragraph');
    textContainer.style.display = 'block';
    
    // Limpiar editor
    const editorContainer = element.querySelector('.quill-editor');
    const actionsContainer = element.querySelector('.edit-actions');
    
    if (editorContainer) editorContainer.remove();
    if (actionsContainer) actionsContainer.remove();
    
    quillInstances.delete(elementId);
};

/**
 * Guarda la edición de título
 */
window.saveHeadingEdit = function(elementId) {
    const element = document.querySelector(`[data-element-id="${elementId}"]`);
    const input = document.getElementById(`headingInput_${elementId}`);
    const levelSelect = document.getElementById(`headingLevel_${elementId}`);
    
    if (!element || !input || !levelSelect) return;
    
    const newText = input.value.trim();
    const newLevel = levelSelect.value;
    
    if (!newText) {
        showNotification('El título no puede estar vacío', 'warning');
        return;
    }
    
    // Actualizar elemento visual
    const headingElement = element.querySelector('h1, h2, h3, h4, h5, h6');
    headingElement.outerHTML = `<${newLevel}>${newText}</${newLevel}>`;
    
    // Limpiar editor
    element.querySelector('.heading-edit').remove();
    
    // Actualizar datos
    const elementData = editorState.elements.find(el => el.id === elementId);
    if (elementData) {
        elementData.content.text = newText;
        elementData.settings.level = parseInt(newLevel.replace('h', ''));
    }
    
    markAsModified();
    showNotification('Título actualizado', 'success');
};

/**
 * Cancela la edición de título
 */
window.cancelHeadingEdit = function(elementId) {
    const element = document.querySelector(`[data-element-id="${elementId}"]`);
    
    if (!element) return;
    
    // Restaurar título original
    const headingElement = element.querySelector('h1, h2, h3, h4, h5, h6');
    headingElement.style.display = 'block';
    
    // Limpiar editor
    const editContainer = element.querySelector('.heading-edit');
    if (editContainer) editContainer.remove();
};

/**
 * Muestra modal de edición de imagen
 */
function showImageEditModal(elementId, elementData) {
    const modal = document.getElementById('elementSettingsModal');
    const modalBody = document.getElementById('elementSettingsBody');
    
    modalBody.innerHTML = `
        <div class="row">
            <div class="col-6">
                <img src="${elementData.content.file_path}" class="img-fluid rounded" alt="Preview">
            </div>
            <div class="col-6">
                <div class="mb-3">
                    <label class="form-label">Ancho</label>
                    <select class="form-select" id="imageWidth">
                        <option value="100%" ${elementData.settings.width === '100%' ? 'selected' : ''}>Ancho completo</option>
                        <option value="75%" ${elementData.settings.width === '75%' ? 'selected' : ''}>75%</option>
                        <option value="50%" ${elementData.settings.width === '50%' ? 'selected' : ''}>50%</option>
                        <option value="25%" ${elementData.settings.width === '25%' ? 'selected' : ''}>25%</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Alineación</label>
                    <select class="form-select" id="imageAlignment">
                        <option value="left" ${elementData.settings.alignment === 'left' ? 'selected' : ''}>Izquierda</option>
                        <option value="center" ${elementData.settings.alignment === 'center' ? 'selected' : ''}>Centro</option>
                        <option value="right" ${elementData.settings.alignment === 'right' ? 'selected' : ''}>Derecha</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Radio de borde</label>
                    <input type="range" class="form-range" min="0" max="50" value="${parseInt(elementData.settings.border_radius)}" id="borderRadius">
                    <div class="d-flex justify-content-between text-muted small">
                        <span>0px</span>
                        <span id="borderRadiusValue">${elementData.settings.border_radius}</span>
                        <span>50px</span>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Descripción</label>
                    <input type="text" class="form-control" id="imageCaption" value="${elementData.settings.caption || ''}" placeholder="Descripción opcional">
                </div>
            </div>
        </div>
    `;
    
    // Event listener para el rango
    document.getElementById('borderRadius').addEventListener('input', function() {
        document.getElementById('borderRadiusValue').textContent = this.value + 'px';
    });
    
    // Configurar botón de guardar
    document.getElementById('saveElementSettings').onclick = function() {
        saveImageSettings(elementId);
    };
    
    new bootstrap.Modal(modal).show();
}

/**
 * Guarda configuraciones de imagen
 */
function saveImageSettings(elementId) {
    const elementData = editorState.elements.find(el => el.id === elementId);
    const element = document.querySelector(`[data-element-id="${elementId}"]`);
    
    if (!elementData || !element) return;
    
    // Obtener nuevos valores
    const width = document.getElementById('imageWidth').value;
    const alignment = document.getElementById('imageAlignment').value;
    const borderRadius = document.getElementById('borderRadius').value + 'px';
    const caption = document.getElementById('imageCaption').value;
    
    // Actualizar configuración
    elementData.settings.width = width;
    elementData.settings.alignment = alignment;
    elementData.settings.border_radius = borderRadius;
    elementData.settings.caption = caption;
    
    // Actualizar elemento visual
    const img = element.querySelector('img');
    const container = element.querySelector('.element-image');
    
    img.style.width = width;
    img.style.borderRadius = borderRadius;
    container.style.textAlign = alignment;
    
    // Actualizar o crear descripción
    let captionEl = element.querySelector('.image-caption');
    if (caption) {
        if (!captionEl) {
            captionEl = document.createElement('div');
            captionEl.className = 'image-caption mt-2';
            container.appendChild(captionEl);
        }
        captionEl.textContent = caption;
    } else if (captionEl) {
        captionEl.remove();
    }
    
    markAsModified();
    bootstrap.Modal.getInstance(document.getElementById('elementSettingsModal')).hide();
    showNotification('Configuración de imagen actualizada', 'success');
}

/**
 * Funciones de utilidad para WYSIWYG
 */
const WYSIWYGUtils = {
    
    /**
     * Limpia HTML de contenido peligroso
     */
    sanitizeHTML: function(html) {
        const temp = document.createElement('div');
        temp.innerHTML = html;
        
        // Remover scripts y eventos
        const scripts = temp.querySelectorAll('script');
        scripts.forEach(script => script.remove());
        
        const elements = temp.querySelectorAll('*');
        elements.forEach(el => {
            // Remover atributos de eventos
            for (let attr of el.attributes) {
                if (attr.name.startsWith('on')) {
                    el.removeAttribute(attr.name);
                }
            }
        });
        
        return temp.innerHTML;
    },
    
    /**
     * Convierte texto plano a HTML
     */
    textToHTML: function(text) {
        return text
            .replace(/\n/g, '<br>')
            .replace(/\t/g, '&nbsp;&nbsp;&nbsp;&nbsp;');
    },
    
    /**
     * Extrae texto plano de HTML
     */
    htmlToText: function(html) {
        const temp = document.createElement('div');
        temp.innerHTML = html;
        return temp.textContent || temp.innerText || '';
    },
    
    /**
     * Aplica formato a una selección
     */
    applyFormat: function(elementId, format, value = null) {
        const quill = quillInstances.get(elementId);
        if (!quill) return;
        
        const range = quill.getSelection();
        if (!range) return;
        
        switch (format) {
            case 'bold':
                quill.format('bold', !quill.getFormat().bold);
                break;
            case 'italic':
                quill.format('italic', !quill.getFormat().italic);
                break;
            case 'color':
                quill.format('color', value);
                break;
            // Agregar más formatos según necesidad
        }
    }
};

// Implementar editElement globalmente
window.editElement = function(elementId) {
    activateEditMode(elementId);
};

console.log('✅ WYSIWYG JavaScript cargado');
