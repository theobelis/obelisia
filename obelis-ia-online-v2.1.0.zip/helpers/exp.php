<?php
// helpers/exp.php
// Inicializa la conexión a la base de datos
require_once __DIR__ . '/db.php';

// Constantes de experiencia
define('EXP_USO_HERRAMIENTA', 5);
define('EXP_GUARDAR_CREACION', 10);
define('EXP_MULTIPLIER_PREMIUM', 2);

/**
 * Suma EXP al usuario según la acción realizada.
 *
 * @param int $userId
 * @param string $actionType ('use_tool' o 'save_creation')
 * @global PDO $db
 * @return void
 */
function addExp(int $userId, string $actionType)
{
    global $db;
    // Obtener datos del usuario
    $stmt = $db->prepare("SELECT exp_total, membership_type FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user) return;

    // Registrar actividad de uso de herramienta o guardado de creación
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $action = ($actionType === 'use_tool') ? 'Uso de herramienta' : 'Guardado de creación';
    $description = ($actionType === 'use_tool') ? 'El usuario utilizó una herramienta IA.' : 'El usuario guardó una creación.';
    $stmtLog = $db->prepare("INSERT INTO activity_logs (user_id, action, description, ip_address, user_agent, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmtLog->execute([$userId, $action, $description, $ip, $ua]);

    // Determinar EXP base según acción
    $exp = 0;
    switch ($actionType) {
        case 'use_tool':
            $exp = EXP_USO_HERRAMIENTA;
            break;
        case 'save_creation':
            $exp = EXP_GUARDAR_CREACION;
            break;
        default:
            return; // Acción no reconocida
    }

    // Multiplicador para usuarios premium
    if ($user['membership_type'] === 'premium') {
        $exp *= EXP_MULTIPLIER_PREMIUM;
    }

    // Sumar EXP y actualizar en la base de datos
    $newExpTotal = $user['exp_total'] + $exp;
    $stmt = $db->prepare("UPDATE users SET exp_total = ? WHERE id = ?");
    $stmt->execute([$newExpTotal, $userId]);

    // Verificar si sube de nivel
    checkAndLevelUp($userId);
}

/**
 * Verifica si el usuario debe subir de nivel y actualiza los valores.
 *
 * @param int $userId
 * @global PDO $db
 * @return void
 */
function checkAndLevelUp(int $userId)
{
    global $db;
    // Obtener datos actuales
    $stmt = $db->prepare("SELECT level, exp_total, exp_until_next_level FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user) return;

    $level = (int)$user['level'];
    $expTotal = (int)$user['exp_total'];
    $expNext = (int)$user['exp_until_next_level'];

    // Subir de nivel mientras tenga suficiente EXP
    $leveledUp = false;
    while ($expTotal >= $expNext) {
        $expTotal -= $expNext;
        $level++;
        $expNext = 100 * ($level + 1); // Fórmula de EXP para siguiente nivel
        $leveledUp = true;
    }

    if ($leveledUp) {
        // Actualizar en la base de datos
        $stmt = $db->prepare("UPDATE users SET level = ?, exp_total = ?, exp_until_next_level = ? WHERE id = ?");
        $stmt->execute([$level, $expTotal, $expNext, $userId]);
    }
}

/**
 * Guarda una creación del usuario y otorga EXP.
 *
 * @param int $userId
 * @param array $creationData (debe incluir al menos 'file_path', 'tool_used', etc.)
 * @global PDO $db
 * @return void
 */
function saveCreationAndAwardExp(int $userId, array $creationData)
{
    global $db;
    // Insertar la creación en la tabla user_creations (ahora con title, description y privacy)
    $privacy = ($creationData['privacy'] ?? 'private') === 'public' ? 'public' : 'private';
    $stmt = $db->prepare("INSERT INTO user_creations (user_id, file_path, tool_used, title, description, privacy, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
    $stmt->execute([
        $userId,
        $creationData['file_path'] ?? null,
        $creationData['tool_used'] ?? null,
        $creationData['title'] ?? null,
        $creationData['description'] ?? null,
        $privacy
    ]);
    // Registrar actividad específica de guardado de creación
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $desc = 'Guardó una creación con la herramienta: ' . ($creationData['tool_used'] ?? 'desconocida');
    $stmtLog = $db->prepare("INSERT INTO activity_logs (user_id, action, description, ip_address, user_agent, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmtLog->execute([$userId, 'Guardado de creación', $desc, $ip, $ua]);
    // Otorgar EXP por guardar creación
    addExp($userId, 'save_creation');
}
