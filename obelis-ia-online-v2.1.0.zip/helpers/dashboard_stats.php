<?php
// Elimina registros de tool_usage con más de 1 mes de antigüedad
function clean_old_tool_usage($db, $user_id) {
    $stmt = $db->prepare("DELETE FROM tool_usage WHERE user_id = ? AND created_at < DATE_SUB(NOW(), INTERVAL 1 MONTH)");
    $stmt->execute([$user_id]);
}
// helpers/dashboard_stats.php
// Funciones para obtener actividad reciente y estadísticas del usuario

function get_recent_activity($db, $user_id, $limit = 5) {
    $limit = (int)$limit;
    $stmt = $db->prepare("SELECT action, description, created_at FROM activity_logs WHERE user_id = ? AND action != 'Navegación' ORDER BY created_at DESC LIMIT $limit");
    $stmt->execute([$user_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function get_tool_usage_stats($db, $user_id) {
    // Contar herramientas únicas usadas este mes desde tool_usage
    $stmt = $db->prepare("SELECT COUNT(DISTINCT tool_id) as used_this_month FROM tool_usage WHERE user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 1 MONTH)");
    $stmt->execute([$user_id]);
    $used_this_month = $stmt->fetchColumn();

    // Total permitido (puedes ajustar según tu lógica de planes)
    $stmt2 = $db->prepare("SELECT max_monthly_usage FROM users WHERE id = ?");
    $stmt2->execute([$user_id]);
    $max_monthly = $stmt2->fetchColumn();
    if (!$max_monthly) $max_monthly = 20; // valor por defecto

    return [
        'used_this_month' => (int)$used_this_month,
        'max_monthly' => (int)$max_monthly
    ];
}

function get_active_time_stats($db, $user_id) {
    // Sumar tiempo activo real por día usando activity_logs
    $stmt = $db->prepare("SELECT DATE(created_at) as dia, MIN(created_at) as inicio, MAX(created_at) as fin FROM activity_logs WHERE user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) GROUP BY dia");
    $stmt->execute([$user_id]);
    $dias = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $total_segundos = 0;
    foreach ($dias as $dia) {
        $inicio = strtotime($dia['inicio']);
        $fin = strtotime($dia['fin']);
        if ($fin > $inicio) {
            $total_segundos += ($fin - $inicio);
        } else {
            $total_segundos += 600; // Si solo hay un registro, suma 10 minutos por defecto
        }

        // Eliminar solo los logs de navegación intermedios, conservar solo el primero y el último de navegación de cada día
        $stmt_nav = $db->prepare("SELECT id FROM activity_logs WHERE user_id = ? AND action = 'Navegación' AND DATE(created_at) = ? ORDER BY created_at ASC");
        $stmt_nav->execute([$user_id, $dia['dia']]);
        $nav_ids = $stmt_nav->fetchAll(PDO::FETCH_COLUMN);
        if (count($nav_ids) > 2) {
            // Conservar solo el primer y último log de navegación
            $ids_to_delete = array_slice($nav_ids, 1, -1); // todos menos el primero y el último
            if (!empty($ids_to_delete)) {
                $in = str_repeat('?,', count($ids_to_delete) - 1) . '?';
                $params = $ids_to_delete;
                $sql = "DELETE FROM activity_logs WHERE id IN ($in)";
                $stmt_del = $db->prepare($sql);
                $stmt_del->execute($params);
            }
        }
    }
    $horas = floor($total_segundos / 3600);
    $minutos = floor(($total_segundos % 3600) / 60);
    return [
        'horas' => (int)$horas,
        'minutos' => (int)$minutos
    ];
}
