<?php
/**
 * Helper: Envío de emails de confirmación de suscripción
 */

function send_subscription_confirmation($user_id, $plan, $billing_cycle, $amount, $transaction_id) {
    global $db;
    
    // Obtener datos del usuario
    $stmt = $db->prepare("SELECT email, first_name, last_name FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        throw new Exception('Usuario no encontrado');
    }
    
    $to = $user['email'];
    $name = trim($user['first_name'] . ' ' . $user['last_name']);
    
    // Configurar detalles del plan
    $plan_details = [
        'premium' => [
            'name' => 'Premium',
            'features' => [
                'Acceso completo a Obelis Studio',
                'Herramientas de IA avanzadas',
                'Generación ilimitada de contenido',
                'Soporte prioritario',
                'Exportación en múltiples formatos',
                'Colaboración en tiempo real'
            ]
        ]
    ];
    
    $billing_labels = [
        'monthly' => 'Mensual',
        'yearly' => 'Anual'
    ];
    
    $plan_name = $plan_details[$plan]['name'] ?? ucfirst($plan);
    $billing_label = $billing_labels[$billing_cycle] ?? ucfirst($billing_cycle);
    $features = $plan_details[$plan]['features'] ?? [];
    
    // Calcular fecha de expiración
    $expiry_date = $billing_cycle === 'yearly' ? 
        date('d/m/Y', strtotime('+1 year')) : 
        date('d/m/Y', strtotime('+1 month'));
    
    // Construir email HTML
    $subject = "¡Bienvenido a Obelis Premium! - Confirmación de suscripción";
    
    $html_body = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Confirmación de Suscripción</title>
        <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 0; background-color: #f8f9fa; }
            .container { max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
            .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 40px 30px; text-align: center; }
            .header h1 { margin: 0; font-size: 28px; font-weight: 600; }
            .header p { margin: 10px 0 0; font-size: 16px; opacity: 0.9; }
            .content { padding: 40px 30px; }
            .welcome { text-align: center; margin-bottom: 30px; }
            .welcome h2 { color: #2d3748; margin: 0 0 10px; font-size: 24px; }
            .welcome p { color: #718096; font-size: 16px; margin: 0; }
            .plan-details { background-color: #f7fafc; border-radius: 8px; padding: 25px; margin: 30px 0; }
            .plan-title { font-size: 20px; font-weight: 600; color: #2d3748; margin: 0 0 15px; }
            .plan-info { display: flex; justify-content: space-between; margin-bottom: 20px; }
            .plan-info div { text-align: center; }
            .plan-info .label { color: #718096; font-size: 14px; margin-bottom: 5px; }
            .plan-info .value { color: #2d3748; font-size: 18px; font-weight: 600; }
            .features { margin-top: 20px; }
            .features h4 { color: #2d3748; margin: 0 0 15px; font-size: 16px; }
            .features ul { margin: 0; padding: 0; list-style: none; }
            .features li { color: #4a5568; margin-bottom: 8px; padding-left: 20px; position: relative; }
            .features li:before { content: '✓'; color: #48bb78; font-weight: bold; position: absolute; left: 0; }
            .transaction { background-color: #edf2f7; border-radius: 6px; padding: 20px; margin: 20px 0; }
            .transaction h4 { margin: 0 0 15px; color: #2d3748; }
            .transaction-row { display: flex; justify-content: space-between; margin-bottom: 8px; }
            .transaction-row:last-child { margin-bottom: 0; font-weight: 600; }
            .cta { text-align: center; margin: 30px 0; }
            .btn { display: inline-block; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 15px 30px; text-decoration: none; border-radius: 6px; font-weight: 600; }
            .footer { background-color: #f7fafc; padding: 30px; text-align: center; color: #718096; font-size: 14px; }
            .footer a { color: #667eea; text-decoration: none; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>🎉 ¡Suscripción Activada!</h1>
                <p>Ahora eres parte de Obelis Premium</p>
            </div>
            
            <div class='content'>
                <div class='welcome'>
                    <h2>¡Hola, " . htmlspecialchars($name) . "!</h2>
                    <p>Tu suscripción a Obelis Premium ha sido activada exitosamente. Ya puedes disfrutar de todas las características premium.</p>
                </div>
                
                <div class='plan-details'>
                    <div class='plan-title'>Detalles de tu Suscripción</div>
                    <div class='plan-info'>
                        <div>
                            <div class='label'>Plan</div>
                            <div class='value'>{$plan_name}</div>
                        </div>
                        <div>
                            <div class='label'>Facturación</div>
                            <div class='value'>{$billing_label}</div>
                        </div>
                        <div>
                            <div class='label'>Válido hasta</div>
                            <div class='value'>{$expiry_date}</div>
                        </div>
                    </div>
                    
                    <div class='features'>
                        <h4>Características incluidas:</h4>
                        <ul>";
                        
    foreach ($features as $feature) {
        $html_body .= "<li>" . htmlspecialchars($feature) . "</li>";
    }
    
    $html_body .= "
                        </ul>
                    </div>
                </div>
                
                <div class='transaction'>
                    <h4>Detalles de la Transacción</h4>
                    <div class='transaction-row'>
                        <span>ID de Transacción:</span>
                        <span>" . htmlspecialchars($transaction_id) . "</span>
                    </div>
                    <div class='transaction-row'>
                        <span>Método de Pago:</span>
                        <span>PayPal</span>
                    </div>
                    <div class='transaction-row'>
                        <span>Monto:</span>
                        <span>$" . number_format($amount, 2) . " USD</span>
                    </div>
                    <div class='transaction-row'>
                        <span>Fecha:</span>
                        <span>" . date('d/m/Y H:i') . "</span>
                    </div>
                </div>
                
                <div class='cta'>
                    <a href='" . SITE_URL . "/studio/' class='btn'>Comenzar con Obelis Studio</a>
                </div>
            </div>
            
            <div class='footer'>
                <p>Si tienes alguna pregunta, contáctanos en <a href='mailto:soporte@obelis.com'>soporte@obelis.com</a></p>
                <p>© " . date('Y') . " Obelis. Todos los derechos reservados.</p>
                <p><a href='" . SITE_URL . "/pages/legal/terms.php'>Términos</a> | <a href='" . SITE_URL . "/pages/legal/privacy.php'>Privacidad</a></p>
            </div>
        </div>
    </body>
    </html>";
    
    // Versión texto plano
    $text_body = "
¡Hola, {$name}!

Tu suscripción a Obelis Premium ha sido activada exitosamente.

DETALLES DE LA SUSCRIPCIÓN:
- Plan: {$plan_name}
- Facturación: {$billing_label}
- Válido hasta: {$expiry_date}

CARACTERÍSTICAS INCLUIDAS:
" . implode("\n", array_map(function($f) { return "• {$f}"; }, $features)) . "

DETALLES DE LA TRANSACCIÓN:
- ID: {$transaction_id}
- Método: PayPal
- Monto: $" . number_format($amount, 2) . " USD
- Fecha: " . date('d/m/Y H:i') . "

Puedes comenzar a usar Obelis Studio visitando: " . SITE_URL . "/studio/

Si tienes alguna pregunta, contáctanos en soporte@obelis.com

© " . date('Y') . " Obelis. Todos los derechos reservados.
    ";
    
    // Headers del email
    $headers = "From: Obelis <noreply@obelis.com>\r\n";
    $headers .= "Reply-To: soporte@obelis.com\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: multipart/alternative; boundary=\"boundary123\"\r\n";
    
    // Cuerpo multipart
    $email_body = "--boundary123\r\n";
    $email_body .= "Content-Type: text/plain; charset=UTF-8\r\n\r\n";
    $email_body .= $text_body . "\r\n";
    $email_body .= "--boundary123\r\n";
    $email_body .= "Content-Type: text/html; charset=UTF-8\r\n\r\n";
    $email_body .= $html_body . "\r\n";
    $email_body .= "--boundary123--\r\n";
    
    // Enviar email
    $sent = mail($to, $subject, $email_body, $headers);
    
    if (!$sent) {
        throw new Exception('No se pudo enviar el email de confirmación');
    }
    
    return true;
}
?>
