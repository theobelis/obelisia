<?php
/**
 * Helper: Consulta de estadísticas de usuarios
 * Reemplaza la VIEW 'user_statistics' eliminada del SQL
 * 
 * Esta consulta obtiene estadísticas completas de usuarios incluyendo:
 * - Información básica del usuario
 * - Total de uso de herramientas
 * - Total de pagos completados  
 * - Uso mensual de herramientas (últimos 30 días)
 */

require_once __DIR__ . '/db.php';

/**
 * Obtiene estadísticas de usuarios
 * @param PDO $pdo Conexión a la base de datos
 * @param int|null $user_id ID específico de usuario (opcional)
 * @param int $page Página para paginación (default: 1)
 * @param int $limit Límite de resultados por página (default: 20)
 * @return array Estadísticas de usuarios
 */
function getUserStatistics($pdo, $user_id = null, $page = 1, $limit = 20) {
    $offset = ($page - 1) * $limit;
    
    // Consulta base (reemplaza la VIEW user_statistics)
    $sql = "
        SELECT 
            u.id,
            u.username,
            u.email,
            u.membership_type,
            u.status,
            u.created_at,
            u.last_login,
            COUNT(tu.id) AS total_tool_usage,
            COALESCE(SUM(p.amount), 0) AS total_payments,
            (
                SELECT COUNT(0) 
                FROM tool_usage tu2 
                WHERE tu2.user_id = u.id 
                AND tu2.created_at >= CURRENT_TIMESTAMP - INTERVAL 30 DAY
            ) AS monthly_usage
        FROM users u 
        LEFT JOIN tool_usage tu ON u.id = tu.user_id
        LEFT JOIN payments p ON u.id = p.user_id AND p.status = 'completed'
        WHERE u.role <> 'admin'
    ";
    
    $params = [];
    
    // Filtrar por usuario específico si se proporciona
    if ($user_id) {
        $sql .= " AND u.id = ?";
        $params[] = $user_id;
    }
    
    $sql .= " GROUP BY u.id ORDER BY u.created_at DESC";
    
    // Agregar paginación si no es un usuario específico
    if (!$user_id) {
        $sql .= " LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
    }
    
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Formatear resultados
        foreach ($results as &$user) {
            $user['total_tool_usage'] = (int)$user['total_tool_usage'];
            $user['total_payments'] = (float)$user['total_payments'];
            $user['monthly_usage'] = (int)$user['monthly_usage'];
            $user['created_at_formatted'] = date('d/m/Y', strtotime($user['created_at']));
            $user['last_login_formatted'] = $user['last_login'] ? date('d/m/Y H:i', strtotime($user['last_login'])) : 'Nunca';
        }
        
        return $results;
        
    } catch (PDOException $e) {
        error_log("Error en getUserStatistics: " . $e->getMessage());
        return [];
    }
}

/**
 * Obtiene el total de usuarios para paginación
 * @param PDO $pdo Conexión a la base de datos
 * @return int Total de usuarios (excluyendo admins)
 */
function getTotalUsers($pdo) {
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role <> 'admin'");
        $stmt->execute();
        return (int)$stmt->fetchColumn();
    } catch (PDOException $e) {
        error_log("Error en getTotalUsers: " . $e->getMessage());
        return 0;
    }
}

/**
 * Obtiene estadísticas resumidas de todos los usuarios
 * @param PDO $pdo Conexión a la base de datos
 * @return array Estadísticas resumidas
 */
function getUserStatisticsSummary($pdo) {
    try {
        $stmt = $pdo->prepare("
            SELECT 
                COUNT(*) as total_users,
                COUNT(CASE WHEN membership_type = 'premium' THEN 1 END) as premium_users,
                COUNT(CASE WHEN status = 'active' THEN 1 END) as active_users,
                COUNT(CASE WHEN last_login >= CURRENT_TIMESTAMP - INTERVAL 30 DAY THEN 1 END) as monthly_active_users,
                COALESCE(SUM(
                    (SELECT COUNT(*) FROM tool_usage tu WHERE tu.user_id = u.id)
                ), 0) as total_tool_usage,
                COALESCE(SUM(
                    (SELECT SUM(amount) FROM payments p WHERE p.user_id = u.id AND p.status = 'completed')
                ), 0) as total_revenue
            FROM users u 
            WHERE u.role <> 'admin'
        ");
        $stmt->execute();
        $summary = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Formatear números
        $summary['total_users'] = (int)$summary['total_users'];
        $summary['premium_users'] = (int)$summary['premium_users'];
        $summary['active_users'] = (int)$summary['active_users'];
        $summary['monthly_active_users'] = (int)$summary['monthly_active_users'];
        $summary['total_tool_usage'] = (int)$summary['total_tool_usage'];
        $summary['total_revenue'] = (float)$summary['total_revenue'];
        
        return $summary;
        
    } catch (PDOException $e) {
        error_log("Error en getUserStatisticsSummary: " . $e->getMessage());
        return [
            'total_users' => 0,
            'premium_users' => 0,
            'active_users' => 0,
            'monthly_active_users' => 0,
            'total_tool_usage' => 0,
            'total_revenue' => 0.0
        ];
    }
}

/**
 * Función de conveniencia para obtener estadísticas de un usuario específico
 * @param PDO $pdo Conexión a la base de datos
 * @param int $user_id ID del usuario
 * @return array|null Estadísticas del usuario o null si no existe
 */
function getSingleUserStatistics($pdo, $user_id) {
    $results = getUserStatistics($pdo, $user_id);
    return !empty($results) ? $results[0] : null;
}
?>
