<?php
// helpers/generate_sitemap.php
// Script para generar sitemap.xml profesional y dinámico para ObelisIA

// cron-job.org
// --- Protección por clave GET para ejecución remota segura ---
$clave = '280101sitemap'; // Cambia esto por una clave fuerte
if (php_sapi_name() !== 'cli') { // Solo exigir clave si NO es CLI
    if (!isset($_GET['key']) || $_GET['key'] !== $clave) {
        http_response_code(403);
        exit('Acceso denegado');
    }
}

require_once __DIR__ . '/../src/Router/MainRouter.php';

use ObelisIA\Router\MainRouter;

define('BASE_URL', 'https://obelis.online');

date_default_timezone_set('America/Lima');
$today = date('Y-m-d');

// 1. Rutas públicas principales (del router)
$publicRoutes = [
    '' => ['changefreq' => 'daily',   'priority' => '1.0'],
    'inicio' => ['changefreq' => 'daily',   'priority' => '1.0'],
    'precios' => ['changefreq' => 'monthly', 'priority' => '0.8'],
    'caracteristicas' => ['changefreq' => 'monthly', 'priority' => '0.8'],
    'herramientas' => ['changefreq' => 'weekly',  'priority' => '0.9'],
    'contacto' => ['changefreq' => 'yearly',  'priority' => '0.5'],
    'acerca' => ['changefreq' => 'yearly',  'priority' => '0.5'],
    'legal/privacidad' => ['changefreq' => 'yearly',  'priority' => '0.3'],
    'legal/terminos' => ['changefreq' => 'yearly',  'priority' => '0.3'],
    'soporte/faq' => ['changefreq' => 'monthly', 'priority' => '0.4'],
];

// 2. Herramientas individuales (slugs)
$toolSlugs = [
    'bg-remover',
    'color-palette',
    'convert-img',
    'edit-img',
    'ia-audio',
    'ia-img',
    'ia-text',
    'ia-video',
    'word-counter',
    'music-composer',
    'image-generator',
    'text-generator',
    'video-generator',
    'image-converter',
    'image-editor',
];

// 3. Construir XML
$xml = [];
$xml[] = '<?xml version="1.0" encoding="UTF-8"?>';
$xml[] = '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

foreach ($publicRoutes as $route => $meta) {
    $loc = BASE_URL . ($route ? '/' . $route : '/');
    $xml[] = "  <url>";
    $xml[] = "    <loc>{$loc}</loc>";
    $xml[] = "    <lastmod>{$today}</lastmod>";
    $xml[] = "    <changefreq>{$meta['changefreq']}</changefreq>";
    $xml[] = "    <priority>{$meta['priority']}</priority>";
    $xml[] = "  </url>";
}

foreach ($toolSlugs as $slug) {
    $loc = BASE_URL . '/herramientas/' . $slug;
    $xml[] = "  <url>";
    $xml[] = "    <loc>{$loc}</loc>";
    $xml[] = "    <lastmod>{$today}</lastmod>";
    $xml[] = "    <changefreq>weekly</changefreq>";
    $xml[] = "    <priority>0.7</priority>";
    $xml[] = "  </url>";
}

$xml[] = '</urlset>';

// 4. Guardar sitemap.xml en la raíz
file_put_contents(__DIR__ . '/../sitemap.xml', implode("\n", $xml));
echo "Sitemap generado correctamente en sitemap.xml\n";
