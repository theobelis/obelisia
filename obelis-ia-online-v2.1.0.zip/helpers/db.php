<?php
// helpers/db.php
// Obtiene la conexión PDO usando la clase centralizada

// Cargar variables de entorno
require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../src/Database/Database.php';

use Dotenv\Dotenv;
use ObelisIA\Database\Database;

// Inicializar variables de entorno
$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

function getDbConnection() {
    // Usar MySQLi para compatibilidad con ObelisStudio
    $host = $_ENV['DB_HOST'];
    $db_name = $_ENV['DB_NAME'];
    $username = $_ENV['DB_USER'];
    $password = $_ENV['DB_PASS'];
    
    $connection = new mysqli($host, $username, $password, $db_name);
    
    if ($connection->connect_error) {
        error_log('Error de conexión mysqli: ' . $connection->connect_error);
        return null;
    }
    
    $connection->set_charset("utf8mb4");
    return $connection;
}

// Mantener compatibilidad PDO para otros módulos
function getPdoConnection() {
    $database = new Database();
    return $database->getConnection();
}

$database = new Database();
$db = getDbConnection(); // Cambiar a mysqli por defecto
$pdo = getPdoConnection(); // Mantener PDO disponible

if (!$db) {
    error_log('Error de conexión a la base de datos (helpers/db.php)');
    http_response_code(500);
    die(json_encode(['error' => 'Error de conexión a la base de datos']));
}

// Asegúrate de que la tabla tenga la columna privacy
// Si la columna privacy no existe, agrégala (solo para desarrollo, puedes migrar en producción)
try {
    $db->query("ALTER TABLE user_creations ADD COLUMN privacy ENUM('public','private') NOT NULL DEFAULT 'private'");
} catch (Exception $e) {
    // Ya existe, ignorar
}
?>
