<?php
/**
 * Centraliza el registro de actividad de usuario y admin.
 * Llama SIEMPRE a estas funciones desde backend, nunca uses includes sueltos.
 *
 * Ejemplo de uso:
 *   log_user_activity($db, $user['id'], 'Acción', 'Descripción opcional');
 *   log_admin_activity($db, $user['id'], 'Acción admin', 'Descripción');
 */

/**
 * Registra una actividad de admin en la tabla admin_activity_logs
 * @param PDO $db
 * @param int $user_id
 * @param string $action
 * @param string $description
 * @return bool
 */
function log_admin_activity($db, $user_id, $action, $description) {
    try {
        $stmt = $db->prepare("INSERT INTO admin_activity_logs (user_id, action, description, created_at) VALUES (?, ?, ?, NOW())");
        return $stmt->execute([$user_id, $action, $description]);
    } catch (Exception $e) {
        // Opcional: loguear error a un archivo o sistema externo
        return false;
    }
}

/**
 * Registra una acción en activity_logs para el usuario actual.
 * Si la acción corresponde a una herramienta, también registra en tool_usage.
 * @param PDO $db
 * @param int $user_id
 * @param string $action
 * @param string $description
 * @param array $extra Opcional: ['ip' => ..., 'ua' => ...]
 * @return void
 */
function log_user_activity($db, $user_id, $action, $description = '', $extra = []) {
    $ip = $extra['ip'] ?? ($_SERVER['REMOTE_ADDR'] ?? '');
    $ua = $extra['ua'] ?? ($_SERVER['HTTP_USER_AGENT'] ?? '');
    try {
        $stmt = $db->prepare("INSERT INTO activity_logs (user_id, action, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$user_id, $action, $description, $ip, $ua]);
    } catch (Exception $e) {
        // Opcional: loguear error a un archivo o sistema externo
    }

    // Si la acción es de herramienta, registrar también en tool_usage
    $tool_map = [
        'Generación de imagen' => 2,
        'Generación de audio' => 4,
        'Generación de texto' => 9,
        'Conversión de imagen' => 8,
        'Descarga de imagen editada' => 5,
        'Descarga de imagen sin fondo' => 6,
        'Generación de paleta de colores' => 7
    ];
    if (isset($tool_map[$action])) {
        $tool_id = $tool_map[$action];
        try {
            $stmt2 = $db->prepare("INSERT INTO tool_usage (user_id, tool_id, credits_used, success, metadata) VALUES (?, ?, 1, 1, ?)");
            $meta = json_encode(['description' => $description, 'ip' => $ip, 'ua' => $ua]);
            $stmt2->execute([$user_id, $tool_id, $meta]);
        } catch (Exception $e) {
            // Opcional: loguear error a un archivo o sistema externo
        }
    }
}
