<?php
/**
 * Devuelve la URL de la imagen de perfil del usuario o un placeholder con la inicial si no hay imagen.
 * @param array $user_data Debe contener al menos 'full_name' y opcionalmente 'profile_image'.
 * @param int $size Tamaño de la imagen (en px, por defecto 120)
 * @return string URL de la imagen de perfil
 */
function get_profile_pic_url(array $user_data, int $size = 120): string {
    if (!empty($user_data['profile_image'])) {
        return $user_data['profile_image'];
    }
    $initial = isset($user_data['full_name']) && $user_data['full_name'] !== ''
        ? strtoupper(substr($user_data['full_name'], 0, 1))
        : '?';
    // Puedes personalizar colores aquí
    $bg = '667eea';
    $fg = 'ffffff';
    return "https://placehold.co/{$size}x{$size}/{$bg}/{$fg}?text=" . urlencode($initial);
}
