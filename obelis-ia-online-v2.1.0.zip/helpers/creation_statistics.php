<?php
/**
 * helpers/creation_statistics.php
 * Funciones para obtener estadísticas de creaciones
 * Reemplaza la vista creation_statistics que no se puede crear por permisos
 */

/**
 * Función principal para obtener estadísticas de creaciones con filtros avanzados
 */
function getCreationStatistics($db, $options = []) {
    $defaults = [
        'user_id' => null,
        'type' => null,
        'tool_used' => null,
        'privacy' => null,
        'limit' => null,
        'offset' => 0,
        'order_by' => 'engagement_score',
        'order_dir' => 'DESC',
        'include_user' => false,
        'date_from' => null,
        'date_to' => null
    ];
    
    $options = array_merge($defaults, $options);
    
    $whereConditions = ["uc.status = 'completed'"];
    $params = [];
    
    // Filtros
    if ($options['user_id']) {
        $whereConditions[] = "uc.user_id = ?";
        $params[] = $options['user_id'];
    }
    
    if ($options['type']) {
        $whereConditions[] = "uc.type = ?";
        $params[] = $options['type'];
    }
    
    if ($options['tool_used']) {
        $whereConditions[] = "uc.tool_used = ?";
        $params[] = $options['tool_used'];
    }
    
    if ($options['privacy']) {
        $whereConditions[] = "uc.privacy = ?";
        $params[] = $options['privacy'];
    }
    
    if ($options['date_from']) {
        $whereConditions[] = "uc.created_at >= ?";
        $params[] = $options['date_from'];
    }
    
    if ($options['date_to']) {
        $whereConditions[] = "uc.created_at <= ?";
        $params[] = $options['date_to'];
    }
    
    $whereClause = "WHERE " . implode(" AND ", $whereConditions);
    
    // Campos base
    $selectFields = [
        "uc.id",
        "uc.user_id", 
        "uc.title",
        "uc.description",
        "uc.file_path",
        "uc.type",
        "uc.tool_used",
        "uc.privacy",
        "uc.created_at",
        "COALESCE(likes.like_count, 0) as like_count",
        "COALESCE(comments.comment_count, 0) as comment_count",
        "COALESCE(reports.report_count, 0) as report_count",
        "(COALESCE(likes.like_count, 0) + COALESCE(comments.comment_count, 0) * 2) as engagement_score"
    ];
    
    // Incluir datos del usuario si se solicita
    if ($options['include_user']) {
        $selectFields = array_merge($selectFields, [
            "u.username",
            "u.full_name", 
            "u.profile_image"
        ]);
    }
    
    $userJoin = $options['include_user'] ? "JOIN users u ON uc.user_id = u.id" : "";
    
    // Ordenamiento
    $validOrderFields = ['created_at', 'engagement_score', 'like_count', 'comment_count', 'title'];
    $orderBy = in_array($options['order_by'], $validOrderFields) ? $options['order_by'] : 'engagement_score';
    $orderDir = strtoupper($options['order_dir']) === 'ASC' ? 'ASC' : 'DESC';
    
    // Límite y offset
    $limitClause = "";
    if ($options['limit']) {
        $limitClause = "LIMIT " . intval($options['limit']);
        if ($options['offset']) {
            $limitClause .= " OFFSET " . intval($options['offset']);
        }
    }
    
    $sql = "
        SELECT " . implode(", ", $selectFields) . "
        FROM user_creations uc
        {$userJoin}
        LEFT JOIN (
            SELECT creation_id, COUNT(*) as like_count 
            FROM creation_likes 
            GROUP BY creation_id
        ) likes ON uc.id = likes.creation_id
        LEFT JOIN (
            SELECT creation_id, COUNT(*) as comment_count 
            FROM creation_comments 
            WHERE status = 'active' 
            GROUP BY creation_id
        ) comments ON uc.id = comments.creation_id
        LEFT JOIN (
            SELECT creation_id, COUNT(*) as report_count 
            FROM content_reports 
            WHERE creation_id IS NOT NULL AND status != 'dismissed' 
            GROUP BY creation_id
        ) reports ON uc.id = reports.creation_id
        {$whereClause}
        ORDER BY {$orderBy} {$orderDir}, uc.created_at DESC
        {$limitClause}
    ";
    
    try {
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Procesar resultados
        foreach ($results as &$item) {
            $item['like_count'] = (int)$item['like_count'];
            $item['comment_count'] = (int)$item['comment_count'];
            $item['report_count'] = (int)$item['report_count'];
            $item['engagement_score'] = (int)$item['engagement_score'];
            
            // Usar función timeAgo de social_functions.php si está disponible
            if (function_exists('timeAgo')) {
                $item['created_at_formatted'] = timeAgo($item['created_at']);
            } else {
                $item['created_at_formatted'] = date('d/m/Y', strtotime($item['created_at']));
            }
        }
        
        return $results;
    } catch (Exception $e) {
        error_log("Error getting creation statistics: " . $e->getMessage());
        return [];
    }
}

/**
 * Función para obtener estadísticas resumidas de un usuario
 */
function getUserCreationStats($db, $user_id) {
    $sql = "
        SELECT 
            COUNT(DISTINCT uc.id) as total_creations,
            COUNT(DISTINCT CASE WHEN uc.privacy = 'public' THEN uc.id END) as public_creations,
            COALESCE(SUM(likes.like_count), 0) as total_likes,
            COALESCE(SUM(comments.comment_count), 0) as total_comments,
            COUNT(DISTINCT uc.type) as creation_types,
            ROUND(AVG(COALESCE(likes.like_count, 0) + COALESCE(comments.comment_count, 0) * 2), 2) as avg_engagement,
            (SELECT COUNT(*) FROM user_follows WHERE following_id = ?) as followers_count,
            (SELECT COUNT(*) FROM user_follows WHERE follower_id = ?) as following_count,
            MAX(uc.created_at) as last_creation_date
        FROM user_creations uc
        LEFT JOIN (
            SELECT creation_id, COUNT(*) as like_count 
            FROM creation_likes 
            GROUP BY creation_id
        ) likes ON uc.id = likes.creation_id
        LEFT JOIN (
            SELECT creation_id, COUNT(*) as comment_count 
            FROM creation_comments 
            WHERE status = 'active' 
            GROUP BY creation_id
        ) comments ON uc.id = comments.creation_id
        WHERE uc.user_id = ? AND uc.status = 'completed'
    ";
    
    try {
        $stmt = $db->prepare($sql);
        $stmt->execute([$user_id, $user_id, $user_id]);
        $stats = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($stats) {
            $stats['total_creations'] = (int)$stats['total_creations'];
            $stats['public_creations'] = (int)$stats['public_creations'];
            $stats['total_likes'] = (int)$stats['total_likes'];
            $stats['total_comments'] = (int)$stats['total_comments'];
            $stats['creation_types'] = (int)$stats['creation_types'];
            $stats['followers_count'] = (int)$stats['followers_count'];
            $stats['following_count'] = (int)$stats['following_count'];
            $stats['avg_engagement'] = (float)$stats['avg_engagement'];
        }
        
        return $stats;
    } catch (Exception $e) {
        error_log("Error getting user creation stats: " . $e->getMessage());
        return null;
    }
}

/**
 * Función para obtener las creaciones más populares
 */
function getTopCreations($db, $limit = 10, $period_days = 30, $type = null) {
    $whereConditions = [
        "uc.status = 'completed'",
        "uc.privacy = 'public'"
    ];
    $params = [];
    
    if ($period_days) {
        $whereConditions[] = "uc.created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)";
        $params[] = $period_days;
    }
    
    if ($type) {
        $whereConditions[] = "uc.type = ?";
        $params[] = $type;
    }
    
    $params[] = $limit;
    
    $sql = "
        SELECT 
            uc.id,
            uc.title,
            uc.description,
            uc.file_path,
            uc.type,
            uc.tool_used,
            uc.created_at,
            u.username,
            u.full_name,
            u.profile_image,
            COALESCE(likes.like_count, 0) as like_count,
            COALESCE(comments.comment_count, 0) as comment_count,
            (COALESCE(likes.like_count, 0) + COALESCE(comments.comment_count, 0) * 2) as engagement_score
        FROM user_creations uc
        JOIN users u ON uc.user_id = u.id
        LEFT JOIN (
            SELECT creation_id, COUNT(*) as like_count 
            FROM creation_likes 
            GROUP BY creation_id
        ) likes ON uc.id = likes.creation_id
        LEFT JOIN (
            SELECT creation_id, COUNT(*) as comment_count 
            FROM creation_comments 
            WHERE status = 'active' 
            GROUP BY creation_id
        ) comments ON uc.id = comments.creation_id
        WHERE " . implode(" AND ", $whereConditions) . "
        ORDER BY engagement_score DESC, uc.created_at DESC
        LIMIT ?
    ";
    
    try {
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($results as &$item) {
            $item['like_count'] = (int)$item['like_count'];
            $item['comment_count'] = (int)$item['comment_count'];
            $item['engagement_score'] = (int)$item['engagement_score'];
            
            if (function_exists('timeAgo')) {
                $item['created_at_formatted'] = timeAgo($item['created_at']);
            } else {
                $item['created_at_formatted'] = date('d/m/Y', strtotime($item['created_at']));
            }
        }
        
        return $results;
    } catch (Exception $e) {
        error_log("Error getting top creations: " . $e->getMessage());
        return [];
    }
}

/**
 * Función para buscar creaciones con estadísticas
 */
function searchCreationsWithStats($db, $search_term, $options = []) {
    $defaults = [
        'type' => null,
        'tool_used' => null,
        'limit' => 20,
        'offset' => 0
    ];
    
    $options = array_merge($defaults, $options);
    
    $whereConditions = [
        "uc.status = 'completed'",
        "uc.privacy = 'public'"
    ];
    $params = [];
    
    // Búsqueda por término
    if ($search_term) {
        $whereConditions[] = "(uc.title LIKE ? OR uc.description LIKE ? OR u.username LIKE ?)";
        $search_param = "%{$search_term}%";
        $params = array_merge($params, [$search_param, $search_param, $search_param]);
    }
    
    // Filtros adicionales
    if ($options['type']) {
        $whereConditions[] = "uc.type = ?";
        $params[] = $options['type'];
    }
    
    if ($options['tool_used']) {
        $whereConditions[] = "uc.tool_used = ?";
        $params[] = $options['tool_used'];
    }
    
    $sql = "
        SELECT 
            uc.id,
            uc.title,
            uc.description,
            uc.file_path,
            uc.type,
            uc.tool_used,
            uc.created_at,
            u.username,
            u.full_name,
            u.profile_image,
            COALESCE(likes.like_count, 0) as like_count,
            COALESCE(comments.comment_count, 0) as comment_count,
            (COALESCE(likes.like_count, 0) + COALESCE(comments.comment_count, 0) * 2) as engagement_score
        FROM user_creations uc
        JOIN users u ON uc.user_id = u.id
        LEFT JOIN (
            SELECT creation_id, COUNT(*) as like_count 
            FROM creation_likes 
            GROUP BY creation_id
        ) likes ON uc.id = likes.creation_id
        LEFT JOIN (
            SELECT creation_id, COUNT(*) as comment_count 
            FROM creation_comments 
            WHERE status = 'active' 
            GROUP BY creation_id
        ) comments ON uc.id = comments.creation_id
        WHERE " . implode(" AND ", $whereConditions);
    
    // Ordenamiento por relevancia si hay término de búsqueda
    if ($search_term) {
        $sql .= "
        ORDER BY 
            CASE 
                WHEN uc.title LIKE ? THEN 1
                WHEN uc.description LIKE ? THEN 2
                WHEN u.username LIKE ? THEN 3
                ELSE 4
            END,
            engagement_score DESC,
            uc.created_at DESC";
        $search_param = "%{$search_term}%";
        $params = array_merge($params, [$search_param, $search_param, $search_param]);
    } else {
        $sql .= " ORDER BY engagement_score DESC, uc.created_at DESC";
    }
    
    $sql .= " LIMIT " . intval($options['limit']);
    if ($options['offset']) {
        $sql .= " OFFSET " . intval($options['offset']);
    }
    
    try {
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($results as &$item) {
            $item['like_count'] = (int)$item['like_count'];
            $item['comment_count'] = (int)$item['comment_count'];
            $item['engagement_score'] = (int)$item['engagement_score'];
            
            if (function_exists('timeAgo')) {
                $item['created_at_formatted'] = timeAgo($item['created_at']);
            } else {
                $item['created_at_formatted'] = date('d/m/Y', strtotime($item['created_at']));
            }
        }
        
        return $results;
    } catch (Exception $e) {
        error_log("Error searching creations: " . $e->getMessage());
        return [];
    }
}
?>
