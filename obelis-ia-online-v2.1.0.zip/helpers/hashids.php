<?php
// Hashids helper para ObelisIA
use Hashids\Hashids;

function getHashidsInstance() {
    static $hashids = null;
    if ($hashids === null) {
        $hashids = new Hashids('obelisIA_salt', 8);
    }
    return $hashids;
}
