<?php
// helpers/csrf.php
// Archivo dummy para evitar error de inclusión
// Si necesitas protección CSRF real, implementa aquí la lógica
