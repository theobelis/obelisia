<?php
// api/delete_creation.php
require_once __DIR__ . '/../helpers/db.php';
session_start();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'status' => 'error',
        'message' => 'Método no permitido.'
    ]);
    exit;
}

$userId = $_SESSION['user_id'] ?? null;
if (!$userId) {
    http_response_code(401);
    echo json_encode([
        'status' => 'error',
        'message' => 'No autenticado.'
    ]);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$id = $data['id'] ?? null;
if (!$id) {
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => 'ID de creación no proporcionado.'
    ]);
    exit;
}

// Solo permite borrar creaciones del usuario actual
$stmt = $db->prepare('DELETE FROM user_creations WHERE id = ? AND user_id = ?');
$stmt->execute([$id, $userId]);
if ($stmt->rowCount() > 0) {
    echo json_encode(['status' => 'success']);
} else {
    http_response_code(403);
    echo json_encode([
        'status' => 'error',
        'message' => 'No tienes permiso para eliminar esta creación o no existe.'
    ]);
}
