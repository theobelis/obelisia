<?php
// api/log_activity.php
// Endpoint para registrar logs de actividad vía AJAX

session_start();
// DEBUG: Guardar el contenido de la sesión en un log
file_put_contents(__DIR__.'/../logs/session_debug.log', date('Y-m-d H:i:s')."\n".print_r($_SESSION, true)."\n", FILE_APPEND);
// Compatibilidad: si el usuario está en $_SESSION['user']['id'], usarlo como user_id
if (!isset($_SESSION['user_id']) && isset($_SESSION['user']['id'])) {
    $_SESSION['user_id'] = $_SESSION['user']['id'];
}

require_once __DIR__ . '/../helpers/log_activity.php';
require_once __DIR__ . '/../src/Database/Database.php';
use ObelisIA\Database\Database;
$database = new Database();
$db = $database->getConnection();

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'No autenticado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$action = $data['action'] ?? '';
$description = $data['description'] ?? ($data['details'] ?? '');

if (!$action) {
    http_response_code(400);
    echo json_encode(['error' => 'Falta acción']);
    exit;
}

// $db debe estar inicializado por config.php o global
if (!isset($db)) {
    http_response_code(500);
    echo json_encode(['error' => 'DB no disponible']);
    exit;
}

try {
    log_user_activity($db, $_SESSION['user_id'], $action, $description);
    echo json_encode(['success' => true]);
} catch (Throwable $e) {
    http_response_code(500);
    $msg = $e->getMessage();
    $trace = $e->getTraceAsString();
    echo json_encode(['error' => $msg, 'trace' => $trace]);
    // DEBUG: mostrar en pantalla si se accede por navegador
    if (php_sapi_name() !== 'cli') {
        echo '<div style="background:#fff;color:#b00;padding:1em;margin:1em 0;border:2px solid #b00;z-index:9999;position:relative;">';
        echo '<b>Error log_activity.php:</b> ' . htmlspecialchars($msg) . '<br><pre>' . htmlspecialchars($trace) . '</pre>';
        echo '</div>';
    }
}
