<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../helpers/db.php';

// Verificar autenticación
session_start();
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

// Validar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

try {
    // Obtener datos JSON
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('JSON inválido');
    }

    $target_user_id = filter_var($input['user_id'] ?? null, FILTER_VALIDATE_INT);
    $action = $input['action'] ?? '';

    if (!$target_user_id || !in_array($action, ['follow', 'unfollow'])) {
        throw new Exception('Parámetros inválidos');
    }

    $current_user_id = $_SESSION['user_id'];

    // No permitir seguirse a sí mismo
    if ($target_user_id == $current_user_id) {
        throw new Exception('No puedes seguirte a ti mismo');
    }

    // Verificar que el usuario objetivo existe y está activo
    $stmt = $db->prepare("
        SELECT id, username 
        FROM users 
        WHERE id = ? AND status = 'active'
    ");
    $stmt->execute([$target_user_id]);
    $target_user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$target_user) {
        throw new Exception('Usuario no encontrado o no disponible');
    }

    $db->beginTransaction();

    if ($action === 'follow') {
        // Seguir usuario (INSERT IGNORE para evitar duplicados)
        $stmt = $db->prepare("
            INSERT IGNORE INTO user_follows (follower_id, following_id, created_at) 
            VALUES (?, ?, NOW())
        ");
        $stmt->execute([$current_user_id, $target_user_id]);
        
        if ($stmt->rowCount() === 0) {
            throw new Exception('Ya sigues a este usuario');
        }

        // Registrar actividad
        require_once __DIR__ . '/../../helpers/log_activity.php';
        log_user_activity($db, $current_user_id, 'Follow', "Comenzó a seguir a @{$target_user['username']}");

        // Crear notificación para el usuario seguido
        $stmt = $db->prepare("
            INSERT INTO social_notifications (user_id, from_user_id, type, message, created_at) 
            VALUES (?, ?, 'follow', 'comenzó a seguirte 👥🎉', NOW())
        ");
        $stmt->execute([$target_user_id, $current_user_id]);

        $message = 'Ahora sigues a ' . $target_user['username'];

    } else { // unfollow
        // Dejar de seguir
        $stmt = $db->prepare("
            DELETE FROM user_follows 
            WHERE follower_id = ? AND following_id = ?
        ");
        $stmt->execute([$current_user_id, $target_user_id]);
        
        if ($stmt->rowCount() === 0) {
            throw new Exception('No sigues a este usuario');
        }

        // Registrar actividad
        require_once __DIR__ . '/../../helpers/log_activity.php';
        log_user_activity($db, $current_user_id, 'Unfollow', "Dejó de seguir a @{$target_user['username']}");

        $message = 'Dejaste de seguir a ' . $target_user['username'];
    }

    // Obtener conteos actualizados
    $stmt = $db->prepare("
        SELECT 
            (SELECT COUNT(*) FROM user_follows WHERE following_id = ?) as followers_count,
            (SELECT COUNT(*) FROM user_follows WHERE follower_id = ?) as following_count
    ");
    $stmt->execute([$target_user_id, $target_user_id]);
    $counts = $stmt->fetch(PDO::FETCH_ASSOC);

    $db->commit();

    echo json_encode([
        'success' => true,
        'action' => $action,
        'message' => $message,
        'followers_count' => (int)$counts['followers_count'],
        'following_count' => (int)$counts['following_count']
    ]);

} catch (Exception $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
    
    // Log del error
    error_log("Error en toggle_follow.php: " . $e->getMessage());
}
?>
