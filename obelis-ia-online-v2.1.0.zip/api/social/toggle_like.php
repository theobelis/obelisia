<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../helpers/db.php';

// Verificar autenticación
session_start();
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

// Validar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

try {
    // Obtener datos JSON
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('JSON inválido');
    }

    $creation_id = filter_var($input['creation_id'] ?? null, FILTER_VALIDATE_INT);
    $action = $input['action'] ?? '';

    if (!$creation_id || !in_array($action, ['like', 'unlike'])) {
        throw new Exception('Parámetros inválidos');
    }

    $user_id = $_SESSION['user_id'];

    $db = getDbConnection();
    
    // Verificar que la creación existe y es pública
    $stmt = $db->prepare("
        SELECT id, user_id, title 
        FROM user_creations 
        WHERE id = ? AND privacy = 'public' AND status = 'completed'
    ");
    $stmt->execute([$creation_id]);
    $creation = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$creation) {
        throw new Exception('Creación no encontrada o no pública');
    }

    // No permitir que un usuario le dé like a su propia creación
    if ($creation['user_id'] == $user_id) {
        throw new Exception('No puedes dar like a tu propia creación');
    }

    $db->beginTransaction();

    if ($action === 'like') {
        // Agregar like (INSERT IGNORE para evitar duplicados)
        $stmt = $db->prepare("
            INSERT IGNORE INTO creation_likes (user_id, creation_id, created_at) 
            VALUES (?, ?, NOW())
        ");
        $stmt->execute([$user_id, $creation_id]);
        
        if ($stmt->rowCount() === 0) {
            throw new Exception('Ya has dado like a esta creación');
        }

        // Crear notificación para el dueño de la creación
        $stmt = $db->prepare("
            INSERT INTO social_notifications (user_id, from_user_id, type, creation_id, message, created_at) 
            VALUES (?, ?, 'like', ?, 'le gustó tu creación 😍❤️', NOW())
        ");
        $stmt->execute([$creation['user_id'], $user_id, $creation_id]);

    } else { // unlike
        // Quitar like
        $stmt = $db->prepare("
            DELETE FROM creation_likes 
            WHERE user_id = ? AND creation_id = ?
        ");
        $stmt->execute([$user_id, $creation_id]);
        
        if ($stmt->rowCount() === 0) {
            throw new Exception('No has dado like a esta creación');
        }

        // Eliminar notificación de like
        $stmt = $db->prepare("
            DELETE FROM social_notifications 
            WHERE user_id = ? AND from_user_id = ? AND type = 'like' AND creation_id = ?
        ");
        $stmt->execute([$creation['user_id'], $user_id, $creation_id]);
    }

    // Obtener el conteo actualizado de likes
    $stmt = $db->prepare("
        SELECT COUNT(*) as like_count 
        FROM creation_likes 
        WHERE creation_id = ?
    ");
    $stmt->execute([$creation_id]);
    $like_count = $stmt->fetchColumn();

    $db->commit();

    echo json_encode([
        'success' => true,
        'action' => $action,
        'like_count' => (int)$like_count,
        'message' => $action === 'like' ? 'Like agregado' : 'Like quitado'
    ]);

} catch (Exception $e) {
    if (isset($db) && $db->inTransaction()) {
        $db->rollBack();
    }
    
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
    
    // Log del error
    error_log("Error en toggle_like.php: " . $e->getMessage());
}
?>
