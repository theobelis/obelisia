<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../helpers/db.php';
require_once __DIR__ . '/../../helpers/social_functions.php';
require_once __DIR__ . '/../../helpers/creation_statistics.php';

// Verificar autenticación
session_start();
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

try {
    $query = filter_var(trim($_GET['q'] ?? ''), FILTER_SANITIZE_STRING);
    $type = filter_var($_GET['type'] ?? 'all', FILTER_SANITIZE_STRING); // all, creations, users
    $creation_type = filter_var($_GET['creation_type'] ?? '', FILTER_SANITIZE_STRING);
    $tool = filter_var($_GET['tool'] ?? '', FILTER_SANITIZE_STRING);
    $limit = min(20, max(1, intval($_GET['limit'] ?? 10)));
    
    // Validar tipos permitidos
    $allowed_types = ['all', 'creations', 'users'];
    if (!in_array($type, $allowed_types)) {
        throw new Exception('Tipo de búsqueda no válido');
    }

    if (empty($query)) {
        throw new Exception('Consulta de búsqueda requerida');
    }

    if (strlen($query) < 2) {
        throw new Exception('La búsqueda debe tener al menos 2 caracteres');
    }
    
    // Validar que la query no contenga caracteres sospechosos
    if (preg_match('/[<>"\']/', $query)) {
        throw new Exception('Caracteres no válidos en la búsqueda');
    }

    $results = [
        'creations' => [],
        'users' => [],
        'total' => 0
    ];

    $search_term = "%{$query}%";

    // Buscar creaciones si se solicita
    if ($type === 'all' || $type === 'creations') {
        $search_options = [
            'type' => !empty($creation_type) ? $creation_type : null,
            'tool_used' => !empty($tool) ? $tool : null,
            'limit' => $limit
        ];
        
        $results['creations'] = searchCreationsWithStats($pdo, $query, $search_options);
    }

    // Buscar usuarios si se solicita
    if ($type === 'all' || $type === 'users') {
        $users_sql = "
            SELECT 
                u.id,
                u.username,
                u.full_name,
                u.bio,
                u.profile_image,
                u.membership_type,
                u.level,
                (SELECT COUNT(*) FROM user_creations WHERE user_id = u.id AND privacy = 'public' AND status = 'completed') as creation_count,
                (SELECT COUNT(*) FROM user_follows WHERE following_id = u.id) as followers_count,
                (SELECT COUNT(*) FROM creation_likes cl JOIN user_creations uc ON cl.creation_id = uc.id WHERE uc.user_id = u.id) as total_likes
            FROM users u
            WHERE u.status = 'active' 
            AND (u.username LIKE ? OR u.full_name LIKE ? OR u.bio LIKE ?)
            ORDER BY 
                CASE 
                    WHEN u.username LIKE ? THEN 1
                    WHEN u.full_name LIKE ? THEN 2
                    WHEN u.bio LIKE ? THEN 3
                    ELSE 4
                END,
                (SELECT COUNT(*) FROM user_follows WHERE following_id = u.id) DESC,
                (SELECT COUNT(*) FROM user_creations WHERE user_id = u.id AND privacy = 'public' AND status = 'completed') DESC
            LIMIT " . intval($limit) . "
        ";

        $users_params = [
            $search_term, $search_term, $search_term,
            $search_term, $search_term, $search_term
        ];

        $stmt = $pdo->prepare($users_sql);
        $stmt->execute($users_params);
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($users as &$user) {
            $user['creation_count'] = (int)$user['creation_count'];
            $user['followers_count'] = (int)$user['followers_count'];
            $user['total_likes'] = (int)$user['total_likes'];
            
            // Verificar si el usuario actual sigue a este usuario
            $follow_stmt = $pdo->prepare("SELECT 1 FROM user_follows WHERE follower_id = ? AND following_id = ?");
            $follow_stmt->execute([$_SESSION['user_id'], $user['id']]);
            $user['is_following'] = $follow_stmt->fetch() !== false;
        }

        $results['users'] = $users;
    }

    $results['total'] = count($results['creations']) + count($results['users']);

    // Registrar búsqueda para analytics (opcional)
    try {
        $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, description) VALUES (?, ?, ?)");
        $stmt->execute([$_SESSION['user_id'], 'Búsqueda', "Buscó: '{$query}' (tipo: {$type})"]);
    } catch (Exception $e) {
        // Ignorar errores de logging
    }

    echo json_encode([
        'success' => true,
        'query' => $query,
        'results' => $results
    ]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
    
    error_log("Error en search.php: " . $e->getMessage());
}
?>
