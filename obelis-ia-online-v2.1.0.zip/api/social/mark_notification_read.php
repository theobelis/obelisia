<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../helpers/db.php';
session_start();

header('Content-Type: application/json');

// Verificar que el usuario esté logueado
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

$user_id = $_SESSION['user_id'];

// Solo permitir POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Método no permitido']);
    exit;
}

// Obtener datos del request
$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['notification_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'ID de notificación requerido']);
    exit;
}

$notification_id = (int)$input['notification_id'];

try {
    // Verificar que la notificación pertenece al usuario
    $stmt = $pdo->prepare("
        SELECT user_id 
        FROM social_notifications 
        WHERE id = ? AND user_id = ?
    ");
    $stmt->execute([$notification_id, $user_id]);
    
    if (!$stmt->fetch()) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Notificación no encontrada']);
        exit;
    }
    
    // Marcar como leída
    $stmt = $pdo->prepare("
        UPDATE social_notifications 
        SET is_read = 1, read_at = NOW() 
        WHERE id = ? AND user_id = ?
    ");
    $stmt->execute([$notification_id, $user_id]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Notificación marcada como leída'
    ]);
    
} catch (Exception $e) {
    error_log("Error al marcar notificación como leída: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Error interno del servidor']);
}
?>
