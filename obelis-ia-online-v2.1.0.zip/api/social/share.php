<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../helpers/db.php';

// Verificar autenticación
session_start();
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

// Validar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('JSON inválido');
    }

    $creation_id = filter_var($input['creation_id'] ?? null, FILTER_VALIDATE_INT);
    $type = $input['type'] ?? 'link'; // link, social, email

    if (!$creation_id) {
        throw new Exception('ID de creación inválido');
    }

    $db = getDbConnection();
    
    // Verificar que la creación existe y es pública
    $stmt = $db->prepare("
        SELECT 
            uc.id, uc.title, uc.description, uc.file_path, uc.type as creation_type,
            u.username, u.full_name
        FROM user_creations uc
        JOIN users u ON uc.user_id = u.id
        WHERE uc.id = ? AND uc.privacy = 'public' AND uc.status = 'completed'
    ");
    $stmt->execute([$creation_id]);
    $creation = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$creation) {
        throw new Exception('Creación no encontrada o no es pública');
    }

    // Generar URLs base
    $base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];
    $creation_url = $base_url . '/comunidad#creation-' . $creation_id;
    
    // Preparar datos para compartir
    $share_data = [
        'success' => true,
        'creation' => [
            'id' => $creation['id'],
            'title' => $creation['title'] ?: 'Creación sin título',
            'description' => $creation['description'] ?: 'Mira esta increíble creación',
            'creator' => $creation['full_name'] ?: $creation['username'],
            'type' => $creation['creation_type']
        ],
        'urls' => [
            'direct' => $creation_url,
            'profile' => $base_url . '/usuario?id=' . $creation['username']
        ]
    ];

    // Generar URLs específicas según el tipo solicitado
    if ($type === 'social') {
        $text = urlencode("¡Mira esta increíble creación de {$creation['full_name']} en ObelisIA! 🎨");
        $url_encoded = urlencode($creation_url);
        
        $share_data['social_urls'] = [
            'twitter' => "https://twitter.com/intent/tweet?text={$text}&url={$url_encoded}",
            'facebook' => "https://www.facebook.com/sharer/sharer.php?u={$url_encoded}",
            'linkedin' => "https://www.linkedin.com/sharing/share-offsite/?url={$url_encoded}",
            'whatsapp' => "https://wa.me/?text={$text}%20{$url_encoded}",
            'telegram' => "https://t.me/share/url?url={$url_encoded}&text={$text}"
        ];
    }

    if ($type === 'email') {
        $subject = urlencode("Te comparto esta creación de ObelisIA");
        $body = urlencode("Hola,\n\nQuería compartir contigo esta increíble creación que encontré en ObelisIA:\n\n" .
                         "Título: {$creation['title']}\n" .
                         "Creador: {$creation['full_name']}\n" .
                         "Enlace: {$creation_url}\n\n" .
                         "¡Espero que te guste!\n\nSaludos");
        
        $share_data['email_url'] = "mailto:?subject={$subject}&body={$body}";
    }

    // El registro de actividad es opcional - si falla, continuamos
    // (comentado temporalmente para evitar errores)
    /*
    try {
        $stmt = $db->prepare("
            INSERT INTO activity_logs (user_id, action, description, created_at) 
            VALUES (?, 'Compartir', 'Compartió una creación', NOW())
        ");
        $stmt->execute([$_SESSION['user_id']]);
    } catch (Exception $e) {
        error_log("Info: No se pudo registrar actividad de compartir: " . $e->getMessage());
    }
    */

    echo json_encode($share_data);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
