<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../helpers/db.php';
require_once __DIR__ . '/../../helpers/social_functions.php';

// Verificar autenticación
session_start();
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

// Validar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

try {
    // Obtener datos JSON
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('JSON inválido');
    }

    $creation_id = filter_var($input['creation_id'] ?? null, FILTER_VALIDATE_INT);
    $comment = trim($input['comment'] ?? '');
    $parent_id = filter_var($input['parent_id'] ?? null, FILTER_VALIDATE_INT);

    // Validaciones
    if (!$creation_id) {
        throw new Exception('ID de creación inválido');
    }

    if (empty($comment)) {
        throw new Exception('El comentario no puede estar vacío');
    }

    if (strlen($comment) > 1000) {
        throw new Exception('El comentario es demasiado largo (máximo 1000 caracteres)');
    }

    $user_id = $_SESSION['user_id'];

    // Verificar que la creación existe y es pública
    $stmt = $db->prepare("
        SELECT id, user_id 
        FROM user_creations 
        WHERE id = ? AND privacy = 'public' AND status = 'completed'
    ");
    $stmt->execute([$creation_id]);
    $creation = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$creation) {
        throw new Exception('Creación no encontrada o no pública');
    }

    // Si es una respuesta, verificar que el comentario padre existe
    if ($parent_id) {
        $stmt = $db->prepare("
            SELECT id 
            FROM creation_comments 
            WHERE id = ? AND creation_id = ? AND status = 'active' AND parent_id IS NULL
        ");
        $stmt->execute([$parent_id, $creation_id]);
        
        if (!$stmt->fetch()) {
            throw new Exception('Comentario padre no encontrado');
        }
    }

    // Verificar límite de comentarios por usuario por día (anti-spam)
    $stmt = $db->prepare("
        SELECT COUNT(*) 
        FROM creation_comments 
        WHERE user_id = ? AND DATE(created_at) = CURDATE()
    ");
    $stmt->execute([$user_id]);
    $daily_comments = $stmt->fetchColumn();

    if ($daily_comments >= 50) {
        throw new Exception('Has alcanzado el límite diario de comentarios');
    }

    $db->beginTransaction();

    // Insertar comentario
    $stmt = $db->prepare("
        INSERT INTO creation_comments (user_id, creation_id, parent_id, comment, created_at) 
        VALUES (?, ?, ?, ?, NOW())
    ");
    $stmt->execute([$user_id, $creation_id, $parent_id, $comment]);
    
    $comment_id = $db->lastInsertId();

    // Registrar actividad
    require_once __DIR__ . '/../../helpers/log_activity.php';
    $activity_desc = $parent_id 
        ? "Respondió a un comentario en la creación ID: {$creation_id}"
        : "Comentó en la creación ID: {$creation_id}";
    log_user_activity($db, $user_id, 'Comentario', $activity_desc);

    // Crear notificación para el dueño de la creación (si no es el mismo usuario)
    if ($creation['user_id'] != $user_id) {
        $stmt = $db->prepare("
            INSERT INTO social_notifications (user_id, from_user_id, type, creation_id, message, created_at) 
            VALUES (?, ?, 'comment', ?, 'comentó en tu creación 💬✨', NOW())
        ");
        $stmt->execute([$creation['user_id'], $user_id, $creation_id]);
    }

    // Obtener los datos del comentario insertado para la respuesta
    $stmt = $db->prepare("
        SELECT 
            cc.id,
            cc.comment,
            cc.created_at,
            cc.parent_id,
            u.username,
            u.full_name,
            u.profile_image
        FROM creation_comments cc
        JOIN users u ON cc.user_id = u.id
        WHERE cc.id = ?
    ");
    $stmt->execute([$comment_id]);
    $new_comment = $stmt->fetch(PDO::FETCH_ASSOC);

    $db->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Comentario agregado exitosamente',
        'comment' => [
            'id' => $new_comment['id'],
            'comment' => $new_comment['comment'],
            'created_at' => $new_comment['created_at'],
            'created_at_formatted' => 'hace unos segundos',
            'parent_id' => $new_comment['parent_id'],
            'user_id' => $user_id,
            'username' => $new_comment['username'],
            'full_name' => $new_comment['full_name'],
            'profile_image' => $new_comment['profile_image'],
            'replies' => [],
            'replies_count' => 0,
            'is_edited' => false
        ]
    ]);

} catch (Exception $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
    
    error_log("Error en add_comment.php: " . $e->getMessage());
}
?>
