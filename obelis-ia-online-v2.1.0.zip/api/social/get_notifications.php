<?php
error_reporting(E_ALL);
ini_set('display_errors', 0); // No mostrar errores en la salida

header('Content-Type: application/json; charset=utf-8');

// Verificar autenticación primero
session_start();
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

// Incluir base de datos con manejo de errores
try {
    require_once __DIR__ . '/../../helpers/db.php';
    require_once __DIR__ . '/../../helpers/social_functions.php';
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error de conexión a la base de datos']);
    error_log("Error en get_notifications.php - DB connection: " . $e->getMessage());
    exit;
}

try {
    $user_id = $_SESSION['user_id'];
    $limit = 20; // Limitar a 20 notificaciones recientes

    // Obtener notificaciones de la tabla social_notifications
    $sql = "
        SELECT 
            sn.id,
            sn.type,
            sn.message,
            sn.creation_id,
            sn.is_read,
            sn.created_at,
            u.username,
            u.full_name,
            u.profile_image
        FROM social_notifications sn
        JOIN users u ON sn.from_user_id = u.id
        WHERE sn.user_id = ?
        ORDER BY sn.created_at DESC
        LIMIT " . intval($limit);

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_id]);
    $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Formatear notificaciones
    $unread_notifications = [];
    $read_notifications = [];
    
    foreach ($notifications as &$notification) {
        $notification['created_at_formatted'] = timeAgo($notification['created_at']);
        $notification['is_read'] = (bool)$notification['is_read'];
        
        // Si hay creation_id, obtener título de la creación
        if ($notification['creation_id']) {
            $creation_stmt = $pdo->prepare("SELECT title FROM user_creations WHERE id = ?");
            $creation_stmt->execute([$notification['creation_id']]);
            $creation = $creation_stmt->fetch();
            $notification['creation_title'] = $creation ? $creation['title'] : 'Creación eliminada';
        }
        
        // Separar por estado de lectura
        if ($notification['is_read']) {
            $read_notifications[] = $notification;
        } else {
            $unread_notifications[] = $notification;
        }
    }

    // Contar notificaciones no leídas
    $unread_count = count($unread_notifications);

    echo json_encode([
        'success' => true,
        'notifications' => $notifications,
        'unread_notifications' => $unread_notifications,
        'read_notifications' => $read_notifications,
        'unread_count' => $unread_count,
        'total' => count($notifications)
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error interno del servidor',
        'error_details' => $e->getMessage() // Solo para debugging, remover en producción
    ]);
    
    error_log("Error en get_notifications.php: " . $e->getMessage() . " - Line: " . $e->getLine() . " - File: " . $e->getFile());
}
?>
