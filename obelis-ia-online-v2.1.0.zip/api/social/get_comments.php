<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../helpers/db.php';
require_once __DIR__ . '/../../helpers/social_functions.php';

// Verificar autenticación
session_start();
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

try {
    $creation_id = filter_var($_GET['creation_id'] ?? null, FILTER_VALIDATE_INT);
    
    if (!$creation_id) {
        throw new Exception('ID de creación inválido');
    }

    // Verificar que la creación existe y es pública
    $stmt = $db->prepare("
        SELECT id 
        FROM user_creations 
        WHERE id = ? AND privacy = 'public' AND status = 'completed'
    ");
    $stmt->execute([$creation_id]);
    
    if (!$stmt->fetch()) {
        throw new Exception('Creación no encontrada o no pública');
    }

    // Obtener comentarios con información del usuario
    $stmt = $db->prepare("
        SELECT 
            cc.id,
            cc.comment,
            cc.created_at,
            cc.updated_at,
            cc.parent_id,
            u.id as user_id,
            u.username,
            u.full_name,
            u.profile_image,
            (SELECT COUNT(*) FROM creation_comments WHERE parent_id = cc.id AND status = 'active') as replies_count
        FROM creation_comments cc
        JOIN users u ON cc.user_id = u.id
        WHERE cc.creation_id = ? AND cc.status = 'active'
        ORDER BY 
            CASE WHEN cc.parent_id IS NULL THEN cc.id ELSE cc.parent_id END,
            cc.parent_id IS NULL DESC,
            cc.created_at ASC
    ");
    $stmt->execute([$creation_id]);
    $comments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Organizar comentarios jerárquicamente
    $organized_comments = [];
    $replies = [];

    foreach ($comments as $comment) {
        $comment['created_at_formatted'] = timeAgo($comment['created_at']);
        $comment['is_edited'] = $comment['updated_at'] !== $comment['created_at'];
        
        if ($comment['parent_id'] === null) {
            $comment['replies'] = [];
            $organized_comments[$comment['id']] = $comment;
        } else {
            $replies[$comment['parent_id']][] = $comment;
        }
    }

    // Agregar respuestas a los comentarios principales
    foreach ($replies as $parent_id => $parent_replies) {
        if (isset($organized_comments[$parent_id])) {
            $organized_comments[$parent_id]['replies'] = $parent_replies;
        }
    }

    echo json_encode([
        'success' => true,
        'comments' => array_values($organized_comments),
        'total' => count($organized_comments)
    ]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
    
    error_log("Error en get_comments.php: " . $e->getMessage());
}

function timeAgo($datetime) {
    $time = time() - strtotime($datetime);
    if ($time < 60) return 'hace unos segundos';
    if ($time < 3600) return 'hace ' . floor($time/60) . ' minutos';
    if ($time < 86400) return 'hace ' . floor($time/3600) . ' horas';
    if ($time < 2592000) return 'hace ' . floor($time/86400) . ' días';
    return date('d M Y', strtotime($datetime));
}
?>
