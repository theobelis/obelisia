<?php
/**
 * API para cargar una creación de contenido existente
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once __DIR__ . '/../../helpers/db.php';
require_once __DIR__ . '/../../src/Auth/Auth.php';

$auth = new \ObelisIA\Auth\Auth();

if (!$auth->isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

try {
    $creationId = filter_var($_GET['id'] ?? '', FILTER_SANITIZE_STRING);
    
    if (empty($creationId)) {
        throw new Exception('ID de creación requerido');
    }
    
    // Validar formato del ID (debe ser alfanumérico, sin caracteres especiales)
    if (!preg_match('/^[a-zA-Z0-9_-]+$/', $creationId)) {
        throw new Exception('Formato de ID no válido');
    }
    
    $user = $auth->getCurrentUser();
    $userId = $user['id'];
    
    // Obtener la creación básica
    $stmt = $db->prepare("
        SELECT uc.*, cc.content_json, cc.html_content, cc.plain_text, cc.tags, cc.word_count, cc.reading_time
        FROM user_creations uc
        LEFT JOIN content_creations cc ON uc.id = cc.creation_id
        WHERE uc.id = ? AND uc.user_id = ?
    ");
    
    $stmt->execute([$creationId, $userId]);
    $creation = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$creation) {
        throw new Exception('Creación no encontrada');
    }
    
    // Preparar la respuesta
    $response = [
        'success' => true,
        'creation' => [
            'id' => $creation['id'],
            'title' => $creation['title'],
            'description' => $creation['description'],
            'content' => $creation['content_json'],
            'html_content' => $creation['html_content'],
            'plain_text' => $creation['plain_text'],
            'tags' => $creation['tags'],
            'visibility' => $creation['privacy'],
            'settings' => $creation['settings'],
            'is_published' => $creation['is_public'] == 1,
            'word_count' => $creation['word_count'] ?? 0,
            'reading_time' => $creation['reading_time'] ?? 1,
            'created_at' => $creation['created_at'],
            'updated_at' => $creation['updated_at']
        ]
    ];
    
    echo json_encode($response);
    
} catch (Exception $e) {
    error_log("Error en get_content_creation: " . $e->getMessage());
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
