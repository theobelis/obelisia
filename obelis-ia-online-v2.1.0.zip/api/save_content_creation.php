<?php
/**
 * API para guardar creaciones de contenido del Content Creator
 * Maneja el guardado de documentos tipo blog/artículo
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, PUT');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once __DIR__ . '/../../helpers/db.php';
require_once __DIR__ . '/../../src/Auth/Auth.php';

$auth = new \ObelisIA\Auth\Auth();

if (!$auth->isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('Datos JSON inválidos');
    }
    
    $user = $auth->getCurrentUser();
    $userId = $user['id'];
    
    // Validar datos requeridos
    $title = trim($input['title'] ?? '');
    if (empty($title)) {
        throw new Exception('El título es requerido');
    }
    
    $description = trim($input['description'] ?? '');
    $tags = trim($input['tags'] ?? '');
    $content = $input['content'] ?? '';
    $htmlContent = $input['html_content'] ?? '';
    $plainText = $input['plain_text'] ?? '';
    $visibility = $input['visibility'] ?? 'private';
    $settings = $input['settings'] ?? [];
    $creationId = $input['id'] ?? null;
    
    // Validar longitud del contenido
    if (strlen($plainText) > 50000) {
        throw new Exception('El contenido es demasiado largo (máximo 50,000 caracteres)');
    }
    
    // Validar visibilidad
    if (!in_array($visibility, ['private', 'public', 'unlisted'])) {
        $visibility = 'private';
    }
    
    // Preparar configuraciones como JSON
    $settingsJson = json_encode($settings, JSON_UNESCAPED_UNICODE);
    
    // Generar slug para URL amigable
    $slug = generateSlug($title, $userId);
    
    if ($creationId) {
        // Actualizar creación existente
        $stmt = $db->prepare("
            UPDATE user_creations 
            SET title = ?, description = ?, file_path = ?, settings = ?, privacy = ?, updated_at = NOW()
            WHERE id = ? AND user_id = ?
        ");
        
        $success = $stmt->execute([
            $title,
            $description,
            $slug, // Usar slug como file_path para contenido
            $settingsJson,
            $visibility,
            $creationId,
            $userId
        ]);
        
        if (!$success) {
            throw new Exception('Error al actualizar la creación');
        }
        
        // Actualizar tabla de contenido detallado
        updateContentDetails($db, $creationId, $content, $htmlContent, $plainText, $tags);
        
        $responseId = $creationId;
        $message = 'Creación actualizada exitosamente';
        
    } else {
        // Crear nueva creación
        $stmt = $db->prepare("
            INSERT INTO user_creations 
            (user_id, type, tool_used, title, description, file_path, settings, privacy, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $success = $stmt->execute([
            $userId,
            'text', // Tipo para contenido de blog
            'content-creator', // Herramienta utilizada
            $title,
            $description,
            $slug,
            $settingsJson,
            $visibility,
            'completed'
        ]);
        
        if (!$success) {
            throw new Exception('Error al crear la creación');
        }
        
        $responseId = $db->lastInsertId();
        
        // Insertar contenido detallado
        insertContentDetails($db, $responseId, $content, $htmlContent, $plainText, $tags);
        
        $message = 'Creación guardada exitosamente';
    }
    
    // Log de actividad
    try {
        require_once __DIR__ . '/../../helpers/log_activity.php';
        logActivity($userId, 'creation', ($creationId ? 'Actualizó' : 'Creó') . ' una creación de contenido: ' . $title);
    } catch (Exception $e) {
        // Log de actividad no crítico, continuar
        error_log("Error logging activity: " . $e->getMessage());
    }
    
    // Respuesta exitosa
    echo json_encode([
        'success' => true,
        'message' => $message,
        'id' => $responseId,
        'slug' => $slug,
        'url' => '/creacion/' . $slug
    ]);
    
} catch (Exception $e) {
    error_log("Error en save_content_creation: " . $e->getMessage());
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

/**
 * Genera un slug único para la URL de la creación
 */
function generateSlug($title, $userId) {
    // Convertir a minúsculas y reemplazar caracteres especiales
    $slug = strtolower($title);
    $slug = preg_replace('/[^a-z0-9\s-]/', '', $slug);
    $slug = preg_replace('/[\s-]+/', '-', $slug);
    $slug = trim($slug, '-');
    
    // Limitar longitud
    $slug = substr($slug, 0, 50);
    
    // Agregar timestamp para unicidad
    $slug .= '-' . time();
    
    return $slug;
}

/**
 * Inserta los detalles del contenido en una tabla separada
 */
function insertContentDetails($db, $creationId, $content, $htmlContent, $plainText, $tags) {
    // Crear tabla si no existe
    $createTableSql = "
        CREATE TABLE IF NOT EXISTS content_creations (
            id INT AUTO_INCREMENT PRIMARY KEY,
            creation_id INT NOT NULL,
            content_json LONGTEXT,
            html_content LONGTEXT,
            plain_text LONGTEXT,
            tags TEXT,
            word_count INT DEFAULT 0,
            reading_time INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (creation_id) REFERENCES user_creations(id) ON DELETE CASCADE
        )
    ";
    $db->exec($createTableSql);
    
    // Calcular estadísticas
    $wordCount = str_word_count($plainText);
    $readingTime = max(1, ceil($wordCount / 200)); // 200 palabras por minuto
    
    $stmt = $db->prepare("
        INSERT INTO content_creations 
        (creation_id, content_json, html_content, plain_text, tags, word_count, reading_time)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $creationId,
        $content,
        $htmlContent,
        $plainText,
        $tags,
        $wordCount,
        $readingTime
    ]);
}

/**
 * Actualiza los detalles del contenido
 */
function updateContentDetails($db, $creationId, $content, $htmlContent, $plainText, $tags) {
    // Calcular estadísticas
    $wordCount = str_word_count($plainText);
    $readingTime = max(1, ceil($wordCount / 200));
    
    $stmt = $db->prepare("
        UPDATE content_creations 
        SET content_json = ?, html_content = ?, plain_text = ?, tags = ?, 
            word_count = ?, reading_time = ?, updated_at = NOW()
        WHERE creation_id = ?
    ");
    
    $success = $stmt->execute([
        $content,
        $htmlContent,
        $plainText,
        $tags,
        $wordCount,
        $readingTime,
        $creationId
    ]);
    
    // Si no existe, crear
    if ($stmt->rowCount() === 0) {
        insertContentDetails($db, $creationId, $content, $htmlContent, $plainText, $tags);
    }
}
?>
