<?php
require_once '../../src/Config/config.php';
require_once '../../src/Services/CreditSystem.php';

header('Content-Type: application/json');

// Verificar autenticación
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No autenticado']);
    exit;
}

// Verificar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

// Obtener datos JSON
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Datos inválidos']);
    exit;
}

$required_fields = ['package_id', 'credits_amount', 'total_amount', 'payment_method'];
foreach ($required_fields as $field) {
    if (!isset($input[$field])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => "Campo requerido: $field"]);
        exit;
    }
}

$user_id = $_SESSION['user_id'];
$package_id = intval($input['package_id']);
$credits_amount = intval($input['credits_amount']);
$bonus_credits = intval($input['bonus_credits'] ?? 0);
$total_amount = floatval($input['total_amount']);
$payment_method = $input['payment_method'];
$currency = $input['currency'] ?? 'USD';

try {
    $db->beginTransaction();
    
    // Verificar que el paquete existe y está activo
    $stmt = $db->prepare("
        SELECT * FROM credit_packages 
        WHERE id = ? AND is_active = 1
    ");
    $stmt->execute([$package_id]);
    $package = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$package) {
        throw new Exception('Paquete no encontrado o inactivo');
    }
    
    // Verificar que los datos coinciden con el paquete
    if ($package['credits_amount'] != $credits_amount || 
        $package['price'] != $total_amount ||
        $package['bonus_credits'] != $bonus_credits) {
        throw new Exception('Los datos del paquete no coinciden');
    }
    
    // Generar ID de transacción único
    $transaction_id = 'CR_' . time() . '_' . $user_id . '_' . $package_id;
    
    // En una implementación real, aquí procesarías el pago con PayPal/Stripe
    // Por ahora, simularemos un pago exitoso
    $payment_id = 'SIMULATED_' . $transaction_id;
    $payment_status = 'completed'; // En real sería 'pending' hasta confirmar
    
    // Registrar la compra en la base de datos
    $stmt = $db->prepare("
        INSERT INTO credit_purchases (
            user_id, package_id, credits_purchased, bonus_credits,
            amount_paid, payment_method, payment_id, payment_status,
            payment_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    
    $stmt->execute([
        $user_id, $package_id, $credits_amount, $bonus_credits,
        $total_amount, $payment_method, $payment_id, $payment_status
    ]);
    
    $purchase_id = $db->lastInsertId();
    
    // Si el pago fue exitoso, añadir créditos al usuario
    if ($payment_status === 'completed') {
        $creditSystem = new CreditSystem($db);
        $total_credits_to_add = $credits_amount + $bonus_credits;
        
        // Añadir créditos base
        $creditSystem->addCredits(
            $user_id, 
            $credits_amount, 
            'purchase',
            "Compra de paquete: {$package['package_name']}",
            $purchase_id,
            'credit_purchase'
        );
        
        // Añadir créditos bonus si los hay
        if ($bonus_credits > 0) {
            $creditSystem->addCredits(
                $user_id, 
                $bonus_credits, 
                'bonus',
                "Créditos bonus por compra de paquete: {$package['package_name']}",
                $purchase_id,
                'credit_purchase'
            );
        }
        
        // Registrar actividad
        $stmt = $db->prepare("
            INSERT INTO user_activity_log (user_id, action, details, ip_address) 
            VALUES (?, 'credit_purchase', ?, ?)
        ");
        
        $details = json_encode([
            'package_name' => $package['package_name'],
            'credits_purchased' => $credits_amount,
            'bonus_credits' => $bonus_credits,
            'amount_paid' => $total_amount,
            'payment_method' => $payment_method,
            'purchase_id' => $purchase_id
        ]);
        
        $stmt->execute([
            $user_id,
            $details,
            $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        ]);
        
        // Obtener créditos actualizados del usuario
        $stmt = $db->prepare("SELECT credits FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $updated_credits = $stmt->fetchColumn();
    }
    
    $db->commit();
    
    // Crear notificación automática para el admin sobre el pago
    try {
        require_once '../../admin/includes/functions.php';
        
        // Obtener datos del usuario para la notificación
        $stmt = $db->prepare("SELECT username FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $username = $stmt->fetchColumn();
        
        // Determinar si es upgrade a premium o solo compra de créditos
        if ($credits_amount >= 1000 || $total_amount >= 15) { // Criterios para premium
            notifyUserUpgradeToPremium($user_id, $username ?: "Usuario #{$user_id}", 'Premium');
        } else {
            // Usar la función existente notifyNewPayment
            notifyNewPayment($total_amount, $user_id, $transaction_id);
        }
    } catch (Exception $e) {
        // Log error pero no fallar el pago
        error_log("Error creating admin payment notification: " . $e->getMessage());
    }
    
    // Respuesta exitosa
    echo json_encode([
        'success' => true,
        'message' => 'Compra procesada exitosamente',
        'purchase_id' => $purchase_id,
        'transaction_id' => $transaction_id,
        'credits_added' => $credits_amount + $bonus_credits,
        'new_credit_balance' => $updated_credits ?? null,
        'payment_status' => $payment_status
    ]);
    
} catch (Exception $e) {
    $db->rollBack();
    
    error_log("Error en compra de créditos: " . $e->getMessage());
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error procesando la compra: ' . $e->getMessage()
    ]);
}
?>
