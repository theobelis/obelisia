<?php
/**
 * Endpoint para guardar creaciones del editor unificado
 * Maneja el guardado de composiciones complejas que combinan múltiples tipos de recursos
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once __DIR__ . '/../../helpers/db.php';
require_once __DIR__ . '/../../src/Auth/Auth.php';

$auth = new \ObelisIA\Auth\Auth();

if (!$auth->isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('Datos JSON inválidos');
    }
    
    $user = $auth->getCurrentUser();
    $userId = $user['id'];
    
    // Validar datos requeridos
    $requiredFields = ['title', 'canvasData', 'layers'];
    foreach ($requiredFields as $field) {
        if (!isset($input[$field]) || empty($input[$field])) {
            throw new Exception("Campo requerido faltante: $field");
        }
    }
    
    $title = trim($input['title']);
    $description = trim($input['description'] ?? '');
    $canvasData = $input['canvasData']; // Base64 del canvas
    $layers = $input['layers']; // Array de capas
    $isPublic = isset($input['isPublic']) ? (bool)$input['isPublic'] : false;
    $privacy = $isPublic ? 'public' : 'private';
    
    // Validar tamaño del título
    if (strlen($title) > 255) {
        throw new Exception('El título es demasiado largo (máximo 255 caracteres)');
    }
    
    // Validar y procesar la imagen del canvas
    if (!str_starts_with($canvasData, 'data:image/')) {
        throw new Exception('Datos de canvas inválidos');
    }
    
    // Extraer y decodificar la imagen
    $imageData = explode(',', $canvasData, 2);
    if (count($imageData) !== 2) {
        throw new Exception('Formato de imagen inválido');
    }
    
    $base64Data = $imageData[1];
    $binaryData = base64_decode($base64Data);
    
    if ($binaryData === false) {
        throw new Exception('Error al decodificar la imagen');
    }
    
    // Crear directorio para guardar la creación
    $uploadsDir = __DIR__ . '/../../uploads/unified-creations/';
    if (!is_dir($uploadsDir)) {
        if (!mkdir($uploadsDir, 0755, true)) {
            throw new Exception('Error al crear directorio de uploads');
        }
    }
    
    // Generar nombre único para el archivo
    $timestamp = time();
    $filename = "unified_creation_{$userId}_{$timestamp}.png";
    $filePath = $uploadsDir . $filename;
    $relativePath = "uploads/unified-creations/" . $filename;
    
    // Guardar la imagen
    if (file_put_contents($filePath, $binaryData) === false) {
        throw new Exception('Error al guardar la imagen');
    }
    
    $fileSize = filesize($filePath);
    
    // Preparar configuraciones como JSON
    $settings = [
        'canvas_width' => $input['canvasWidth'] ?? 800,
        'canvas_height' => $input['canvasHeight'] ?? 600,
        'layers' => $layers,
        'resources_used' => $input['resourcesUsed'] ?? [],
        'editor_version' => '1.0',
        'creation_timestamp' => $timestamp
    ];
    
    $settingsJson = json_encode($settings, JSON_UNESCAPED_UNICODE);
    
    // Insertar en la base de datos
    $stmt = $db->prepare("
        INSERT INTO user_creations 
        (user_id, type, tool_used, title, description, file_path, file_size, file_type, settings, is_public, privacy, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $success = $stmt->execute([
        $userId,
        'image', // Tipo principal (aunque es una composición)
        'unified-editor', // Herramienta utilizada
        $title,
        $description,
        $relativePath,
        $fileSize,
        'image/png',
        $settingsJson,
        $isPublic ? 1 : 0,
        $privacy,
        'completed'
    ]);
    
    if (!$success) {
        throw new Exception('Error al guardar en la base de datos');
    }
    
    $creationId = $db->lastInsertId();
    
    // Log de actividad
    try {
        require_once __DIR__ . '/../../helpers/log_activity.php';
        logActivity($userId, 'creation', 'Creó una composición unificada: ' . $title);
    } catch (Exception $e) {
        // Log de actividad no crítico, continuar
        error_log("Error logging activity: " . $e->getMessage());
    }
    
    // Respuesta exitosa
    echo json_encode([
        'success' => true,
        'message' => 'Creación guardada exitosamente',
        'data' => [
            'id' => $creationId,
            'title' => $title,
            'file_path' => $relativePath,
            'file_size' => $fileSize,
            'created_at' => date('Y-m-d H:i:s')
        ]
    ]);
    
} catch (Exception $e) {
    error_log("Error en save_unified_creation: " . $e->getMessage());
    
    // Limpiar archivo si se creó pero falló la DB
    if (isset($filePath) && file_exists($filePath)) {
        unlink($filePath);
    }
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
