<?php

/**
 * API: Registrar visualización de anuncio
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../../src/Config/config.php';
require_once __DIR__ . '/../../src/Services/AdSystem.php';

// Verificar autenticación
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Usuario no autenticado']);
    exit;
}

// Verificar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('Datos inválidos');
    }
    
    $ad_id = $input['ad_id'] ?? '';
    $tool_type = $input['tool_type'] ?? '';
    $view_duration = intval($input['view_duration'] ?? 0);
    
    if (empty($ad_id) || empty($tool_type) || $view_duration < 10) {
        throw new Exception('Datos de visualización incompletos');
    }
    
    $adSystem = new AdSystem($db, $_SESSION['user_id']);
    $result = $adSystem->logAdView($ad_id, $tool_type, $view_duration);
    
    echo json_encode([
        'success' => true,
        'message' => 'Visualización registrada correctamente'
    ]);
    
} catch (Exception $e) {
    error_log("Error en log_ad_view.php: " . $e->getMessage());
    
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
