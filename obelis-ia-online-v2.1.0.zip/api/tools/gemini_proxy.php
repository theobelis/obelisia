<?php
// api/tools/gemini_proxy.php
// Proxy PHP para InfinityFree que conecta el frontend con la API de Gemini usando la clave definida en config.php

require_once __DIR__ . '/src/Config/config.php';

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed']);
    exit;
}

if (!defined('GEMINI_API_KEY') || !GEMINI_API_KEY) {
    http_response_code(500);
    echo json_encode(['error' => 'Server API Key not configured.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$contents = $input['contents'] ?? null;
if (!$contents) {
    http_response_code(400);
    echo json_encode(['error' => 'GenerateContentRequest.contents: contents is not specified']);
    exit;
}

$googleApiUrl = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=' . GEMINI_API_KEY;

$options = [
    'http' => [
        'header'  => "Content-Type: application/json\r\n",
        'method'  => 'POST',
        'content' => json_encode(['contents' => $contents]),
        'timeout' => 30
    ]
];
$context  = stream_context_create($options);
$result = @file_get_contents($googleApiUrl, false, $context);

if ($result === FALSE) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to process AI request through proxy.']);
    exit;
}

http_response_code(200);
echo $result;
