<?php

/**
 * API: Obtener estadísticas del usuario
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../../src/Config/config.php';
require_once __DIR__ . '/../../src/Services/CreditSystem.php';

// Verificar autenticación
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Usuario no autenticado']);
    exit;
}

try {
    $creditSystem = new CreditSystem($db, $_SESSION['user_id']);
    $stats = $creditSystem->getUserStats();
    
    // Obtener información adicional
    $stmt = $db->prepare("
        SELECT subscription_type, subscription_status 
        FROM users 
        WHERE id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $user_info = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Obtener logros recientes
    $stmt = $db->prepare("
        SELECT achievement_type, achievement_data, credits_reward, created_at
        FROM user_achievements 
        WHERE user_id = ?
        ORDER BY created_at DESC 
        LIMIT 5
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $recent_achievements = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Obtener estadísticas de uso por herramienta
    $stmt = $db->prepare("
        SELECT tool_type, COUNT(*) as usage_count, SUM(credits_cost) as total_credits
        FROM generation_logs 
        WHERE user_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)
        GROUP BY tool_type
        ORDER BY usage_count DESC
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $tool_usage = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'level' => $stats['level'],
        'total_experience' => $stats['total_experience'],
        'experience_for_next_level' => $stats['experience_for_next_level'],
        'credits' => $stats['credits'],
        'total_generations' => $stats['total_generations'],
        'daily_generations' => $stats['daily_generations'],
        'monthly_generations' => $stats['monthly_generations'],
        'subscription_type' => $user_info['subscription_type'],
        'subscription_status' => $user_info['subscription_status'],
        'recent_achievements' => $recent_achievements,
        'tool_usage' => $tool_usage
    ]);
    
} catch (Exception $e) {
    error_log("Error en get_user_stats.php: " . $e->getMessage());
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error obteniendo estadísticas'
    ]);
}
?>
