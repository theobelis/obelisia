<?php
// api/tools/proxy-crop-image.php
// Proxy backend para descargar, recortar y servir imágenes externas sin CORS

header('Access-Control-Allow-Origin: *');
header('Content-Type: image/png');

$url = $_GET['url'] ?? '';
$crop_px = isset($_GET['crop']) ? intval($_GET['crop']) : 60;

// Validar URL básica
if (!$url || !filter_var($url, FILTER_VALIDATE_URL)) {
    http_response_code(400);
    echo 'URL inválida';
    exit;
}

// Lista de dominios permitidos para evitar SSRF
$allowed_domains = [
    'picsum.photos',
    'via.placeholder.com',
    'placehold.co',
    'images.unsplash.com',
    'source.unsplash.com',
    'cdn.pixabay.com',
    'images.pexels.com'
];

$parsed_url = parse_url($url);
if (!$parsed_url || !isset($parsed_url['host'])) {
    http_response_code(400);
    echo 'URL malformada';
    exit;
}

// Verificar que el dominio esté en la lista de permitidos
$host = strtolower($parsed_url['host']);
$is_allowed = false;
foreach ($allowed_domains as $allowed_domain) {
    if ($host === $allowed_domain || str_ends_with($host, '.' . $allowed_domain)) {
        $is_allowed = true;
        break;
    }
}

if (!$is_allowed) {
    http_response_code(403);
    echo 'Dominio no permitido';
    exit;
}

// Validar que sea HTTPS para mayor seguridad
if ($parsed_url['scheme'] !== 'https') {
    http_response_code(400);
    echo 'Solo se permiten URLs HTTPS';
    exit;
}

// Descargar la imagen remota
$image_data = @file_get_contents($url);
if ($image_data === false) {
    http_response_code(404);
    echo 'No se pudo descargar la imagen';
    exit;
}

// Crear imagen desde datos
$img = @imagecreatefromstring($image_data);
if (!$img) {
    http_response_code(415);
    echo 'Formato de imagen no soportado';
    exit;
}

$width = imagesx($img);
$height = imagesy($img);
$crop = min($crop_px, $height - 1);
$new_height = $height - $crop;

$canvas = imagecreatetruecolor($width, $new_height);
imagealphablending($canvas, false);
imagesavealpha($canvas, true);

// Copiar la imagen recortada
imagecopy($canvas, $img, 0, 0, 0, 0, $width, $new_height);

// Salida como PNG
imagepng($canvas);
imagedestroy($img);
imagedestroy($canvas);
