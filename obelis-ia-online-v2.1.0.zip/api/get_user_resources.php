<?php
/**
 * API para obtener recursos del usuario (imágenes, textos, etc.)
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once __DIR__ . '/../../helpers/db.php';
require_once __DIR__ . '/../../src/Auth/Auth.php';

$auth = new \ObelisIA\Auth\Auth();

if (!$auth->isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

try {
    $user = $auth->getCurrentUser();
    $userId = $user['id'];
    
    // Obtener recursos del usuario desde user_creations
    $stmt = $db->prepare("
        SELECT id, type, title, description, file_path, created_at, tool_used
        FROM user_creations 
        WHERE user_id = ? 
        ORDER BY created_at DESC 
        LIMIT 50
    ");
    
    $stmt->execute([$userId]);
    $creations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $resources = [];
    
    foreach ($creations as $creation) {
        $resource = [
            'id' => $creation['id'],
            'title' => $creation['title'] ?: 'Sin título',
            'type' => $creation['type'],
            'tool' => $creation['tool_used'],
            'url' => $creation['file_path'],
            'created_at' => $creation['created_at']
        ];
        
        // Agregar propiedades específicas según el tipo
        switch ($creation['type']) {
            case 'image':
                $resource['thumbnail'] = $creation['file_path'];
                break;
            case 'text':
                $resource['content'] = substr($creation['description'] ?: '', 0, 100);
                break;
        }
        
        $resources[] = $resource;
    }
    
    echo json_encode([
        'success' => true,
        'resources' => $resources
    ]);
    
} catch (Exception $e) {
    error_log("Error en get_user_resources: " . $e->getMessage());
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
