<?php
/**
 * API para publicar una creación de contenido
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once __DIR__ . '/../../helpers/db.php';
require_once __DIR__ . '/../../src/Auth/Auth.php';

$auth = new \ObelisIA\Auth\Auth();

if (!$auth->isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('Datos JSON inválidos');
    }
    
    $creationId = $input['id'] ?? '';
    
    if (empty($creationId)) {
        throw new Exception('ID de creación requerido');
    }
    
    $user = $auth->getCurrentUser();
    $userId = $user['id'];
    
    // Verificar que la creación pertenece al usuario
    $stmt = $db->prepare("SELECT id, title, file_path FROM user_creations WHERE id = ? AND user_id = ?");
    $stmt->execute([$creationId, $userId]);
    $creation = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$creation) {
        throw new Exception('Creación no encontrada');
    }
    
    // Actualizar como publicada
    $stmt = $db->prepare("
        UPDATE user_creations 
        SET is_public = 1, privacy = 'public', updated_at = NOW()
        WHERE id = ? AND user_id = ?
    ");
    
    $success = $stmt->execute([$creationId, $userId]);
    
    if (!$success) {
        throw new Exception('Error al publicar la creación');
    }
    
    // Generar URL pública
    $publicUrl = 'https://' . $_SERVER['HTTP_HOST'] . '/creacion/' . $creation['file_path'];
    
    // Log de actividad
    try {
        require_once __DIR__ . '/../../helpers/log_activity.php';
        logActivity($userId, 'publish', 'Publicó la creación: ' . $creation['title']);
    } catch (Exception $e) {
        error_log("Error logging activity: " . $e->getMessage());
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Creación publicada exitosamente',
        'public_url' => $publicUrl
    ]);
    
} catch (Exception $e) {
    error_log("Error en publish_content_creation: " . $e->getMessage());
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
