<?php
// api/save_creation.php
require_once __DIR__ . '/../helpers/exp.php';
session_start();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'status' => 'error',
        'message' => 'Método no permitido.'
    ]);
    exit;
}

$userId = $_SESSION['user_id'] ?? null;
if (!$userId) {
    http_response_code(401);
    echo json_encode([
        'status' => 'error',
        'message' => 'No autenticado.'
    ]);
    exit;
}

$creationData = json_decode(file_get_contents('php://input'), true);

if (!is_array($creationData) || empty($creationData['file_path']) || empty($creationData['tool_used']) || empty($creationData['title']) || empty($creationData['description'])) {
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => 'Datos de creación incompletos (falta título o descripción).'
    ]);
    exit;
}

try {
    saveCreationAndAwardExp($userId, $creationData);
    echo json_encode([
        'status' => 'success',
        'message' => 'Creación guardada y experiencia otorgada.'
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Error interno al guardar la creación.',
        'details' => $e->getMessage()
    ]);
}
