<?php
// api/award_exp.php
require_once __DIR__ . '/../helpers/exp.php';
session_start();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'status' => 'error',
        'message' => 'Método no permitido.'
    ]);
    exit;
}

$userId = $_SESSION['user_id'] ?? null;
if (!$userId) {
    http_response_code(401);
    echo json_encode([
        'status' => 'error',
        'message' => 'No autenticado.'
    ]);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$actionType = $data['action'] ?? null;

if (!in_array($actionType, ['use_tool', 'save_creation'], true)) {
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => 'Acción no válida.'
    ]);
    exit;
}

try {
    addExp($userId, $actionType);
    echo json_encode([
        'status' => 'success',
        'message' => 'Experiencia otorgada.'
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Error interno al otorgar experiencia.',
        'details' => $e->getMessage()
    ]);
}
