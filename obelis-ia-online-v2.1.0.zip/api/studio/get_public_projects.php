<?php
/**
 * API: Obtener proyectos públicos
 * Retorna proyectos públicos para mostrar en la comunidad
 */

header('Content-Type: application/json');
require_once '../../../helpers/db.php';
require_once '../../../src/ObelisStudio/ObelisStudio.php';

try {
    $page = max(1, intval($_GET['page'] ?? 1));
    $limit = min(50, max(1, intval($_GET['limit'] ?? 20))); // Entre 1 y 50
    $offset = ($page - 1) * $limit;
    
    $studio = new \ObelisIA\ObelisStudio\ObelisStudio();
    $projects = $studio->getPublicProjects($limit, $offset);
    
    // Obtener total para paginación
    $stmt = $conn->prepare("
        SELECT COUNT(*) as total 
        FROM obelis_studio_projects 
        WHERE is_public = 1 AND status = 'published'
    ");
    $stmt->execute();
    $total = $stmt->get_result()->fetch_assoc()['total'];
    
    $total_pages = ceil($total / $limit);
    
    echo json_encode([
        'success' => true,
        'projects' => $projects,
        'pagination' => [
            'current_page' => $page,
            'total_pages' => $total_pages,
            'total_items' => $total,
            'items_per_page' => $limit,
            'has_next' => $page < $total_pages,
            'has_prev' => $page > 1
        ]
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error interno del servidor',
        'message' => $e->getMessage()
    ]);
}
?>
