<?php
/**
 * API: Agregar comentario a proyecto
 * Maneja comentarios en proyectos de Obelis Studio
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../helpers/db.php';

// Verificar autenticación
session_start();
if (!isset($_SESSION['user'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

// Validar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

try {
    // Obtener datos JSON
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('JSON inválido');
    }

    $project_id = filter_var($input['project_id'] ?? null, FILTER_VALIDATE_INT);
    $content = trim($input['content'] ?? '');
    $parent_id = filter_var($input['parent_id'] ?? null, FILTER_VALIDATE_INT);

    // Validaciones
    if (!$project_id) {
        throw new Exception('ID de proyecto inválido');
    }

    if (empty($content)) {
        throw new Exception('El comentario no puede estar vacío');
    }

    if (strlen($content) > 1000) {
        throw new Exception('El comentario es demasiado largo (máximo 1000 caracteres)');
    }

    $user_id = $_SESSION['user']['id'];

    // Verificar que el proyecto existe y es público
    $stmt = $pdo->prepare("
        SELECT id, user_id, title 
        FROM obelis_studio_projects 
        WHERE id = ? AND is_public = 1
    ");
    $stmt->execute([$project_id]);
    $project = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$project) {
        throw new Exception('Proyecto no encontrado o no es público');
    }

    // Si es una respuesta, verificar que el comentario padre existe
    if ($parent_id) {
        $stmt = $pdo->prepare("
            SELECT id 
            FROM project_comments 
            WHERE id = ? AND project_id = ? AND parent_id IS NULL
        ");
        $stmt->execute([$parent_id, $project_id]);
        
        if (!$stmt->fetch()) {
            throw new Exception('Comentario padre no encontrado');
        }
    }

    // Verificar límite de comentarios por usuario por día (anti-spam)
    $stmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM project_comments 
        WHERE user_id = ? AND DATE(created_at) = CURDATE()
    ");
    $stmt->execute([$user_id]);
    $daily_comments = $stmt->fetchColumn();

    if ($daily_comments >= 50) {
        throw new Exception('Has alcanzado el límite diario de comentarios');
    }

    $pdo->beginTransaction();

    // Insertar comentario
    $stmt = $pdo->prepare("
        INSERT INTO project_comments (user_id, project_id, parent_id, content, created_at) 
        VALUES (?, ?, ?, ?, NOW())
    ");
    $stmt->execute([$user_id, $project_id, $parent_id, $content]);
    
    $comment_id = $pdo->lastInsertId();

    // LÓGICA MANUAL: Actualizar contador de comentarios (reemplaza al TRIGGER)
    $stmt = $pdo->prepare("
        INSERT INTO project_stats_cache (project_id, comments_count, last_updated)
        VALUES (?, 1, CURRENT_TIMESTAMP)
        ON DUPLICATE KEY UPDATE
        comments_count = comments_count + 1,
        last_updated = CURRENT_TIMESTAMP
    ");
    $stmt->execute([$project_id]);

    // Registrar actividad
    if (file_exists(__DIR__ . '/../../helpers/log_activity.php')) {
        require_once __DIR__ . '/../../helpers/log_activity.php';
        $activity_desc = $parent_id 
            ? "Respondió a un comentario en el proyecto: {$project['title']}"
            : "Comentó en el proyecto: {$project['title']}";
        log_user_activity($pdo, $user_id, 'Comentario', $activity_desc);
    }

    // Obtener los datos del comentario insertado para la respuesta
    $stmt = $pdo->prepare("
        SELECT 
            pc.id,
            pc.content,
            pc.created_at,
            pc.parent_id,
            u.username,
            u.full_name,
            u.profile_image
        FROM project_comments pc
        JOIN users u ON pc.user_id = u.id
        WHERE pc.id = ?
    ");
    $stmt->execute([$comment_id]);
    $new_comment = $stmt->fetch(PDO::FETCH_ASSOC);

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Comentario agregado exitosamente',
        'comment' => [
            'id' => $new_comment['id'],
            'content' => $new_comment['content'],
            'created_at' => $new_comment['created_at'],
            'created_at_formatted' => 'hace unos segundos',
            'parent_id' => $new_comment['parent_id'],
            'user_id' => $user_id,
            'username' => $new_comment['username'],
            'full_name' => $new_comment['full_name'],
            'profile_image' => $new_comment['profile_image'],
            'replies' => [],
            'replies_count' => 0,
            'is_edited' => false
        ]
    ]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
    
    error_log("Error en add_comment.php: " . $e->getMessage());
}
?>
