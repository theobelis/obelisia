<?php
/**
 * API: Crear nuevo proyecto
 * Crea un nuevo proyecto en el Studio
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../../helpers/db.php';
require_once __DIR__ . '/../../src/ObelisStudio/ObelisStudio.php';

// Verificar autenticación
session_start();
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'No autenticado']);
    exit;
}

// Verificar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('Datos inválidos');
    }
    
    $title = trim($input['title'] ?? '');
    $description = trim($input['description'] ?? '');
    
    if (empty($title)) {
        throw new Exception('El título es requerido');
    }
    
    if (strlen($title) > 255) {
        throw new Exception('El título es demasiado largo (máximo 255 caracteres)');
    }
    
    if (strlen($description) > 500) {
        throw new Exception('La descripción es demasiado larga (máximo 500 caracteres)');
    }
    
    $studio = new \ObelisIA\ObelisStudio\ObelisStudio($_SESSION['user_id']);
    
    // Verificar acceso
    if (!$studio->hasAccess()) {
        throw new Exception('No tienes acceso al Studio');
    }
    
    $result = $studio->createProject($title, $description);
    
    if ($result['success']) {
        echo json_encode([
            'success' => true,
            'project_id' => $result['project_id'],
            'message' => $result['message']
        ]);
    } else {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => $result['message']
        ]);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error interno del servidor',
        'message' => $e->getMessage(),
        'debug' => [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString()
        ]
    ]);
}
?>
