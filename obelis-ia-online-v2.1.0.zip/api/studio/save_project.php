<?php
/**
 * API: Guardar proyecto del Studio
 * Guarda o actualiza un proyecto (auto-guardado o manual)
 */

header('Content-Type: application/json');
require_once '../../../helpers/db.php';
require_once '../../../src/ObelisStudio/ProjectManager.php';

// Verificar autenticación
session_start();
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'No autenticado']);
    exit;
}

// Verificar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('Datos inválidos');
    }
    
    $project_id = $input['project_id'] ?? null;
    $project_data = $input['project_data'] ?? [];
    
    if (!$project_id) {
        throw new Exception('ID del proyecto requerido');
    }
    
    $projectManager = new \ObelisIA\ObelisStudio\ProjectManager($_SESSION['user_id']);
    $result = $projectManager->saveProject($project_id, $project_data);
    
    if ($result['success']) {
        echo json_encode([
            'success' => true,
            'message' => $result['message'],
            'timestamp' => date('Y-m-d H:i:s')
        ]);
    } else {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => $result['message']
        ]);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error interno del servidor',
        'message' => $e->getMessage()
    ]);
}
?>
