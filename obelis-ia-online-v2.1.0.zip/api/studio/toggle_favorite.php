<?php
/**
 * API: Toggle favorito en proyecto
 * Maneja agregar/quitar favoritos de proyectos
 */

require_once '../../helpers/db.php';

header('Content-Type: application/json');

try {
    // Verificar autenticación
    if (!isset($_SESSION['user'])) {
        throw new Exception('Debes iniciar sesión');
    }
    
    // Verificar método
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método no permitido');
    }
    
    // Obtener datos
    $input = json_decode(file_get_contents('php://input'), true);
    $projectId = $input['project_id'] ?? null;
    $userId = $_SESSION['user']['id'];
    
    if (!$projectId) {
        throw new Exception('ID de proyecto requerido');
    }
    
    // Verificar que el proyecto existe y es público
    $stmt = $pdo->prepare("SELECT id, user_id FROM obelis_studio_projects WHERE id = ? AND is_public = 1");
    $stmt->execute([$projectId]);
    $project = $stmt->fetch();
    
    if (!$project) {
        throw new Exception('Proyecto no encontrado o no es público');
    }
    
    // Verificar si ya está en favoritos
    $stmt = $pdo->prepare("SELECT id FROM project_favorites WHERE project_id = ? AND user_id = ?");
    $stmt->execute([$projectId, $userId]);
    $existingFavorite = $stmt->fetch();
    
    $pdo->beginTransaction();
    
    if ($existingFavorite) {
        // Remover favorito
        $stmt = $pdo->prepare("DELETE FROM project_favorites WHERE project_id = ? AND user_id = ?");
        $stmt->execute([$projectId, $userId]);
        $favorited = false;
        
        // LÓGICA MANUAL: Actualizar contador de favoritos (reemplaza al TRIGGER)
        $stmt = $pdo->prepare("
            UPDATE project_stats_cache
            SET favorites_count = GREATEST(0, favorites_count - 1),
                last_updated = CURRENT_TIMESTAMP
            WHERE project_id = ?
        ");
        $stmt->execute([$projectId]);
    } else {
        // Agregar favorito
        $stmt = $pdo->prepare("INSERT INTO project_favorites (project_id, user_id, created_at) VALUES (?, ?, NOW())");
        $stmt->execute([$projectId, $userId]);
        $favorited = true;
        
        // LÓGICA MANUAL: Actualizar contador de favoritos (reemplaza al TRIGGER)
        $stmt = $pdo->prepare("
            INSERT INTO project_stats_cache (project_id, favorites_count, last_updated)
            VALUES (?, 1, CURRENT_TIMESTAMP)
            ON DUPLICATE KEY UPDATE
            favorites_count = favorites_count + 1,
            last_updated = CURRENT_TIMESTAMP
        ");
        $stmt->execute([$projectId]);
    }
    
    // Obtener total de favoritos actualizado
    $stmt = $pdo->prepare("SELECT COUNT(*) as favorite_count FROM project_favorites WHERE project_id = ?");
    $stmt->execute([$projectId]);
    $favoriteCount = $stmt->fetchColumn();
    
    // Registrar actividad
    if (file_exists(__DIR__ . '/../../helpers/log_activity.php')) {
        require_once __DIR__ . '/../../helpers/log_activity.php';
        $activity_desc = $favorited ? "Agregó proyecto a favoritos" : "Quitó proyecto de favoritos";
        log_user_activity($pdo, $userId, 'Favorito', $activity_desc);
    }
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'favorited' => $favorited,
        'favorite_count' => (int)$favoriteCount
    ]);
    
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
