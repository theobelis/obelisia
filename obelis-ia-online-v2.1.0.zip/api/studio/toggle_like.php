<?php
/**
 * API: Toggle like en proyecto
 * Maneja likes y unlikes de proyectos
 */

require_once '../../helpers/db.php';

header('Content-Type: application/json');

try {
    // Verificar autenticación
    if (!isset($_SESSION['user'])) {
        throw new Exception('Debes iniciar sesión');
    }
    
    // Verificar método
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método no permitido');
    }
    
    // Obtener datos
    $input = json_decode(file_get_contents('php://input'), true);
    $projectId = $input['project_id'] ?? null;
    $userId = $_SESSION['user']['id'];
    
    if (!$projectId) {
        throw new Exception('ID de proyecto requerido');
    }
    
    // Verificar que el proyecto existe y es público
    $stmt = $pdo->prepare("SELECT id, user_id FROM obelis_studio_projects WHERE id = ? AND is_public = 1");
    $stmt->execute([$projectId]);
    $project = $stmt->fetch();
    
    if (!$project) {
        throw new Exception('Proyecto no encontrado o no es público');
    }
    
    // No permitir like a proyectos propios
    if ($userId == $project['user_id']) {
        throw new Exception('No puedes dar like a tus propios proyectos');
    }
    
    // Verificar si ya tiene like
    $stmt = $pdo->prepare("SELECT id FROM project_likes WHERE project_id = ? AND user_id = ?");
    $stmt->execute([$projectId, $userId]);
    $existingLike = $stmt->fetch();
    
    $pdo->beginTransaction();
    
    if ($existingLike) {
        // Remover like
        $stmt = $pdo->prepare("DELETE FROM project_likes WHERE project_id = ? AND user_id = ?");
        $stmt->execute([$projectId, $userId]);
        $liked = false;
        
        // LÓGICA MANUAL: Actualizar contador de likes (reemplaza al TRIGGER)
        $stmt = $pdo->prepare("
            UPDATE project_stats_cache
            SET likes_count = GREATEST(0, likes_count - 1),
                last_updated = CURRENT_TIMESTAMP
            WHERE project_id = ?
        ");
        $stmt->execute([$projectId]);
    } else {
        // Agregar like
        $stmt = $pdo->prepare("INSERT INTO project_likes (project_id, user_id, created_at) VALUES (?, ?, NOW())");
        $stmt->execute([$projectId, $userId]);
        $liked = true;
        
        // LÓGICA MANUAL: Actualizar contador de likes (reemplaza al TRIGGER)
        $stmt = $pdo->prepare("
            INSERT INTO project_stats_cache (project_id, likes_count, last_updated)
            VALUES (?, 1, CURRENT_TIMESTAMP)
            ON DUPLICATE KEY UPDATE
            likes_count = likes_count + 1,
            last_updated = CURRENT_TIMESTAMP
        ");
        $stmt->execute([$projectId]);
    }
    
    // Obtener total de likes actualizado
    $stmt = $pdo->prepare("SELECT COUNT(*) as like_count FROM project_likes WHERE project_id = ?");
    $stmt->execute([$projectId]);
    $likeCount = $stmt->fetchColumn();
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'liked' => $liked,
        'like_count' => (int)$likeCount
    ]);
    
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
