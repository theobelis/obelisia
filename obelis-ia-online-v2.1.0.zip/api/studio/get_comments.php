<?php
/**
 * API: Obtener comentarios de proyecto
 * Retorna comentarios de un proyecto con estructura jerárquica
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../helpers/db.php';

try {
    $project_id = filter_var($_GET['project_id'] ?? null, FILTER_VALIDATE_INT);
    
    if (!$project_id) {
        throw new Exception('ID de proyecto inválido');
    }

    // Verificar que el proyecto existe y es público
    $stmt = $pdo->prepare("
        SELECT id 
        FROM obelis_studio_projects 
        WHERE id = ? AND is_public = 1
    ");
    $stmt->execute([$project_id]);
    
    if (!$stmt->fetch()) {
        throw new Exception('Proyecto no encontrado o no es público');
    }

    // Obtener comentarios principales (sin parent_id)
    $stmt = $pdo->prepare("
        SELECT 
            pc.id,
            pc.content,
            pc.created_at,
            pc.is_edited,
            pc.parent_id,
            u.id as user_id,
            u.username,
            u.full_name,
            u.profile_image,
            (SELECT COUNT(*) FROM project_comments WHERE parent_id = pc.id) as replies_count
        FROM project_comments pc
        JOIN users u ON pc.user_id = u.id
        WHERE pc.project_id = ? AND pc.parent_id IS NULL
        ORDER BY pc.created_at DESC
    ");
    $stmt->execute([$project_id]);
    $main_comments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Obtener respuestas para cada comentario principal
    $comments_with_replies = [];
    
    foreach ($main_comments as $comment) {
        // Formatear fecha
        $comment['created_at_formatted'] = formatTimeAgo($comment['created_at']);
        
        // Obtener respuestas
        $stmt = $pdo->prepare("
            SELECT 
                pc.id,
                pc.content,
                pc.created_at,
                pc.is_edited,
                pc.parent_id,
                u.id as user_id,
                u.username,
                u.full_name,
                u.profile_image
            FROM project_comments pc
            JOIN users u ON pc.user_id = u.id
            WHERE pc.parent_id = ?
            ORDER BY pc.created_at ASC
        ");
        $stmt->execute([$comment['id']]);
        $replies = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Formatear fechas de respuestas
        foreach ($replies as &$reply) {
            $reply['created_at_formatted'] = formatTimeAgo($reply['created_at']);
        }
        
        $comment['replies'] = $replies;
        $comments_with_replies[] = $comment;
    }

    echo json_encode([
        'success' => true,
        'comments' => $comments_with_replies,
        'total_comments' => count($main_comments)
    ]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
    
    error_log("Error en get_comments.php: " . $e->getMessage());
}

/**
 * Formatear tiempo relativo
 */
function formatTimeAgo($datetime) {
    $time = time() - strtotime($datetime);
    
    if ($time < 60) {
        return 'hace unos segundos';
    } elseif ($time < 3600) {
        $minutes = floor($time / 60);
        return "hace {$minutes} minuto" . ($minutes > 1 ? 's' : '');
    } elseif ($time < 86400) {
        $hours = floor($time / 3600);
        return "hace {$hours} hora" . ($hours > 1 ? 's' : '');
    } elseif ($time < 2592000) {
        $days = floor($time / 86400);
        return "hace {$days} día" . ($days > 1 ? 's' : '');
    } else {
        return date('d/m/Y', strtotime($datetime));
    }
}
?>
