<?php
/**
 * API: Registrar visualización de proyecto
 * Incrementa el contador de vistas
 */

require_once '../../helpers/db.php';

header('Content-Type: application/json');

try {
    // Verificar método
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método no permitido');
    }
    
    // Obtener datos
    $input = json_decode(file_get_contents('php://input'), true);
    $projectId = $input['project_id'] ?? null;
    
    if (!$projectId) {
        throw new Exception('ID de proyecto requerido');
    }
    
    // Verificar que el proyecto existe y es público
    $stmt = $pdo->prepare("SELECT id, user_id FROM obelis_studio_projects WHERE id = ? AND is_public = 1");
    $stmt->execute([$projectId]);
    $project = $stmt->fetch();
    
    if (!$project) {
        throw new Exception('Proyecto no encontrado o no es público');
    }
    
    // No contar visualizaciones del propio autor
    $userId = $_SESSION['user']['id'] ?? null;
    if ($userId && $userId == $project['user_id']) {
        echo json_encode(['success' => true, 'message' => 'Vista de autor no contada']);
        exit;
    }
    
    // Incrementar contador de visualizaciones
    $stmt = $pdo->prepare("UPDATE obelis_studio_projects SET views = views + 1 WHERE id = ?");
    $stmt->execute([$projectId]);
    
    // Registrar vista detallada (opcional, para analytics)
    if ($userId) {
        $stmt = $pdo->prepare("
            INSERT INTO project_views (project_id, user_id, viewed_at, ip_address) 
            VALUES (?, ?, NOW(), ?)
            ON DUPLICATE KEY UPDATE viewed_at = NOW()
        ");
        $stmt->execute([$projectId, $userId, $_SERVER['REMOTE_ADDR'] ?? '']);
    }
    
    echo json_encode(['success' => true]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
