<?php
/**
 * API: Obtener biblioteca personal del usuario
 * Retorna todas las creaciones del usuario para usar en el Studio
 */

header('Content-Type: application/json');
require_once '../../../helpers/db.php';
require_once '../../../src/ObelisStudio/ElementManager.php';

// Verificar autenticación
session_start();
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'No autenticado']);
    exit;
}

try {
    $elementManager = new \ObelisIA\ObelisStudio\ElementManager($_SESSION['user_id']);
    $library = $elementManager->getUserLibrary();
    
    // Organizar por tipo para mejor UX
    $organized_library = [
        'images' => [],
        'texts' => [],
        'audios' => [],
        'others' => []
    ];
    
    foreach ($library as $item) {
        switch ($item['type']) {
            case 'image':
                $organized_library['images'][] = $item;
                break;
            case 'text':
                $organized_library['texts'][] = $item;
                break;
            case 'audio':
                $organized_library['audios'][] = $item;
                break;
            default:
                $organized_library['others'][] = $item;
        }
    }
    
    echo json_encode([
        'success' => true,
        'library' => $organized_library,
        'total_items' => count($library)
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error interno del servidor',
        'message' => $e->getMessage()
    ]);
}
?>
