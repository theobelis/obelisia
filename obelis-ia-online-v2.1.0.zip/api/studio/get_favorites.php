<?php
/**
 * API: Obtener favoritos del usuario
 * Retorna proyectos marcados como favoritos por el usuario
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../helpers/db.php';

// Verificar autenticación
session_start();
if (!isset($_SESSION['user'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

try {
    $userId = $_SESSION['user']['id'];
    $page = filter_var($_GET['page'] ?? 1, FILTER_VALIDATE_INT);
    $limit = filter_var($_GET['limit'] ?? 12, FILTER_VALIDATE_INT);
    
    if ($page < 1) $page = 1;
    if ($limit < 1 || $limit > 50) $limit = 12;
    
    $offset = ($page - 1) * $limit;
    
    // Obtener proyectos favoritos del usuario
    $stmt = $pdo->prepare("
        SELECT 
            p.id,
            p.title,
            p.description,
            p.thumbnail,
            p.created_at,
            p.updated_at,
            u.username,
            u.full_name,
            u.profile_image,
            pf.created_at as favorited_at,
            COALESCE(stats.views_count, 0) as views,
            COALESCE(stats.likes_count, 0) as likes,
            COALESCE(stats.comments_count, 0) as comments,
            COALESCE(stats.favorites_count, 0) as favorites
        FROM project_favorites pf
        JOIN obelis_studio_projects p ON pf.project_id = p.id
        JOIN users u ON p.user_id = u.id
        LEFT JOIN project_stats_cache stats ON p.id = stats.project_id
        WHERE pf.user_id = ? AND p.is_public = 1
        ORDER BY pf.created_at DESC
        LIMIT ? OFFSET ?
    ");
    $stmt->execute([$userId, $limit, $offset]);
    $favorites = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Contar total de favoritos
    $stmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM project_favorites pf
        JOIN obelis_studio_projects p ON pf.project_id = p.id
        WHERE pf.user_id = ? AND p.is_public = 1
    ");
    $stmt->execute([$userId]);
    $totalFavorites = $stmt->fetchColumn();
    
    // Formatear fechas
    foreach ($favorites as &$favorite) {
        $favorite['created_at_formatted'] = formatTimeAgo($favorite['created_at']);
        $favorite['favorited_at_formatted'] = formatTimeAgo($favorite['favorited_at']);
        $favorite['views'] = (int)$favorite['views'];
        $favorite['likes'] = (int)$favorite['likes'];
        $favorite['comments'] = (int)$favorite['comments'];
        $favorite['favorites'] = (int)$favorite['favorites'];
    }
    
    echo json_encode([
        'success' => true,
        'favorites' => $favorites,
        'pagination' => [
            'current_page' => $page,
            'total_pages' => ceil($totalFavorites / $limit),
            'total_items' => (int)$totalFavorites,
            'items_per_page' => $limit
        ]
    ]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
    
    error_log("Error en get_favorites.php: " . $e->getMessage());
}

/**
 * Formatear tiempo relativo
 */
function formatTimeAgo($datetime) {
    $time = time() - strtotime($datetime);
    
    if ($time < 60) {
        return 'hace unos segundos';
    } elseif ($time < 3600) {
        $minutes = floor($time / 60);
        return "hace {$minutes} minuto" . ($minutes > 1 ? 's' : '');
    } elseif ($time < 86400) {
        $hours = floor($time / 3600);
        return "hace {$hours} hora" . ($hours > 1 ? 's' : '');
    } elseif ($time < 2592000) {
        $days = floor($time / 86400);
        return "hace {$days} día" . ($days > 1 ? 's' : '');
    } else {
        return date('d/m/Y', strtotime($datetime));
    }
}
?>
