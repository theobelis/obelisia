<?php
/**
 * API: Eliminar comentario de proyecto
 * Elimina comentario y actualiza contador manualmente
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../helpers/db.php';

// Verificar autenticación
session_start();
if (!isset($_SESSION['user'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

// Validar método DELETE
if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

try {
    // Obtener datos JSON
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('JSON inválido');
    }

    $comment_id = filter_var($input['comment_id'] ?? null, FILTER_VALIDATE_INT);
    
    if (!$comment_id) {
        throw new Exception('ID de comentario inválido');
    }

    $user_id = $_SESSION['user']['id'];

    // Verificar que el comentario existe y pertenece al usuario
    $stmt = $pdo->prepare("
        SELECT pc.id, pc.project_id, pc.user_id, pc.parent_id,
               p.user_id as project_owner_id
        FROM project_comments pc
        JOIN obelis_studio_projects p ON pc.project_id = p.id
        WHERE pc.id = ?
    ");
    $stmt->execute([$comment_id]);
    $comment = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$comment) {
        throw new Exception('Comentario no encontrado');
    }

    // Verificar permisos (solo el autor del comentario o el dueño del proyecto pueden eliminar)
    if ($comment['user_id'] != $user_id && $comment['project_owner_id'] != $user_id) {
        throw new Exception('No tienes permisos para eliminar este comentario');
    }

    $pdo->beginTransaction();

    // Contar total de comentarios que se van a eliminar (incluye respuestas)
    $stmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM project_comments 
        WHERE id = ? OR parent_id = ?
    ");
    $stmt->execute([$comment_id, $comment_id]);
    $comments_to_delete = $stmt->fetchColumn();

    // Eliminar comentario (las respuestas se eliminan por CASCADE)
    $stmt = $pdo->prepare("DELETE FROM project_comments WHERE id = ?");
    $stmt->execute([$comment_id]);

    // LÓGICA MANUAL: Actualizar contador de comentarios (reemplaza al TRIGGER)
    $stmt = $pdo->prepare("
        UPDATE project_stats_cache
        SET comments_count = GREATEST(0, comments_count - ?),
            last_updated = CURRENT_TIMESTAMP
        WHERE project_id = ?
    ");
    $stmt->execute([$comments_to_delete, $comment['project_id']]);

    // Registrar actividad
    if (file_exists(__DIR__ . '/../../helpers/log_activity.php')) {
        require_once __DIR__ . '/../../helpers/log_activity.php';
        log_user_activity($pdo, $user_id, 'Comentario eliminado', "Eliminó comentario en proyecto ID: {$comment['project_id']}");
    }

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Comentario eliminado exitosamente'
    ]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
    
    error_log("Error en delete_comment.php: " . $e->getMessage());
}
?>
