<?php
/**
 * API: Gestión de elementos en proyectos
 * Añadir, actualizar, reordenar y eliminar elementos
 */

header('Content-Type: application/json');
require_once '../../../helpers/db.php';
require_once '../../../src/ObelisStudio/ElementManager.php';

// Verificar autenticación
session_start();
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'No autenticado']);
    exit;
}

// Verificar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('Datos inválidos');
    }
    
    $action = $input['action'] ?? null;
    $elementManager = new \ObelisIA\ObelisStudio\ElementManager($_SESSION['user_id']);
    
    switch ($action) {
        case 'add':
            $project_id = $input['project_id'] ?? null;
            $element_type = $input['element_type'] ?? null;
            $element_id = $input['element_id'] ?? null;
            $position = $input['position'] ?? null;
            $settings = $input['settings'] ?? [];
            
            if (!$project_id || !$element_type) {
                throw new Exception('Datos insuficientes para añadir elemento');
            }
            
            $result = $elementManager->addElementToProject($project_id, $element_type, $element_id, $position, $settings);
            break;
            
        case 'update':
            $element_id = $input['element_id'] ?? null;
            $settings = $input['settings'] ?? [];
            
            if (!$element_id) {
                throw new Exception('ID del elemento requerido');
            }
            
            $result = $elementManager->updateElementSettings($element_id, $settings);
            break;
            
        case 'reorder':
            $project_id = $input['project_id'] ?? null;
            $element_orders = $input['element_orders'] ?? [];
            
            if (!$project_id || empty($element_orders)) {
                throw new Exception('Datos insuficientes para reordenar');
            }
            
            $result = $elementManager->reorderElements($project_id, $element_orders);
            break;
            
        case 'remove':
            $element_id = $input['element_id'] ?? null;
            
            if (!$element_id) {
                throw new Exception('ID del elemento requerido');
            }
            
            $result = $elementManager->removeElementFromProject($element_id);
            break;
            
        default:
            throw new Exception('Acción no válida');
    }
    
    if ($result['success']) {
        echo json_encode($result);
    } else {
        http_response_code(400);
        echo json_encode($result);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error interno del servidor',
        'message' => $e->getMessage()
    ]);
}
?>
