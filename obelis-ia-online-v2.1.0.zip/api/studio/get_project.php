<?php
/**
 * API: Obtener proyecto específico
 * Carga un proyecto para edición o visualización
 */

header('Content-Type: application/json');
require_once '../../../helpers/db.php';
require_once '../../../src/ObelisStudio/ProjectManager.php';

// Verificar autenticación para proyectos privados
session_start();
$user_id = $_SESSION['user_id'] ?? null;

try {
    $project_id = $_GET['id'] ?? null;
    
    if (!$project_id) {
        throw new Exception('ID del proyecto requerido');
    }
    
    $projectManager = new \ObelisIA\ObelisStudio\ProjectManager($user_id);
    $project = $projectManager->getProject($project_id);
    
    if (!$project) {
        http_response_code(404);
        echo json_encode([
            'success' => false,
            'error' => 'Proyecto no encontrado'
        ]);
        exit;
    }
    
    // Si el proyecto no es público, verificar que el usuario sea el propietario
    if (!$project['is_public'] && (!$user_id || $project['user_id'] != $user_id)) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => 'Sin permisos para acceder a este proyecto'
        ]);
        exit;
    }
    
    // Obtener información del autor si el proyecto es público
    if ($project['is_public'] && $project['user_id'] != $user_id) {
        $stmt = $conn->prepare("SELECT username, profile_pic FROM users WHERE id = ?");
        $stmt->bind_param("i", $project['user_id']);
        $stmt->execute();
        $author = $stmt->get_result()->fetch_assoc();
        $project['author'] = $author;
    }
    
    // Determinar si el usuario puede editar
    $can_edit = $user_id && ($project['user_id'] == $user_id);
    
    echo json_encode([
        'success' => true,
        'project' => $project,
        'can_edit' => $can_edit
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error interno del servidor',
        'message' => $e->getMessage()
    ]);
}
?>
