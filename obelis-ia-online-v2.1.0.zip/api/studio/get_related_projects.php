<?php
/**
 * API: Obtener proyectos relacionados
 * Encuentra proyectos similares basados en tags y categoría
 */

require_once '../../helpers/db.php';

header('Content-Type: application/json');

try {
    // Verificar método
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        throw new Exception('Método no permitido');
    }
    
    // Obtener ID del proyecto
    $projectId = $_GET['id'] ?? null;
    if (!$projectId) {
        throw new Exception('ID de proyecto requerido');
    }
    
    // Obtener información del proyecto actual
    $stmt = $pdo->prepare("
        SELECT category, tags, user_id 
        FROM obelis_studio_projects 
        WHERE id = ? AND is_public = 1
    ");
    $stmt->execute([$projectId]);
    $currentProject = $stmt->fetch();
    
    if (!$currentProject) {
        throw new Exception('Proyecto no encontrado');
    }
    
    // Buscar proyectos relacionados
    $query = "
        SELECT 
            p.id,
            p.title,
            p.description,
            p.thumbnail,
            p.views,
            p.created_at,
            u.username,
            COALESCE(likes.like_count, 0) as likes
        FROM obelis_studio_projects p
        JOIN users u ON p.user_id = u.id
        LEFT JOIN (
            SELECT project_id, COUNT(*) as like_count 
            FROM project_likes 
            GROUP BY project_id
        ) likes ON p.id = likes.project_id
        WHERE p.is_public = 1 
        AND p.id != ?
        AND (
            p.category = ?
            OR p.user_id = ?
            OR (p.tags IS NOT NULL AND p.tags != '' AND ? IS NOT NULL AND ? != '')
        )
        ORDER BY 
            CASE WHEN p.category = ? THEN 3 ELSE 0 END +
            CASE WHEN p.user_id = ? THEN 2 ELSE 0 END +
            CASE WHEN p.tags LIKE CONCAT('%', ?, '%') THEN 1 ELSE 0 END DESC,
            p.views DESC,
            p.created_at DESC
        LIMIT 6
    ";
    
    $tags = $currentProject['tags'] ?? '';
    $category = $currentProject['category'] ?? '';
    $userId = $currentProject['user_id'];
    
    $stmt = $pdo->prepare($query);
    $stmt->execute([
        $projectId,
        $category,
        $userId,
        $tags,
        $tags,
        $category,
        $userId,
        $tags
    ]);
    
    $projects = $stmt->fetchAll();
    
    // Formatear resultados
    $formattedProjects = [];
    foreach ($projects as $project) {
        $formattedProjects[] = [
            'id' => $project['id'],
            'title' => $project['title'],
            'description' => $project['description'],
            'thumbnail' => $project['thumbnail'],
            'username' => $project['username'],
            'views' => (int)$project['views'],
            'likes' => (int)$project['likes'],
            'created_at' => $project['created_at']
        ];
    }
    
    echo json_encode([
        'success' => true,
        'projects' => $formattedProjects
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'projects' => []
    ]);
}
