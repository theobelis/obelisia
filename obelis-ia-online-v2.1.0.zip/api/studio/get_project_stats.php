<?php
/**
 * API: Obtener estadísticas del proyecto
 * Maneja visualizaciones, likes y comentarios
 */

require_once '../../helpers/db.php';
require_once '../../src/ObelisStudio/ObelisStudio.php';

header('Content-Type: application/json');

try {
    // Verificar método
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        throw new Exception('Método no permitido');
    }
    
    // Obtener ID del proyecto
    $projectId = $_GET['id'] ?? null;
    if (!$projectId) {
        throw new Exception('ID de proyecto requerido');
    }
    
    // Obtener estadísticas del proyecto
    $stmt = $pdo->prepare("
        SELECT 
            p.id,
            p.views,
            COALESCE(likes.like_count, 0) as likes,
            COALESCE(comments.comment_count, 0) as comments,
            COALESCE(user_like.liked, 0) as user_liked
        FROM obelis_studio_projects p
        LEFT JOIN (
            SELECT project_id, COUNT(*) as like_count 
            FROM project_likes 
            WHERE project_id = ? 
            GROUP BY project_id
        ) likes ON p.id = likes.project_id
        LEFT JOIN (
            SELECT project_id, COUNT(*) as comment_count 
            FROM project_comments 
            WHERE project_id = ? 
            GROUP BY project_id
        ) comments ON p.id = comments.project_id
        LEFT JOIN (
            SELECT project_id, 1 as liked 
            FROM project_likes 
            WHERE project_id = ? AND user_id = ?
        ) user_like ON p.id = user_like.project_id
        WHERE p.id = ?
    ");
    
    $userId = $_SESSION['user']['id'] ?? null;
    $stmt->execute([$projectId, $projectId, $projectId, $userId, $projectId]);
    $project = $stmt->fetch();
    
    if (!$project) {
        throw new Exception('Proyecto no encontrado');
    }
    
    echo json_encode([
        'success' => true,
        'stats' => [
            'views' => (int)$project['views'],
            'likes' => (int)$project['likes'],
            'comments' => (int)$project['comments'],
            'user_liked' => (bool)$project['user_liked']
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
