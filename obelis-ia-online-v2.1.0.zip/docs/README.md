# Estructura del Proyecto: htdocs

```
htdocs/
├── .env
├── admin
│   ├── _dashboard_section.php
│   ├── _notifications_section.php
│   ├── _payments_section.php
│   ├── _settings_section.php
│   ├── _tools_section.php
│   ├── _users_section.php
│   ├── admin_panel.php
│   ├── ajax
│   │   ├── bootstrap.php
│   │   ├── dashboard
│   │   │   └── index.php
│   │   ├── financial
│   │   │   ├── financial_transaction.php
│   │   │   └── index.php
│   │   ├── notifications
│   │   │   └── get_notifications.php
│   │   ├── payments
│   │   │   ├── export_payments.php
│   │   │   ├── get_list.php
│   │   │   └── index.php
│   │   ├── settings
│   │   │   ├── get_settings.php
│   │   │   ├── index.php
│   │   │   └── save_setting.php
│   │   ├── tools
│   │   │   ├── actions.php
│   │   │   ├── delete_tool.php
│   │   │   ├── get_list.php
│   │   │   ├── index.php
│   │   │   ├── save_tool.php
│   │   │   └── toggle_tool.php
│   │   └── users
│   │       ├── actions.php
│   │       ├── get_list.php
│   │       └── index.php
│   ├── analytics.php
│   ├── creations.php
│   ├── debug_admin.php
│   ├── index.php
│   ├── payments.php
│   ├── por_implementar
│   │   ├── css
│   │   │   └── main.css
│   │   ├── index.html
│   │   ├── js
│   │   │   └── app.js
│   │   └── py
│   │       ├── analizar_proyecto.py
│   │       ├── generate-readme.py
│   │       └── run_watcher.py
│   ├── settings.php
│   └── users.php
├── ads.txt
├── ajax
│   ├── bootstrap.php
│   └── payments
│       ├── cancel_subscription.php
│       ├── create_checkout_session.php
│       ├── create_mp_preference.php
│       ├── download_invoice.php
│       ├── mp_webhook.php
│       └── paypal_capture_order.php
├── assets
│   ├── banners
│   │   ├── partials
│   │   │   └── premium_banner_for_tools.php
│   │   ├── premium_banner.php
│   │   └── premium_banner_simple.php
│   ├── css
│   │   ├── admin-panel
│   │   │   ├── admin.css
│   │   │   └── general
│   │   ├── general
│   │   │   ├── _activity.css
│   │   │   ├── _admin.css
│   │   │   ├── _alerts.css
│   │   │   ├── _base.css
│   │   │   ├── _botones.css
│   │   │   ├── _cards.css
│   │   │   ├── _dropdown.css
│   │   │   ├── _header-stats.css
│   │   │   ├── _inputs.css
│   │   │   ├── _main-content.css
│   │   │   ├── _modals.css
│   │   │   ├── _navbar.css
│   │   │   ├── _pagination.css
│   │   │   ├── _responsive.css
│   │   │   ├── _scroll.css
│   │   │   ├── _sections.css
│   │   │   ├── _settings.css
│   │   │   ├── _sidebar.css
│   │   │   ├── _tools.css
│   │   │   ├── _users.css
│   │   │   ├── _variables.css
│   │   │   ├── darkmode.css
│   │   │   └── main.css
│   │   └── tools
│   │       ├── bg-remover
│   │       │   └── style.css
│   │       ├── color-palette
│   │       │   ├── side-layout.css
│   │       │   └── style.css
│   │       ├── convert-img
│   │       │   └── side-layout.css
│   │       ├── edit-img
│   │       │   └── style.css
│   │       ├── general
│   │       │   ├── main.css
│   │       │   ├── style.css
│   │       │   ├── styles
│   │       │   │   ├── _about-section.css
│   │       │   │   ├── _base.css
│   │       │   │   ├── _buttons.css
│   │       │   │   ├── _editor.css
│   │       │   │   ├── _faq-section.css
│   │       │   │   ├── _forms.css
│   │       │   │   ├── _global-ad-banner.css
│   │       │   │   ├── _global-modals.css
│   │       │   │   ├── _navbar.css
│   │       │   │   ├── _responsive.css
│   │       │   │   └── _utilities.css
│   │       │   └── tools-page.css
│   │       ├── ia-audio
│   │       │   └── style.css
│   │       ├── ia-img
│   │       │   └── style.css
│   │       ├── ia-text
│   │       │   ├── palette-style.css
│   │       │   └── style.css
│   │       └── ia-video
│   │           └── style.css
│   ├── html
│   ├── images
│   ├── img
│   │   ├── El Limpiador y el Eco Silencioso.png
│   │   ├── Pocoyo.gif
│   │   ├── banner.webp
│   │   ├── banner2.webp
│   │   ├── favicon.ico
│   │   ├── favicon.jpeg
│   │   ├── imagen-generada.png
│   │   ├── logo-1280x720.jpg
│   │   ├── logo.jpg
│   │   ├── logo.webp
│   │   ├── marca_de_agua.jpg
│   │   └── marca_de_agua.webp
│   └── js
│       ├── admin-panel
│       │   ├── api.js
│       │   ├── main.js
│       │   ├── sections
│       │   │   ├── dashboard.js
│       │   │   ├── payments.js
│       │   │   ├── tools.js
│       │   │   └── users.js
│       │   ├── state.js
│       │   └── ui.js
│       ├── admin-panel.js
│       ├── custom.js
│       ├── general
│       │   ├── components
│       │   │   ├── carousel.js
│       │   │   ├── faq.js
│       │   │   ├── modals.js
│       │   │   └── navbar.js
│       │   ├── darkmode.js
│       │   ├── effects
│       │   │   └── floating-elements.js
│       │   ├── global.js
│       │   ├── password_toggle.js
│       │   └── utils
│       │       └── helpers.js
│       ├── payments
│       │   └── buy.js
│       └── tools
│           ├── bg-remover
│           │   └── app.js
│           ├── color-palette
│           │   ├── app.js
│           │   ├── palette-history.js
│           │   └── premium-options.js
│           ├── convert-img
│           │   ├── app.js
│           │   ├── config.js
│           │   ├── downloadManager.js
│           │   ├── fileHandler.js
│           │   ├── imageProcessing.js
│           │   ├── limitManager.js
│           │   ├── main.js
│           │   ├── state.js
│           │   ├── storage.js
│           │   └── uiUpdater.js
│           ├── edit-img
│           │   ├── adjustments
│           │   │   └── colorAdjustments.js
│           │   ├── app.js
│           │   ├── canvas.js
│           │   ├── filters
│           │   │   ├── blurFilter.js
│           │   │   ├── filterManager.js
│           │   │   ├── grayscaleFilter.js
│           │   │   ├── invertFilter.js
│           │   │   ├── sepiaFilter.js
│           │   │   └── sharpenFilter.js
│           │   ├── history.js
│           │   ├── main.js
│           │   ├── script.js
│           │   ├── tools
│           │   │   ├── brushTool.js
│           │   │   ├── cropTool.js
│           │   │   ├── eraserTool.js
│           │   │   ├── eyedropperTool.js
│           │   │   ├── textTool.js
│           │   │   └── toolManager.js
│           │   ├── ui.js
│           │   └── utils
│           │       └── constants.js
│           ├── ia-audio
│           │   ├── aiService.js
│           │   ├── app.js
│           │   ├── config.js
│           │   ├── limitManager.js
│           │   ├── main.js
│           │   └── state.js
│           ├── ia-img
│           │   ├── aiService.js
│           │   ├── app.js
│           │   ├── config.js
│           │   ├── editorManager.js
│           │   ├── galleryManager.js
│           │   ├── imageProcessor.js
│           │   ├── main.js
│           │   ├── state.js
│           │   └── uiUpdater.js
│           └── ia-text
│               ├── aiService.js
│               ├── app.js
│               ├── audioPlayer.js
│               ├── clipboardDownload.js
│               ├── config.js
│               ├── historyManager.js
│               ├── limitManager.js
│               ├── main.js
│               ├── state.js
│               ├── storage.js
│               ├── textFormatter.js
│               └── voiceManager.js
├── composer.lock
├── crear_estructura.sh
├── create_pages.py
├── dashboard
│   └── dashboard.php
├── db-copy
│   └── if0_39552758_obelisia_db.sql
├── emails
│   ├── contact
│   │   └── contact.html
│   └── verification
│       └── verify.html
├── helpers
│   ├── dashboard_stats.php
│   ├── log_activity.php
│   ├── log_activity_include.php
│   └── profile_pic.php
├── index.php
├── lib
│   └── fpdf
│       └── fpdf.php
├── logs
│   └── session_debug.log
├── obelisai-main
│   ├── ads.txt
│   ├── convert-img
│   │   └── index.html
│   ├── css
│   ├── dashboard
│   │   ├── css
│   │   │   └── main.css
│   │   ├── index.html
│   │   ├── js
│   │   │   └── app.js
│   │   └── py
│   │       ├── analizar_proyecto.py
│   │       ├── generate-readme.py
│   │       └── run_watcher.py
│   ├── edit-img
│   │   └── index.html
│   ├── ia-audio
│   │   └── index.html
│   ├── ia-img
│   │   ├── css
│   │   │   └── style.css
│   │   ├── index.html
│   │   └── js
│   │       ├── aiService.js
│   │       ├── app.js
│   │       ├── config.js
│   │       ├── editorManager.js
│   │       ├── galleryManager.js
│   │       ├── imageProcessor.js
│   │       ├── main.js
│   │       ├── state.js
│   │       └── uiUpdater.js
│   ├── ia-text
│   │   └── index.html
│   ├── img
│   │   ├── El Limpiador y el Eco Silencioso.png
│   │   ├── Pocoyo.gif
│   │   ├── banner.webp
│   │   ├── banner2.webp
│   │   ├── favicon.ico
│   │   ├── imagen-generada.png
│   │   ├── logo-1280x720.jpg
│   │   ├── logo.jpg
│   │   ├── logo.webp
│   │   ├── marca_de_agua.jpg
│   │   └── marca_de_agua.webp
│   ├── index.html
│   ├── js
│   ├── package-lock.json
│   ├── package.json
│   ├── reporte_datos.json
│   ├── requirements.txt
│   └── start_watcher.sh
├── pages
│   ├── auth
│   │   ├── login.php
│   │   └── register.php
│   ├── caracteristicas.php
│   ├── error
│   │   ├── 403.php
│   │   ├── 404.php
│   │   ├── 500.php
│   │   ├── 503.php
│   │   └── maintenance.php
│   ├── home.php
│   ├── legal
│   │   ├── privacidad.php
│   │   └── terminos.php
│   ├── precios.php
│   ├── soporte
│   │   └── faq.php
│   ├── static
│   │   ├── about.php
│   │   └── contact.php
│   ├── tools_page.php
│   └── user
│       ├── buy.php
│       ├── creaciones.php
│       ├── notificaciones.php
│       ├── profile.php
│       ├── recursos.php
│       ├── suscripcion.php
│       └── upgrade.php
├── plantilla_api.php
├── plantilla_pagina.php
├── project_scanner.py
├── project_snapshot.txt
├── reporte_datos.json
├── robots.txt
├── sitemap.xml
├── src
│   ├── Auth
│   │   ├── Auth.php
│   │   ├── Login.php
│   │   ├── Register.php
│   │   └── Verify.php
│   ├── Config
│   │   └── config.php
│   ├── Database
│   │   ├── Database.php
│   │   └── DatabaseInfinityFree.php
│   ├── Router
│   │   └── MainRouter.php
│   ├── Services
│   │   └── MetaTagGenerator.php
│   ├── Tools
│   │   ├── BackgroundRemover.php
│   │   ├── ColorPaletteGenerator.php
│   │   ├── ImageConverter.php
│   │   ├── ImageEditor.php
│   │   ├── ImageGenerator.php
│   │   ├── MusicComposer.php
│   │   ├── TextGenerator.php
│   │   ├── VideoGenerator.php
│   │   ├── WordCounter.php
│   │   └── views
│   │       ├── BackgroundRemover_view.php
│   │       ├── ColorPaletteGenerator_view.php
│   │       ├── ImageConverter_view.php
│   │       ├── ImageEditor_view.php
│   │       ├── ImageGenerator_view.php
│   │       ├── MusicComposer_view.php
│   │       ├── TextGenerator_view.php
│   │       └── VideoGenerator_view.php
│   └── Utils
│       ├── Premium.php
│       ├── Uploader.php
│       ├── footer.php
│       └── header.php
├── uploads
│   ├── 688958e606a2b-1000124829.jpg
│   ├── edited-6889596a7d4b0-1000124894.jpg
│   ├── palette-688959293d1de-1000124829.jpg
│   └── palette-68895941c0ce7-1000124275.jpg
├── pages/
│   ├── auth/
│   │   ├── verify.php
└── verificar_error.log
```
