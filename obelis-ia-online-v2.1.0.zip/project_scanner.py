import os
import datetime

def advanced_project_scan():
    """
    Scans key project directories and files, compiling their full content into a single text file.
    """
    print("🚀 Iniciando escaneo avanzado del proyecto...")
    
    # Lista de directorios y archivos clave a incluir en el reporte
    scan_targets = [
        'src', 
        'pages', 
        'assets/js', 
        'assets/css',
        'admin',
        'ajax',
        'index.php',
        '.htaccess',
        'login.php',
        'register.php',
        'dashboard.php'
    ]
    
    # Archivos a ignorar dentro de los directorios escaneados
    ignore_files = [
        'advanced_scanner.py', 
        'project_snapshot.txt',
        'project_structure.json',
        'project_scanner.py',
        'create_pages.py',
        'develop_and_clean.py',
        'implement_features.py',
        'create_new_pages.py'
    ]
    
    output_filename = 'project_snapshot.txt'
    
    try:
        with open(output_filename, 'w', encoding='utf-8') as report_file:
            # Escribir una cabecera en el reporte
            report_file.write("=" * 80 + "\n")
            report_file.write(f" REPORTE DEL PROYECTO OBELISIA\n")
            report_file.write(f" Generado el: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            report_file.write("=" * 80 + "\n\n")

            for target in scan_targets:
                target_path = os.path.abspath(target)
                
                if not os.path.exists(target_path):
                    print(f"   - ⚠️  Advertencia: No se encontró el objetivo '{target}'. Omitiendo.")
                    continue

                if os.path.isdir(target_path):
                    # Es un directorio, lo recorremos
                    for dirpath, _, filenames in os.walk(target_path):
                        for filename in filenames:
                            if filename in ignore_files:
                                continue
                            
                            file_path = os.path.join(dirpath, filename)
                            write_file_content_to_report(file_path, report_file)
                else:
                    # Es un archivo individual
                    write_file_content_to_report(target_path, report_file)

        print(f"\n✨ ¡Escaneo completado! Se ha creado el archivo '{output_filename}'.")
        print("Por favor, adjunta este archivo en tu próximo mensaje para un diagnóstico preciso.")

    except Exception as e:
        print(f"\n❌ Error durante el escaneo: {e}")

def write_file_content_to_report(file_path, report_file):
    """Lee el contenido de un archivo y lo escribe en el reporte con un formato claro."""
    relative_path = os.path.relpath(file_path)
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        report_file.write("-" * 80 + "\n")
        report_file.write(f"RUTA DEL ARCHIVO: {relative_path}\n")
        report_file.write("-" * 80 + "\n")
        report_file.write(content)
        report_file.write("\n\n")
        print(f"   - ✅ Procesado: {relative_path}")

    except Exception as e:
        print(f"   - ⚠️  No se pudo leer el archivo {relative_path}: {e}")

if __name__ == "__main__":
    advanced_project_scan()
