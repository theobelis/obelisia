#!/usr/bin/env python3
"""
Script para eliminar TRIGGERS de archivo SQL de MySQL
Elimina completamente todas las referencias a TRIGGERS para evitar errores en hosting compartido
"""

import re
import sys
import os

def remove_triggers_from_sql(input_file, output_file):
    """Elimina todos los TRIGGERS del archivo SQL"""
    
    print("🔧 Procesando archivo SQL para eliminar TRIGGERS...")
    
    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            content = f.read()
    except FileNotFoundError:
        print(f"❌ Error: No se encontró el archivo {input_file}")
        return False
    except Exception as e:
        print(f"❌ Error al leer el archivo: {e}")
        return False
    
    # Contar TRIGGERS y VIEWs originales
    original_triggers = len(re.findall(r'CREATE TRIGGER', content, re.IGNORECASE))
    original_views = len(re.findall(r'CREATE.*VIEW.*DEFINER', content, re.IGNORECASE))
    print(f"📊 TRIGGERS encontrados: {original_triggers}")
    print(f"👁️  VIEWs con DEFINER encontradas: {original_views}")
    
    # Patrones para eliminar TRIGGERS, VIEWs y elementos relacionados
    patterns_to_remove = [
        # Comentarios de disparadores
        r'--\s*Disparadores.*?--.*?\n',
        
        # DROP TRIGGER statements
        r'DROP TRIGGER IF EXISTS.*?;\s*\n',
        
        # Bloques completos de TRIGGERS (incluyendo DELIMITER)
        r'DELIMITER \$\$\s*\n.*?CREATE TRIGGER.*?END\s*\$\$\s*\nDELIMITER ;\s*\n',
        
        # DELIMITER statements solos (que quedaron huérfanos)
        r'DELIMITER \$\$\s*\n\$\$\s*\nDELIMITER ;\s*\n',
        
        # CREATE TRIGGER sin DELIMITER (por si acaso)
        r'CREATE TRIGGER.*?END\s*;\s*\n',
        
        # VIEWs con DEFINER (problema de hosting compartido)
        r'CREATE\s+(?:ALGORITHM=\w+\s+)?DEFINER=`[^`]+`@`[^`]+`\s+(?:SQL\s+SECURITY\s+\w+\s+)?VIEW.*?;',
        
        # DROP VIEW statements
        r'DROP VIEW IF EXISTS.*?;\s*\n',
        
        # Líneas vacías múltiples que quedaron
        r'\n\s*\n\s*\n',
    ]
    
    # Aplicar cada patrón
    for pattern in patterns_to_remove:
        content = re.sub(pattern, '\n', content, flags=re.DOTALL | re.IGNORECASE)
    
    # Limpiar líneas vacías múltiples al final
    content = re.sub(r'\n{3,}', '\n\n', content)
    
    # Verificar que se eliminaron todos los TRIGGERS y VIEWs
    remaining_triggers = len(re.findall(r'CREATE TRIGGER', content, re.IGNORECASE))
    remaining_views = len(re.findall(r'CREATE.*VIEW.*DEFINER', content, re.IGNORECASE))
    
    issues = []
    if remaining_triggers > 0:
        issues.append(f"{remaining_triggers} TRIGGERS")
    if remaining_views > 0:
        issues.append(f"{remaining_views} VIEWs con DEFINER")
    
    if issues:
        print(f"⚠️  Advertencia: Aún quedan {', '.join(issues)}")
        
        # Mostrar elementos restantes para debug
        if remaining_triggers > 0:
            triggers = re.findall(r'CREATE TRIGGER.*?(?=CREATE|--|\Z)', content, re.DOTALL | re.IGNORECASE)
            for i, trigger in enumerate(triggers[:2]):
                print(f"🔍 TRIGGER restante {i+1}:")
                print(trigger[:200] + "..." if len(trigger) > 200 else trigger)
        
        if remaining_views > 0:
            views = re.findall(r'CREATE.*VIEW.*DEFINER.*?;', content, re.DOTALL | re.IGNORECASE)
            for i, view in enumerate(views[:2]):
                print(f"👁️  VIEW restante {i+1}:")
                print(view[:200] + "..." if len(view) > 200 else view)
    
    try:
        # Crear directorio de salida si no existe
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(content)
            
        print(f"✅ Archivo procesado exitosamente")
        print(f"📁 Archivo original: {input_file}")
        print(f"📁 Archivo sin TRIGGERS/VIEWs: {output_file}")
        print(f"🗑️  TRIGGERS eliminados: {original_triggers - remaining_triggers}")
        print(f"👁️  VIEWs eliminadas: {original_views - remaining_views}")
        
        if remaining_triggers == 0 and remaining_views == 0:
            print("🎉 ¡Todos los TRIGGERS y VIEWs problemáticas fueron eliminados!")
        
        return remaining_triggers == 0 and remaining_views == 0
        
    except Exception as e:
        print(f"❌ Error al escribir el archivo: {e}")
        return False

def main():
    # Rutas de archivos
    base_dir = "/opt/lampp/htdocs"
    input_file = f"{base_dir}/backups/database/if0_39552758_obelisia_db.sql"
    output_file = f"{base_dir}/backups/database/if0_39552758_obelisia_db_production.sql"
    
    success = remove_triggers_from_sql(input_file, output_file)
    
    if success:
        print("\n🚀 ¡Listo para producción!")
        print(f"📤 Sube el archivo: {output_file}")
        print("\n⚠️  IMPORTANTE:")
        print("   - Los TRIGGERS fueron reemplazados con lógica en PHP")
        print("   - Las VIEWs problemáticas fueron eliminadas")
        print("   - Las estadísticas se actualizarán automáticamente")
        print("   - Usa consultas directas en lugar de VIEWs")
        print("   - Ejecuta 'php tools/sync_project_stats.php' una sola vez después de importar")
    else:
        print("\n❌ Hubo problemas al procesar el archivo")
        print("   Revisa manualmente el archivo de salida")
        
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())
