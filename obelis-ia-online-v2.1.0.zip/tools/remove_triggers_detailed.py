#!/usr/bin/env python3
"""
Script para eliminar TRIGGERS y VIEWs de archivo SQL de MySQL
Muestra detalladamente qué elimina para replicar la funcionalidad en código
"""

import re
import sys
import os

def remove_triggers_and_views_from_sql(input_file, output_file):
    """Elimina todos los TRIGGERS y VIEWs del archivo SQL mostrando qué se elimina"""
    
    print("🔧 Procesando archivo SQL para eliminar TRIGGERS y VIEWs...")
    
    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            content = f.read()
    except FileNotFoundError:
        print(f"❌ Error: No se encontró el archivo {input_file}")
        return False
    except Exception as e:
        print(f"❌ Error al leer el archivo: {e}")
        return False
    
    print("\n" + "="*80)
    print("📋 ANÁLISIS DETALLADO DE ELEMENTOS A ELIMINAR")
    print("="*80)
    
    # 1. ENCONTRAR Y MOSTRAR TRIGGERS
    print("\n🎯 1. ANALIZANDO TRIGGERS...")
    trigger_pattern = r'CREATE TRIGGER\s+`?([^`\s]+)`?\s+([^`\s]+)\s+([^`\s]+)\s+ON\s+`?([^`\s]+)`?\s+FOR EACH ROW\s+BEGIN(.*?)END'
    triggers = re.findall(trigger_pattern, content, re.DOTALL | re.IGNORECASE)
    
    if triggers:
        print(f"📊 TRIGGERS encontrados: {len(triggers)}")
        print("\n🗑️  TRIGGERS que se eliminarán (debes replicar en PHP):")
        
        for i, (name, timing, event, table, body) in enumerate(triggers, 1):
            print(f"\n   {i}. 📌 TRIGGER: {name}")
            print(f"      📅 Momento: {timing.upper()} {event.upper()}")
            print(f"      📋 Tabla: {table}")
            print(f"      🔧 Lógica a replicar en PHP:")
            
            # Limpiar y mostrar el cuerpo del trigger
            clean_body = re.sub(r'\s+', ' ', body.strip())
            clean_body = clean_body.replace('NEW.', '$nuevo_registro[\'').replace('OLD.', '$registro_anterior[\'')
            clean_body = re.sub(r'(\w+);', r'\1\'];', clean_body)
            
            if len(clean_body) > 200:
                print(f"         {clean_body[:200]}...")
            else:
                print(f"         {clean_body}")
            
            print(f"      ⚡ Implementar en: api/{table.replace('project_', 'studio/')}.php")
    else:
        print("✅ No se encontraron TRIGGERS")
    
    # 2. ENCONTRAR Y MOSTRAR VIEWS
    print(f"\n🎯 2. ANALIZANDO VIEWS...")
    view_pattern = r'CREATE\s+(?:ALGORITHM=\w+\s+)?(?:DEFINER=`[^`]+`@`[^`]+`\s+)?(?:SQL\s+SECURITY\s+\w+\s+)?VIEW\s+`?([^`\s]+)`?\s+AS\s+(SELECT.*?)(?=;|\n--|\nCREATE|\Z)'
    views = re.findall(view_pattern, content, re.DOTALL | re.IGNORECASE)
    
    if views:
        print(f"📊 VIEWs encontradas: {len(views)}")
        print("\n🗑️  VIEWs que se eliminarán (usar consulta directa en PHP):")
        
        for i, (name, query) in enumerate(views, 1):
            print(f"\n   {i}. 👁️  VIEW: {name}")
            print(f"      📝 Consulta SQL a usar directamente:")
            
            # Limpiar y formatear la consulta
            clean_query = re.sub(r'\s+', ' ', query.strip())
            lines = clean_query.split()
            formatted_lines = []
            current_line = ""
            
            for word in lines:
                if len(current_line + word) > 60:
                    formatted_lines.append(current_line.strip())
                    current_line = "         " + word + " "
                else:
                    current_line += word + " "
            
            if current_line.strip():
                formatted_lines.append(current_line.strip())
            
            print("         " + "\n".join(formatted_lines))
            print(f"      📂 Implementar en: helpers/{name}_query.php")
    else:
        print("✅ No se encontraron VIEWs problemáticas")
    
    print("\n" + "="*80)
    print("🗑️  INICIANDO ELIMINACIÓN...")
    print("="*80)
    
    # Patrones para eliminar TRIGGERS, VIEWs y elementos relacionados
    patterns_to_remove = [
        # VIEWs completas (incluyendo DEFINER problemático)
        (r'CREATE\s+(?:ALGORITHM=\w+\s+)?(?:DEFINER=`[^`]+`@`[^`]+`\s+)?(?:SQL\s+SECURITY\s+\w+\s+)?VIEW.*?;', "VIEWs"),
        
        # DROP VIEW statements
        (r'DROP VIEW IF EXISTS.*?;\s*\n', "DROP VIEW statements"),
        
        # Comentarios de disparadores
        (r'--\s*Disparadores.*?--.*?\n', "Comentarios de disparadores"),
        
        # DROP TRIGGER statements
        (r'DROP TRIGGER IF EXISTS.*?;\s*\n', "DROP TRIGGER statements"),
        
        # Bloques completos de TRIGGERS (incluyendo DELIMITER)
        (r'DELIMITER \$\$\s*\n.*?CREATE TRIGGER.*?END\s*\$\$\s*\nDELIMITER ;\s*\n', "Bloques de TRIGGERS"),
        
        # DELIMITER statements solos (que quedaron huérfanos)
        (r'DELIMITER \$\$\s*\n\$\$\s*\nDELIMITER ;\s*\n', "DELIMITER huérfanos"),
        
        # CREATE TRIGGER sin DELIMITER (por si acaso)
        (r'CREATE TRIGGER.*?END\s*;\s*\n', "TRIGGERS sin DELIMITER"),
    ]
    
    # Aplicar cada patrón y contar eliminaciones
    total_removals = 0
    for pattern, description in patterns_to_remove:
        matches = len(re.findall(pattern, content, re.DOTALL | re.IGNORECASE))
        if matches > 0:
            print(f"🗑️  Eliminando {matches} {description}")
            total_removals += matches
        content = re.sub(pattern, '\n', content, flags=re.DOTALL | re.IGNORECASE)
    
    # Limpiar líneas vacías múltiples
    content = re.sub(r'\n{3,}', '\n\n', content)
    
    # Verificar que se eliminaron todos los elementos problemáticos
    remaining_triggers = len(re.findall(r'CREATE TRIGGER', content, re.IGNORECASE))
    remaining_views = len(re.findall(r'CREATE.*?VIEW.*?DEFINER', content, re.IGNORECASE))
    
    try:
        # Crear directorio de salida si no existe
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(content)
            
        print(f"\n✅ Archivo procesado exitosamente")
        print(f"📁 Archivo original: {input_file}")
        print(f"📁 Archivo limpio: {output_file}")
        print(f"🗑️  Total de eliminaciones: {total_removals}")
        print(f"⚠️  TRIGGERS restantes: {remaining_triggers}")
        print(f"⚠️  VIEWs restantes: {remaining_views}")
        
        if remaining_triggers == 0 and remaining_views == 0:
            print("\n🎉 ¡Archivo completamente limpio para producción!")
        
        return remaining_triggers == 0 and remaining_views == 0
        
    except Exception as e:
        print(f"❌ Error al escribir el archivo: {e}")
        return False

def main():
    # Rutas de archivos
    base_dir = "/opt/lampp/htdocs"
    input_file = f"{base_dir}/backups/database/if0_39552758_obelisia_db.sql"
    output_file = f"{base_dir}/backups/database/if0_39552758_obelisia_db_production_v2.sql"
    
    success = remove_triggers_and_views_from_sql(input_file, output_file)
    
    print("\n" + "="*80)
    print("📋 INSTRUCCIONES PARA REPLICAR FUNCIONALIDAD")
    print("="*80)
    
    if success:
        print("\n🚀 ¡Archivo listo para producción!")
        print(f"📤 Sube el archivo: {output_file}")
        print("\n📝 PASOS SIGUIENTES:")
        print("   1. ✅ Verificar que todas las APIs de TRIGGERS están implementadas")
        print("   2. ✅ Crear consultas PHP para reemplazar VIEWs eliminadas")
        print("   3. ✅ Ejecutar sincronización: php tools/sync_project_stats.php")
        print("   4. ✅ Probar todas las funcionalidades afectadas")
    else:
        print("\n❌ Revisa los elementos restantes y elimínalos manualmente")
        
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())
