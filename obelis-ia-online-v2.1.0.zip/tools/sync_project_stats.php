<?php
/**
 * Script de mantenimiento: Sincronizar estadísticas de proyectos
 * Este script recalcula y actualiza las estadísticas en project_stats_cache
 * Útil después de migrar de TRIGGERS a lógica manual
 */

require_once __DIR__ . '/../helpers/db.php';

echo "🔧 Iniciando sincronización de estadísticas de proyectos...\n";

try {
    $pdo->beginTransaction();
    
    // Obtener todos los proyectos
    $stmt = $pdo->prepare("SELECT id, title FROM obelis_studio_projects ORDER BY id");
    $stmt->execute();
    $projects = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $updated_count = 0;
    
    foreach ($projects as $project) {
        $project_id = $project['id'];
        
        // Contar likes
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM project_likes WHERE project_id = ?");
        $stmt->execute([$project_id]);
        $likes_count = $stmt->fetchColumn();
        
        // Contar comentarios
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM project_comments WHERE project_id = ?");
        $stmt->execute([$project_id]);
        $comments_count = $stmt->fetchColumn();
        
        // Contar favoritos
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM project_favorites WHERE project_id = ?");
        $stmt->execute([$project_id]);
        $favorites_count = $stmt->fetchColumn();
        
        // Contar vistas (si existe la tabla project_views)
        $views_count = 0;
        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM project_views WHERE project_id = ?");
            $stmt->execute([$project_id]);
            $views_count = $stmt->fetchColumn();
        } catch (PDOException $e) {
            // La tabla project_views no existe o hay error, usar 0
            $views_count = 0;
        }
        
        // Actualizar o insertar estadísticas
        $stmt = $pdo->prepare("
            INSERT INTO project_stats_cache 
            (project_id, views_count, likes_count, comments_count, favorites_count, last_updated)
            VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON DUPLICATE KEY UPDATE
            views_count = VALUES(views_count),
            likes_count = VALUES(likes_count),
            comments_count = VALUES(comments_count),
            favorites_count = VALUES(favorites_count),
            last_updated = CURRENT_TIMESTAMP
        ");
        
        $stmt->execute([$project_id, $views_count, $likes_count, $comments_count, $favorites_count]);
        
        $updated_count++;
        echo "✅ Proyecto #{$project_id}: {$project['title']} - Likes: {$likes_count}, Comentarios: {$comments_count}, Favoritos: {$favorites_count}, Vistas: {$views_count}\n";
    }
    
    $pdo->commit();
    
    echo "\n🎉 ¡Sincronización completada exitosamente!\n";
    echo "📊 Total de proyectos actualizados: {$updated_count}\n";
    echo "\n💡 Las estadísticas ahora están sincronizadas y la aplicación funcionará correctamente sin TRIGGERS.\n";
    
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    echo "❌ Error durante la sincronización: " . $e->getMessage() . "\n";
    exit(1);
}
?>
