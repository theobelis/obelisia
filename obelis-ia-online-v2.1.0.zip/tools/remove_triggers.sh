#!/bin/bash

# Script para eliminar TRIGGERS del archivo SQL de base de datos
# Este script crea una versión del archivo SQL sin los TRIGGERS que causan problemas en hosting compartido

INPUT_FILE="/opt/lampp/htdocs/backups/database/if0_39552758_obelisia_db.sql"
OUTPUT_FILE="/opt/lampp/htdocs/backups/database/if0_39552758_obelisia_db_sin_triggers.sql"

echo "🔧 Procesando archivo SQL para eliminar TRIGGERS..."

# Crear copia del archivo original y eliminar secciones de TRIGGERS
sed '
/^DELIMITER \$\$/,/^DELIMITER ;$/{
    /CREATE TRIGGER/,/^END$/d
}
/^-- Disparadores/,/^-- /{
    /^-- Disparadores/d
    /^$/d
}
/^DROP TRIGGER IF EXISTS/d
' "$INPUT_FILE" > "$OUTPUT_FILE"

echo "✅ Archivo procesado exitosamente"
echo "📁 Archivo original: $INPUT_FILE"
echo "📁 Archivo sin TRIGGERS: $OUTPUT_FILE"
echo ""
echo "🚀 Ahora puedes subir el archivo '$OUTPUT_FILE' a tu hosting sin errores de TRIGGERS"
echo ""
echo "⚠️  IMPORTANTE: Los TRIGGERS fueron reemplazados con lógica en el código PHP"
echo "   Las estadísticas se actualizarán automáticamente a través de la aplicación"
