<?php
require_once 'config/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once '../src/Database/Database.php';

use ObelisIA\Database\Database;

start_admin_session();

// Verificar autenticación de admin
if (!isAdminAuthenticated()) {
    header('Location: auth/login.php');
    exit;
}

$page_title = 'Panel de Administración Dinámico - ObelisIA';
$current_page = 'dashboard';

// Obtener estadísticas del dashboard
$stats = getDashboardStats();

// Inicializar base de datos para obtener tablas
try {
    $database = new Database();
    $conn = $database->getConnection();
    
    // Obtener lista de tablas
    $query = "SHOW TABLES";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Filtrar tablas que no queremos mostrar en el admin
    $excludedTables = ['migrations', 'sessions', 'cache', 'jobs', 'failed_jobs'];
    $adminTables = array_filter($tables, function($table) use ($excludedTables) {
        return !in_array($table, $excludedTables);
    });
    
} catch (Exception $e) {
    error_log("Error obteniendo tablas: " . $e->getMessage());
    $adminTables = [];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    
    <!-- CSS del proyecto existente -->
    <link rel="stylesheet" href="<?php echo admin_url('assets/css/admin.css'); ?>">
    <link rel="stylesheet" href="<?php echo admin_url('assets/css/dashboard.css'); ?>">
    <link rel="stylesheet" href="<?php echo admin_url('assets/css/dynamic-tables.css'); ?>">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <!-- CSS para animaciones y efectos adicionales -->
    <style>
        @keyframes slideInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .admin-layout {
            display: flex;
            min-height: 100vh;
            padding-top: var(--header-height);
        }
        
        .table-nav-link {
            display: flex;
            align-items: center;
            padding: 0.75rem 1rem;
            color: var(--muted-text);
            text-decoration: none;
            border-radius: 6px;
            margin-bottom: 0.25rem;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }
        
        .table-nav-link:hover {
            background: var(--dark-card);
            color: var(--light-text);
            text-decoration: none;
        }
        
        .table-nav-link.active {
            background: rgba(99, 102, 241, 0.1);
            color: var(--primary-color);
            border-left-color: var(--primary-color);
        }
        
        .table-nav-link i {
            margin-right: 0.75rem;
            width: 16px;
            text-align: center;
        }
        
        .loading-spinner {
            display: none;
            text-align: center;
            padding: 3rem;
            background: rgba(30, 41, 59, 0.95);
            border-radius: 1rem;
            backdrop-filter: blur(10px);
        }
        
        .spinner-border {
            width: 3rem;
            height: 3rem;
            color: var(--primary-color);
        }
        
        .table-section-title {
            color: var(--secondary-color);
            font-weight: 600;
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 1rem;
            margin-top: 1.5rem;
            position: relative;
            padding-left: 1rem;
        }
        
        .table-section-title:first-child {
            margin-top: 0;
        }
        
        .table-section-title::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 3px;
            height: 1rem;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            border-radius: 2px;
        }
        
        /* Efectos de carga en botones */
        .btn .fa-spinner {
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* Bootstrap overrides para modo oscuro */
        .alert {
            border: none;
            border-radius: 0.75rem;
            padding: 1.5rem;
        }
        
        .btn {
            border-radius: 0.75rem;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .form-control {
            border-radius: 0.5rem;
            border: 1px solid var(--border-color);
            background: var(--dark-card);
            color: var(--light-text);
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(99, 102, 234, 0.25);
            background: var(--dark-card);
            color: var(--light-text);
        }
        
        .table {
            color: var(--light-text);
        }
        
        .table-responsive {
            border-radius: 0.75rem;
            overflow: hidden;
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="admin-layout">
        <!-- Sidebar Dinámico -->
        <aside class="admin-sidebar" id="adminSidebar">
            <nav class="sidebar-nav">
                <!-- Dashboard Principal -->
                <div class="nav-section">
                    <h3>Principal</h3>
                    <ul style="list-style: none; padding: 0;">
                        <li>
                            <a href="#dashboard" class="table-nav-link active" id="dashboard-link" data-table="dashboard" data-tooltip="Dashboard">
                                <i class="fas fa-tachometer-alt"></i>
                                <span>Dashboard</span>
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- Tablas de Base de Datos -->
                <?php if (!empty($adminTables)): ?>
                <div class="nav-section">
                    <h3>Gestión de Datos</h3>
                    <ul style="list-style: none; padding: 0;">
                        <?php 
                        // Agrupar tablas por categoría
                        $tableGroups = [
                            'Usuarios' => ['users', 'user_profiles', 'user_activity', 'user_sessions'],
                            'Contenido' => ['blog_posts', 'content_creations', 'projects', 'comments', 'reports'],
                            'Finanzas' => ['payments', 'credits', 'subscriptions', 'transactions'],
                            'Sistema' => ['settings', 'logs', 'api_keys', 'notifications'],
                            'Social' => ['social_posts', 'social_likes', 'social_follows', 'social_comments']
                        ];
                        
                        $categorizedTables = [];
                        $uncategorizedTables = [];
                        
                        foreach ($adminTables as $table) {
                            $categorized = false;
                            foreach ($tableGroups as $category => $patterns) {
                                foreach ($patterns as $pattern) {
                                    if (strpos($table, $pattern) !== false || $table === $pattern) {
                                        $categorizedTables[$category][] = $table;
                                        $categorized = true;
                                        break 2;
                                    }
                                }
                            }
                            if (!$categorized) {
                                $uncategorizedTables[] = $table;
                            }
                        }
                        
                        // Mostrar tablas categorizadas
                        foreach ($categorizedTables as $category => $tables): ?>
                            <li class="table-section-title"><?php echo $category; ?></li>
                            <?php foreach ($tables as $table): ?>
                                <li>
                                    <a href="#<?php echo $table; ?>" class="table-nav-link" data-table="<?php echo $table; ?>" data-tooltip="<?php echo formatTableName($table); ?>">
                                        <i class="fas <?php echo getTableIcon($table); ?>"></i>
                                        <span><?php echo formatTableName($table); ?></span>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                        
                        <!-- Mostrar tablas no categorizadas -->
                        <?php if (!empty($uncategorizedTables)): ?>
                            <li class="table-section-title">Otras Tablas</li>
                            <?php foreach ($uncategorizedTables as $table): ?>
                                <li>
                                    <a href="#<?php echo $table; ?>" class="table-nav-link" data-table="<?php echo $table; ?>" data-tooltip="<?php echo formatTableName($table); ?>">
                                        <i class="fas fa-table"></i>
                                        <span><?php echo formatTableName($table); ?></span>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </ul>
                </div>
                <?php endif; ?>
            </nav>
        </aside>
        
        <!-- Contenido Principal Dinámico -->
        <main class="admin-content">
            <!-- Área de contenido que se carga dinámicamente -->
            <div id="dynamic-content">
                <!-- Dashboard por defecto -->
                <div class="dashboard-header">
                    <h1><i class="fas fa-tachometer-alt"></i> Panel de Control Dinámico</h1>
                    <p>Administra tu base de datos de forma intuitiva y eficiente</p>
                </div>

                <!-- Tarjetas de estadísticas -->
                <div class="stats-grid">
                    <div class="stat-card users">
                        <div class="stat-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo number_format($stats['total_users'] ?? 0); ?></h3>
                            <p>Usuarios Totales</p>
                            <span class="stat-change positive">+<?php echo $stats['new_users_today'] ?? 0; ?> hoy</span>
                        </div>
                    </div>

                    <div class="stat-card creations">
                        <div class="stat-icon">
                            <i class="fas fa-magic"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo number_format($stats['total_creations'] ?? 0); ?></h3>
                            <p>Creaciones Totales</p>
                            <span class="stat-change positive">+<?php echo $stats['new_creations_today'] ?? 0; ?> hoy</span>
                        </div>
                    </div>

                    <div class="stat-card revenue">
                        <div class="stat-icon">
                            <i class="fas fa-dollar-sign"></i>
                        </div>
                        <div class="stat-content">
                            <h3>$<?php echo number_format($stats['total_revenue'] ?? 0, 2); ?></h3>
                            <p>Ingresos Totales</p>
                            <span class="stat-change positive">+$<?php echo number_format($stats['revenue_today'] ?? 0, 2); ?> hoy</span>
                        </div>
                    </div>

                    <div class="stat-card activity">
                        <div class="stat-icon">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo number_format($stats['activity_today'] ?? 0); ?></h3>
                            <p>Actividad Hoy</p>
                            <span class="stat-change">Acciones realizadas</span>
                        </div>
                    </div>
                </div>

                <!-- Información adicional sobre el sistema dinámico -->
                <div style="background: var(--dark-surface); border: 1px solid var(--border-color); border-radius: 1rem; padding: 2rem; box-shadow: var(--shadow-md); margin-top: 1rem;">
                    <div style="background: linear-gradient(135deg, rgba(99, 102, 241, 0.1) 0%, rgba(139, 92, 246, 0.1) 100%); border: 1px solid rgba(99, 102, 241, 0.2); border-radius: 0.75rem; padding: 1.5rem; margin-bottom: 2rem;">
                        <h4 style="color: var(--primary-color); margin-bottom: 1rem;"><i class="fas fa-info-circle"></i> Panel de Administración Dinámico</h4>
                        <p style="color: var(--light-text); margin-bottom: 0;">
                            Selecciona cualquier tabla de la barra lateral para ver y gestionar sus datos. 
                            El sistema carga automáticamente todas las tablas de tu base de datos y te permite 
                            visualizar, editar y eliminar registros de forma intuitiva.
                        </p>
                    </div>
                    
                    <div class="row mt-4">
                        <div class="col-md-6">
                            <h5 style="color: var(--light-text); margin-bottom: 1rem;"><i class="fas fa-database" style="color: var(--primary-color);"></i> Tablas Disponibles</h5>
                            <p style="color: var(--muted-text);">Se han detectado <strong style="color: var(--primary-color);"><?php echo count($adminTables); ?> tablas</strong> en tu base de datos.</p>
                        </div>
                        <div class="col-md-6">
                            <h5 style="color: var(--light-text); margin-bottom: 1rem;"><i class="fas fa-cogs" style="color: var(--secondary-color);"></i> Funcionalidades</h5>
                            <ul style="color: var(--muted-text); margin-bottom: 0;">
                                <li>Vista de datos en tiempo real</li>
                                <li>Edición inline de registros</li>
                                <li>Eliminación segura con confirmación</li>
                                <li>Búsqueda y filtrado</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Loading spinner -->
            <div id="loading-spinner" class="loading-spinner">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Cargando...</span>
                </div>
                <p class="mt-2">Cargando datos...</p>
            </div>
        </main>
    </div>

    <!-- JavaScript para funcionalidad dinámica -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="<?php echo admin_url('assets/js/ui.js'); ?>"></script>
    
    <script>
        // Variables globales
        let currentTable = null;
        
        // Función para cargar dashboard
        function loadDashboard() {
            // Remover clase active de todos los links
            document.querySelectorAll('.table-nav-link').forEach(link => {
                link.classList.remove('active');
            });
            
            // Agregar clase active al dashboard
            document.getElementById('dashboard-link').classList.add('active');
            
            // Mostrar spinner
            document.getElementById('loading-spinner').style.display = 'block';
            document.getElementById('dynamic-content').style.display = 'none';
            
            // Cargar contenido del dashboard
            fetch('api/dashboard.php', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.text();
            })
            .then(html => {
                // Ocultar spinner
                document.getElementById('loading-spinner').style.display = 'none';
                
                // Cargar contenido
                document.getElementById('dynamic-content').innerHTML = html;
                document.getElementById('dynamic-content').style.display = 'block';
                
                // Actualizar URL
                window.history.pushState({table: 'dashboard'}, '', '#dashboard');
            })
            .catch(error => {
                console.error('Error cargando dashboard:', error);
                
                // Ocultar spinner
                document.getElementById('loading-spinner').style.display = 'none';
                
                // Mostrar error
                document.getElementById('dynamic-content').innerHTML = `
                    <div class="alert alert-danger">
                        <h4>Error al cargar el dashboard</h4>
                        <p>No se pudo cargar el contenido del dashboard. Error: ${error.message}</p>
                        <button onclick="loadDashboard()" class="btn btn-primary">Reintentar</button>
                    </div>
                `;
                document.getElementById('dynamic-content').style.display = 'block';
            });
        }
        
        // Función para cargar una tabla específica
        function loadTable(tableName, page = 1, search = '') {
            if (currentTable === tableName && page === 1 && search === '') return; // No recargar si es la misma configuración
            
            currentTable = tableName;
            
            // Mostrar spinner
            document.getElementById('loading-spinner').style.display = 'block';
            document.getElementById('dynamic-content').style.display = 'none';
            
            // Remover clase active de todos los links
            document.querySelectorAll('.table-nav-link').forEach(link => {
                link.classList.remove('active');
            });
            
            // Agregar clase active al link seleccionado
            const targetLink = document.querySelector(`[data-table="${tableName}"]`);
            if (targetLink) {
                targetLink.classList.add('active');
            }
            
            // Construir URL con parámetros
            let url = `api/tables.php?table=${encodeURIComponent(tableName)}`;
            if (page > 1) url += `&page=${page}`;
            if (search) url += `&search=${encodeURIComponent(search)}`;
            
            // Realizar petición AJAX
            fetch(url, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.text();
            })
            .then(html => {
                // Ocultar spinner
                document.getElementById('loading-spinner').style.display = 'none';
                
                // Cargar contenido
                document.getElementById('dynamic-content').innerHTML = html;
                document.getElementById('dynamic-content').style.display = 'block';
                
                // Actualizar URL
                updateURL(tableName);
                
                // Reinicializar tooltips y otros componentes de Bootstrap si es necesario
                initializeTableFeatures();
            })
            .catch(error => {
                console.error('Error cargando tabla:', error);
                
                // Ocultar spinner
                document.getElementById('loading-spinner').style.display = 'none';
                
                // Mostrar error
                document.getElementById('dynamic-content').innerHTML = `
                    <div class="alert alert-danger">
                        <h4><i class="fas fa-exclamation-triangle"></i> Error</h4>
                        <p>No se pudo cargar la tabla "${tableName}". Error: ${error.message}</p>
                        <button class="btn btn-outline-secondary" onclick="loadDashboard()">
                            <i class="fas fa-home"></i> Volver al Dashboard
                        </button>
                    </div>
                `;
                document.getElementById('dynamic-content').style.display = 'block';
            });
        }
        
        // Función para inicializar características de la tabla cargada
        function initializeTableFeatures() {
            // Inicializar tooltips de Bootstrap
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
            
            // Funcionalidad de búsqueda en tiempo real
            const searchInput = document.getElementById('table-search');
            if (searchInput) {
                searchInput.addEventListener('input', function() {
                    const searchTerm = this.value.toLowerCase();
                    const tableRows = document.querySelectorAll('#data-table tbody tr');
                    
                    tableRows.forEach(row => {
                        const rowText = row.textContent.toLowerCase();
                        row.style.display = rowText.includes(searchTerm) ? '' : 'none';
                    });
                });
            }
        }
        
        // Función global para eliminar registro
        function deleteRecord(table, id) {
            if (!confirm('¿Estás seguro de que quieres eliminar este registro? Esta acción no se puede deshacer.')) {
                return;
            }
            
            fetch(`api/tables.php?action=delete&table=${encodeURIComponent(table)}&id=${encodeURIComponent(id)}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Recargar la tabla
                    loadTable(table);
                    
                    // Mostrar mensaje de éxito
                    showAlert('success', 'Registro eliminado correctamente');
                } else {
                    showAlert('danger', data.message || 'Error al eliminar el registro');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert('danger', 'Error de conexión al eliminar el registro');
            });
        }
        
        // Función para cargar formulario de edición
        function loadEditForm(table, id) {
            // Mostrar spinner
            document.getElementById('loading-spinner').style.display = 'block';
            document.getElementById('dynamic-content').style.display = 'none';
            
            // Construir URL
            const url = `api/edit.php?table=${encodeURIComponent(table)}&id=${encodeURIComponent(id)}&mode=edit`;
            
            // Realizar petición AJAX
            fetch(url, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.text();
            })
            .then(html => {
                // Ocultar spinner
                document.getElementById('loading-spinner').style.display = 'none';
                
                // Cargar contenido del formulario
                document.getElementById('dynamic-content').innerHTML = html;
                document.getElementById('dynamic-content').style.display = 'block';
            })
            .catch(error => {
                console.error('Error cargando formulario de edición:', error);
                
                // Ocultar spinner
                document.getElementById('loading-spinner').style.display = 'none';
                
                // Mostrar error
                document.getElementById('dynamic-content').innerHTML = `
                    <div class="alert alert-danger">
                        <h4><i class="fas fa-exclamation-triangle"></i> Error</h4>
                        <p>No se pudo cargar el formulario de edición. Error: ${error.message}</p>
                        <button class="btn btn-outline-secondary" onclick="loadTable('${table}')">
                            <i class="fas fa-arrow-left"></i> Volver a la tabla
                        </button>
                    </div>
                `;
                document.getElementById('dynamic-content').style.display = 'block';
            });
        }
        
        // Función para cargar formulario de agregar registro
        function loadAddForm(table) {
            // Mostrar spinner
            document.getElementById('loading-spinner').style.display = 'block';
            document.getElementById('dynamic-content').style.display = 'none';
            
            // Construir URL
            const url = `api/edit.php?table=${encodeURIComponent(table)}&mode=add`;
            
            // Realizar petición AJAX
            fetch(url, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.text();
            })
            .then(html => {
                // Ocultar spinner
                document.getElementById('loading-spinner').style.display = 'none';
                
                // Cargar contenido del formulario
                document.getElementById('dynamic-content').innerHTML = html;
                document.getElementById('dynamic-content').style.display = 'block';
            })
            .catch(error => {
                console.error('Error cargando formulario de agregar:', error);
                
                // Ocultar spinner
                document.getElementById('loading-spinner').style.display = 'none';
                
                // Mostrar error
                document.getElementById('dynamic-content').innerHTML = `
                    <div class="alert alert-danger">
                        <h4><i class="fas fa-exclamation-triangle"></i> Error</h4>
                        <p>No se pudo cargar el formulario para agregar registro. Error: ${error.message}</p>
                        <button class="btn btn-outline-secondary" onclick="loadTable('${table}')">
                            <i class="fas fa-arrow-left"></i> Volver a la tabla
                        </button>
                    </div>
                `;
                document.getElementById('dynamic-content').style.display = 'block';
            });
        }
        
        // Función para mostrar alertas
        function showAlert(type, message) {
            const alertContainer = document.getElementById('alert-container') || createAlertContainer();
            
            const alert = document.createElement('div');
            alert.className = `alert alert-${type} alert-dismissible fade show`;
            alert.innerHTML = `
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            
            alertContainer.appendChild(alert);
            
            // Auto remover después de 5 segundos
            setTimeout(() => {
                if (alert.parentNode) {
                    alert.remove();
                }
            }, 5000);
        }
        
        // Función para crear contenedor de alertas si no existe
        function createAlertContainer() {
            const container = document.createElement('div');
            container.id = 'alert-container';
            container.style.position = 'fixed';
            container.style.top = '20px';
            container.style.right = '20px';
            container.style.zIndex = '9999';
            container.style.maxWidth = '400px';
            
            document.body.appendChild(container);
            return container;
        }
        
        // Funciones globales para botones de acción en tablas
        function editRecord(table, id) {
            loadEditForm(table, id);
        }
        
        function addRecord(table) {
            loadAddForm(table);
        }
        
        // Función global para eliminar registro (ya definida más arriba)
        // function deleteRecord está definida más arriba en la línea 582
        
        // Inicializar al cargar la página
        document.addEventListener('DOMContentLoaded', function() {
            // Agregar event listeners a los enlaces de tabla
            document.querySelectorAll('.table-nav-link').forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault(); // Prevenir comportamiento por defecto
                    const tableName = this.getAttribute('data-table');
                    if (tableName) {
                        if (tableName === 'dashboard') {
                            loadDashboard();
                        } else {
                            loadTable(tableName);
                        }
                    }
                });
            });
            
            // Si hay un hash en la URL, cargar esa tabla
            const hash = window.location.hash.substring(1);
            if (hash && hash !== 'dashboard' && hash !== '') {
                loadTable(hash);
            } else {
                loadDashboard();
            }
        });
        
        // Actualizar URL cuando se cambie de tabla
        function updateURL(table) {
            window.history.pushState({table: table}, '', `#${table}`);
        }
        
        // Manejar navegación con botones atrás/adelante
        window.addEventListener('popstate', function(event) {
            if (event.state && event.state.table) {
                loadTable(event.state.table);
            } else {
                loadDashboard();
            }
        });
    </script>
</body>
</html>

<?php
// Funciones auxiliares para el sidebar dinámico
function getTableIcon($tableName) {
    $icons = [
        'users' => 'fa-users',
        'user_profiles' => 'fa-id-card',
        'user_activity' => 'fa-history',
        'user_sessions' => 'fa-sign-in-alt',
        'blog_posts' => 'fa-blog',
        'content_creations' => 'fa-palette',
        'projects' => 'fa-project-diagram',
        'comments' => 'fa-comments',
        'reports' => 'fa-flag',
        'payments' => 'fa-credit-card',
        'credits' => 'fa-coins',
        'subscriptions' => 'fa-crown',
        'transactions' => 'fa-exchange-alt',
        'settings' => 'fa-cogs',
        'logs' => 'fa-file-alt',
        'api_keys' => 'fa-key',
        'notifications' => 'fa-bell',
        'social_posts' => 'fa-share-alt',
        'social_likes' => 'fa-heart',
        'social_follows' => 'fa-user-plus',
        'social_comments' => 'fa-comment'
    ];
    
    foreach ($icons as $pattern => $icon) {
        if (strpos($tableName, $pattern) !== false || $tableName === $pattern) {
            return $icon;
        }
    }
    
    return 'fa-table'; // Icono por defecto
}

function formatTableName($tableName) {
    // Convertir snake_case a Título Formateado
    $formatted = str_replace('_', ' ', $tableName);
    $formatted = ucwords($formatted);
    
    // Reemplazos específicos para mejorar la legibilidad
    $replacements = [
        'Api Keys' => 'Claves API',
        'Blog Posts' => 'Artículos del Blog',
        'Content Creations' => 'Creaciones de Contenido',
        'User Profiles' => 'Perfiles de Usuario',
        'User Activity' => 'Actividad de Usuarios',
        'User Sessions' => 'Sesiones de Usuario',
        'Social Posts' => 'Publicaciones Sociales',
        'Social Likes' => 'Me Gusta',
        'Social Follows' => 'Seguidores',
        'Social Comments' => 'Comentarios Sociales'
    ];
    
    return $replacements[$formatted] ?? $formatted;
}
?>
