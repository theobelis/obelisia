<?php
// Redirigir al login real en auth/login.php
header('Location: auth/login.php');
exit;
?>
