<?php
require_once 'config/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

start_admin_session();

// Verificar autenticación de admin
if (!isAdminAuthenticated()) {
    header('Location: auth/login.php');
    exit;
}

require_once 'includes/functions.php';

start_admin_session();

// Verificar autenticación de admin
if (!isAdminAuthenticated()) {
    header('Location: auth/login.php');
    exit;
}

$page_title = 'Panel de Administración - ObelisIA';
$current_page = 'dashboard';

// Obtener estadísticas del dashboard
$stats = getDashboardStats();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="<?php echo admin_url('assets/css/admin.css'); ?>">
    <link rel="stylesheet" href="<?php echo admin_url('assets/css/dashboard.css'); ?>">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="admin-layout">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="admin-content">
            <div class="dashboard-header">
                <h1><i class="fas fa-tachometer-alt"></i> Panel de Control</h1>
                <p>Resumen general del sistema ObelisIA</p>
            </div>

            <!-- Tarjetas de estadísticas -->
            <div class="stats-grid">
                <div class="stat-card users">
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php echo number_format($stats['total_users']); ?></h3>
                        <p>Usuarios Totales</p>
                        <span class="stat-change positive">+<?php echo $stats['new_users_today']; ?> hoy</span>
                    </div>
                </div>

                <div class="stat-card creations">
                    <div class="stat-icon">
                        <i class="fas fa-magic"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php echo number_format($stats['total_creations']); ?></h3>
                        <p>Creaciones Totales</p>
                        <span class="stat-change positive">+<?php echo $stats['new_creations_today']; ?> hoy</span>
                    </div>
                </div>

                <div class="stat-card revenue">
                    <div class="stat-icon">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                    <div class="stat-content">
                        <h3>$<?php echo number_format($stats['total_revenue'], 2); ?></h3>
                        <p>Ingresos Totales</p>
                        <span class="stat-change positive">+$<?php echo number_format($stats['revenue_today'], 2); ?> hoy</span>
                    </div>
                </div>

                <div class="stat-card activity">
                    <div class="stat-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php echo number_format($stats['activity_today']); ?></h3>
                        <p>Actividad Hoy</p>
                        <span class="stat-change">Acciones realizadas</span>
                    </div>
                </div>
            </div>

            <!-- Gráficos y datos -->
            <div class="charts-grid">
                <div class="chart-container">
                    <h3><i class="fas fa-chart-area"></i> Usuarios Registrados (Últimos 7 días)</h3>
                    <canvas id="usersChart"></canvas>
                </div>

                <div class="chart-container">
                    <h3><i class="fas fa-chart-pie"></i> Distribución de Herramientas IA</h3>
                    <canvas id="toolsChart"></canvas>
                </div>
            </div>

            <!-- Tablas de actividad reciente -->
            <div class="recent-activity">
                <div class="activity-section">
                    <h3><i class="fas fa-clock"></i> Actividad Reciente</h3>
                    <div class="activity-list">
                        <?php foreach ($stats['recent_activity'] as $activity): ?>
                        <div class="activity-item">
                            <div class="activity-icon">
                                <i class="fas fa-<?php echo getActivityIcon($activity['action']); ?>"></i>
                            </div>
                            <div class="activity-content">
                                <p><?php echo safe_html($activity['description'], 'Sin descripción'); ?></p>
                                <small><?php echo timeAgo($activity['created_at']); ?></small>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="activity-section">
                    <h3><i class="fas fa-exclamation-triangle"></i> Reportes Pendientes</h3>
                    <div class="reports-list">
                        <?php foreach ($stats['pending_reports'] as $report): ?>
                        <div class="report-item priority-<?php echo $report['priority']; ?>">
                            <h4><?php echo htmlspecialchars($report['type']); ?></h4>
                            <p><?php echo htmlspecialchars($report['description']); ?></p>
                            <small><?php echo timeAgo($report['created_at']); ?></small>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="<?php echo admin_url('assets/js/admin.js'); ?>"></script>
    <script src="<?php echo admin_url('assets/js/dashboard.js'); ?>"></script>
</body>
</html>
