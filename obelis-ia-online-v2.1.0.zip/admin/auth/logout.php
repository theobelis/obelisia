<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth.php';

// Verificar autenticación
if (isAdminAuthenticated()) {
    logAdminActivity($_SESSION['admin_id'], 'logout', 'Cierre de sesión manual');
}

// Destruir sesión
destroyAdminSession();
session_destroy();

// Redirigir al login
header('Location: ../auth/login.php');
exit;
?>
