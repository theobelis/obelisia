<?php
// Cargar variables de entorno
require_once __DIR__ . '/../../vendor/autoload.php';

use Dotenv\Dotenv;

// Inicializar variables de entorno
$dotenv = Dotenv::createImmutable(__DIR__ . '/../../');
$dotenv->load();

// Configuración de sesión ANTES de cualquier session_start()
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.cookie_secure', 0); // Cambiar a 1 en HTTPS
    ini_set('session.use_strict_mode', 1);
    ini_set('session.gc_maxlifetime', 3600);
    ini_set('session.cookie_lifetime', 0);
}

// Configuración de la base de datos desde variables de entorno
define('DB_HOST', $_ENV['DB_HOST']);
define('DB_NAME', $_ENV['DB_NAME']);
define('DB_USER', $_ENV['DB_USER']);
define('DB_PASS', $_ENV['DB_PASS']);

// Configuración del admin
define('ADMIN_SESSION_TIMEOUT', 3600); // 1 hora en segundos
define('ADMIN_RECORDS_PER_PAGE', 25);
define('ADMIN_MAX_UPLOAD_SIZE', 10485760); // 10MB
define('CSRF_TOKEN_EXPIRY', 1800); // 30 minutos para tokens CSRF

// Configuración de seguridad
define('CSRF_TOKEN_EXPIRY', 1800); // 30 minutos
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_TIMEOUT', 900); // 15 minutos

// Configuración de paths
define('ADMIN_ROOT', dirname(__FILE__));
define('ADMIN_URL', '/admin');
define('UPLOADS_PATH', ADMIN_ROOT . '/uploads');
define('LOGS_PATH', ADMIN_ROOT . '/logs');

// Función para obtener la ruta base del admin desde cualquier subdirectorio
function get_admin_base_path() {
    $script_path = $_SERVER['SCRIPT_NAME'];
    $admin_pos = strpos($script_path, '/admin/');
    if ($admin_pos !== false) {
        return '/admin/';
    }
    return '/admin/';
}

// Función para generar rutas relativas correctas
function admin_asset($path) {
    // Obtener el nivel de profundidad desde /admin/
    $script_path = $_SERVER['SCRIPT_NAME'];
    $admin_pos = strpos($script_path, '/admin/');
    
    if ($admin_pos === false) {
        return $path;
    }
    
    // Contar niveles después de /admin/
    $after_admin = substr($script_path, $admin_pos + 7); // +7 para "/admin/"
    $levels = substr_count($after_admin, '/');
    
    // Generar la ruta relativa correcta
    $base = str_repeat('../', $levels);
    return $base . ltrim($path, '/');
}

// Configuración de la aplicación
define('APP_NAME', 'ObelisIA Admin');
define('APP_VERSION', '1.0.0');
define('TIMEZONE', 'America/Mexico_City');

// Establecer zona horaria
date_default_timezone_set(TIMEZONE);

// Configuración de errores para desarrollo
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
// Ocultar warnings de deprecación por ahora para PHP 8+
error_reporting(E_ALL & ~E_DEPRECATED & ~E_STRICT);

// Función para iniciar sesión de forma segura
function start_admin_session() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

// Conexión a la base de datos
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    die("Error de conexión a la base de datos: " . $e->getMessage());
}

// Función para limpiar output
function clean_output() {
    if (ob_get_level()) {
        ob_end_clean();
    }
    ob_start();
}

// Autoloader simple para clases
spl_autoload_register(function ($class) {
    $file = ADMIN_ROOT . '/classes/' . $class . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

// Incluir funciones de autenticación
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
?>
