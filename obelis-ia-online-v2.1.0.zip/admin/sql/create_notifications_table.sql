-- Usar la base de datos específica
USE if0_39552758_obelisia_db;

-- Tabla para notificaciones del administrador
CREATE TABLE IF NOT EXISTS admin_notifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    admin_id INT NOT NULL DEFAULT 1,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    link VARCHAR(500) NULL,
    type ENUM('info', 'success', 'warning', 'error') DEFAULT 'info',
    icon VARCHAR(50) DEFAULT 'fa-bell',
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    read_at TIMESTAMP NULL,
    INDEX idx_admin_unread (admin_id, is_read),
    INDEX idx_created_at (created_at)
);

-- Insertar algunas notificaciones de ejemplo
INSERT INTO admin_notifications (title, message, link, type, icon, is_read) VALUES
('Nuevo usuario registrado', 'Juan Pérez se ha registrado en la plataforma', 'users', 'success', 'fa-user-plus', FALSE),
('Usuario Premium', 'María García ha adquirido una suscripción Premium', 'subscriptions', 'success', 'fa-crown', FALSE),
('Nuevo contenido creado', 'Se ha publicado nuevo contenido en el sistema', 'content_creations', 'info', 'fa-palette', FALSE),
('Pago recibido', 'Se ha recibido un pago de $29.99', 'payments', 'success', 'fa-dollar-sign', FALSE),
('Reporte de contenido', 'Se ha reportado contenido inapropiado', 'reports', 'warning', 'fa-flag', FALSE);
