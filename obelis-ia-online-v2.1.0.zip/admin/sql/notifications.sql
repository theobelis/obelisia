-- ===============================================
-- SISTEMA DE NOTIFICACIONES PARA ADMIN PANEL
-- ObelisIA Project - Admin Notifications
-- ===============================================

CREATE TABLE IF NOT EXISTS `admin_notifications` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `admin_id` INT(11) UNSIGNED NOT NULL DEFAULT 1,
    `title` VARCHAR(255) NOT NULL,
    `message` TEXT NOT NULL,
    `link` VARCHAR(500) NULL DEFAULT NULL,
    `type` ENUM('info', 'success', 'warning', 'error') NOT NULL DEFAULT 'info',
    `icon` VARCHAR(50) DEFAULT 'fas fa-info-circle',
    `is_read` TINYINT(1) NOT NULL DEFAULT 0,
    `priority` ENUM('low', 'medium', 'high', 'urgent') NOT NULL DEFAULT 'medium',
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `read_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    INDEX `idx_admin_id` (`admin_id`),
    INDEX `idx_is_read` (`is_read`),
    INDEX `idx_created_at` (`created_at`),
    INDEX `idx_priority` (`priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===============================================
-- DATOS DE EJEMPLO PARA TESTING
-- ===============================================

INSERT INTO `admin_notifications` (`admin_id`, `title`, `message`, `link`, `type`, `icon`, `is_read`, `priority`) VALUES
(1, 'Nuevo usuario registrado', 'Se ha registrado un nuevo usuario en la plataforma: john.doe@example.com', '#users', 'info', 'fas fa-user-plus', 0, 'medium'),
(1, 'Reporte de contenido', 'Se ha reportado contenido inapropiado que requiere revisión inmediata', '#reports', 'warning', 'fas fa-exclamation-triangle', 0, 'high'),
(1, 'Pago recibido', 'Se ha procesado un nuevo pago de $49.99 por suscripción premium', '#payments', 'success', 'fas fa-dollar-sign', 0, 'medium'),
(1, 'Error del sistema', 'Se detectó un error en el procesamiento de imágenes IA', '#system_logs', 'error', 'fas fa-bug', 0, 'urgent'),
(1, 'Actualización completada', 'La actualización del sistema se completó exitosamente', null, 'success', 'fas fa-check-circle', 1, 'low');

-- ===============================================
-- FUNCIÓN HELPER PARA CREAR NOTIFICACIONES
-- ===============================================

DELIMITER $$

CREATE PROCEDURE IF NOT EXISTS `CreateAdminNotification`(
    IN p_admin_id INT,
    IN p_title VARCHAR(255),
    IN p_message TEXT,
    IN p_link VARCHAR(500),
    IN p_type ENUM('info', 'success', 'warning', 'error'),
    IN p_icon VARCHAR(50),
    IN p_priority ENUM('low', 'medium', 'high', 'urgent')
)
BEGIN
    INSERT INTO `admin_notifications` 
    (`admin_id`, `title`, `message`, `link`, `type`, `icon`, `priority`) 
    VALUES 
    (p_admin_id, p_title, p_message, p_link, p_type, p_icon, p_priority);
END$$

DELIMITER ;

-- ===============================================
-- ÍNDICES ADICIONALES PARA OPTIMIZACIÓN
-- ===============================================

-- Índice compuesto para consultas frecuentes
CREATE INDEX `idx_admin_unread` ON `admin_notifications` (`admin_id`, `is_read`, `created_at` DESC);

-- Índice para consultas por tipo y prioridad
CREATE INDEX `idx_type_priority` ON `admin_notifications` (`type`, `priority`, `created_at` DESC);
