<?php
session_start();
$_SESSION['admin_id'] = 1;
$_SESSION['admin_username'] = 'Obelis';
$_SESSION['admin_full_name'] = 'Administrador Obelis';
$_SESSION['admin_last_activity'] = time();
echo "✅ Sesión de admin creada<br>";
echo "<a href='/admin/'>🚀 Ir al Panel</a>";
?>
