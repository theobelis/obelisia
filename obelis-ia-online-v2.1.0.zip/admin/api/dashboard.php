<?php
require_once '../config/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

start_admin_session();

// Verificar autenticación
if (!isAdminAuthenticated()) {
    http_response_code(401);
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

// Verificar que sea una petición AJAX
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || $_SERVER['HTTP_X_REQUESTED_WITH'] !== 'XMLHttpRequest') {
    http_response_code(400);
    echo json_encode(['error' => 'Solo peticiones AJAX']);
    exit;
}

try {
    // Obtener estadísticas del dashboard
    $stats = getDashboardStats();
    
    // Generar HTML del dashboard
    ob_start();
    ?>
    <div class="dashboard-header" style="margin-bottom: 2rem;">
        <h1 style="font-size: 2rem; font-weight: 700; color: var(--light-text); margin-bottom: 0.5rem; display: flex; align-items: center; gap: 0.75rem;"><i class="fas fa-tachometer-alt" style="color: var(--primary-color);"></i> Panel de Control Dinámico</h1>
        <p style="color: var(--muted-text); font-size: 1.1rem;">Administra tu base de datos de forma intuitiva y eficiente</p>
    </div>

    <!-- Tarjetas de estadísticas -->
    <div class="stats-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem; margin-bottom: 2.5rem;">
        <div class="stat-card users" style="background: var(--dark-surface); border: 1px solid var(--border-color); border-radius: 1rem; padding: 1.5rem; display: flex; align-items: center; gap: 1rem; transition: var(--transition-fast); position: relative; overflow: hidden;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='var(--shadow-lg)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none'">
            <div style="content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px; background: linear-gradient(90deg, #3b82f6, #1d4ed8);"></div>
            <div class="stat-icon" style="width: 4rem; height: 4rem; border-radius: 1rem; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; background: rgba(59, 130, 246, 0.1); color: #3b82f6;">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-content">
                <h3 style="font-size: 2rem; font-weight: 700; color: var(--light-text); margin-bottom: 0.25rem;"><?php echo number_format($stats['total_users'] ?? 0); ?></h3>
                <p style="color: var(--muted-text); margin-bottom: 0.5rem;">Usuarios Totales</p>
                <span class="stat-change positive" style="color: var(--success-color); font-size: 0.875rem; font-weight: 600;">+<?php echo $stats['new_users_today'] ?? 0; ?> hoy</span>
            </div>
        </div>

        <div class="stat-card creations" style="background: var(--dark-surface); border: 1px solid var(--border-color); border-radius: 1rem; padding: 1.5rem; display: flex; align-items: center; gap: 1rem; transition: var(--transition-fast); position: relative; overflow: hidden;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='var(--shadow-lg)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none'">
            <div style="content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px; background: linear-gradient(90deg, #8b5cf6, #7c3aed);"></div>
            <div class="stat-icon" style="width: 4rem; height: 4rem; border-radius: 1rem; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; background: rgba(139, 92, 246, 0.1); color: #8b5cf6;">
                <i class="fas fa-magic"></i>
            </div>
                        <div class="stat-content">
                <h3 style="font-size: 2rem; font-weight: 700; color: var(--light-text); margin-bottom: 0.25rem;"><?php echo number_format($stats['total_creations'] ?? 0); ?></h3>
                <p style="color: var(--muted-text); margin-bottom: 0.5rem;">Creaciones Totales</p>
                <span class="stat-change positive" style="color: var(--success-color); font-size: 0.875rem; font-weight: 600;">+<?php echo $stats['new_creations_today'] ?? 0; ?> hoy</span>
            </div>
        </div>

        <div class="stat-card revenue" style="background: var(--dark-surface); border: 1px solid var(--border-color); border-radius: 1rem; padding: 1.5rem; display: flex; align-items: center; gap: 1rem; transition: var(--transition-fast); position: relative; overflow: hidden;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='var(--shadow-lg)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none'">
            <div style="content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px; background: linear-gradient(90deg, #10b981, #059669);"></div>
            <div class="stat-icon" style="width: 4rem; height: 4rem; border-radius: 1rem; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; background: rgba(16, 185, 129, 0.1); color: #10b981;">
                <i class="fas fa-dollar-sign"></i>
            </div>
            <div class="stat-content">
                <h3 style="font-size: 2rem; font-weight: 700; color: var(--light-text); margin-bottom: 0.25rem;">$<?php echo number_format($stats['total_revenue'] ?? 0, 2); ?></h3>
                <p style="color: var(--muted-text); margin-bottom: 0.5rem;">Ingresos Totales</p>
                <span class="stat-change positive" style="color: var(--success-color); font-size: 0.875rem; font-weight: 600;">+$<?php echo number_format($stats['revenue_today'] ?? 0, 2); ?> hoy</span>
            </div>
        </div>

        <div class="stat-card activity" style="background: var(--dark-surface); border: 1px solid var(--border-color); border-radius: 1rem; padding: 1.5rem; display: flex; align-items: center; gap: 1rem; transition: var(--transition-fast); position: relative; overflow: hidden;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='var(--shadow-lg)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none'">
            <div style="content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px; background: linear-gradient(90deg, #f59e0b, #d97706);"></div>
            <div class="stat-icon" style="width: 4rem; height: 4rem; border-radius: 1rem; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; background: rgba(245, 158, 11, 0.1); color: #f59e0b;">
                <i class="fas fa-chart-line"></i>
            </div>
            <div class="stat-content">
                <h3 style="font-size: 2rem; font-weight: 700; color: var(--light-text); margin-bottom: 0.25rem;"><?php echo number_format($stats['activity_today'] ?? 0); ?></h3>
                <p style="color: var(--muted-text); margin-bottom: 0.5rem;">Actividad Hoy</p>
                <span class="stat-change neutral" style="color: var(--muted-text); font-size: 0.875rem;">Acciones realizadas</span>
            </div>
        </div>
    </div>

    <!-- Información adicional -->
    <div class="row mt-4">
        <div class="col-md-12">
            <div style="background: var(--dark-surface); border: 1px solid var(--border-color); border-radius: 1rem; padding: 2rem; box-shadow: var(--shadow-md);">
                <div style="background: linear-gradient(135deg, rgba(99, 102, 241, 0.1) 0%, rgba(139, 92, 246, 0.1) 100%); border: 1px solid rgba(99, 102, 241, 0.2); border-radius: 0.75rem; padding: 1.5rem; margin-bottom: 2rem;">
                    <h4 style="color: var(--primary-color); margin-bottom: 1rem;"><i class="fas fa-info-circle"></i> Panel de Administración Dinámico</h4>
                    <p style="color: var(--light-text); margin-bottom: 0;">
                        Selecciona cualquier tabla de la barra lateral para ver y gestionar sus datos. 
                        El sistema carga automáticamente todas las tablas de tu base de datos y te permite 
                        visualizar, editar y eliminar registros de forma intuitiva.
                    </p>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <h5 style="color: var(--light-text); margin-bottom: 1rem;"><i class="fas fa-database" style="color: var(--primary-color);"></i> Gestión de Base de Datos</h5>
                        <ul style="color: var(--muted-text); margin-bottom: 0;">
                            <li>Vista de datos en tiempo real</li>
                            <li>Edición segura de registros</li>
                            <li>Eliminación con confirmación</li>
                            <li>Búsqueda y filtrado avanzado</li>
                        </ul>
                    </div>
                    <div class="col-md-6">
                        <h5 style="color: var(--light-text); margin-bottom: 1rem;"><i class="fas fa-cogs" style="color: var(--secondary-color);"></i> Características</h5>
                        <ul style="color: var(--muted-text); margin-bottom: 0;">
                            <li>Interfaz responsiva y moderna</li>
                            <li>Navegación dinámica</li>
                            <li>Formularios adaptativos</li>
                            <li>Sistema de notificaciones</li>
                        </ul>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Acciones Rápidas -->
    <div class="row mt-4">
        <div class="col-md-12">
            <div style="background: var(--dark-surface); border: 1px solid var(--border-color); border-radius: 1rem; padding: 2rem; box-shadow: var(--shadow-md);">
                <h5 style="color: var(--light-text); margin-bottom: 1.5rem;"><i class="fas fa-bolt" style="color: var(--warning-color);"></i> Acciones Rápidas</h5>
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <button onclick="loadTable('users')" class="btn w-100" style="background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%); color: white; border: none; padding: 1rem; border-radius: 0.75rem; transition: all 0.3s ease;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='var(--shadow-lg)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none'">
                            <i class="fas fa-users fa-2x mb-2"></i><br>
                            Gestionar Usuarios
                        </button>
                    </div>
                    <div class="col-md-3 mb-3">
                        <button onclick="loadTable('content_creations')" class="btn w-100" style="background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); color: white; border: none; padding: 1rem; border-radius: 0.75rem; transition: all 0.3s ease;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='var(--shadow-lg)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none'">
                            <i class="fas fa-magic fa-2x mb-2"></i><br>
                            Ver Creaciones
                        </button>
                    </div>
                    <div class="col-md-3 mb-3">
                        <button onclick="loadTable('payments')" class="btn w-100" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; border: none; padding: 1rem; border-radius: 0.75rem; transition: all 0.3s ease;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='var(--shadow-lg)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none'">
                            <i class="fas fa-credit-card fa-2x mb-2"></i><br>
                            Gestionar Pagos
                        </button>
                    </div>
                    <div class="col-md-3 mb-3">
                        <button onclick="loadTable('blog_posts')" class="btn w-100" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white; border: none; padding: 1rem; border-radius: 0.75rem; transition: all 0.3s ease;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='var(--shadow-lg)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none'">
                            <i class="fas fa-blog fa-2x mb-2"></i><br>
                            Gestionar Blog
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php
    $dashboardContent = ob_get_clean();
    echo $dashboardContent;
    
} catch (Exception $e) {
    http_response_code(500);
    echo '<div style="background: linear-gradient(135deg, var(--error-color) 0%, #dc2626 100%); color: white; border: none; border-radius: 0.75rem; padding: 1.5rem;">Error al cargar dashboard: ' . htmlspecialchars($e->getMessage()) . '</div>';
}
?>
