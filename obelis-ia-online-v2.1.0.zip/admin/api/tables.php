<?php
require_once '../config/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once '../../src/Database/Database.php';

use ObelisIA\Database\Database;

// Configurar cabeceras
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');

// Manejar preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

start_admin_session();

// Verificar autenticación de admin
if (!isAdminAuthenticated()) {
    http_response_code(401);
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

try {
    $database = new Database();
    $conn = $database->getConnection();
    
    $action = $_GET['action'] ?? 'view';
    $tableName = $_GET['table'] ?? '';
    
    if (empty($tableName)) {
        throw new Exception('Nombre de tabla requerido');
    }
    
    // Validar que la tabla exista
    $tablesQuery = "SHOW TABLES LIKE :table";
    $tablesStmt = $conn->prepare($tablesQuery);
    $tablesStmt->execute([':table' => $tableName]);
    
    if ($tablesStmt->rowCount() === 0) {
        throw new Exception('Tabla no encontrada');
    }
    
    switch ($action) {
        case 'delete':
            header('Content-Type: application/json');
            handleDelete($conn, $tableName);
            break;
        case 'edit':
            header('Content-Type: text/html');
            handleEdit($conn, $tableName);
            break;
        case 'view':
        default:
            header('Content-Type: text/html');
            handleView($conn, $tableName);
            break;
    }
    
} catch (Exception $e) {
    error_log("Error en API tables: " . $e->getMessage());
    
    if ($action === 'view') {
        // Para vista, devolvemos HTML de error
        header('Content-Type: text/html');
        echo '<div class="alert alert-danger">
                <h4><i class="fas fa-exclamation-triangle"></i> Error</h4>
                <p>Error: ' . htmlspecialchars($e->getMessage()) . '</p>
              </div>';
    } else {
        // Para acciones, devolvemos JSON de error
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}

/**
 * Manejar vista de tabla
 */
function handleView($conn, $tableName) {
    header('Content-Type: text/html');
    
    // Obtener información de la tabla
    $tableInfo = getTableStructure($conn, $tableName);
    $columns = $tableInfo['columns'];
    $primaryKey = $tableInfo['primary_key'];
    
    // Parámetros de paginación
    $page = intval($_GET['page'] ?? 1);
    $limit = intval($_GET['limit'] ?? 50);
    $offset = ($page - 1) * $limit;
    $search = $_GET['search'] ?? '';
    
    // Construir query de búsqueda
    $whereClause = '';
    $searchParams = [];
    
    if (!empty($search)) {
        $searchConditions = [];
        foreach ($columns as $column) {
            if (in_array($column['type'], ['varchar', 'text', 'longtext', 'mediumtext'])) {
                $searchConditions[] = "{$column['name']} LIKE :search";
            }
        }
        
        if (!empty($searchConditions)) {
            $whereClause = 'WHERE ' . implode(' OR ', $searchConditions);
            $searchParams[':search'] = '%' . $search . '%';
        }
    }
    
    // Obtener total de registros
    $countQuery = "SELECT COUNT(*) as total FROM `{$tableName}` {$whereClause}";
    $countStmt = $conn->prepare($countQuery);
    $countStmt->execute($searchParams);
    $totalRecords = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    // Obtener datos
    $dataQuery = "SELECT * FROM `{$tableName}` {$whereClause} ORDER BY {$primaryKey} DESC LIMIT {$limit} OFFSET {$offset}";
    $dataStmt = $conn->prepare($dataQuery);
    $dataStmt->execute($searchParams);
    $data = $dataStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Calcular paginación
    $totalPages = ceil($totalRecords / $limit);
    
    // Generar HTML
    renderTableView($tableName, $columns, $data, $primaryKey, $page, $totalPages, $totalRecords, $search);
}

/**
 * Manejar eliminación de registro
 */
function handleDelete($conn, $tableName) {
    $id = $_GET['id'] ?? '';
    
    if (empty($id)) {
        throw new Exception('ID requerido para eliminar');
    }
    
    // Obtener clave primaria de la tabla
    $tableInfo = getTableStructure($conn, $tableName);
    $primaryKey = $tableInfo['primary_key'];
    
    // Ejecutar eliminación
    $deleteQuery = "DELETE FROM `{$tableName}` WHERE `{$primaryKey}` = :id";
    $deleteStmt = $conn->prepare($deleteQuery);
    $result = $deleteStmt->execute([':id' => $id]);
    
    if ($result && $deleteStmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => 'Registro eliminado correctamente']);
    } else {
        throw new Exception('No se pudo eliminar el registro o no existe');
    }
}

/**
 * Obtener estructura de una tabla
 */
function getTableStructure($conn, $tableName) {
    // Obtener columnas
    $columnsQuery = "DESCRIBE `{$tableName}`";
    $columnsStmt = $conn->prepare($columnsQuery);
    $columnsStmt->execute();
    $columns = $columnsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Formatear información de columnas
    $formattedColumns = [];
    $primaryKey = null;
    
    foreach ($columns as $column) {
        $type = explode('(', $column['Type'])[0];
        
        $formattedColumns[] = [
            'name' => $column['Field'],
            'type' => $type,
            'null' => $column['Null'] === 'YES',
            'key' => $column['Key'],
            'default' => $column['Default'],
            'extra' => $column['Extra']
        ];
        
        if ($column['Key'] === 'PRI') {
            $primaryKey = $column['Field'];
        }
    }
    
    return [
        'columns' => $formattedColumns,
        'primary_key' => $primaryKey ?: 'id' // Fallback a 'id' si no hay PK definida
    ];
}

/**
 * Renderizar vista de tabla
 */
function renderTableView($tableName, $columns, $data, $primaryKey, $currentPage, $totalPages, $totalRecords, $search) {
    $formattedTableName = formatTableName($tableName);
    
    echo '<div class="table-view-container" style="background: var(--dark-surface); border: 1px solid var(--border-color); border-radius: 1rem; padding: 2rem; box-shadow: var(--shadow-md); margin-bottom: 2rem; animation: slideInUp 0.3s ease-out;">';
    
    // Header de la tabla
    echo '<div class="table-header mb-4">';
    echo '<div class="d-flex justify-content-between align-items-center">';
    echo '<div>';
    echo '<h2 style="color: var(--light-text); font-weight: 700;"><i class="fas ' . getTableIcon($tableName) . '" style="color: var(--primary-color);"></i> ' . $formattedTableName . '</h2>';
    echo '<p style="color: var(--muted-text);">Gestiona los registros de la tabla <code style="background: var(--primary-color); color: white; padding: 0.25rem 0.5rem; border-radius: 4px;">' . $tableName . '</code></p>';
    echo '</div>';
    echo '<div>';
    echo '<button class="btn" style="background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%); color: white; border: none; padding: 0.75rem 1.5rem; border-radius: 0.75rem; transition: all 0.3s ease;" onclick="addRecord(\'' . $tableName . '\')" onmouseover="this.style.transform=\'translateY(-2px)\'; this.style.boxShadow=\'var(--shadow-lg)\'" onmouseout="this.style.transform=\'translateY(0)\'; this.style.boxShadow=\'none\'"><i class="fas fa-plus"></i> Agregar</button>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    
    // Barra de búsqueda y filtros
    echo '<div class="table-controls mb-3" style="background: rgba(30, 41, 59, 0.7); backdrop-filter: blur(10px); border: 1px solid var(--border-color); border-radius: 0.75rem; padding: 1rem;">';
    echo '<div class="row">';
    echo '<div class="col-md-6">';
    echo '<div class="input-group">';
    echo '<input type="text" class="form-control" style="background: var(--dark-card); border-color: var(--border-color); color: var(--light-text);" id="table-search" placeholder="Buscar en ' . $formattedTableName . '..." value="' . htmlspecialchars($search) . '">';
    echo '<button class="btn btn-outline-secondary" style="border-color: var(--border-color); color: var(--muted-text);" type="button" onclick="searchTable()"><i class="fas fa-search"></i></button>';
    echo '</div>';
    echo '</div>';
    echo '<div class="col-md-6 text-end">';
    echo '<span style="color: var(--muted-text);">Mostrando <strong style="color: var(--primary-color);">' . count($data) . '</strong> de <strong style="color: var(--primary-color);">' . $totalRecords . '</strong> registros</span>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    
    // Tabla de datos
    if (empty($data)) {
        echo '<div class="alert" style="background: linear-gradient(135deg, rgba(30, 41, 59, 0.7) 0%, rgba(51, 65, 85, 0.7) 100%); backdrop-filter: blur(10px); color: var(--light-text); border: 2px dashed var(--border-color); border-radius: 0.75rem; text-align: center; padding: 2rem;">';
        echo '<i class="fas fa-info-circle fa-2x mb-3" style="color: var(--primary-color);"></i>';
        echo '<h4 style="color: var(--light-text); margin-bottom: 1rem;">No hay datos disponibles</h4>';
        echo '<p style="color: var(--muted-text);">No se encontraron registros en esta tabla' . (!empty($search) ? ' para la búsqueda "' . htmlspecialchars($search) . '"' : '') . '</p>';
        echo '</div>';
    } else {
        echo '<div class="table-responsive" style="border-radius: 0.75rem; overflow: scroll; box-shadow: var(--shadow-md);">';
        echo '<table class="table table-hover mb-0" id="data-table" style="background: var(--dark-surface);">';
        
        // Header de la tabla
        echo '<thead style="background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);">';
        echo '<tr>';
        foreach ($columns as $column) {
            $icon = getColumnIcon($column['type']);
            echo '<th style="color: white; font-weight: 600; border: none; padding: 1rem 0.75rem;">';
            echo '<i class="fas ' . $icon . ' me-1" style="opacity: 0.8;"></i>';
            echo htmlspecialchars($column['name']);
            if ($column['key'] === 'PRI') {
                echo ' <i class="fas fa-key ms-1" style="color: #f59e0b; filter: drop-shadow(0 0 2px rgba(245, 158, 11, 0.3));" title="Clave primaria"></i>';
            }
            echo '</th>';
        }
        echo '<th width="120" style="color: white; font-weight: 600; border: none; padding: 1rem 0.75rem;">Acciones</th>';
        echo '</tr>';
        echo '</thead>';
        
        // Cuerpo de la tabla
        echo '<tbody>';
        foreach ($data as $row) {
            echo '<tr style="transition: all 0.2s ease;" onmouseover="this.style.background=\'var(--dark-card)\'; this.style.transform=\'translateY(-1px)\'; this.style.boxShadow=\'0 2px 4px rgba(0, 0, 0, 0.1)\'" onmouseout="this.style.background=\'\'; this.style.transform=\'translateY(0)\'; this.style.boxShadow=\'none\'">';
            foreach ($columns as $column) {
                $value = $row[$column['name']] ?? null;
                echo '<td style="padding: 1rem 0.75rem; vertical-align: middle; border-bottom: 1px solid var(--border-color); color: var(--light-text);">';
                echo formatCellValue($value, $column['type']);
                echo '</td>';
            }
            
            // Columna de acciones
            echo '<td style="padding: 1rem 0.75rem; vertical-align: middle; border-bottom: 1px solid var(--border-color);">';
            echo '<div class="btn-group btn-group-sm">';
            echo '<button class="btn btn-outline-primary" style="border-color: var(--primary-color); color: var(--primary-color); transition: all 0.2s ease;" onclick="editRecord(\'' . $tableName . '\', \'' . $row[$primaryKey] . '\')" title="Editar" onmouseover="this.style.background=\'var(--primary-color)\'; this.style.color=\'white\'; this.style.transform=\'translateY(-1px)\'" onmouseout="this.style.background=\'\'; this.style.color=\'var(--primary-color)\'; this.style.transform=\'translateY(0)\'">';
            echo '<i class="fas fa-edit"></i>';
            echo '</button>';
            echo '<button class="btn btn-outline-danger" style="border-color: var(--error-color); color: var(--error-color); transition: all 0.2s ease;" onclick="deleteRecord(\'' . $tableName . '\', \'' . $row[$primaryKey] . '\')" title="Eliminar" onmouseover="this.style.background=\'var(--error-color)\'; this.style.color=\'white\'; this.style.transform=\'translateY(-1px)\'" onmouseout="this.style.background=\'\'; this.style.color=\'var(--error-color)\'; this.style.transform=\'translateY(0)\'">';
            echo '<i class="fas fa-trash"></i>';
            echo '</button>';
            echo '</div>';
            echo '</td>';
            
            echo '</tr>';
        }
        echo '</tbody>';
        echo '</table>';
        echo '</div>';
        
        // Paginación
        if ($totalPages > 1) {
            renderPagination($currentPage, $totalPages, $tableName, $search);
        }
    }
    
    echo '</div>';
    
    // JavaScript específico para esta tabla
    echo '<script>';
    echo 'function searchTable() {';
    echo '    const search = document.getElementById("table-search").value;';
    echo '    loadTable("' . $tableName . '", 1, search);';
    echo '}';
    
    echo 'document.getElementById("table-search").addEventListener("keypress", function(e) {';
    echo '    if (e.key === "Enter") {';
    echo '        searchTable();';
    echo '    }';
    echo '});';
    echo '</script>';
}

/**
 * Renderizar paginación
 */
function renderPagination($currentPage, $totalPages, $tableName, $search) {
    echo '<nav aria-label="Paginación de tabla" class="mt-4">';
    echo '<ul class="pagination justify-content-center" style="margin-bottom: 0;">';
    
    // Botón anterior
    if ($currentPage > 1) {
        echo '<li class="page-item">';
        echo '<a class="page-link" style="color: var(--primary-color); background: var(--dark-surface); border: 1px solid var(--border-color); margin: 0 0.125rem; border-radius: 0.5rem; padding: 0.75rem 1rem; transition: all 0.2s ease;" href="#" onclick="loadTable(\'' . $tableName . '\', ' . ($currentPage - 1) . ', \'' . htmlspecialchars($search) . '\')" onmouseover="this.style.background=\'var(--primary-color)\'; this.style.color=\'white\'; this.style.borderColor=\'var(--primary-color)\'; this.style.transform=\'translateY(-1px)\'" onmouseout="this.style.background=\'var(--dark-surface)\'; this.style.color=\'var(--primary-color)\'; this.style.borderColor=\'var(--border-color)\'; this.style.transform=\'translateY(0)\'">';
        echo '<i class="fas fa-chevron-left"></i> Anterior';
        echo '</a>';
        echo '</li>';
    }
    
    // Números de página
    $start = max(1, $currentPage - 2);
    $end = min($totalPages, $currentPage + 2);
    
    if ($start > 1) {
        echo '<li class="page-item"><a class="page-link" style="color: var(--primary-color); background: var(--dark-surface); border: 1px solid var(--border-color); margin: 0 0.125rem; border-radius: 0.5rem; padding: 0.75rem 1rem; transition: all 0.2s ease;" href="#" onclick="loadTable(\'' . $tableName . '\', 1, \'' . htmlspecialchars($search) . '\')" onmouseover="this.style.background=\'var(--primary-color)\'; this.style.color=\'white\'; this.style.borderColor=\'var(--primary-color)\'; this.style.transform=\'translateY(-1px)\'" onmouseout="this.style.background=\'var(--dark-surface)\'; this.style.color=\'var(--primary-color)\'; this.style.borderColor=\'var(--border-color)\'; this.style.transform=\'translateY(0)\'">1</a></li>';
        if ($start > 2) {
            echo '<li class="page-item disabled"><span class="page-link" style="background: var(--dark-surface); color: var(--muted-text); border: 1px solid var(--border-color); margin: 0 0.125rem; border-radius: 0.5rem; padding: 0.75rem 1rem;">...</span></li>';
        }
    }
    
    for ($i = $start; $i <= $end; $i++) {
        $active = ($i === $currentPage) ? 'active' : '';
        $activeStyle = ($i === $currentPage) ? 'background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%); color: white; border-color: var(--primary-color);' : 'color: var(--primary-color); background: var(--dark-surface); border: 1px solid var(--border-color);';
        echo '<li class="page-item ' . $active . '">';
        echo '<a class="page-link" style="' . $activeStyle . ' margin: 0 0.125rem; border-radius: 0.5rem; padding: 0.75rem 1rem; transition: all 0.2s ease;" href="#" onclick="loadTable(\'' . $tableName . '\', ' . $i . ', \'' . htmlspecialchars($search) . '\')"';
        if ($i !== $currentPage) {
            echo ' onmouseover="this.style.background=\'var(--primary-color)\'; this.style.color=\'white\'; this.style.borderColor=\'var(--primary-color)\'; this.style.transform=\'translateY(-1px)\'" onmouseout="this.style.background=\'var(--dark-surface)\'; this.style.color=\'var(--primary-color)\'; this.style.borderColor=\'var(--border-color)\'; this.style.transform=\'translateY(0)\'"';
        }
        echo '>' . $i . '</a>';
        echo '</li>';
    }
    
    if ($end < $totalPages) {
        if ($end < $totalPages - 1) {
            echo '<li class="page-item disabled"><span class="page-link" style="background: var(--dark-surface); color: var(--muted-text); border: 1px solid var(--border-color); margin: 0 0.125rem; border-radius: 0.5rem; padding: 0.75rem 1rem;">...</span></li>';
        }
        echo '<li class="page-item"><a class="page-link" style="color: var(--primary-color); background: var(--dark-surface); border: 1px solid var(--border-color); margin: 0 0.125rem; border-radius: 0.5rem; padding: 0.75rem 1rem; transition: all 0.2s ease;" href="#" onclick="loadTable(\'' . $tableName . '\', ' . $totalPages . ', \'' . htmlspecialchars($search) . '\')" onmouseover="this.style.background=\'var(--primary-color)\'; this.style.color=\'white\'; this.style.borderColor=\'var(--primary-color)\'; this.style.transform=\'translateY(-1px)\'" onmouseout="this.style.background=\'var(--dark-surface)\'; this.style.color=\'var(--primary-color)\'; this.style.borderColor=\'var(--border-color)\'; this.style.transform=\'translateY(0)\')">' . $totalPages . '</a></li>';
    }
    
    // Botón siguiente
    if ($currentPage < $totalPages) {
        echo '<li class="page-item">';
        echo '<a class="page-link" style="color: var(--primary-color); background: var(--dark-surface); border: 1px solid var(--border-color); margin: 0 0.125rem; border-radius: 0.5rem; padding: 0.75rem 1rem; transition: all 0.2s ease;" href="#" onclick="loadTable(\'' . $tableName . '\', ' . ($currentPage + 1) . ', \'' . htmlspecialchars($search) . '\')" onmouseover="this.style.background=\'var(--primary-color)\'; this.style.color=\'white\'; this.style.borderColor=\'var(--primary-color)\'; this.style.transform=\'translateY(-1px)\'" onmouseout="this.style.background=\'var(--dark-surface)\'; this.style.color=\'var(--primary-color)\'; this.style.borderColor=\'var(--border-color)\'; this.style.transform=\'translateY(0)\'">';
        echo 'Siguiente <i class="fas fa-chevron-right"></i>';
        echo '</a>';
        echo '</li>';
    }
    
    echo '</ul>';
    echo '</nav>';
}

/**
 * Formatear valor de celda según tipo
 */
function formatCellValue($value, $type) {
    if ($value === null) {
        return '<em style="background: var(--dark-card); color: var(--muted-text); padding: 0.125rem 0.375rem; border-radius: 4px; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.5px;">NULL</em>';
    }
    
    if ($value === '') {
        return '<em style="color: var(--muted-text); font-style: italic;">vacío</em>';
    }
    
    switch (strtolower($type)) {
        case 'int':
        case 'bigint':
        case 'smallint':
        case 'tinyint':
            return '<span style="color: var(--info-color); font-weight: 600;">' . number_format($value) . '</span>';
        
        case 'decimal':
        case 'float':
        case 'double':
            return '<span style="color: var(--success-color); font-weight: 600;">$' . number_format($value, 2) . '</span>';
        
        case 'datetime':
        case 'timestamp':
            return '<span style="color: var(--warning-color); font-weight: 500;">' . date('d/m/Y H:i', strtotime($value)) . '</span>';
        
        case 'date':
            return '<span style="color: var(--warning-color); font-weight: 500;">' . date('d/m/Y', strtotime($value)) . '</span>';
        
        case 'text':
        case 'longtext':
        case 'mediumtext':
            $truncated = strlen($value) > 100 ? substr($value, 0, 100) . '...' : $value;
            return '<span title="' . htmlspecialchars($value) . '" style="color: var(--light-text);">' . htmlspecialchars($truncated) . '</span>';
        
        case 'json':
            return '<code style="background: var(--dark-card); color: var(--info-color); padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.875rem;">' . htmlspecialchars(substr($value, 0, 50)) . '...</code>';
        
        default:
            return '<span style="color: var(--light-text);">' . htmlspecialchars($value) . '</span>';
    }
}

/**
 * Obtener icono para tipo de columna
 */
function getColumnIcon($type) {
    $icons = [
        'int' => 'fa-hashtag',
        'bigint' => 'fa-hashtag',
        'smallint' => 'fa-hashtag',
        'tinyint' => 'fa-hashtag',
        'varchar' => 'fa-font',
        'text' => 'fa-align-left',
        'longtext' => 'fa-align-left',
        'mediumtext' => 'fa-align-left',
        'datetime' => 'fa-calendar',
        'timestamp' => 'fa-clock',
        'date' => 'fa-calendar-day',
        'decimal' => 'fa-dollar-sign',
        'float' => 'fa-dollar-sign',
        'double' => 'fa-dollar-sign',
        'json' => 'fa-code',
        'enum' => 'fa-list',
        'boolean' => 'fa-toggle-on'
    ];
    
    return $icons[$type] ?? 'fa-database';
}

// Incluir funciones auxiliares del archivo principal
function getTableIcon($tableName) {
    $icons = [
        'users' => 'fa-users',
        'user_profiles' => 'fa-id-card',
        'user_activity' => 'fa-history',
        'user_sessions' => 'fa-sign-in-alt',
        'blog_posts' => 'fa-blog',
        'content_creations' => 'fa-palette',
        'projects' => 'fa-project-diagram',
        'comments' => 'fa-comments',
        'reports' => 'fa-flag',
        'payments' => 'fa-credit-card',
        'credits' => 'fa-coins',
        'subscriptions' => 'fa-crown',
        'transactions' => 'fa-exchange-alt',
        'settings' => 'fa-cogs',
        'logs' => 'fa-file-alt',
        'api_keys' => 'fa-key',
        'notifications' => 'fa-bell',
        'social_posts' => 'fa-share-alt',
        'social_likes' => 'fa-heart',
        'social_follows' => 'fa-user-plus',
        'social_comments' => 'fa-comment'
    ];
    
    foreach ($icons as $pattern => $icon) {
        if (strpos($tableName, $pattern) !== false || $tableName === $pattern) {
            return $icon;
        }
    }
    
    return 'fa-table';
}

function formatTableName($tableName) {
    $formatted = str_replace('_', ' ', $tableName);
    $formatted = ucwords($formatted);
    
    $replacements = [
        'Api Keys' => 'Claves API',
        'Blog Posts' => 'Artículos del Blog',
        'Content Creations' => 'Creaciones de Contenido',
        'User Profiles' => 'Perfiles de Usuario',
        'User Activity' => 'Actividad de Usuarios',
        'User Sessions' => 'Sesiones de Usuario',
        'Social Posts' => 'Publicaciones Sociales',
        'Social Likes' => 'Me Gusta',
        'Social Follows' => 'Seguidores',
        'Social Comments' => 'Comentarios Sociales'
    ];
    
    return $replacements[$formatted] ?? $formatted;
}
?>
