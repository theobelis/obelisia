<?php
require_once '../config/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once '../../src/Database/Database.php';

use ObelisIA\Database\Database;

// Configurar cabeceras
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');

// Manejar preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

start_admin_session();

// Verificar autenticación de admin
if (!isAdminAuthenticated()) {
    http_response_code(401);
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

// Verificar que sea una petición AJAX
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || $_SERVER['HTTP_X_REQUESTED_WITH'] !== 'XMLHttpRequest') {
    http_response_code(400);
    echo json_encode(['error' => 'Solo peticiones AJAX']);
    exit;
}

try {
    // Obtener y validar parámetros
    $searchQuery = trim($_GET['q'] ?? '');
    $limit = min(intval($_GET['limit'] ?? 50), 100); // Máximo 100 resultados
    $tables = $_GET['tables'] ?? ''; // Opcional: limitar a tablas específicas
    
    // Validar término de búsqueda
    if (empty($searchQuery)) {
        echo json_encode([
            'success' => true,
            'results' => [],
            'message' => 'Término de búsqueda vacío'
        ]);
        exit;
    }
    
    // Validar longitud mínima
    if (strlen($searchQuery) < 2) {
        echo json_encode([
            'success' => true,
            'results' => [],
            'message' => 'Término de búsqueda muy corto (mínimo 2 caracteres)'
        ]);
        exit;
    }
    
    // Inicializar base de datos
    $database = new Database();
    $conn = $database->getConnection();
    
    // Realizar búsqueda
    $searchResults = performGlobalSearch($conn, $searchQuery, $limit, $tables);
    
    echo json_encode([
        'success' => true,
        'results' => $searchResults,
        'query' => $searchQuery,
        'total_results' => count($searchResults)
    ]);

} catch (Exception $e) {
    error_log("Error en búsqueda global: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error interno del servidor',
        'message' => 'No se pudo realizar la búsqueda'
    ]);
}

/**
 * Realizar búsqueda global en todas las tablas
 */
function performGlobalSearch($conn, $searchQuery, $limit, $specificTables = '') {
    $results = [];
    $searchTerm = '%' . $searchQuery . '%';
    
    // Obtener lista de tablas
    $tablesToSearch = getSearchableTables($conn, $specificTables);
    
    foreach ($tablesToSearch as $tableName) {
        try {
            $tableResults = searchInTable($conn, $tableName, $searchQuery, $searchTerm);
            if (!empty($tableResults)) {
                $results = array_merge($results, $tableResults);
            }
            
            // Limitar resultados totales
            if (count($results) >= $limit) {
                $results = array_slice($results, 0, $limit);
                break;
            }
            
        } catch (Exception $e) {
            // Log error pero continuar con otras tablas
            error_log("Error buscando en tabla {$tableName}: " . $e->getMessage());
            continue;
        }
    }
    
    // Ordenar resultados por relevancia
    usort($results, function($a, $b) {
        return $b['relevance'] <=> $a['relevance'];
    });
    
    return $results;
}

/**
 * Obtener lista de tablas donde buscar
 */
function getSearchableTables($conn, $specificTables = '') {
    // Tablas a excluir de la búsqueda
    $excludedTables = [
        'migrations',
        'sessions', 
        'cache',
        'jobs',
        'failed_jobs',
        'password_resets',
        'personal_access_tokens'
    ];
    
    if (!empty($specificTables)) {
        // Si se especifican tablas, usar solo esas
        $tables = array_map('trim', explode(',', $specificTables));
        return array_filter($tables, function($table) use ($excludedTables) {
            return !in_array($table, $excludedTables);
        });
    }
    
    // Obtener todas las tablas
    $query = "SHOW TABLES";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $allTables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Filtrar tablas excluidas
    return array_filter($allTables, function($table) use ($excludedTables) {
        return !in_array($table, $excludedTables);
    });
}

/**
 * Buscar en una tabla específica
 */
function searchInTable($conn, $tableName, $originalQuery, $searchTerm) {
    $results = [];
    
    // Obtener estructura de la tabla
    $columnsQuery = "DESCRIBE `{$tableName}`";
    $columnsStmt = $conn->prepare($columnsQuery);
    $columnsStmt->execute();
    $columns = $columnsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Identificar columnas de texto para búsqueda
    $searchableColumns = [];
    $primaryKey = null;
    $displayColumns = [];
    
    foreach ($columns as $column) {
        $columnName = $column['Field'];
        $columnType = strtolower($column['Type']);
        
        // Identificar clave primaria
        if ($column['Key'] === 'PRI') {
            $primaryKey = $columnName;
        }
        
        // Columnas de texto para búsqueda
        if (strpos($columnType, 'varchar') !== false || 
            strpos($columnType, 'text') !== false ||
            strpos($columnType, 'char') !== false) {
            $searchableColumns[] = $columnName;
        }
        
        // Primeras 3 columnas para mostrar
        if (count($displayColumns) < 3) {
            $displayColumns[] = $columnName;
        }
    }
    
    // Si no hay columnas de texto, saltar esta tabla
    if (empty($searchableColumns)) {
        return $results;
    }
    
    // Construir consulta de búsqueda
    $whereConditions = [];
    $parameters = [];
    
    foreach ($searchableColumns as $column) {
        $whereConditions[] = "`{$column}` LIKE :search_term_{$column}";
        $parameters["search_term_{$column}"] = $searchTerm;
    }
    
    $whereClause = implode(' OR ', $whereConditions);
    
    // Seleccionar columnas a mostrar
    $selectColumns = array_unique(array_merge([$primaryKey], $displayColumns));
    $selectClause = implode(', ', array_map(function($col) {
        return "`{$col}`";
    }, $selectColumns));
    
    $searchQuery = "
        SELECT {$selectClause}
        FROM `{$tableName}` 
        WHERE {$whereClause}
        LIMIT 10
    ";
    
    $stmt = $conn->prepare($searchQuery);
    $stmt->execute($parameters);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Procesar resultados
    foreach ($rows as $row) {
        $relevance = calculateRelevance($row, $originalQuery, $searchableColumns);
        
        $result = [
            'table' => $tableName,
            'table_display' => formatTableName($tableName),
            'id' => $row[$primaryKey] ?? null,
            'data' => $row,
            'preview' => generatePreview($row, $displayColumns),
            'matches' => findMatches($row, $originalQuery, $searchableColumns),
            'relevance' => $relevance,
            'url' => "admin/index.php#{$tableName}",
            'edit_url' => "admin/api/edit.php?table={$tableName}&id=" . ($row[$primaryKey] ?? ''),
            'icon' => getTableIcon($tableName)
        ];
        
        $results[] = $result;
    }
    
    return $results;
}

/**
 * Calcular relevancia del resultado
 */
function calculateRelevance($row, $searchQuery, $searchableColumns) {
    $relevance = 0;
    $searchQuery = strtolower($searchQuery);
    
    foreach ($searchableColumns as $column) {
        if (!isset($row[$column]) || empty($row[$column])) continue;
        
        $value = strtolower($row[$column]);
        
        // Coincidencia exacta (mayor peso)
        if ($value === $searchQuery) {
            $relevance += 100;
        }
        // Comienza con el término
        elseif (strpos($value, $searchQuery) === 0) {
            $relevance += 50;
        }
        // Contiene el término
        elseif (strpos($value, $searchQuery) !== false) {
            $relevance += 25;
        }
        
        // Bonus por columnas importantes (nombre, título, etc.)
        if (strpos($column, 'name') !== false || 
            strpos($column, 'title') !== false ||
            strpos($column, 'email') !== false) {
            $relevance += 10;
        }
    }
    
    return $relevance;
}

/**
 * Generar vista previa del resultado
 */
function generatePreview($row, $displayColumns) {
    $preview = [];
    
    foreach ($displayColumns as $column) {
        if (isset($row[$column]) && !empty($row[$column])) {
            $value = $row[$column];
            
            // Truncar valores largos
            if (strlen($value) > 50) {
                $value = substr($value, 0, 47) . '...';
            }
            
            $preview[$column] = htmlspecialchars($value);
        }
    }
    
    return $preview;
}

/**
 * Encontrar coincidencias específicas
 */
function findMatches($row, $searchQuery, $searchableColumns) {
    $matches = [];
    $searchQuery = strtolower($searchQuery);
    
    foreach ($searchableColumns as $column) {
        if (!isset($row[$column]) || empty($row[$column])) continue;
        
        $value = strtolower($row[$column]);
        
        if (strpos($value, $searchQuery) !== false) {
            $matches[] = [
                'column' => $column,
                'value' => htmlspecialchars($row[$column]),
                'highlighted' => highlightMatches($row[$column], $searchQuery)
            ];
        }
    }
    
    return $matches;
}

/**
 * Resaltar coincidencias en el texto
 */
function highlightMatches($text, $searchQuery) {
    $highlighted = preg_replace(
        '/(' . preg_quote($searchQuery, '/') . ')/i',
        '<mark>$1</mark>',
        htmlspecialchars($text)
    );
    
    return $highlighted;
}

// Funciones auxiliares (reutilizar las existentes)
function formatTableName($tableName) {
    // Convertir snake_case a Título Formateado
    $formatted = str_replace('_', ' ', $tableName);
    $formatted = ucwords($formatted);
    
    // Reemplazos específicos
    $replacements = [
        'Api Keys' => 'Claves API',
        'Blog Posts' => 'Artículos del Blog',
        'Content Creations' => 'Creaciones de Contenido',
        'User Profiles' => 'Perfiles de Usuario',
        'User Activity' => 'Actividad de Usuarios',
        'User Sessions' => 'Sesiones de Usuario',
        'Social Posts' => 'Publicaciones Sociales',
        'Social Likes' => 'Me Gusta',
        'Social Follows' => 'Seguidores',
        'Social Comments' => 'Comentarios Sociales'
    ];
    
    return $replacements[$formatted] ?? $formatted;
}

function getTableIcon($tableName) {
    $icons = [
        'users' => 'fa-users',
        'user_profiles' => 'fa-id-card',
        'user_activity' => 'fa-history',
        'user_sessions' => 'fa-sign-in-alt',
        'blog_posts' => 'fa-blog',
        'content_creations' => 'fa-palette',
        'projects' => 'fa-project-diagram',
        'comments' => 'fa-comments',
        'reports' => 'fa-flag',
        'payments' => 'fa-credit-card',
        'credits' => 'fa-coins',
        'subscriptions' => 'fa-crown',
        'transactions' => 'fa-exchange-alt',
        'settings' => 'fa-cogs',
        'logs' => 'fa-file-alt',
        'api_keys' => 'fa-key',
        'notifications' => 'fa-bell',
        'social_posts' => 'fa-share-alt',
        'social_likes' => 'fa-heart',
        'social_follows' => 'fa-user-plus',
        'social_comments' => 'fa-comment'
    ];
    
    foreach ($icons as $pattern => $icon) {
        if (strpos($tableName, $pattern) !== false || $tableName === $pattern) {
            return $icon;
        }
    }
    
    return 'fa-table';
}
?>
