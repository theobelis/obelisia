<?php
require_once '../config/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once '../../src/Database/Database.php';

use ObelisIA\Database\Database;

// Configurar cabeceras
header('Content-Type: text/html; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');

// Manejar preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

start_admin_session();

// Verificar autenticación de admin
if (!isAdminAuthenticated()) {
    http_response_code(401);
    echo '<div class="alert alert-danger">No autorizado</div>';
    exit;
}

// Verificar que sea una petición AJAX
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || $_SERVER['HTTP_X_REQUESTED_WITH'] !== 'XMLHttpRequest') {
    http_response_code(400);
    echo '<div class="alert alert-danger">Solo peticiones AJAX</div>';
    exit;
}

try {
    $database = new Database();
    $conn = $database->getConnection();
    
    $tableName = $_GET['table'] ?? '';
    $recordId = $_GET['id'] ?? '';
    $mode = $_GET['mode'] ?? 'edit'; // 'edit' o 'add'
    
    if (empty($tableName)) {
        throw new Exception('Nombre de tabla requerido');
    }
    
    if ($mode === 'edit' && empty($recordId)) {
        throw new Exception('ID de registro requerido para edición');
    }
    
    // Validar que la tabla exista
    $tablesQuery = "SHOW TABLES LIKE :table";
    $tablesStmt = $conn->prepare($tablesQuery);
    $tablesStmt->execute([':table' => $tableName]);
    
    if ($tablesStmt->rowCount() === 0) {
        throw new Exception('Tabla no encontrada');
    }
    
    // Obtener estructura de la tabla
    $tableStructure = getTableStructure($conn, $tableName);
    $columns = $tableStructure['columns'];
    $primaryKey = $tableStructure['primary_key'];
    
    // Obtener datos del registro si es edición
    $recordData = [];
    if ($mode === 'edit') {
        $recordQuery = "SELECT * FROM `{$tableName}` WHERE `{$primaryKey}` = :id";
        $recordStmt = $conn->prepare($recordQuery);
        $recordStmt->execute([':id' => $recordId]);
        $recordData = $recordStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$recordData) {
            throw new Exception('Registro no encontrado');
        }
    }
    
    // Generar formulario
    renderEditForm($tableName, $columns, $recordData, $primaryKey, $mode);
    
} catch (Exception $e) {
    http_response_code(500);
    echo '<div class="alert alert-danger">Error: ' . htmlspecialchars($e->getMessage()) . '</div>';
}

/**
 * Obtener estructura de una tabla
 */
function getTableStructure($conn, $tableName) {
    // Obtener columnas
    $columnsQuery = "DESCRIBE `{$tableName}`";
    $columnsStmt = $conn->prepare($columnsQuery);
    $columnsStmt->execute();
    $columns = $columnsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Formatear información de columnas
    $formattedColumns = [];
    $primaryKey = null;
    
    foreach ($columns as $column) {
        $type = explode('(', $column['Type'])[0];
        $length = null;
        
        // Extraer longitud si existe
        if (preg_match('/\((\d+)\)/', $column['Type'], $matches)) {
            $length = $matches[1];
        }
        
        $formattedColumns[] = [
            'name' => $column['Field'],
            'type' => $type,
            'length' => $length,
            'null' => $column['Null'] === 'YES',
            'key' => $column['Key'],
            'default' => $column['Default'],
            'extra' => $column['Extra']
        ];
        
        if ($column['Key'] === 'PRI') {
            $primaryKey = $column['Field'];
        }
    }
    
    return [
        'columns' => $formattedColumns,
        'primary_key' => $primaryKey ?: 'id'
    ];
}

/**
 * Renderizar formulario de edición
 */
function renderEditForm($tableName, $columns, $recordData, $primaryKey, $mode) {
    $formattedTableName = formatTableName($tableName);
    $title = $mode === 'edit' ? 'Editar' : 'Agregar';
    $submitText = $mode === 'edit' ? 'Actualizar' : 'Crear';
    
    echo '<div class="edit-form-container">';
    
    // Header del formulario
    echo '<div class="form-header">';
    echo '<div class="d-flex justify-content-between align-items-center">';
    echo '<div>';
    echo '<h2><i class="fas fa-edit"></i> ' . $title . ' Registro - ' . $formattedTableName . '</h2>';
    echo '<p>Tabla: <code>' . $tableName . '</code>';
    if ($mode === 'edit' && !empty($recordData[$primaryKey])) {
        echo ' | ID: <code>' . htmlspecialchars($recordData[$primaryKey]) . '</code>';
    }
    echo '</p>';
    echo '</div>';
    echo '<div>';
    echo '<button type="button" class="btn btn-secondary" onclick="loadTable(\'' . $tableName . '\')"><i class="fas fa-arrow-left"></i> Volver</button>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    
    // Formulario
    echo '<form id="edit-form" class="needs-validation" novalidate>';
    echo '<input type="hidden" name="table" value="' . htmlspecialchars($tableName) . '">';
    echo '<input type="hidden" name="mode" value="' . $mode . '">';
    
    if ($mode === 'edit') {
        echo '<input type="hidden" name="id" value="' . htmlspecialchars($recordData[$primaryKey]) . '">';
    }
    
    echo '<div class="row">';
    
    foreach ($columns as $column) {
        // Saltar campos auto-increment en modo agregar
        if ($mode === 'add' && $column['extra'] === 'auto_increment') {
            continue;
        }
        
        // Determinar si el campo es readonly
        $readonly = ($column['key'] === 'PRI' && $mode === 'edit') || $column['extra'] === 'auto_increment';
        
        echo '<div class="col-md-6 mb-3">';
        echo '<label for="field_' . $column['name'] . '" class="form-label">';
        echo htmlspecialchars($column['name']);
        
        // Indicadores
        if ($column['key'] === 'PRI') {
            echo ' <i class="fas fa-key" title="Clave primaria"></i>';
        }
        if (!$column['null'] && !$readonly) {
            echo ' <span class="text-danger">*</span>';
        }
        if ($readonly) {
            echo ' <span class="text-muted">(solo lectura)</span>';
        }
        
        echo '</label>';
        
        // Generar campo según tipo
        echo generateFormField($column, $recordData[$column['name']] ?? null, $readonly);
        
        // Información adicional
        echo '<div class="form-text" style="font-size: 0.8rem; color: var(--muted-text); margin-top: 0.25rem;">';
        echo 'Tipo: ' . $column['type'];
        if ($column['length']) {
            echo ' (' . $column['length'] . ')';
        }
        if ($column['null']) {
            echo ' | Permite NULL';
        }
        if ($column['default'] !== null) {
            echo ' | Por defecto: ' . htmlspecialchars($column['default']);
        }
        echo '</div>';
        
        echo '</div>';
    }
    
    echo '</div>';
    
    // Botones del formulario
    echo '<div class="form-actions">';
    echo '<div class="d-flex justify-content-between">';
    echo '<button type="button" class="btn btn-secondary" onclick="loadTable(\'' . $tableName . '\')">';
    echo '<i class="fas fa-times"></i> Cancelar';
    echo '</button>';
    echo '<button type="submit" class="btn btn-primary">';
    echo '<i class="fas fa-save"></i> ' . $submitText;
    echo '</button>';
    echo '</div>';
    echo '</div>';
    
    echo '</form>';
    echo '</div>';
    
    // JavaScript para el formulario
    echo '<script>';
    echo 'document.getElementById("edit-form").addEventListener("submit", function(e) {';
    echo '    e.preventDefault();';
    echo '    submitEditForm();';
    echo '});';
    
    echo 'function submitEditForm() {';
    echo '    const form = document.getElementById("edit-form");';
    echo '    const formData = new FormData(form);';
    echo '    ';
    echo '    // Mostrar spinner en el botón';
    echo '    const submitBtn = form.querySelector("button[type=submit]");';
    echo '    const originalText = submitBtn.innerHTML;';
    echo '    submitBtn.innerHTML = "<i class=\"fas fa-spinner fa-spin\"></i> Guardando...";';
    echo '    submitBtn.disabled = true;';
    echo '    ';
    echo '    fetch("api/update.php", {';
    echo '        method: "POST",';
    echo '        body: formData,';
    echo '        headers: {';
    echo '            "X-Requested-With": "XMLHttpRequest"';
    echo '        }';
    echo '    })';
    echo '    .then(response => response.json())';
    echo '    .then(data => {';
    echo '        submitBtn.innerHTML = originalText;';
    echo '        submitBtn.disabled = false;';
    echo '        ';
    echo '        if (data.success) {';
    echo '            showAlert("success", data.message || "Registro guardado correctamente");';
    echo '            // Volver a la tabla después de un breve delay';
    echo '            setTimeout(() => {';
    echo '                loadTable("' . $tableName . '");';
    echo '            }, 1500);';
    echo '        } else {';
    echo '            showAlert("danger", data.message || "Error al guardar el registro");';
    echo '        }';
    echo '    })';
    echo '    .catch(error => {';
    echo '        submitBtn.innerHTML = originalText;';
    echo '        submitBtn.disabled = false;';
    echo '        console.error("Error:", error);';
    echo '        showAlert("danger", "Error de conexión al guardar el registro");';
    echo '    });';
    echo '}';
    echo '</script>';
}

/**
 * Generar campo de formulario según tipo de columna
 */
function generateFormField($column, $value, $readonly) {
    $fieldId = 'field_' . $column['name'];
    $fieldName = $column['name'];
    $required = !$column['null'] && !$readonly ? 'required' : '';
    $readonlyAttr = $readonly ? 'readonly' : '';
    $value = htmlspecialchars($value ?? '');
    
    switch ($column['type']) {
        case 'text':
        case 'longtext':
        case 'mediumtext':
            return '<textarea class="form-control" id="' . $fieldId . '" name="' . $fieldName . '" rows="4" ' . $required . ' ' . $readonlyAttr . '>' . $value . '</textarea>';
        
        case 'int':
        case 'bigint':
        case 'smallint':
        case 'tinyint':
            $max = $column['length'] ? 'max="' . str_repeat('9', $column['length']) . '"' : '';
            return '<input type="number" class="form-control" id="' . $fieldId . '" name="' . $fieldName . '" value="' . $value . '" ' . $required . ' ' . $readonlyAttr . ' ' . $max . '>';
        
        case 'decimal':
        case 'float':
        case 'double':
            return '<input type="number" step="0.01" class="form-control" id="' . $fieldId . '" name="' . $fieldName . '" value="' . $value . '" ' . $required . ' ' . $readonlyAttr . '>';
        
        case 'date':
            return '<input type="date" class="form-control" id="' . $fieldId . '" name="' . $fieldName . '" value="' . $value . '" ' . $required . ' ' . $readonlyAttr . '>';
        
        case 'datetime':
        case 'timestamp':
            // Convertir formato para input datetime-local
            if ($value && !$readonly) {
                $datetime = new DateTime($value);
                $value = $datetime->format('Y-m-d\TH:i');
            }
            return '<input type="datetime-local" class="form-control" id="' . $fieldId . '" name="' . $fieldName . '" value="' . $value . '" ' . $required . ' ' . $readonlyAttr . '>';
        
        case 'enum':
            // Para campos ENUM, necesitaríamos obtener los valores posibles
            // Por simplicidad, usamos un input text
            return '<input type="text" class="form-control" id="' . $fieldId . '" name="' . $fieldName . '" value="' . $value . '" ' . $required . ' ' . $readonlyAttr . '>';
        
        case 'boolean':
        case 'tinyint':
            if ($column['length'] == 1) {
                $checked = ($value == 1) ? 'checked' : '';
                return '<div class="form-check"><input type="checkbox" class="form-check-input" id="' . $fieldId . '" name="' . $fieldName . '" value="1" ' . $checked . ' ' . $readonlyAttr . '><label class="form-check-label" for="' . $fieldId . '">Activado</label></div>';
            }
            // Si no es boolean, caer al default
        
        default:
            $maxlength = $column['length'] ? 'maxlength="' . $column['length'] . '"' : '';
            return '<input type="text" class="form-control" id="' . $fieldId . '" name="' . $fieldName . '" value="' . $value . '" ' . $required . ' ' . $readonlyAttr . ' ' . $maxlength . '>';
    }
}

/**
 * Formatear nombre de tabla para mostrar
 */
function formatTableName($tableName) {
    $formatted = str_replace('_', ' ', $tableName);
    $formatted = ucwords($formatted);
    
    $replacements = [
        'Api Keys' => 'Claves API',
        'Blog Posts' => 'Artículos del Blog',
        'Content Creations' => 'Creaciones de Contenido',
        'User Profiles' => 'Perfiles de Usuario',
        'User Activity' => 'Actividad de Usuarios',
        'User Sessions' => 'Sesiones de Usuario',
        'Social Posts' => 'Publicaciones Sociales',
        'Social Likes' => 'Me Gusta',
        'Social Follows' => 'Seguidores',
        'Social Comments' => 'Comentarios Sociales'
    ];
    
    return $replacements[$formatted] ?? $formatted;
}
?>
