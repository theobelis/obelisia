<?php
require_once '../config/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once '../../src/Database/Database.php';

use ObelisIA\Database\Database;

// Configurar cabeceras para JSON
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');

// Manejar preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

start_admin_session();

// Verificar autenticación de admin
if (!isAdminAuthenticated()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

// Verificar que sea una petición AJAX
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || $_SERVER['HTTP_X_REQUESTED_WITH'] !== 'XMLHttpRequest') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Solo peticiones AJAX']);
    exit;
}

try {
    $database = new Database();
    $conn = $database->getConnection();

    $tableName = $_POST['table'] ?? '';
    $mode = $_POST['mode'] ?? 'edit';
    $recordId = $_POST['id'] ?? '';

    if (empty($tableName)) {
        throw new Exception('Nombre de tabla requerido');
    }

    if ($mode === 'edit' && empty($recordId)) {
        throw new Exception('ID de registro requerido para edición');
    }

    // Validar que la tabla exista
    $tablesQuery = "SHOW TABLES LIKE :table";
    $tablesStmt = $conn->prepare($tablesQuery);
    $tablesStmt->execute([':table' => $tableName]);
    
    if ($tablesStmt->rowCount() === 0) {
        throw new Exception('Tabla no encontrada');
    }

    // Obtener estructura de la tabla para validación
    $tableStructure = getTableStructure($conn, $tableName);
    $columns = $tableStructure['columns'];
    $primaryKey = $tableStructure['primary_key'];

    if ($mode === 'edit') {
        // Modo edición
        $setClause = [];
        $bindParams = [];

        // Recorrer los datos del formulario, excluyendo los campos de control
        foreach ($_POST as $key => $value) {
            if (!in_array($key, ['table', 'mode', 'id'])) {
                // Verificar que el campo exista en la tabla
                $fieldExists = false;
                foreach ($columns as $column) {
                    if ($column['name'] === $key) {
                        $fieldExists = true;
                        // No actualizar campos auto-increment o claves primarias
                        if ($column['extra'] === 'auto_increment' || $column['key'] === 'PRI') {
                            break 2; // Salir de ambos loops
                        }
                        break;
                    }
                }
                
                if ($fieldExists) {
                    $setClause[] = "`$key` = :$key";
                    $bindParams[":$key"] = $value === '' ? null : $value;
                }
            }
        }

        if (empty($setClause)) {
            throw new Exception('No hay datos válidos para actualizar');
        }

        $setClauseString = implode(', ', $setClause);
        $query = "UPDATE `$tableName` SET $setClauseString WHERE `$primaryKey` = :id";
        $stmt = $conn->prepare($query);

        // Vincular los parámetros de forma segura
        foreach ($bindParams as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->bindValue(':id', $recordId, PDO::PARAM_INT);

        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            echo json_encode(['success' => true, 'message' => 'Registro actualizado correctamente']);
        } else {
            echo json_encode(['success' => true, 'message' => 'No se realizaron cambios en el registro']);
        }

    } else {
        // Modo agregar
        $fields = [];
        $placeholders = [];
        $bindParams = [];

        // Recorrer los datos del formulario para inserción
        foreach ($_POST as $key => $value) {
            if (!in_array($key, ['table', 'mode'])) {
                // Verificar que el campo exista en la tabla
                $fieldExists = false;
                foreach ($columns as $column) {
                    if ($column['name'] === $key) {
                        $fieldExists = true;
                        // Saltar campos auto-increment
                        if ($column['extra'] === 'auto_increment') {
                            break 2;
                        }
                        break;
                    }
                }
                
                if ($fieldExists) {
                    $fields[] = "`$key`";
                    $placeholders[] = ":$key";
                    $bindParams[":$key"] = $value === '' ? null : $value;
                }
            }
        }

        if (empty($fields)) {
            throw new Exception('No hay datos válidos para insertar');
        }

        $fieldsString = implode(', ', $fields);
        $placeholdersString = implode(', ', $placeholders);
        $query = "INSERT INTO `$tableName` ($fieldsString) VALUES ($placeholdersString)";
        $stmt = $conn->prepare($query);

        // Vincular los parámetros de forma segura
        foreach ($bindParams as $key => $value) {
            $stmt->bindValue($key, $value);
        }

        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            echo json_encode(['success' => true, 'message' => 'Registro creado correctamente']);
        } else {
            throw new Exception('No se pudo crear el registro');
        }
    }

} catch (Exception $e) {
    error_log("Error en API update: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}

/**
 * Obtener estructura de una tabla
 */
function getTableStructure($conn, $tableName) {
    $columnsQuery = "DESCRIBE `{$tableName}`";
    $columnsStmt = $conn->prepare($columnsQuery);
    $columnsStmt->execute();
    $columns = $columnsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    $formattedColumns = [];
    $primaryKey = null;
    
    foreach ($columns as $column) {
        $type = explode('(', $column['Type'])[0];
        $length = null;
        
        if (preg_match('/\((\d+)\)/', $column['Type'], $matches)) {
            $length = $matches[1];
        }
        
        $formattedColumns[] = [
            'name' => $column['Field'],
            'type' => $type,
            'length' => $length,
            'null' => $column['Null'] === 'YES',
            'key' => $column['Key'],
            'default' => $column['Default'],
            'extra' => $column['Extra']
        ];
        
        if ($column['Key'] === 'PRI') {
            $primaryKey = $column['Field'];
        }
    }
    
    return [
        'columns' => $formattedColumns,
        'primary_key' => $primaryKey ?: 'id'
    ];
}
?>
