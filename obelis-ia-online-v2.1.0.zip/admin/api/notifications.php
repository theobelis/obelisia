<?php
/**
 * ObelisIA Admin Notifications API
 * Endpoint para gestión de notificaciones del panel de administración
 */

// Iniciar buffer de salida para capturar cualquier output no deseado
ob_start();

require_once '../config/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once '../../src/Database/Database.php';

use ObelisIA\Database\Database;

// Limpiar cualquier output previo
ob_clean();

// Configurar cabeceras CORS
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');
header('Content-Type: application/json; charset=utf-8');

// Manejar preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

start_admin_session();

// Verificar autenticación de admin
if (!isAdminAuthenticated()) {
    http_response_code(401);
    echo json_encode(['error' => 'No autorizado', 'success' => false]);
    exit;
}

// Verificar que sea una petición AJAX
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || $_SERVER['HTTP_X_REQUESTED_WITH'] !== 'XMLHttpRequest') {
    http_response_code(400);
    echo json_encode(['error' => 'Solo peticiones AJAX permitidas', 'success' => false]);
    exit;
}

try {
    $database = new Database();
    $conn = $database->getConnection();
    
    $method = $_SERVER['REQUEST_METHOD'];
    $adminId = $_SESSION['admin_id'] ?? 1; // Default admin ID
    
    switch ($method) {
        case 'GET':
            handleGetNotifications($conn, $adminId);
            exit;
            
        case 'POST':
            handlePostNotifications($conn, $adminId);
            exit;
            
        default:
            http_response_code(405);
            echo json_encode(['error' => 'Método no permitido', 'success' => false]);
            exit;
    }
    
} catch (Exception $e) {
    error_log("Error en notifications.php: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'error' => 'Error interno del servidor',
        'success' => false,
        'details' => $e->getMessage()
    ]);
    exit;
}

// No debería llegar aquí, pero por seguridad
exit;

/**
 * Manejar peticiones GET - Obtener notificaciones
 */
function handleGetNotifications($conn, $adminId) {
    $action = $_GET['action'] ?? 'list';
    
    switch ($action) {
        case 'count':
            getUnreadCount($conn, $adminId);
            break;
            
        case 'list':
        default:
            getNotifications($conn, $adminId);
            break;
    }
}

/**
 * Manejar peticiones POST - Acciones sobre notificaciones
 */
function handlePostNotifications($conn, $adminId) {
    $input = json_decode(file_get_contents('php://input'), true);
    $action = $input['action'] ?? $_POST['action'] ?? '';
    
    switch ($action) {
        case 'mark_read':
            $notificationId = $input['notification_id'] ?? $_POST['notification_id'] ?? 0;
            markAsRead($conn, $adminId, $notificationId);
            break;
            
        case 'mark_all_read':
            markAllAsRead($conn, $adminId);
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['error' => 'Acción no válida', 'success' => false]);
    }
}

/**
 * Obtener lista de notificaciones
 */
function getNotifications($conn, $adminId) {
    $limit = $_GET['limit'] ?? 10;
    $offset = $_GET['offset'] ?? 0;
    
    $query = "
        SELECT 
            id,
            title,
            message,
            link,
            type,
            icon,
            is_read,
            created_at,
            CASE 
                WHEN created_at >= NOW() - INTERVAL 1 HOUR THEN 'hace unos minutos'
                WHEN created_at >= NOW() - INTERVAL 1 DAY THEN CONCAT(TIMESTAMPDIFF(HOUR, created_at, NOW()), ' horas')
                WHEN created_at >= NOW() - INTERVAL 1 WEEK THEN CONCAT(TIMESTAMPDIFF(DAY, created_at, NOW()), ' días')
                ELSE DATE_FORMAT(created_at, '%d/%m/%Y %H:%i')
            END as time_ago
        FROM admin_notifications 
        WHERE admin_id = :admin_id 
        ORDER BY created_at DESC 
        LIMIT :limit OFFSET :offset
    ";
    
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':admin_id', $adminId, PDO::PARAM_INT);
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    
    $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Formatear las notificaciones
    $formattedNotifications = array_map(function($notification) {
        return [
            'id' => (int)$notification['id'],
            'title' => $notification['title'],
            'message' => $notification['message'],
            'link' => $notification['link'],
            'type' => $notification['type'],
            'icon' => $notification['icon'],
            'is_read' => (bool)$notification['is_read'],
            'time_ago' => $notification['time_ago'],
            'created_at' => $notification['created_at']
        ];
    }, $notifications);
    
    echo json_encode([
        'success' => true,
        'notifications' => $formattedNotifications,
        'count' => count($formattedNotifications)
    ]);
}

/**
 * Obtener conteo de notificaciones no leídas
 */
function getUnreadCount($conn, $adminId) {
    $query = "
        SELECT COUNT(*) as unread_count 
        FROM admin_notifications 
        WHERE admin_id = :admin_id AND is_read = FALSE
    ";
    
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':admin_id', $adminId, PDO::PARAM_INT);
    $stmt->execute();
    
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'unread_count' => (int)$result['unread_count']
    ]);
}

/**
 * Marcar una notificación como leída
 */
function markAsRead($conn, $adminId, $notificationId) {
    if (!$notificationId) {
        http_response_code(400);
        echo json_encode(['error' => 'ID de notificación requerido', 'success' => false]);
        return;
    }
    
    $query = "
        UPDATE admin_notifications 
        SET is_read = TRUE, read_at = NOW() 
        WHERE id = :notification_id AND admin_id = :admin_id
    ";
    
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':notification_id', $notificationId, PDO::PARAM_INT);
    $stmt->bindParam(':admin_id', $adminId, PDO::PARAM_INT);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Notificación marcada como leída']);
    } else {
        throw new Exception('Error al marcar notificación como leída');
    }
}

/**
 * Marcar todas las notificaciones como leídas
 */
function markAllAsRead($conn, $adminId) {
    $query = "
        UPDATE admin_notifications 
        SET is_read = TRUE, read_at = NOW() 
        WHERE admin_id = :admin_id AND is_read = FALSE
    ";
    
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':admin_id', $adminId, PDO::PARAM_INT);
    
    if ($stmt->execute()) {
        $affectedRows = $stmt->rowCount();
        echo json_encode([
            'success' => true, 
            'message' => 'Todas las notificaciones marcadas como leídas',
            'affected_rows' => $affectedRows
        ]);
    } else {
        throw new Exception('Error al marcar todas las notificaciones como leídas');
    }
}

/**
 * Crear una nueva notificación
 */
function createNotification($conn, $adminId, $title, $message, $link = null, $type = 'info', $icon = 'fa-bell') {
    $query = "
        INSERT INTO admin_notifications (admin_id, title, message, link, type, icon) 
        VALUES (:admin_id, :title, :message, :link, :type, :icon)
    ";
    
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':admin_id', $adminId, PDO::PARAM_INT);
    $stmt->bindParam(':title', $title, PDO::PARAM_STR);
    $stmt->bindParam(':message', $message, PDO::PARAM_STR);
    $stmt->bindParam(':link', $link, PDO::PARAM_STR);
    $stmt->bindParam(':type', $type, PDO::PARAM_STR);
    $stmt->bindParam(':icon', $icon, PDO::PARAM_STR);
    
    return $stmt->execute();
}

?>
            handleGetNotifications($conn, $adminId);
            break;
            
        case 'POST':
            handlePostNotifications($conn, $adminId);
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['error' => 'Método no permitido', 'success' => false]);
            break;
    }
    
} catch (Exception $e) {
    error_log("Error en notifications.php: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'error' => 'Error interno del servidor',
        'success' => false,
        'details' => $e->getMessage()
    ]);
}

/**
 * Manejar peticiones GET - Obtener notificaciones
 */
function handleGetNotifications($conn, $adminId) {
    $action = $_GET['action'] ?? 'list';
    
    switch ($action) {
        case 'count':
            getUnreadCount($conn, $adminId);
            break;
            
        case 'list':
        default:
            getNotificationsList($conn, $adminId);
            break;
    }
}

/**
 * Obtener número de notificaciones no leídas
 */
function getUnreadCount($conn, $adminId) {
    $query = "SELECT COUNT(*) as unread_count 
              FROM admin_notifications 
              WHERE admin_id = :admin_id AND is_read = 0";
    
    $stmt = $conn->prepare($query);
    $stmt->execute([':admin_id' => $adminId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'unread_count' => (int)$result['unread_count']
    ]);
}

/**
 * Obtener lista de notificaciones
 */
function getNotificationsList($conn, $adminId) {
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
    $onlyUnread = isset($_GET['unread']) && $_GET['unread'] === 'true';
    
    $whereClause = "WHERE admin_id = :admin_id";
    if ($onlyUnread) {
        $whereClause .= " AND is_read = 0";
    }
    
    $query = "SELECT id, title, message, link, type, icon, is_read, priority, 
                     created_at, read_at,
                     CASE 
                         WHEN created_at >= NOW() - INTERVAL 1 HOUR THEN 'hace pocos minutos'
                         WHEN created_at >= NOW() - INTERVAL 1 DAY THEN CONCAT(TIMESTAMPDIFF(HOUR, created_at, NOW()), ' horas')
                         WHEN created_at >= NOW() - INTERVAL 1 WEEK THEN CONCAT(TIMESTAMPDIFF(DAY, created_at, NOW()), ' días')
                         ELSE DATE_FORMAT(created_at, '%d/%m/%Y %H:%i')
                     END as time_ago
              FROM admin_notifications 
              {$whereClause}
              ORDER BY 
                  CASE priority 
                      WHEN 'urgent' THEN 1 
                      WHEN 'high' THEN 2 
                      WHEN 'medium' THEN 3 
                      WHEN 'low' THEN 4 
                  END,
                  is_read ASC,
                  created_at DESC 
              LIMIT :limit";
    
    $stmt = $conn->prepare($query);
    $stmt->bindValue(':admin_id', $adminId, PDO::PARAM_INT);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    
    $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Formatear las notificaciones
    foreach ($notifications as &$notification) {
        $notification['is_read'] = (bool)$notification['is_read'];
        $notification['created_at'] = date('c', strtotime($notification['created_at'])); // ISO format
        $notification['read_at'] = $notification['read_at'] ? date('c', strtotime($notification['read_at'])) : null;
    }
    
    echo json_encode([
        'success' => true,
        'notifications' => $notifications,
        'total' => count($notifications)
    ]);
}

/**
 * Manejar peticiones POST - Acciones sobre notificaciones
 */
function handlePostNotifications($conn, $adminId) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        http_response_code(400);
        echo json_encode(['error' => 'Datos JSON inválidos', 'success' => false]);
        return;
    }
    
    $action = $input['action'] ?? '';
    
    switch ($action) {
        case 'mark_read':
            markAsRead($conn, $adminId, $input);
            break;
            
        case 'mark_all_read':
            markAllAsRead($conn, $adminId);
            break;
            
        case 'delete':
            deleteNotification($conn, $adminId, $input);
            break;
            
        case 'create':
            createNotification($conn, $adminId, $input);
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['error' => 'Acción no válida', 'success' => false]);
            break;
    }
}

/**
 * Marcar notificación como leída
 */
function markAsRead($conn, $adminId, $input) {
    if (!isset($input['notification_id'])) {
        http_response_code(400);
        echo json_encode(['error' => 'ID de notificación requerido', 'success' => false]);
        return;
    }
    
    $query = "UPDATE admin_notifications 
              SET is_read = 1, read_at = NOW() 
              WHERE id = :id AND admin_id = :admin_id";
    
    $stmt = $conn->prepare($query);
    $result = $stmt->execute([
        ':id' => $input['notification_id'],
        ':admin_id' => $adminId
    ]);
    
    if ($result && $stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => 'Notificación marcada como leída']);
    } else {
        echo json_encode(['success' => false, 'error' => 'No se pudo actualizar la notificación']);
    }
}

/**
 * Marcar todas las notificaciones como leídas
 */
function markAllAsRead($conn, $adminId) {
    $query = "UPDATE admin_notifications 
              SET is_read = 1, read_at = NOW() 
              WHERE admin_id = :admin_id AND is_read = 0";
    
    $stmt = $conn->prepare($query);
    $result = $stmt->execute([':admin_id' => $adminId]);
    
    $updatedCount = $stmt->rowCount();
    
    echo json_encode([
        'success' => true,
        'message' => "Se marcaron {$updatedCount} notificaciones como leídas",
        'updated_count' => $updatedCount
    ]);
}

/**
 * Eliminar notificación
 */
function deleteNotification($conn, $adminId, $input) {
    if (!isset($input['notification_id'])) {
        http_response_code(400);
        echo json_encode(['error' => 'ID de notificación requerido', 'success' => false]);
        return;
    }
    
    $query = "DELETE FROM admin_notifications 
              WHERE id = :id AND admin_id = :admin_id";
    
    $stmt = $conn->prepare($query);
    $result = $stmt->execute([
        ':id' => $input['notification_id'],
        ':admin_id' => $adminId
    ]);
    
    if ($result && $stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => 'Notificación eliminada']);
    } else {
        echo json_encode(['success' => false, 'error' => 'No se pudo eliminar la notificación']);
    }
}

/**
 * Crear nueva notificación
 */
function createNotification($conn, $adminId, $input) {
    $required = ['title', 'message'];
    foreach ($required as $field) {
        if (!isset($input[$field]) || empty($input[$field])) {
            http_response_code(400);
            echo json_encode(['error' => "Campo {$field} requerido", 'success' => false]);
            return;
        }
    }
    
    $query = "INSERT INTO admin_notifications 
              (admin_id, title, message, link, type, icon, priority) 
              VALUES (:admin_id, :title, :message, :link, :type, :icon, :priority)";
    
    $stmt = $conn->prepare($query);
    $result = $stmt->execute([
        ':admin_id' => $input['target_admin_id'] ?? $adminId,
        ':title' => $input['title'],
        ':message' => $input['message'],
        ':link' => $input['link'] ?? null,
        ':type' => $input['type'] ?? 'info',
        ':icon' => $input['icon'] ?? 'fas fa-info-circle',
        ':priority' => $input['priority'] ?? 'medium'
    ]);
    
    if ($result) {
        $notificationId = $conn->lastInsertId();
        echo json_encode([
            'success' => true,
            'message' => 'Notificación creada exitosamente',
            'notification_id' => $notificationId
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => 'No se pudo crear la notificación']);
    }
}

/**
 * Función helper para crear notificaciones desde otros archivos
 */
function createAdminNotification($title, $message, $link = null, $type = 'info', $icon = 'fas fa-info-circle', $priority = 'medium', $adminId = 1) {
    try {
        $database = new Database();
        $conn = $database->getConnection();
        
        $query = "INSERT INTO admin_notifications 
                  (admin_id, title, message, link, type, icon, priority) 
                  VALUES (:admin_id, :title, :message, :link, :type, :icon, :priority)";
        
        $stmt = $conn->prepare($query);
        return $stmt->execute([
            ':admin_id' => $adminId,
            ':title' => $title,
            ':message' => $message,
            ':link' => $link,
            ':type' => $type,
            ':icon' => $icon,
            ':priority' => $priority
        ]);
    } catch (Exception $e) {
        error_log("Error creando notificación: " . $e->getMessage());
        return false;
    }
}

// Finalizar buffer de salida
ob_end_flush();
?>
