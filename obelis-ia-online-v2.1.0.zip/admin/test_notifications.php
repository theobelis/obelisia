<?php
session_start();

// Verificar que está logueado como admin
if (!isset($_SESSION['admin_id'])) {
    die('Debe estar logueado como administrador');
}

require_once '../src/Database/Database.php';
require_once 'includes/functions.php';

use ObelisIA\Database\Database;

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    $adminId = $_SESSION['admin_id'];
    
    // Crear notificaciones de prueba
    $notifications = [
        [
            'title' => 'Nuevo usuario registrado',
            'message' => 'Juan Pérez se ha registrado en la plataforma',
            'type' => 'user_registration',
            'priority' => 'medium'
        ],
        [
            'title' => 'Pago recibido',
            'message' => 'Se ha recibido un pago de $29.99 de usuario premium',
            'type' => 'payment_received',
            'priority' => 'high'
        ],
        [
            'title' => 'Error del sistema',
            'message' => 'Se detectó un error en el módulo de procesamiento de imágenes',
            'type' => 'system_error',
            'priority' => 'urgent'
        ],
        [
            'title' => 'Reporte generado',
            'message' => 'El reporte mensual de actividad ha sido generado exitosamente',
            'type' => 'report_generated',
            'priority' => 'low'
        ],
        [
            'title' => 'Mantenimiento programado',
            'message' => 'El mantenimiento del servidor está programado para mañana a las 2:00 AM',
            'type' => 'info',
            'priority' => 'medium'
        ]
    ];
    
    foreach ($notifications as $notif) {
        createAdminNotification(
            $adminId,
            $notif['title'],
            $notif['message'],
            $notif['type'],
            null,
            $notif['priority']
        );
    }
    
    echo "✅ Se han creado " . count($notifications) . " notificaciones de prueba\n";
    echo "<br><a href='index.php'>← Volver al admin</a>";
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage();
}
?>
