<?php
/**
 * Sistema de autenticación para el panel de administración
 */

/**
 * Verifica si un administrador está autenticado
 * @return bool True si está autenticado, false en caso contrario
 */
function isAdminAuthenticated() {
    // Asegurar que la sesión esté iniciada
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    // Verificar si existe la sesión de admin y está activa
    if (!isset($_SESSION['admin_id']) || !isset($_SESSION['admin_username'])) {
        return false;
    }
    
    // Verificar timeout de sesión
    if (isset($_SESSION['admin_last_activity'])) {
        if ((time() - $_SESSION['admin_last_activity']) > ADMIN_SESSION_TIMEOUT) {
            // La sesión ha expirado
            destroyAdminSession();
            return false;
        }
    }
    
    // Actualizar última actividad
    $_SESSION['admin_last_activity'] = time();
    
    return true;
}

/**
 * Autentica a un administrador
 * @param string $username Nombre de usuario
 * @param string $password Contraseña
 * @return bool True si la autenticación es exitosa
 */
function authenticateAdmin($username, $password) {
    global $pdo;
    
    try {
        // Buscar al usuario admin
        $stmt = $pdo->prepare("
            SELECT id, username, password, full_name, email, last_login, status 
            FROM users 
            WHERE username = ? AND role = 'admin' AND status = 'active'
        ");
        $stmt->execute([$username]);
        $admin = $stmt->fetch();
        
        if (!$admin) {
            return false;
        }
        
        // Verificar contraseña
        if (!password_verify($password, $admin['password'])) {
            return false;
        }
        
        // Crear sesión de admin
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_username'] = $admin['username'];
        $_SESSION['admin_full_name'] = $admin['full_name'];
        $_SESSION['admin_email'] = $admin['email'];
        $_SESSION['admin_last_activity'] = time();
        $_SESSION['admin_login_time'] = time();
        
        // Actualizar último login
        $stmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
        $stmt->execute([$admin['id']]);
        
        // Log de actividad
        logAdminActivity($admin['id'], 'login', 'Inicio de sesión exitoso');
        
        return true;
        
    } catch (PDOException $e) {
        error_log("Error en authenticateAdmin: " . $e->getMessage());
        return false;
    }
}

/**
 * Destruye la sesión de administrador
 */
function destroyAdminSession() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    // Log de actividad antes de destruir la sesión
    if (isset($_SESSION['admin_id'])) {
        logAdminActivity($_SESSION['admin_id'], 'logout', 'Cierre de sesión');
    }
    
    // Limpiar variables de sesión del admin
    unset($_SESSION['admin_id']);
    unset($_SESSION['admin_username']);
    unset($_SESSION['admin_full_name']);
    unset($_SESSION['admin_email']);
    unset($_SESSION['admin_last_activity']);
    unset($_SESSION['admin_login_time']);
    
    // Si solo quedan variables de admin, destruir la sesión completamente
    if (empty($_SESSION)) {
        session_destroy();
    }
}

/**
 * Obtiene información del administrador autenticado
 * @return array|null Información del admin o null si no está autenticado
 */
function getAuthenticatedAdmin() {
    if (!isAdminAuthenticated()) {
        return null;
    }
    
    return [
        'id' => $_SESSION['admin_id'],
        'username' => $_SESSION['admin_username'],
        'full_name' => $_SESSION['admin_full_name'] ?? $_SESSION['admin_username'],
        'email' => $_SESSION['admin_email'] ?? '',
        'login_time' => $_SESSION['admin_login_time'] ?? time(),
        'last_activity' => $_SESSION['admin_last_activity'] ?? time()
    ];
}

/**
 * Verifica si el admin tiene permisos específicos
 * @param string $permission Permiso a verificar
 * @return bool True si tiene el permiso
 */
function hasAdminPermission($permission) {
    // Por ahora, todos los admins tienen todos los permisos
    // En el futuro se puede implementar un sistema de roles más granular
    return isAdminAuthenticated();
}

/**
 * Verifica autenticación de admin o redirige al login
 * Alias para requireAdminAuth() para compatibilidad
 */
function check_admin_auth() {
    requireAdminAuth();
}

/**
 * Requiere autenticación de admin o redirige al login
 */
function requireAdminAuth() {
    if (!isAdminAuthenticated()) {
        header('Location: ' . admin_url('auth/login.php'));
        exit;
    }
}

/**
 * Registra actividad del administrador
 * @param int $admin_id ID del administrador
 * @param string $action Acción realizada
 * @param string $description Descripción de la acción
 */
function logAdminActivity($admin_id, $action, $description = '') {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO activity_logs (user_id, action, description, ip_address, user_agent, created_at)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
        
        $stmt->execute([$admin_id, $action, $description, $ip, $user_agent]);
        
    } catch (PDOException $e) {
        error_log("Error en logAdminActivity: " . $e->getMessage());
    }
}

/**
 * Genera token CSRF para formularios
 * @return string Token CSRF
 */
function generateCSRFToken() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    $token = bin2hex(random_bytes(32));
    $_SESSION['csrf_token'] = $token;
    $_SESSION['csrf_token_time'] = time();
    
    return $token;
}

/**
 * Verifica token CSRF
 * @param string $token Token a verificar
 * @return bool True si el token es válido
 */
function verifyCSRFToken($token) {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    if (!isset($_SESSION['csrf_token']) || !isset($_SESSION['csrf_token_time'])) {
        return false;
    }
    
    // Verificar expiración del token
    if ((time() - $_SESSION['csrf_token_time']) > CSRF_TOKEN_EXPIRY) {
        unset($_SESSION['csrf_token']);
        unset($_SESSION['csrf_token_time']);
        return false;
    }
    
    return hash_equals($_SESSION['csrf_token'], $token);
}
?>
