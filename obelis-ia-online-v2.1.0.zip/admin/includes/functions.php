<?php
/**
 * Funciones generales del panel de administración
 */

/**
 * Función para generar rutas correctas basadas en la ubicación actual
 */
function admin_url($path = '') {
    // Obtener el nivel de profundidad desde /admin/
    $script_path = $_SERVER['SCRIPT_NAME'];
    $admin_pos = strpos($script_path, '/admin/');
    
    if ($admin_pos === false) {
        return '/admin/' . ltrim($path, '/');
    }
    
    // Contar niveles después de /admin/
    $after_admin = substr($script_path, $admin_pos + 7); // +7 para "/admin/"
    $levels = substr_count($after_admin, '/');
    
    // Generar la ruta relativa correcta
    $base = str_repeat('../', $levels);
    return $base . ltrim($path, '/');
}

/**
 * Obtener estadísticas del dashboard
 */
function getDashboardStats() {
    global $pdo;
    
    $stats = [];
    
    try {
        // Total de usuarios
        $stmt = $pdo->query("SELECT COUNT(*) FROM users");
        $stats['total_users'] = $stmt->fetchColumn();
        
        // Nuevos usuarios hoy
        $stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE DATE(created_at) = CURDATE()");
        $stats['new_users_today'] = $stmt->fetchColumn();
        
        // Total de creaciones (proyectos studio)
        $stmt = $pdo->query("SELECT COUNT(*) FROM obelis_studio_projects");
        $stats['total_creations'] = $stmt->fetchColumn();
        
        // Nuevas creaciones hoy
        $stmt = $pdo->query("SELECT COUNT(*) FROM obelis_studio_projects WHERE DATE(created_at) = CURDATE()");
        $stats['new_creations_today'] = $stmt->fetchColumn();
        
        // Ingresos totales
        $stmt = $pdo->query("SELECT COALESCE(SUM(monto), 0) FROM movimientos_financieros WHERE tipo = 'ingreso'");
        $stats['total_revenue'] = $stmt->fetchColumn();
        
        // Ingresos de hoy
        $stmt = $pdo->query("SELECT COALESCE(SUM(monto), 0) FROM movimientos_financieros WHERE tipo = 'ingreso' AND DATE(fecha) = CURDATE()");
        $stats['revenue_today'] = $stmt->fetchColumn();
        
        // Actividad de hoy
        $stmt = $pdo->query("SELECT COUNT(*) FROM activity_logs WHERE DATE(created_at) = CURDATE()");
        $stats['activity_today'] = $stmt->fetchColumn();
        
        // Actividad reciente
        $stmt = $pdo->query("
            SELECT action, description, created_at 
            FROM activity_logs 
            WHERE description IS NOT NULL 
            ORDER BY created_at DESC 
            LIMIT 10
        ");
        $stats['recent_activity'] = $stmt->fetchAll();
        
        // Reportes pendientes (usando content_reports si existe)
        $stmt = $pdo->query("
            SELECT 'Reporte' as type, 'Contenido reportado' as description, 'high' as priority, created_at 
            FROM content_reports 
            WHERE status = 'pending' 
            ORDER BY created_at DESC 
            LIMIT 5
        ");
        $stats['pending_reports'] = $stmt->fetchAll();
        
        return $stats;
        
    } catch (PDOException $e) {
        error_log("Error obteniendo estadísticas: " . $e->getMessage());
        return [
            'total_users' => 0,
            'new_users_today' => 0,
            'total_creations' => 0,
            'new_creations_today' => 0,
            'total_revenue' => 0,
            'revenue_today' => 0,
            'activity_today' => 0,
            'recent_activity' => [],
            'pending_reports' => []
        ];
    }
}

/**
 * Obtener icono para tipo de actividad
 */
function getActivityIcon($action) {
    $icons = [
        'login' => 'sign-in-alt',
        'logout' => 'sign-out-alt',
        'create' => 'plus-circle',
        'edit' => 'edit',
        'delete' => 'trash',
        'view' => 'eye',
        'upload' => 'upload',
        'download' => 'download',
        'payment' => 'credit-card',
        'register' => 'user-plus',
        'Navegación' => 'mouse-pointer',
        'Guardado de creación' => 'save',
        'Uso de herramienta' => 'magic',
        'Búsqueda' => 'search'
    ];
    
    return $icons[$action] ?? 'circle';
}

/**
 * Formatear tiempo relativo
 */
function timeAgo($datetime) {
    $time = time() - strtotime($datetime);
    
    if ($time < 60) return 'hace unos segundos';
    if ($time < 3600) return 'hace ' . floor($time/60) . ' minutos';
    if ($time < 86400) return 'hace ' . floor($time/3600) . ' horas';
    if ($time < 2592000) return 'hace ' . floor($time/86400) . ' días';
    if ($time < 31536000) return 'hace ' . floor($time/2592000) . ' meses';
    
    return 'hace ' . floor($time/31536000) . ' años';
}

/**
 * Sanitizar entrada de usuario (maneja valores null)
 */
function sanitize_input($data) {
    if ($data === null) {
        return '';
    }
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

/**
 * Función segura para htmlspecialchars que maneja null
 */
function safe_html($data, $default = '') {
    if ($data === null) {
        return $default;
    }
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

/**
 * Función segura para strpos que maneja null
 */
function safe_strpos($haystack, $needle) {
    if ($haystack === null || $needle === null) {
        return false;
    }
    return strpos($haystack, $needle);
}

/**
 * Validar email
 */
function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

/**
 * Generar paginación
 */
function generatePagination($current_page, $total_pages, $base_url) {
    $pagination = '<div class="pagination">';
    
    // Botón anterior
    if ($current_page > 1) {
        $prev_page = $current_page - 1;
        $pagination .= "<a href='{$base_url}?page={$prev_page}' class='pagination-btn'><i class='fas fa-chevron-left'></i></a>";
    }
    
    // Números de página
    $start = max(1, $current_page - 2);
    $end = min($total_pages, $current_page + 2);
    
    if ($start > 1) {
        $pagination .= "<a href='{$base_url}?page=1' class='pagination-num'>1</a>";
        if ($start > 2) {
            $pagination .= "<span class='pagination-dots'>...</span>";
        }
    }
    
    for ($i = $start; $i <= $end; $i++) {
        $active = ($i == $current_page) ? 'active' : '';
        $pagination .= "<a href='{$base_url}?page={$i}' class='pagination-num {$active}'>{$i}</a>";
    }
    
    if ($end < $total_pages) {
        if ($end < $total_pages - 1) {
            $pagination .= "<span class='pagination-dots'>...</span>";
        }
        $pagination .= "<a href='{$base_url}?page={$total_pages}' class='pagination-num'>{$total_pages}</a>";
    }
    
    // Botón siguiente
    if ($current_page < $total_pages) {
        $next_page = $current_page + 1;
        $pagination .= "<a href='{$base_url}?page={$next_page}' class='pagination-btn'><i class='fas fa-chevron-right'></i></a>";
    }
    
    $pagination .= '</div>';
    
    return $pagination;
}

/**
 * Formatear bytes a tamaño legible
 */
function formatBytes($size, $precision = 2) {
    if ($size > 0) {
        $size = (int) $size;
        $base = log($size) / log(1024);
        $suffixes = array(' bytes', ' KB', ' MB', ' GB', ' TB');
        return round(pow(1024, $base - floor($base)), $precision) . $suffixes[floor($base)];
    }
    return $size;
}

/**
 * Generar token único
 */
function generateToken($length = 32) {
    return bin2hex(random_bytes($length));
}

/**
 * Validar archivo subido
 */
function validateUpload($file, $allowed_types = [], $max_size = null) {
    if (!isset($file['tmp_name']) || $file['error'] !== UPLOAD_ERR_OK) {
        return false;
    }
    
    if ($max_size && $file['size'] > $max_size) {
        return false;
    }
    
    if (!empty($allowed_types)) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime_type = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        
        if (!in_array($mime_type, $allowed_types)) {
            return false;
        }
    }
    
    return true;
}

/**
 * Crear mensaje de notificación
 */
function setFlashMessage($type, $message) {
    $_SESSION['flash_message'] = [
        'type' => $type,
        'message' => $message
    ];
}

/**
 * Obtener y limpiar mensaje de notificación
 */
function getFlashMessage() {
    if (isset($_SESSION['flash_message'])) {
        $message = $_SESSION['flash_message'];
        unset($_SESSION['flash_message']);
        return $message;
    }
    return null;
}

/**
 * Exportar datos a CSV
 */
function exportToCSV($data, $filename, $headers = []) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $output = fopen('php://output', 'w');
    
    if (!empty($headers)) {
        fputcsv($output, $headers);
    }
    
    foreach ($data as $row) {
        fputcsv($output, $row);
    }
    
    fclose($output);
    exit;
}

/**
 * Obtener información de tabla
 */
function getTableInfo($table_name) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("DESCRIBE {$table_name}");
        $stmt->execute();
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        return [];
    }
}

/**
 * Obtener todas las tablas de la base de datos
 */
function getAllTables() {
    global $pdo;
    
    try {
        $stmt = $pdo->query("SHOW TABLES");
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (PDOException $e) {
        return [];
    }
}

/**
 * Validar fecha
 */
function validateDate($date, $format = 'Y-m-d') {
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
}

/**
 * Logs de errores personalizados
 */
function logError($message, $context = []) {
    $log_message = date('[Y-m-d H:i:s] ') . $message;
    if (!empty($context)) {
        $log_message .= ' Context: ' . json_encode($context);
    }
    $log_message .= PHP_EOL;
    
    error_log($log_message, 3, LOGS_PATH . '/admin_errors.log');
}

/**
 * SISTEMA DE NOTIFICACIONES PARA ADMIN
 */

/**
 * Crear notificación de administrador
 */
function createAdminNotification($title, $message, $link = null, $type = 'info', $icon = 'fas fa-info-circle', $priority = 'medium', $adminId = 1) {
    try {
        require_once __DIR__ . '/../../src/Database/Database.php';
        
        $database = new ObelisIA\Database\Database();
        $conn = $database->getConnection();
        
        $query = "INSERT INTO admin_notifications 
                  (admin_id, title, message, link, type, icon, priority) 
                  VALUES (:admin_id, :title, :message, :link, :type, :icon, :priority)";
        
        $stmt = $conn->prepare($query);
        return $stmt->execute([
            ':admin_id' => $adminId,
            ':title' => $title,
            ':message' => $message,
            ':link' => $link,
            ':type' => $type,
            ':icon' => $icon,
            ':priority' => $priority
        ]);
    } catch (Exception $e) {
        error_log("Error creando notificación: " . $e->getMessage());
        return false;
    }
}

/**
 * Registrar actividad del admin y crear notificación si es necesario
 */
function logAdminActivityWithNotification($action, $details = '', $createNotification = false, $notificationTitle = '', $notificationMessage = '') {
    try {
        // Usar la función existente logAdminActivity de auth.php
        if (function_exists('logAdminActivity') && isset($_SESSION['admin_id'])) {
            logAdminActivity($_SESSION['admin_id'], $action, $details);
        } else {
            // Log básico si no está disponible la función principal
            logError("Admin Activity: {$action} - {$details}");
        }
        
        // Crear notificación si se solicita
        if ($createNotification && !empty($notificationTitle)) {
            $finalMessage = !empty($notificationMessage) ? $notificationMessage : $details;
            
            // Determinar tipo e icono basado en la acción
            $type = 'info';
            $icon = 'fas fa-info-circle';
            $priority = 'medium';
            
            if (stripos($action, 'error') !== false || stripos($action, 'fail') !== false) {
                $type = 'error';
                $icon = 'fas fa-exclamation-triangle';
                $priority = 'high';
            } elseif (stripos($action, 'success') !== false || stripos($action, 'complete') !== false) {
                $type = 'success';
                $icon = 'fas fa-check-circle';
                $priority = 'low';
            } elseif (stripos($action, 'warning') !== false || stripos($action, 'alert') !== false) {
                $type = 'warning';
                $icon = 'fas fa-exclamation-triangle';
                $priority = 'high';
            }
            
            createAdminNotification($notificationTitle, $finalMessage, null, $type, $icon, $priority);
        }
        
        return true;
    } catch (Exception $e) {
        error_log("Error en logAdminActivityWithNotification: " . $e->getMessage());
        return false;
    }
}

/**
 * Ejemplos de uso del sistema de notificaciones
 */

/**
 * Notificar nuevo usuario registrado
 */
function notifyNewUserRegistered($userEmail, $userId) {
    createAdminNotification(
        'Nuevo usuario registrado',
        "Se ha registrado un nuevo usuario: {$userEmail}",
        "#users",
        'info',
        'fas fa-user-plus',
        'medium'
    );
}

/**
 * Notificar error del sistema
 */
function notifySystemError($errorMessage, $context = '') {
    $message = "Error del sistema: {$errorMessage}";
    if ($context) {
        $message .= " | Contexto: {$context}";
    }
    
    createAdminNotification(
        'Error del sistema',
        $message,
        "#system_logs",
        'error',
        'fas fa-bug',
        'urgent'
    );
}

/**
 * Notificar nuevo pago recibido
 */
function notifyNewPayment($amount, $userId, $paymentId) {
    createAdminNotification(
        'Pago recibido',
        "Se ha procesado un nuevo pago de \${$amount} del usuario ID: {$userId}",
        "#payments",
        'success',
        'fas fa-dollar-sign',
        'medium'
    );
}

/**
 * Notificar contenido reportado
 */
function notifyContentReported($contentType, $contentId, $reason) {
    createAdminNotification(
        'Contenido reportado',
        "Se ha reportado {$contentType} (ID: {$contentId}) por: {$reason}",
        "#reports",
        'warning',
        'fas fa-flag',
        'high'
    );
}

/**
 * Funciones para generar notificaciones automáticas específicas
 */

/**
 * Notificar cuando un nuevo usuario se registra
 */
function notifyNewUserRegistration($userId, $username, $email) {
    $title = "Nuevo usuario registrado";
    $message = "El usuario {$username} se ha registrado en la plataforma";
    
    createAdminNotification(
        $title,
        $message,
        "users",
        'success',
        'fas fa-user-plus'
    );
    
    // Log de la actividad
    logAdminActivity('new_user_notification', "Notificación enviada: {$title} - {$username}");
}

/**
 * Notificar cuando un usuario se hace premium
 */
function notifyUserUpgradeToPremium($userId, $username, $subscriptionType = 'Premium') {
    $title = "¡Nuevo usuario Premium!";
    $message = "{$username} ha adquirido una suscripción {$subscriptionType}";
    
    createAdminNotification(
        $title,
        $message,
        "subscriptions",
        'success',
        'fas fa-crown'
    );
    
    // Log de la actividad
    logAdminActivity('premium_upgrade_notification', "Notificación enviada: {$title} - {$username}");
}

/**
 * Función helper para crear notificaciones de prueba (solo para desarrollo)
 */
function createTestNotifications() {
    // Solo crear en desarrollo
    if (isset($_ENV['APP_ENV']) && $_ENV['APP_ENV'] !== 'development') {
        return;
    }
    
    $testNotifications = [
        [
            'title' => 'Sistema iniciado',
            'message' => 'El panel de administración se ha iniciado correctamente',
            'link' => '#dashboard',
            'type' => 'success',
            'icon' => 'fas fa-check-circle'
        ],
        [
            'title' => 'Nuevo usuario registrado',
            'message' => 'María García se ha registrado en la plataforma hace 5 minutos',
            'link' => 'users',
            'type' => 'success',
            'icon' => 'fas fa-user-plus'
        ],
        [
            'title' => 'Usuario Premium',
            'message' => 'Juan Pérez ha adquirido una suscripción Premium hace 15 minutos',
            'link' => 'subscriptions',
            'type' => 'success',
            'icon' => 'fas fa-crown'
        ],
        [
            'title' => 'Pago recibido',
            'message' => 'Se ha recibido un pago de $29.99 hace 1 hora',
            'link' => 'payments',
            'type' => 'success',
            'icon' => 'fas fa-dollar-sign'
        ]
    ];
    
    foreach ($testNotifications as $notification) {
        createAdminNotification(
            $notification['title'],
            $notification['message'],
            $notification['link'],
            $notification['type'],
            $notification['icon']
        );
    }
}
?>
