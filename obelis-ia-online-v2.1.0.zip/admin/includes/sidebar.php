<aside class="admin-sidebar" id="adminSidebar">
    <nav class="sidebar-nav">
        <div class="nav-section">
            <h3>Principal</h3>
            <ul>
                <li class="<?php echo ($current_page == 'dashboard') ? 'active' : ''; ?>">
                    <a href="<?php echo admin_url('index.php'); ?>">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
            </ul>
        </div>

        <div class="nav-section">
            <h3>Usuarios</h3>
            <ul>
                <li class="<?php echo ($current_page == 'users') ? 'active' : ''; ?>">
                    <a href="<?php echo admin_url('modules/users/users.php'); ?>">
                        <i class="fas fa-users"></i>
                        <span>Gestión de Usuarios</span>
                    </a>
                </li>
                <li class="<?php echo ($current_page == 'activity') ? 'active' : ''; ?>">
                    <a href="<?php echo admin_url('modules/users/activity.php'); ?>">
                        <i class="fas fa-history"></i>
                        <span>Logs de Actividad</span>
                    </a>
                </li>
            </ul>
        </div>

        <div class="nav-section">
            <h3>Contenido</h3>
            <ul>
                <li class="<?php echo ($current_page == 'creations') ? 'active' : ''; ?>">
                    <a href="<?php echo admin_url('modules/content/creations.php'); ?>">
                        <i class="fas fa-palette"></i>
                        <span>Creaciones de Usuario</span>
                    </a>
                </li>
                <li class="<?php echo ($current_page == 'projects') ? 'active' : ''; ?>">
                    <a href="<?php echo admin_url('modules/content/projects.php'); ?>">
                        <i class="fas fa-project-diagram"></i>
                        <span>Proyectos Studio</span>
                    </a>
                </li>
                <li class="<?php echo ($current_page == 'social') ? 'active' : ''; ?>">
                    <a href="<?php echo admin_url('modules/content/social.php'); ?>">
                        <i class="fas fa-share-alt"></i>
                        <span>Red Social</span>
                    </a>
                </li>
                <li class="<?php echo ($current_page == 'comments') ? 'active' : ''; ?>">
                    <a href="<?php echo admin_url('modules/content/comments.php'); ?>">
                        <i class="fas fa-comments"></i>
                        <span>Comentarios</span>
                    </a>
                </li>
                <li class="<?php echo ($current_page == 'reports') ? 'active' : ''; ?>">
                    <a href="<?php echo admin_url('modules/content/reports.php'); ?>">
                        <i class="fas fa-flag"></i>
                        <span>Reportes de Contenido</span>
                    </a>
                </li>
                <li class="<?php echo ($current_page == 'blog') ? 'active' : ''; ?>">
                    <a href="<?php echo admin_url('modules/content/blog.php'); ?>">
                        <i class="fas fa-blog"></i>
                        <span>Blog Posts</span>
                    </a>
                </li>
            </ul>
        </div>

        <div class="nav-section">
            <h3>Finanzas</h3>
            <ul>
                <li class="<?php echo ($current_page == 'credits') ? 'active' : ''; ?>">
                    <a href="<?php echo admin_url('modules/finance/credits.php'); ?>">
                        <i class="fas fa-coins"></i>
                        <span>Gestión de Créditos</span>
                    </a>
                </li>
                <li class="<?php echo ($current_page == 'subscriptions') ? 'active' : ''; ?>">
                    <a href="<?php echo admin_url('modules/finance/subscriptions.php'); ?>">
                        <i class="fas fa-crown"></i>
                        <span>Suscripciones</span>
                    </a>
                </li>
                <li class="<?php echo ($current_page == 'payments') ? 'active' : ''; ?>">
                    <a href="<?php echo admin_url('modules/finance/payments.php'); ?>">
                        <i class="fas fa-credit-card"></i>
                        <span>Pagos</span>
                    </a>
                </li>
                <li class="<?php echo ($current_page == 'credit-packages') ? 'active' : ''; ?>">
                    <a href="<?php echo admin_url('modules/finance/credit-packages.php'); ?>">
                        <i class="fas fa-box"></i>
                        <span>Paquetes de Créditos</span>
                    </a>
                </li>
                <li class="<?php echo ($current_page == 'financial-movements') ? 'active' : ''; ?>">
                    <a href="<?php echo admin_url('modules/finance/financial-movements.php'); ?>">
                        <i class="fas fa-chart-line"></i>
                        <span>Movimientos Financieros</span>
                    </a>
                </li>
            </ul>
        </div>

        <div class="nav-section">
            <h3>Comunicación</h3>
            <ul>
                <li class="<?php echo ($current_page == 'contact-messages') ? 'active' : ''; ?>">
                    <a href="<?php echo admin_url('modules/communication/contact-messages.php'); ?>">
                        <i class="fas fa-envelope"></i>
                        <span>Mensajes de Contacto</span>
                    </a>
                </li>
                <li class="<?php echo ($current_page == 'notifications-admin') ? 'active' : ''; ?>">
                    <a href="<?php echo admin_url('notifications-admin.php'); ?>">
                        <i class="fas fa-bell"></i>
                        <span>Notificaciones Admin</span>
                    </a>
                </li>
            </ul>
        </div>

        <div class="nav-section">
            <h3>Sistema</h3>
            <ul>
                <li class="<?php echo ($current_page == 'pages-meta') ? 'active' : ''; ?>">
                    <a href="<?php echo admin_url('modules/system/pages-meta.php'); ?>">
                        <i class="fas fa-file-alt"></i>
                        <span>Metadatos de Páginas</span>
                    </a>
                </li>
                <li class="<?php echo ($current_page == 'generation-logs') ? 'active' : ''; ?>">
                    <a href="<?php echo admin_url('modules/system/generation-logs.php'); ?>">
                        <i class="fas fa-robot"></i>
                        <span>Logs de Generación IA</span>
                    </a>
                </li>
                <li class="<?php echo ($current_page == 'database') ? 'active' : ''; ?>">
                    <a href="<?php echo admin_url('modules/system/database.php'); ?>">
                        <i class="fas fa-database"></i>
                        <span>Base de Datos</span>
                    </a>
                </li>
            </ul>
        </div>

        <div class="nav-section">
            <h3>Administración</h3>
            <ul>
                <li class="<?php echo ($current_page == 'settings') ? 'active' : ''; ?>">
                    <a href="<?php echo admin_url('modules/system/settings.php'); ?>">
                        <i class="fas fa-cog"></i>
                        <span>Configuración</span>
                    </a>
                </li>
                <li class="<?php echo ($current_page == 'admin-logs') ? 'active' : ''; ?>">
                    <a href="<?php echo admin_url('modules/system/admin-logs.php'); ?>">
                        <i class="fas fa-shield-alt"></i>
                        <span>Logs de Admin</span>
                    </a>
                </li>
                <li class="<?php echo ($current_page == 'backup') ? 'active' : ''; ?>">
                    <a href="<?php echo admin_url('modules/system/backup.php'); ?>">
                        <i class="fas fa-download"></i>
                        <span>Respaldos</span>
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="sidebar-footer">
        <div class="admin-info">
            <div class="admin-avatar">
                <img src="<?php echo admin_url('assets/img/avatar-default.png'); ?>" alt="Admin">
            </div>
            <div class="admin-details">
                <h4><?php echo htmlspecialchars($_SESSION['admin_username'] ?? 'Admin'); ?></h4>
                <p>Administrador</p>
            </div>
        </div>
    </div>
</aside>
