<header class="admin-header">
    <div class="header-left">
        <button class="sidebar-toggle" id="sidebarToggle">
            <i class="fas fa-bars"></i>
        </button>
        <div class="logo">
            <i class="fas fa-magic"></i>
            <span>ObelisIA Admin</span>
        </div>
    </div>
    
    <div class="header-center">
        <div class="search-box">
            <i class="fas fa-search"></i>
            <input type="text" placeholder="Buscar usuarios, proyectos..." id="globalSearch">
            <div class="search-results" id="searchResults"></div>
        </div>
    </div>
    
    <div class="header-right">
        <div class="header-notifications">
            <button class="notification-btn" id="notificationBtn">
                <i class="fas fa-bell"></i>
                <span class="notification-badge" style="display: none;">0</span>
            </button>
            <div class="notifications-dropdown" id="notificationsDropdown">
                <div class="notifications-header">
                    <h4>Notificaciones</h4>
                    <button class="mark-all-read" id="markAllReadBtn">Marcar todas como leídas</button>
                </div>
                <div class="notifications-list" id="notificationsList">
                    <!-- Las notificaciones se cargarán dinámicamente -->
                    <div class="notification-loading" style="text-align: center; padding: 2rem; color: var(--muted-text);">
                        <i class="fas fa-spinner fa-spin"></i>
                        <p>Cargando notificaciones...</p>
                    </div>
                </div>
                <div class="notifications-footer">
                    <a href="<?php echo admin_url('notifications.php'); ?>">Ver todas las notificaciones</a>
                </div>
            </div>
        </div>
        
        <div class="header-profile">
            <button class="profile-btn" id="profileBtn">
                <img src="<?php echo admin_url('../assets/img/default-profile.png'); ?>" alt="Admin" class="profile-avatar">
                <span class="profile-name"><?php echo htmlspecialchars($_SESSION['admin_username'] ?? 'Admin'); ?></span>
                <i class="fas fa-chevron-down"></i>
            </button>
            <div class="profile-dropdown" id="profileDropdown">
                <a href="<?php echo admin_url('profile.php'); ?>"><i class="fas fa-user"></i> Mi Perfil</a>
                <a href="<?php echo admin_url('../../panel'); ?>"><i class="fas fa-dashboard"></i> Panel de Usuario</a>
                <a href="<?php echo admin_url('settings.php'); ?>"><i class="fas fa-cog"></i> Configuración</a>
                <div class="dropdown-divider"></div>
                <a href="<?php echo admin_url('auth/logout.php'); ?>"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a>
            </div>
        </div>
    </div>
</header>
