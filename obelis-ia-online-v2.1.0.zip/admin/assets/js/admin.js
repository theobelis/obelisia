/**
 * JavaScript principal del panel de administración
 */

class AdminPanel {
    constructor() {
        this.init();
        this.bindEvents();
    }

    init() {
        // Inicializar componentes
        this.initSidebar();
        this.initDropdowns();
        this.initSearch();
        this.initNotifications();
    }

    bindEvents() {
        // Toggle sidebar
        document.getElementById('sidebarToggle')?.addEventListener('click', () => {
            this.toggleSidebar();
        });

        // Dropdown toggles
        document.getElementById('notificationBtn')?.addEventListener('click', (e) => {
            e.stopPropagation();
            this.toggleDropdown('notifications');
        });

        document.getElementById('profileBtn')?.addEventListener('click', (e) => {
            e.stopPropagation();
            this.toggleDropdown('profile');
        });

        // Cerrar dropdowns al hacer click fuera
        document.addEventListener('click', () => {
            this.closeAllDropdowns();
        });

        // Búsqueda global
        document.getElementById('globalSearch')?.addEventListener('input', (e) => {
            this.handleGlobalSearch(e.target.value);
        });

        // Responsive
        window.addEventListener('resize', () => {
            this.handleResize();
        });
    }

    initSidebar() {
        const sidebar = document.getElementById('adminSidebar');
        if (!sidebar) return;

        // Estado inicial responsive
        if (window.innerWidth <= 1024) {
            sidebar.classList.remove('open');
        }
    }

    toggleSidebar() {
        const sidebar = document.getElementById('adminSidebar');
        if (!sidebar) return;

        sidebar.classList.toggle('open');
    }

    initDropdowns() {
        // Evitar que se cierren al hacer click dentro
        document.querySelectorAll('.notifications-dropdown, .profile-dropdown')
            .forEach(dropdown => {
                dropdown.addEventListener('click', (e) => {
                    e.stopPropagation();
                });
            });
    }

    toggleDropdown(type) {
        const dropdownId = type === 'notifications' ? 'notificationsDropdown' : 'profileDropdown';
        const dropdown = document.getElementById(dropdownId);
        
        if (!dropdown) return;

        // Cerrar otros dropdowns primero
        this.closeAllDropdowns();
        
        // Toggle el dropdown actual
        dropdown.classList.toggle('show');
    }

    closeAllDropdowns() {
        document.querySelectorAll('.notifications-dropdown, .profile-dropdown')
            .forEach(dropdown => {
                dropdown.classList.remove('show');
            });
    }

    initSearch() {
        this.searchTimeout = null;
    }

    handleGlobalSearch(query) {
        clearTimeout(this.searchTimeout);
        
        if (query.length < 2) {
            this.hideSearchResults();
            return;
        }

        this.searchTimeout = setTimeout(() => {
            this.performSearch(query);
        }, 300);
    }

    async performSearch(query) {
        try {
            const response = await fetch(`api/search.php?q=${encodeURIComponent(query)}`);
            const results = await response.json();
            this.displaySearchResults(results);
        } catch (error) {
            console.error('Error en búsqueda:', error);
        }
    }

    displaySearchResults(results) {
        const resultsContainer = document.getElementById('searchResults');
        if (!resultsContainer) return;

        if (results.length === 0) {
            resultsContainer.innerHTML = '<div class="search-no-results">No se encontraron resultados</div>';
        } else {
            resultsContainer.innerHTML = results.map(result => `
                <div class="search-result-item">
                    <div class="search-result-type">${result.type}</div>
                    <div class="search-result-title">${result.title}</div>
                    <div class="search-result-description">${result.description}</div>
                </div>
            `).join('');
        }

        resultsContainer.style.display = 'block';
    }

    hideSearchResults() {
        const resultsContainer = document.getElementById('searchResults');
        if (resultsContainer) {
            resultsContainer.style.display = 'none';
        }
    }

    initNotifications() {
        // Marcar notificaciones como leídas
        document.querySelector('.mark-all-read')?.addEventListener('click', () => {
            this.markAllNotificationsRead();
        });
    }

    async markAllNotificationsRead() {
        try {
            const response = await fetch('api/notifications.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ action: 'mark_all_read' })
            });

            if (response.ok) {
                // Actualizar UI
                document.querySelectorAll('.notification-item.unread')
                    .forEach(item => item.classList.remove('unread'));
                
                const badge = document.querySelector('.notification-badge');
                if (badge) badge.textContent = '0';
                
                this.showToast('Notificaciones marcadas como leídas', 'success');
            }
        } catch (error) {
            console.error('Error marcando notificaciones:', error);
            this.showToast('Error al marcar notificaciones', 'error');
        }
    }

    handleResize() {
        const sidebar = document.getElementById('adminSidebar');
        if (!sidebar) return;

        if (window.innerWidth > 1024) {
            sidebar.classList.remove('open');
        }
    }

    // Utilidades
    showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.textContent = message;
        
        document.body.appendChild(toast);
        
        setTimeout(() => toast.classList.add('show'), 100);
        
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => document.body.removeChild(toast), 300);
        }, 3000);
    }

    async fetchData(url, options = {}) {
        try {
            const response = await fetch(url, {
                ...options,
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                    ...options.headers
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            return await response.json();
        } catch (error) {
            console.error('Error en petición:', error);
            throw error;
        }
    }

    formatNumber(num) {
        if (num >= 1000000) {
            return (num / 1000000).toFixed(1) + 'M';
        }
        if (num >= 1000) {
            return (num / 1000).toFixed(1) + 'K';
        }
        return num.toString();
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('es-ES', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    formatCurrency(amount, currency = 'USD') {
        return new Intl.NumberFormat('es-ES', {
            style: 'currency',
            currency: currency
        }).format(amount);
    }
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    window.adminPanel = new AdminPanel();
});

// Estilos CSS adicionales para toast
const toastStyles = `
.toast {
    position: fixed;
    top: 100px;
    right: 20px;
    background: var(--dark-surface);
    color: var(--light-text);
    padding: 1rem 1.5rem;
    border-radius: 0.5rem;
    border-left: 4px solid var(--primary-color);
    box-shadow: var(--shadow-lg);
    z-index: 1001;
    opacity: 0;
    transform: translateX(100%);
    transition: all 0.3s ease;
}

.toast.show {
    opacity: 1;
    transform: translateX(0);
}

.toast.toast-success {
    border-left-color: var(--success-color);
}

.toast.toast-error {
    border-left-color: var(--error-color);
}

.toast.toast-warning {
    border-left-color: var(--warning-color);
}

.search-results {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    background: var(--dark-surface);
    border: 1px solid var(--border-color);
    border-radius: 0.5rem;
    box-shadow: var(--shadow-lg);
    max-height: 400px;
    overflow-y: auto;
    z-index: 1000;
    display: none;
}

.search-result-item {
    padding: 1rem;
    border-bottom: 1px solid var(--border-color);
    cursor: pointer;
    transition: var(--transition-fast);
}

.search-result-item:hover {
    background: var(--dark-card);
}

.search-result-item:last-child {
    border-bottom: none;
}

.search-result-type {
    font-size: 0.75rem;
    color: var(--primary-color);
    text-transform: uppercase;
    font-weight: 600;
    margin-bottom: 0.25rem;
}

.search-result-title {
    font-weight: 500;
    color: var(--light-text);
    margin-bottom: 0.25rem;
}

.search-result-description {
    font-size: 0.85rem;
    color: var(--muted-text);
}

.search-no-results {
    padding: 1rem;
    text-align: center;
    color: var(--muted-text);
    font-style: italic;
}
`;

// Inyectar estilos
const style = document.createElement('style');
style.textContent = toastStyles;
document.head.appendChild(style);
