/**
 * JavaScript para gestión de usuarios
 */

class UserManager {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
        this.initModals();
    }

    bindEvents() {
        // Cerrar modales al hacer click fuera
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.closeModal(e.target.id);
            }
        });

        // Cerrar modales con ESC
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeAllModals();
            }
        });
    }

    initModals() {
        // Configurar botones de cerrar modal
        document.querySelectorAll('.modal-close').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const modal = e.target.closest('.modal');
                if (modal) {
                    this.closeModal(modal.id);
                }
            });
        });
    }

    openModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
    }

    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('show');
            document.body.style.overflow = '';
        }
    }

    closeAllModals() {
        document.querySelectorAll('.modal.show').forEach(modal => {
            this.closeModal(modal.id);
        });
    }

    async editUser(userId) {
        try {
            // Obtener datos del usuario
            const response = await fetch(`api/users.php?action=get&id=${userId}`);
            const user = await response.json();

            if (user.success) {
                // Llenar el formulario
                document.getElementById('editUserId').value = userId;
                document.getElementById('editUsername').value = user.data.username;
                document.getElementById('editEmail').value = user.data.email;
                document.getElementById('editFullName').value = user.data.full_name || '';
                document.getElementById('editRole').value = user.data.role;

                this.openModal('editUserModal');
            } else {
                window.adminPanel.showToast('Error al cargar los datos del usuario', 'error');
            }
        } catch (error) {
            console.error('Error loading user:', error);
            window.adminPanel.showToast('Error al cargar los datos del usuario', 'error');
        }
    }

    async saveUser() {
        const form = document.getElementById('editUserForm');
        const formData = new FormData(form);

        try {
            const response = await fetch('api/users.php', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (result.success) {
                window.adminPanel.showToast('Usuario actualizado correctamente', 'success');
                this.closeModal('editUserModal');
                setTimeout(() => location.reload(), 1000);
            } else {
                window.adminPanel.showToast(result.message || 'Error al actualizar el usuario', 'error');
            }
        } catch (error) {
            console.error('Error saving user:', error);
            window.adminPanel.showToast('Error al guardar los cambios', 'error');
        }
    }

    toggleStatus(userId) {
        if (confirm('¿Estás seguro de que quieres cambiar el estado de este usuario?')) {
            document.getElementById('toggleUserId').value = userId;
            document.getElementById('toggleStatusForm').submit();
        }
    }

    deleteUser(userId) {
        if (confirm('¿Estás seguro de que quieres eliminar este usuario? Esta acción no se puede deshacer.')) {
            document.getElementById('deleteUserId').value = userId;
            document.getElementById('deleteUserForm').submit();
        }
    }

    editCredits(userId, currentCredits) {
        const newCredits = prompt(`Ingresa la nueva cantidad de créditos para el usuario:`, currentCredits);
        
        if (newCredits !== null && !isNaN(newCredits) && newCredits >= 0) {
            document.getElementById('creditsUserId').value = userId;
            document.getElementById('creditsAmount').value = parseInt(newCredits);
            document.getElementById('updateCreditsForm').submit();
        } else if (newCredits !== null) {
            window.adminPanel.showToast('Por favor, ingresa un número válido', 'error');
        }
    }

    async openAddUserModal() {
        // Crear modal dinámicamente si no existe
        let modal = document.getElementById('addUserModal');
        
        if (!modal) {
            modal = this.createAddUserModal();
            document.body.appendChild(modal);
        }
        
        // Limpiar formulario
        document.getElementById('addUserForm').reset();
        this.openModal('addUserModal');
    }

    createAddUserModal() {
        const modal = document.createElement('div');
        modal.id = 'addUserModal';
        modal.className = 'modal';
        
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Nuevo Usuario</h3>
                    <button class="modal-close">&times;</button>
                </div>
                <div class="modal-body">
                    <form id="addUserForm">
                        <input type="hidden" name="action" value="add_user">
                        
                        <div class="form-group">
                            <label>Nombre de usuario:</label>
                            <input type="text" name="username" required>
                        </div>
                        
                        <div class="form-group">
                            <label>Email:</label>
                            <input type="email" name="email" required>
                        </div>
                        
                        <div class="form-group">
                            <label>Contraseña:</label>
                            <input type="password" name="password" required minlength="6">
                        </div>
                        
                        <div class="form-group">
                            <label>Nombre completo:</label>
                            <input type="text" name="full_name">
                        </div>
                        
                        <div class="form-group">
                            <label>Rol:</label>
                            <select name="role">
                                <option value="user">Usuario</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>Créditos iniciales:</label>
                            <input type="number" name="credits" value="0" min="0">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-outline" onclick="userManager.closeModal('addUserModal')">Cancelar</button>
                    <button class="btn btn-primary" onclick="userManager.saveNewUser()">Crear Usuario</button>
                </div>
            </div>
        `;

        // Agregar event listeners
        modal.querySelector('.modal-close').addEventListener('click', () => {
            this.closeModal('addUserModal');
        });

        return modal;
    }

    async saveNewUser() {
        const form = document.getElementById('addUserForm');
        const formData = new FormData(form);

        try {
            const response = await fetch('api/users.php', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (result.success) {
                window.adminPanel.showToast('Usuario creado correctamente', 'success');
                this.closeModal('addUserModal');
                setTimeout(() => location.reload(), 1000);
            } else {
                window.adminPanel.showToast(result.message || 'Error al crear el usuario', 'error');
            }
        } catch (error) {
            console.error('Error creating user:', error);
            window.adminPanel.showToast('Error al crear el usuario', 'error');
        }
    }

    async exportUsers() {
        try {
            const response = await fetch('api/users.php?action=export');
            
            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `usuarios_${new Date().toISOString().split('T')[0]}.csv`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
                
                window.adminPanel.showToast('Usuarios exportados correctamente', 'success');
            } else {
                window.adminPanel.showToast('Error al exportar usuarios', 'error');
            }
        } catch (error) {
            console.error('Error exporting users:', error);
            window.adminPanel.showToast('Error al exportar usuarios', 'error');
        }
    }

    // Función para filtrado en tiempo real
    initLiveSearch() {
        const searchInput = document.querySelector('input[name="search"]');
        let searchTimeout;

        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(() => {
                    this.performLiveSearch(e.target.value);
                }, 300);
            });
        }
    }

    async performLiveSearch(query) {
        if (query.length < 2) return;

        try {
            const response = await fetch(`api/users.php?action=search&q=${encodeURIComponent(query)}`);
            const results = await response.json();

            if (results.success) {
                this.updateTableWithResults(results.data);
            }
        } catch (error) {
            console.error('Error in live search:', error);
        }
    }

    updateTableWithResults(users) {
        const tbody = document.querySelector('.data-table tbody');
        if (!tbody) return;

        tbody.innerHTML = users.map(user => `
            <tr>
                <td>${user.id}</td>
                <td>
                    <div class="user-info">
                        <div class="user-avatar">
                            <i class="fas fa-user"></i>
                        </div>
                        <div class="user-details">
                            <span class="username">${this.escapeHtml(user.username)}</span>
                        </div>
                    </div>
                </td>
                <td>${this.escapeHtml(user.email)}</td>
                <td>${this.escapeHtml(user.full_name || 'No especificado')}</td>
                <td>
                    <span class="role-badge role-${user.role}">
                        ${user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                    </span>
                </td>
                <td>
                    <span class="credits-amount" data-user-id="${user.id}">
                        ${new Intl.NumberFormat().format(user.credits || 0)}
                    </span>
                </td>
                <td>
                    <span class="status-badge status-${user.is_active ? 'active' : 'inactive'}">
                        ${user.is_active ? 'Activo' : 'Inactivo'}
                    </span>
                </td>
                <td>${user.last_login ? this.timeAgo(user.last_login) : 'Nunca'}</td>
                <td>${new Date(user.created_at).toLocaleDateString('es-ES')}</td>
                <td>
                    <div class="action-buttons">
                        <button class="btn-action btn-edit" onclick="userManager.editUser(${user.id})" title="Editar">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn-action btn-toggle" onclick="userManager.toggleStatus(${user.id})" title="Cambiar estado">
                            <i class="fas fa-${user.is_active ? 'ban' : 'check'}"></i>
                        </button>
                        <button class="btn-action btn-credits" onclick="userManager.editCredits(${user.id}, ${user.credits || 0})" title="Editar créditos">
                            <i class="fas fa-coins"></i>
                        </button>
                        ${user.role !== 'super_admin' ? `
                            <button class="btn-action btn-delete" onclick="userManager.deleteUser(${user.id})" title="Eliminar">
                                <i class="fas fa-trash"></i>
                            </button>
                        ` : ''}
                    </div>
                </td>
            </tr>
        `).join('');
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    timeAgo(dateString) {
        const now = new Date();
        const date = new Date(dateString);
        const diff = now - date;
        
        const minutes = Math.floor(diff / 60000);
        const hours = Math.floor(diff / 3600000);
        const days = Math.floor(diff / 86400000);
        
        if (minutes < 1) return 'hace un momento';
        if (minutes < 60) return `hace ${minutes} minutos`;
        if (hours < 24) return `hace ${hours} horas`;
        return `hace ${days} días`;
    }
}

// Funciones globales para compatibilidad
function editUser(userId) {
    window.userManager.editUser(userId);
}

function saveUser() {
    window.userManager.saveUser();
}

function toggleStatus(userId) {
    window.userManager.toggleStatus(userId);
}

function deleteUser(userId) {
    window.userManager.deleteUser(userId);
}

function editCredits(userId, currentCredits) {
    window.userManager.editCredits(userId, currentCredits);
}

function openAddUserModal() {
    window.userManager.openAddUserModal();
}

function exportUsers() {
    window.userManager.exportUsers();
}

function closeModal(modalId) {
    window.userManager.closeModal(modalId);
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    window.userManager = new UserManager();
});
