class PaymentManager {
    constructor() {
        this.initializeEventListeners();
        this.currentPaymentId = null;
    }

    initializeEventListeners() {
        // Export payments
        document.addEventListener('click', (e) => {
            if (e.target.closest('[onclick="exportPayments()"]')) {
                e.preventDefault();
                this.exportPayments();
            }
        });

        // Generate financial report
        document.addEventListener('click', (e) => {
            if (e.target.closest('[onclick="generateFinancialReport()"]')) {
                e.preventDefault();
                this.generateFinancialReport();
            }
        });

        // Status update buttons
        document.addEventListener('click', (e) => {
            const button = e.target.closest('button[onclick*="markAs"]');
            if (button) {
                e.preventDefault();
                const onclick = button.getAttribute('onclick');
                const paymentId = onclick.match(/\d+/)[0];
                
                if (onclick.includes('markAsCompleted')) {
                    this.markAsCompleted(paymentId);
                } else if (onclick.includes('markAsFailed')) {
                    this.markAsFailed(paymentId);
                }
            }
        });

        // Refund button
        document.addEventListener('click', (e) => {
            const button = e.target.closest('button[onclick*="refundPayment"]');
            if (button) {
                e.preventDefault();
                const paymentId = button.getAttribute('onclick').match(/\d+/)[0];
                this.refundPayment(paymentId);
            }
        });

        // Generate receipt
        document.addEventListener('click', (e) => {
            const button = e.target.closest('button[onclick*="generateReceipt"]');
            if (button) {
                e.preventDefault();
                const paymentId = button.getAttribute('onclick').match(/\d+/)[0];
                this.generateReceipt(paymentId);
            }
        });
    }

    async viewPayment(paymentId) {
        try {
            this.showLoading('Cargando detalles del pago...');
            
            const response = await fetch(`api/payments.php?action=get&id=${paymentId}`);
            const data = await response.json();
            
            this.hideLoading();
            
            if (data.success) {
                this.showPaymentDetails(data.payment);
            } else {
                this.showAlert('Error', data.message || 'Error al cargar los detalles del pago', 'error');
            }
        } catch (error) {
            this.hideLoading();
            this.showAlert('Error', 'Error de conexión', 'error');
            console.error('Error viewing payment:', error);
        }
    }

    showPaymentDetails(payment) {
        const modal = document.getElementById('paymentModal');
        const detailsContainer = document.getElementById('paymentDetails');
        
        detailsContainer.innerHTML = `
            <div class="payment-details">
                <div class="detail-section">
                    <h4>Información General</h4>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <label>ID de Pago:</label>
                            <span>#${payment.id}</span>
                        </div>
                        <div class="detail-item">
                            <label>Estado:</label>
                            <span class="status-badge status-${payment.status}">
                                ${this.getStatusLabel(payment.status)}
                            </span>
                        </div>
                        <div class="detail-item">
                            <label>Monto:</label>
                            <span class="amount">$${parseFloat(payment.amount).toFixed(2)}</span>
                        </div>
                        <div class="detail-item">
                            <label>Método de Pago:</label>
                            <span>${payment.payment_method || 'N/A'}</span>
                        </div>
                    </div>
                </div>

                <div class="detail-section">
                    <h4>Información del Usuario</h4>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <label>Usuario:</label>
                            <span>${payment.user_username || 'Usuario #' + payment.user_id}</span>
                        </div>
                        <div class="detail-item">
                            <label>ID de Usuario:</label>
                            <span>#${payment.user_id}</span>
                        </div>
                    </div>
                </div>

                <div class="detail-section">
                    <h4>Información de la Transacción</h4>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <label>ID de Transacción:</label>
                            <span>${payment.transaction_id || 'N/A'}</span>
                        </div>
                        <div class="detail-item">
                            <label>Referencia:</label>
                            <span>${payment.reference || 'N/A'}</span>
                        </div>
                        <div class="detail-item">
                            <label>Paquete:</label>
                            <span>${payment.package_name || 'Sin paquete'}</span>
                        </div>
                    </div>
                </div>

                <div class="detail-section">
                    <h4>Fechas</h4>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <label>Fecha de Creación:</label>
                            <span>${new Date(payment.created_at).toLocaleString('es-ES')}</span>
                        </div>
                        <div class="detail-item">
                            <label>Última Actualización:</label>
                            <span>${payment.updated_at ? new Date(payment.updated_at).toLocaleString('es-ES') : 'N/A'}</span>
                        </div>
                    </div>
                </div>

                ${payment.notes ? `
                <div class="detail-section">
                    <h4>Notas</h4>
                    <div class="notes-content">
                        ${payment.notes}
                    </div>
                </div>
                ` : ''}
            </div>
        `;
        
        this.currentPaymentId = payment.id;
        modal.style.display = 'block';
    }

    async markAsCompleted(paymentId) {
        const confirmed = await this.showConfirmDialog({
            title: 'Confirmar Pago',
            message: '¿Estás seguro de que quieres marcar este pago como completado?',
            confirmText: 'Sí, completar',
            cancelText: 'Cancelar',
            type: 'success'
        });

        if (confirmed) {
            this.updatePaymentStatus(paymentId, 'completed');
        }
    }

    async markAsFailed(paymentId) {
        const confirmed = await this.showConfirmDialog({
            title: 'Marcar como Fallido',
            message: '¿Estás seguro de que quieres marcar este pago como fallido?',
            confirmText: 'Sí, marcar como fallido',
            cancelText: 'Cancelar',
            type: 'danger'
        });

        if (confirmed) {
            this.updatePaymentStatus(paymentId, 'failed');
        }
    }

    async refundPayment(paymentId) {
        const confirmed = await this.showConfirmDialog({
            title: 'Procesar Reembolso',
            message: '¿Estás seguro de que quieres procesar el reembolso para este pago? Esta acción no se puede deshacer.',
            confirmText: 'Sí, reembolsar',
            cancelText: 'Cancelar',
            type: 'warning'
        });

        if (confirmed) {
            this.updatePaymentStatus(paymentId, 'refunded');
        }
    }

    async updatePaymentStatus(paymentId, status) {
        try {
            this.showLoading('Actualizando estado del pago...');
            
            const response = await fetch('api/payments.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]')?.content
                },
                body: JSON.stringify({
                    action: 'update_status',
                    payment_id: paymentId,
                    status: status
                })
            });

            const data = await response.json();
            this.hideLoading();

            if (data.success) {
                this.showAlert('Éxito', 'El estado del pago se ha actualizado correctamente', 'success');
                setTimeout(() => location.reload(), 2000);
            } else {
                this.showAlert('Error', data.message || 'Error al actualizar el estado', 'error');
            }
        } catch (error) {
            this.hideLoading();
            this.showAlert('Error', 'Error de conexión', 'error');
            console.error('Error updating payment status:', error);
        }
    }

    async generateReceipt(paymentId) {
        try {
            this.showLoading('Generando recibo...');
            
            const response = await fetch(`api/payments.php?action=receipt&id=${paymentId}`);
            
            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `recibo_pago_${paymentId}.pdf`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
                
                this.hideLoading();
                this.showAlert('Éxito', 'El recibo se ha generado correctamente', 'success');
            } else {
                throw new Error('Error en la respuesta del servidor');
            }
        } catch (error) {
            this.hideLoading();
            this.showAlert('Error', 'Error al generar el recibo', 'error');
            console.error('Error generating receipt:', error);
        }
    }

    async exportPayments() {
        try {
            this.showLoading('Preparando exportación...');
            
            // Get current filters
            const params = new URLSearchParams(window.location.search);
            
            const response = await fetch(`api/payments.php?action=export&${params.toString()}`);
            
            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `pagos_${new Date().toISOString().split('T')[0]}.csv`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
                
                this.hideLoading();
                this.showAlert('Éxito', 'Los pagos se han exportado correctamente', 'success');
            } else {
                throw new Error('Error en la respuesta del servidor');
            }
        } catch (error) {
            this.hideLoading();
            this.showAlert('Error', 'Error al exportar pagos', 'error');
            console.error('Export error:', error);
        }
    }

    async generateFinancialReport() {
        try {
            this.showLoading('Generando reporte financiero...');
            
            const response = await fetch('api/financial-report.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]')?.content
                },
                body: JSON.stringify({
                    type: 'comprehensive',
                    period: 'monthly'
                })
            });
            
            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `reporte_financiero_${new Date().toISOString().split('T')[0]}.pdf`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
                
                this.hideLoading();
                this.showAlert('Éxito', 'El reporte financiero se ha generado correctamente', 'success');
            } else {
                throw new Error('Error en la respuesta del servidor');
            }
        } catch (error) {
            this.hideLoading();
            this.showAlert('Error', 'Error al generar el reporte', 'error');
            console.error('Report error:', error);
        }
    }

    closePaymentModal() {
        const modal = document.getElementById('paymentModal');
        modal.style.display = 'none';
        this.currentPaymentId = null;
    }

    getStatusLabel(status) {
        const labels = {
            'pending': 'Pendiente',
            'completed': 'Completado',
            'failed': 'Fallido',
            'cancelled': 'Cancelado',
            'refunded': 'Reembolsado'
        };
        
        return labels[status] || status;
    }

    // Utility methods (similar to other managers)
    showLoading(message = 'Cargando...') {
        const loader = document.createElement('div');
        loader.id = 'payment-loader';
        loader.className = 'loading-overlay';
        loader.innerHTML = `
            <div class="loading-content">
                <div class="spinner"></div>
                <p>${message}</p>
            </div>
        `;
        document.body.appendChild(loader);
    }

    hideLoading() {
        const loader = document.getElementById('payment-loader');
        if (loader) {
            loader.remove();
        }
    }

    async showConfirmDialog(options) {
        return new Promise((resolve) => {
            const modal = document.createElement('div');
            modal.className = 'modal-overlay';
            modal.innerHTML = `
                <div class="modal confirm-modal">
                    <div class="modal-header">
                        <h3>${options.title}</h3>
                    </div>
                    <div class="modal-body">
                        <p>${options.message}</p>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-outline cancel-btn">${options.cancelText}</button>
                        <button class="btn btn-${options.type || 'primary'} confirm-btn">${options.confirmText}</button>
                    </div>
                </div>
            `;

            document.body.appendChild(modal);

            modal.querySelector('.cancel-btn').addEventListener('click', () => {
                modal.remove();
                resolve(false);
            });

            modal.querySelector('.confirm-btn').addEventListener('click', () => {
                modal.remove();
                resolve(true);
            });

            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.remove();
                    resolve(false);
                }
            });
        });
    }

    showAlert(title, message, type = 'info') {
        const alert = document.createElement('div');
        alert.className = `alert alert-${type}`;
        alert.innerHTML = `
            <div class="alert-header">
                <strong>${title}</strong>
                <button onclick="this.parentElement.parentElement.remove()">×</button>
            </div>
            <div class="alert-body">${message}</div>
        `;

        document.body.appendChild(alert);

        setTimeout(() => {
            if (alert.parentElement) {
                alert.remove();
            }
        }, 5000);
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.paymentManager = new PaymentManager();
});

// Global functions for onclick handlers
function viewPayment(paymentId) {
    if (window.paymentManager) {
        window.paymentManager.viewPayment(paymentId);
    }
}

function markAsCompleted(paymentId) {
    if (window.paymentManager) {
        window.paymentManager.markAsCompleted(paymentId);
    }
}

function markAsFailed(paymentId) {
    if (window.paymentManager) {
        window.paymentManager.markAsFailed(paymentId);
    }
}

function refundPayment(paymentId) {
    if (window.paymentManager) {
        window.paymentManager.refundPayment(paymentId);
    }
}

function generateReceipt(paymentId) {
    if (window.paymentManager) {
        window.paymentManager.generateReceipt(paymentId);
    }
}

function exportPayments() {
    if (window.paymentManager) {
        window.paymentManager.exportPayments();
    }
}

function generateFinancialReport() {
    if (window.paymentManager) {
        window.paymentManager.generateFinancialReport();
    }
}

function closePaymentModal() {
    if (window.paymentManager) {
        window.paymentManager.closePaymentModal();
    }
}
