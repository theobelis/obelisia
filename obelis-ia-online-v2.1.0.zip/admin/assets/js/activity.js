class ActivityManager {
    constructor() {
        this.initializeEventListeners();
        this.refreshInterval = null;
        this.setupRealTimeUpdates();
    }

    initializeEventListeners() {
        // Auto-refresh toggle
        const autoRefreshToggle = document.getElementById('auto-refresh');
        if (autoRefreshToggle) {
            autoRefreshToggle.addEventListener('change', (e) => {
                if (e.target.checked) {
                    this.startAutoRefresh();
                } else {
                    this.stopAutoRefresh();
                }
            });
        }

        // Clear old logs confirmation
        document.addEventListener('click', (e) => {
            if (e.target.closest('[onclick="clearOldLogs()"]')) {
                e.preventDefault();
                this.confirmClearOldLogs();
            }
        });

        // Export logs
        document.addEventListener('click', (e) => {
            if (e.target.closest('[onclick="exportLogs()"]')) {
                e.preventDefault();
                this.exportLogs();
            }
        });

        // Date range picker for filters
        this.initializeDateRangePicker();
    }

    setupRealTimeUpdates() {
        // Check for new activity every 30 seconds
        setInterval(() => {
            this.checkForNewActivity();
        }, 30000);
    }

    async checkForNewActivity() {
        try {
            const response = await fetch('api/activity-stats.php?action=latest');
            const data = await response.json();
            
            if (data.success && data.newCount > 0) {
                this.showNewActivityNotification(data.newCount);
            }
        } catch (error) {
            console.error('Error checking for new activity:', error);
        }
    }

    showNewActivityNotification(count) {
        const notification = document.createElement('div');
        notification.className = 'activity-notification';
        notification.innerHTML = `
            <i class="fas fa-bell"></i>
            <span>${count} nueva(s) actividad(es)</span>
            <button onclick="location.reload()">Actualizar</button>
            <button onclick="this.parentElement.remove()">×</button>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 10000);
    }

    startAutoRefresh() {
        this.refreshInterval = setInterval(() => {
            location.reload();
        }, 60000); // Refresh every minute
    }

    stopAutoRefresh() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
            this.refreshInterval = null;
        }
    }

    async confirmClearOldLogs() {
        const confirmed = await this.showConfirmDialog({
            title: 'Limpiar Logs Antiguos',
            message: '¿Estás seguro de que quieres eliminar los logs de más de 90 días? Esta acción no se puede deshacer.',
            confirmText: 'Sí, eliminar',
            cancelText: 'Cancelar',
            type: 'danger'
        });

        if (confirmed) {
            this.clearOldLogs();
        }
    }

    async clearOldLogs() {
        try {
            this.showLoading('Eliminando logs antiguos...');
            
            const response = await fetch('api/activity.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]')?.content
                },
                body: JSON.stringify({
                    action: 'clear_old_logs'
                })
            });

            const data = await response.json();
            this.hideLoading();

            if (data.success) {
                this.showAlert('Éxito', `Se eliminaron ${data.deleted_count} logs antiguos`, 'success');
                setTimeout(() => location.reload(), 2000);
            } else {
                this.showAlert('Error', data.message || 'Error al eliminar logs', 'error');
            }
        } catch (error) {
            this.hideLoading();
            this.showAlert('Error', 'Error de conexión', 'error');
            console.error('Error clearing old logs:', error);
        }
    }

    async exportLogs() {
        try {
            this.showLoading('Preparando exportación...');
            
            // Get current filters
            const params = new URLSearchParams(window.location.search);
            
            const response = await fetch(`api/activity.php?action=export&${params.toString()}`);
            
            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `activity_logs_${new Date().toISOString().split('T')[0]}.csv`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
                
                this.hideLoading();
                this.showAlert('Éxito', 'Los logs se han exportado correctamente', 'success');
            } else {
                throw new Error('Error en la respuesta del servidor');
            }
        } catch (error) {
            this.hideLoading();
            this.showAlert('Error', 'Error al exportar logs', 'error');
            console.error('Export error:', error);
        }
    }

    initializeDateRangePicker() {
        // Add date range functionality
        const dateInput = document.querySelector('input[name="date"]');
        if (dateInput) {
            // Set max date to today
            dateInput.max = new Date().toISOString().split('T')[0];
            
            // Add quick date filters
            this.addQuickDateFilters();
        }
    }

    addQuickDateFilters() {
        const dateGroup = document.querySelector('input[name="date"]').closest('.filter-group');
        const quickFilters = document.createElement('div');
        quickFilters.className = 'quick-date-filters';
        quickFilters.innerHTML = `
            <button type="button" class="btn btn-sm" onclick="activityManager.setDateFilter('today')">Hoy</button>
            <button type="button" class="btn btn-sm" onclick="activityManager.setDateFilter('yesterday')">Ayer</button>
            <button type="button" class="btn btn-sm" onclick="activityManager.setDateFilter('week')">Esta semana</button>
            <button type="button" class="btn btn-sm" onclick="activityManager.setDateFilter('month')">Este mes</button>
        `;
        
        dateGroup.appendChild(quickFilters);
    }

    setDateFilter(period) {
        const dateInput = document.querySelector('input[name="date"]');
        const today = new Date();
        let targetDate;

        switch (period) {
            case 'today':
                targetDate = today;
                break;
            case 'yesterday':
                targetDate = new Date(today);
                targetDate.setDate(today.getDate() - 1);
                break;
            case 'week':
                targetDate = new Date(today);
                targetDate.setDate(today.getDate() - 7);
                break;
            case 'month':
                targetDate = new Date(today);
                targetDate.setMonth(today.getMonth() - 1);
                break;
        }

        if (targetDate) {
            dateInput.value = targetDate.toISOString().split('T')[0];
            dateInput.closest('form').submit();
        }
    }

    // Utility methods
    showLoading(message = 'Cargando...') {
        const loader = document.createElement('div');
        loader.id = 'activity-loader';
        loader.className = 'loading-overlay';
        loader.innerHTML = `
            <div class="loading-content">
                <div class="spinner"></div>
                <p>${message}</p>
            </div>
        `;
        document.body.appendChild(loader);
    }

    hideLoading() {
        const loader = document.getElementById('activity-loader');
        if (loader) {
            loader.remove();
        }
    }

    async showConfirmDialog(options) {
        return new Promise((resolve) => {
            const modal = document.createElement('div');
            modal.className = 'modal-overlay';
            modal.innerHTML = `
                <div class="modal confirm-modal">
                    <div class="modal-header">
                        <h3>${options.title}</h3>
                    </div>
                    <div class="modal-body">
                        <p>${options.message}</p>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-outline cancel-btn">${options.cancelText}</button>
                        <button class="btn btn-${options.type || 'primary'} confirm-btn">${options.confirmText}</button>
                    </div>
                </div>
            `;

            document.body.appendChild(modal);

            modal.querySelector('.cancel-btn').addEventListener('click', () => {
                modal.remove();
                resolve(false);
            });

            modal.querySelector('.confirm-btn').addEventListener('click', () => {
                modal.remove();
                resolve(true);
            });

            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.remove();
                    resolve(false);
                }
            });
        });
    }

    showAlert(title, message, type = 'info') {
        const alert = document.createElement('div');
        alert.className = `alert alert-${type}`;
        alert.innerHTML = `
            <div class="alert-header">
                <strong>${title}</strong>
                <button onclick="this.parentElement.parentElement.remove()">×</button>
            </div>
            <div class="alert-body">${message}</div>
        `;

        document.body.appendChild(alert);

        setTimeout(() => {
            if (alert.parentElement) {
                alert.remove();
            }
        }, 5000);
    }
}

// Helper functions for PHP integration
function getActivityIcon(action) {
    const icons = {
        'login': 'sign-in-alt',
        'logout': 'sign-out-alt',
        'register': 'user-plus',
        'create_project': 'plus-circle',
        'edit_project': 'edit',
        'delete_project': 'trash',
        'upload_file': 'upload',
        'download_file': 'download',
        'payment': 'credit-card',
        'profile_update': 'user-edit',
        'password_change': 'key',
        'email_change': 'envelope',
        'admin_action': 'shield-alt',
        'api_call': 'code',
        'error': 'exclamation-triangle'
    };
    
    return icons[action] || 'circle';
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.activityManager = new ActivityManager();
});

// Global functions for onclick handlers
function exportLogs() {
    if (window.activityManager) {
        window.activityManager.exportLogs();
    }
}

function clearOldLogs() {
    if (window.activityManager) {
        window.activityManager.confirmClearOldLogs();
    }
}
