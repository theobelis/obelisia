/**
 * JavaScript para gestión de proyectos
 */

class ProjectManager {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
        this.initModals();
    }

    bindEvents() {
        // Cerrar modales al hacer click fuera
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.closeModal(e.target.id);
            }
        });

        // Cerrar modales con ESC
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeAllModals();
            }
        });
    }

    initModals() {
        // Configurar botones de cerrar modal
        document.querySelectorAll('.modal-close').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const modal = e.target.closest('.modal');
                if (modal) {
                    this.closeModal(modal.id);
                }
            });
        });
    }

    openModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
    }

    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('show');
            document.body.style.overflow = '';
        }
    }

    closeAllModals() {
        document.querySelectorAll('.modal.show').forEach(modal => {
            this.closeModal(modal.id);
        });
    }

    async viewProject(projectId) {
        try {
            const response = await fetch(`api/projects.php?action=get&id=${projectId}`);
            const project = await response.json();

            if (project.success) {
                this.showProjectDetails(project.data);
            } else {
                window.adminPanel.showToast('Error al cargar el proyecto', 'error');
            }
        } catch (error) {
            console.error('Error loading project:', error);
            window.adminPanel.showToast('Error al cargar el proyecto', 'error');
        }
    }

    showProjectDetails(project) {
        // Crear modal dinámicamente para mostrar detalles
        let modal = document.getElementById('projectDetailsModal');
        
        if (!modal) {
            modal = this.createProjectDetailsModal();
            document.body.appendChild(modal);
        }
        
        // Llenar contenido
        document.getElementById('detailsTitle').textContent = project.title;
        document.getElementById('detailsDescription').textContent = project.description || 'Sin descripción';
        document.getElementById('detailsCategory').textContent = this.getCategoryLabel(project.category);
        document.getElementById('detailsStatus').textContent = this.getStatusLabel(project.status);
        document.getElementById('detailsVisibility').textContent = project.is_public ? 'Público' : 'Privado';
        document.getElementById('detailsViews').textContent = new Intl.NumberFormat().format(project.views);
        document.getElementById('detailsCreated').textContent = new Date(project.created_at).toLocaleDateString('es-ES');
        document.getElementById('detailsUpdated').textContent = new Date(project.updated_at).toLocaleDateString('es-ES');
        
        if (project.content && project.content !== '{}') {
            try {
                const content = JSON.parse(project.content);
                document.getElementById('detailsContent').innerHTML = this.formatProjectContent(content);
            } catch (e) {
                document.getElementById('detailsContent').textContent = 'Contenido no válido';
            }
        } else {
            document.getElementById('detailsContent').textContent = 'Sin contenido';
        }
        
        this.openModal('projectDetailsModal');
    }

    createProjectDetailsModal() {
        const modal = document.createElement('div');
        modal.id = 'projectDetailsModal';
        modal.className = 'modal';
        
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 800px;">
                <div class="modal-header">
                    <h3>Detalles del Proyecto</h3>
                    <button class="modal-close">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="project-details">
                        <div class="details-grid">
                            <div class="detail-item">
                                <label>Título:</label>
                                <span id="detailsTitle"></span>
                            </div>
                            
                            <div class="detail-item">
                                <label>Descripción:</label>
                                <span id="detailsDescription"></span>
                            </div>
                            
                            <div class="detail-item">
                                <label>Categoría:</label>
                                <span id="detailsCategory"></span>
                            </div>
                            
                            <div class="detail-item">
                                <label>Estado:</label>
                                <span id="detailsStatus"></span>
                            </div>
                            
                            <div class="detail-item">
                                <label>Visibilidad:</label>
                                <span id="detailsVisibility"></span>
                            </div>
                            
                            <div class="detail-item">
                                <label>Visualizaciones:</label>
                                <span id="detailsViews"></span>
                            </div>
                            
                            <div class="detail-item">
                                <label>Creado:</label>
                                <span id="detailsCreated"></span>
                            </div>
                            
                            <div class="detail-item">
                                <label>Actualizado:</label>
                                <span id="detailsUpdated"></span>
                            </div>
                        </div>
                        
                        <div class="content-section">
                            <label>Contenido del Proyecto:</label>
                            <div id="detailsContent" class="content-preview"></div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-outline" onclick="projectManager.closeModal('projectDetailsModal')">Cerrar</button>
                </div>
            </div>
        `;

        // Agregar event listeners
        modal.querySelector('.modal-close').addEventListener('click', () => {
            this.closeModal('projectDetailsModal');
        });

        return modal;
    }

    formatProjectContent(content) {
        if (typeof content === 'object') {
            return `<pre>${JSON.stringify(content, null, 2)}</pre>`;
        }
        return content.toString();
    }

    getCategoryLabel(category) {
        const labels = {
            'personal': 'Personal',
            'professional': 'Profesional',
            'educational': 'Educativo'
        };
        return labels[category] || category;
    }

    getStatusLabel(status) {
        const labels = {
            'draft': 'Borrador',
            'published': 'Publicado',
            'archived': 'Archivado'
        };
        return labels[status] || status;
    }

    toggleVisibility(projectId) {
        if (confirm('¿Estás seguro de que quieres cambiar la visibilidad de este proyecto?')) {
            document.getElementById('toggleProjectId').value = projectId;
            document.getElementById('toggleVisibilityForm').submit();
        }
    }

    changeStatus(projectId, currentStatus) {
        document.getElementById('statusProjectId').value = projectId;
        document.getElementById('newStatus').value = currentStatus;
        this.openModal('changeStatusModal');
    }

    saveStatus() {
        document.getElementById('changeStatusForm').submit();
    }

    deleteProject(projectId) {
        if (confirm('¿Estás seguro de que quieres eliminar este proyecto? Esta acción no se puede deshacer y eliminará también todos los comentarios y likes asociados.')) {
            document.getElementById('deleteProjectId').value = projectId;
            document.getElementById('deleteProjectForm').submit();
        }
    }

    async exportProjects() {
        try {
            const response = await fetch('api/projects.php?action=export');
            
            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `proyectos_${new Date().toISOString().split('T')[0]}.csv`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
                
                window.adminPanel.showToast('Proyectos exportados correctamente', 'success');
            } else {
                window.adminPanel.showToast('Error al exportar proyectos', 'error');
            }
        } catch (error) {
            console.error('Error exporting projects:', error);
            window.adminPanel.showToast('Error al exportar proyectos', 'error');
        }
    }
}

// Funciones globales para compatibilidad
function viewProject(projectId) {
    window.projectManager.viewProject(projectId);
}

function toggleVisibility(projectId) {
    window.projectManager.toggleVisibility(projectId);
}

function changeStatus(projectId, currentStatus) {
    window.projectManager.changeStatus(projectId, currentStatus);
}

function saveStatus() {
    window.projectManager.saveStatus();
}

function deleteProject(projectId) {
    window.projectManager.deleteProject(projectId);
}

function exportProjects() {
    window.projectManager.exportProjects();
}

function closeModal(modalId) {
    window.projectManager.closeModal(modalId);
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    window.projectManager = new ProjectManager();
});

// Estilos adicionales para detalles del proyecto
const projectDetailsStyles = `
.project-details {
    max-height: 70vh;
    overflow-y: auto;
}

.details-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
    margin-bottom: 2rem;
}

.detail-item {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
}

.detail-item label {
    font-weight: 600;
    color: var(--muted-text);
    font-size: 0.85rem;
    text-transform: uppercase;
    letter-spacing: 0.05em;
}

.detail-item span {
    color: var(--light-text);
    font-size: 0.9rem;
}

.content-section {
    border-top: 1px solid var(--border-color);
    padding-top: 1.5rem;
}

.content-section label {
    display: block;
    font-weight: 600;
    color: var(--muted-text);
    font-size: 0.85rem;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    margin-bottom: 1rem;
}

.content-preview {
    background: var(--dark-card);
    border: 1px solid var(--border-color);
    border-radius: 0.5rem;
    padding: 1rem;
    max-height: 300px;
    overflow: auto;
    font-family: 'Monaco', 'Menlo', 'Consolas', monospace;
    font-size: 0.8rem;
    line-height: 1.4;
}

.content-preview pre {
    margin: 0;
    white-space: pre-wrap;
    word-wrap: break-word;
}

.project-info {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
}

.project-title {
    font-weight: 500;
    color: var(--light-text);
}

.project-description {
    font-size: 0.8rem;
    color: var(--muted-text);
    line-height: 1.3;
}

.category-badge {
    padding: 0.25rem 0.75rem;
    border-radius: 1rem;
    font-size: 0.8rem;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.05em;
}

.category-personal {
    background: rgba(59, 130, 246, 0.1);
    color: #60a5fa;
}

.category-professional {
    background: rgba(139, 92, 246, 0.1);
    color: #a78bfa;
}

.category-educational {
    background: rgba(16, 185, 129, 0.1);
    color: #6ee7b7;
}

.status-draft {
    background: rgba(156, 163, 175, 0.1);
    color: #9ca3af;
}

.status-published {
    background: rgba(16, 185, 129, 0.1);
    color: #6ee7b7;
}

.status-archived {
    background: rgba(245, 158, 11, 0.1);
    color: #fbbf24;
}

.visibility-badge {
    padding: 0.25rem 0.75rem;
    border-radius: 1rem;
    font-size: 0.8rem;
    font-weight: 500;
}

.visibility-public {
    background: rgba(16, 185, 129, 0.1);
    color: #6ee7b7;
}

.visibility-private {
    background: rgba(239, 68, 68, 0.1);
    color: #fca5a5;
}

.btn-status {
    background: rgba(245, 158, 11, 0.1);
    color: #fbbf24;
}

.btn-status:hover {
    background: rgba(245, 158, 11, 0.2);
    transform: scale(1.1);
}

@media (max-width: 768px) {
    .details-grid {
        grid-template-columns: 1fr;
    }
}
`;

// Inyectar estilos
const style = document.createElement('style');
style.textContent = projectDetailsStyles;
document.head.appendChild(style);
