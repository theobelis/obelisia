/**
 * ObelisIA Admin UI - Funcionalidad de interfaz de usuario
 * Sistema de toggle de sidebar y dropdown de perfil
 */

class AdminUI {
    constructor() {
        this.init();
    }

    init() {
        this.initSidebarToggle();
        this.initProfileDropdown();
        this.initNotificationsDropdown();
        this.initGlobalClickHandler();
        this.initResponsiveHandlers();
        this.initGlobalSearch();
    }

    /**
     * Inicializar toggle de la sidebar
     */
    initSidebarToggle() {
        const sidebarToggle = document.getElementById('sidebarToggle');
        const adminSidebar = document.getElementById('adminSidebar');
        const adminContent = document.querySelector('.admin-content');
        
        if (!sidebarToggle || !adminSidebar) return;

        sidebarToggle.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            
            // Toggle de la clase collapsed en la sidebar
            adminSidebar.classList.toggle('collapsed');
            
            // Cambiar icono del botón
            const icon = sidebarToggle.querySelector('i');
            if (adminSidebar.classList.contains('collapsed')) {
                icon.className = 'fas fa-bars';
                // Guardar estado en localStorage
                localStorage.setItem('sidebarCollapsed', 'true');
            } else {
                icon.className = 'fas fa-times';
                localStorage.setItem('sidebarCollapsed', 'false');
            }
            
            // Ajustar contenido principal
            if (adminContent) {
                adminContent.classList.toggle('sidebar-collapsed');
            }
            
            // Trigger evento personalizado para otros componentes
            window.dispatchEvent(new CustomEvent('sidebarToggle', {
                detail: { collapsed: adminSidebar.classList.contains('collapsed') }
            }));
        });

        // Restaurar estado desde localStorage
        this.restoreSidebarState();
    }

    /**
     * Restaurar estado de la sidebar desde localStorage
     */
    restoreSidebarState() {
        const savedState = localStorage.getItem('sidebarCollapsed');
        const adminSidebar = document.getElementById('adminSidebar');
        const adminContent = document.querySelector('.admin-content');
        const sidebarToggle = document.getElementById('sidebarToggle');
        
        if (savedState === 'true' && adminSidebar) {
            adminSidebar.classList.add('collapsed');
            if (adminContent) {
                adminContent.classList.add('sidebar-collapsed');
            }
            
            const icon = sidebarToggle?.querySelector('i');
            if (icon) {
                icon.className = 'fas fa-bars';
            }
        }
    }

    /**
     * Inicializar dropdown de perfil
     */
    initProfileDropdown() {
        const profileBtn = document.getElementById('profileBtn');
        const profileDropdown = document.getElementById('profileDropdown');
        
        if (!profileBtn || !profileDropdown) return;

        profileBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            
            // Cerrar otros dropdowns
            this.closeAllDropdowns(profileDropdown);
            
            // Toggle del dropdown de perfil
            profileDropdown.classList.toggle('show');
            
            // Cambiar icono del chevron
            const chevron = profileBtn.querySelector('.fa-chevron-down, .fa-chevron-up');
            if (chevron) {
                if (profileDropdown.classList.contains('show')) {
                    chevron.className = 'fas fa-chevron-up';
                } else {
                    chevron.className = 'fas fa-chevron-down';
                }
            }
        });
    }

    /**
     * Inicializar dropdown de notificaciones
     */
    initNotificationsDropdown() {
        const notificationBtn = document.getElementById('notificationBtn');
        const notificationsDropdown = document.getElementById('notificationsDropdown');
        
        if (!notificationBtn || !notificationsDropdown) return;

        // Cargar notificaciones iniciales
        this.loadNotifications();
        
        // Actualizar cada 30 segundos
        setInterval(() => {
            this.loadNotifications();
        }, 30000);

        notificationBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            
            // Cerrar otros dropdowns
            this.closeAllDropdowns(notificationsDropdown);
            
            // Toggle del dropdown de notificaciones
            notificationsDropdown.classList.toggle('show');
            
            // Si se abre el dropdown, cargar notificaciones
            if (notificationsDropdown.classList.contains('show')) {
                this.loadNotifications();
            }
        });

        // Botón "Marcar todas como leídas"
        const markAllReadBtn = document.querySelector('.mark-all-read');
        if (markAllReadBtn) {
            markAllReadBtn.addEventListener('click', () => {
                this.markAllNotificationsAsRead();
            });
        }
    }

    /**
     * Cargar notificaciones desde el API
     */
    async loadNotifications() {
        try {
            const response = await fetch('api/notifications.php', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });
            const data = await response.json();
            
            if (data.success) {
                this.updateNotificationBadge(data.unread_count);
                this.renderNotifications(data.notifications);
            }
        } catch (error) {
            console.error('Error cargando notificaciones:', error);
        }
    }

    /**
     * Actualizar badge de notificaciones
     */
    updateNotificationBadge(count) {
        const badge = document.querySelector('.notification-badge');
        if (badge) {
            if (count > 0) {
                badge.textContent = count > 99 ? '99+' : count;
                badge.style.display = 'block';
            } else {
                badge.style.display = 'none';
            }
        }
    }

    /**
     * Renderizar lista de notificaciones
     */
    renderNotifications(notifications) {
        const container = document.querySelector('.notifications-list');
        if (!container) return;

        if (notifications.length === 0) {
            container.innerHTML = `
                <div class="notification-item no-notifications">
                    <p class="text-muted">No hay notificaciones</p>
                </div>
            `;
            return;
        }

        container.innerHTML = notifications.map(notification => `
            <div class="notification-item ${notification.read_at ? 'read' : 'unread'}" 
                 data-id="${notification.id}">
                <div class="notification-icon">
                    <i class="fas ${this.getNotificationIcon(notification.type)}"></i>
                </div>
                <div class="notification-content">
                    <div class="notification-title">${notification.title}</div>
                    <div class="notification-message">${notification.message}</div>
                    <div class="notification-time">${this.formatTime(notification.created_at)}</div>
                </div>
                ${!notification.read_at ? '<div class="notification-unread-dot"></div>' : ''}
            </div>
        `).join('');

        // Agregar event listeners para marcar como leído
        container.querySelectorAll('.notification-item.unread').forEach(item => {
            item.addEventListener('click', () => {
                this.markNotificationAsRead(item.dataset.id);
            });
        });
    }

    /**
     * Obtener icono para tipo de notificación
     */
    getNotificationIcon(type) {
        const icons = {
            'user_registration': 'fa-user-plus',
            'payment_received': 'fa-credit-card',
            'system_error': 'fa-exclamation-triangle',
            'report_generated': 'fa-chart-line',
            'info': 'fa-info-circle',
            'warning': 'fa-exclamation-triangle',
            'error': 'fa-times-circle',
            'success': 'fa-check-circle'
        };
        return icons[type] || 'fa-bell';
    }

    /**
     * Formatear tiempo relativo
     */
    formatTime(datetime) {
        const now = new Date();
        const time = new Date(datetime);
        const diff = now - time;
        
        const minutes = Math.floor(diff / 60000);
        const hours = Math.floor(diff / 3600000);
        const days = Math.floor(diff / 86400000);
        
        if (minutes < 1) return 'Ahora';
        if (minutes < 60) return `${minutes}m`;
        if (hours < 24) return `${hours}h`;
        if (days < 7) return `${days}d`;
        
        return time.toLocaleDateString();
    }

    /**
     * Marcar notificación como leída
     */
    async markNotificationAsRead(notificationId) {
        try {
            const response = await fetch('api/notifications.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    action: 'mark_read',
                    notification_id: notificationId
                })
            });

            const data = await response.json();
            if (data.success) {
                // Actualizar UI
                const item = document.querySelector(`[data-id="${notificationId}"]`);
                if (item) {
                    item.classList.remove('unread');
                    item.classList.add('read');
                    const dot = item.querySelector('.notification-unread-dot');
                    if (dot) dot.remove();
                }
                
                // Actualizar badge
                this.loadNotifications();
            }
        } catch (error) {
            console.error('Error marcando notificación como leída:', error);
        }
    }

    /**
     * Marcar todas las notificaciones como leídas
     */
    async markAllNotificationsAsRead() {
        try {
            const response = await fetch('api/notifications.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    action: 'mark_all_read'
                })
            });

            const data = await response.json();
            if (data.success) {
                // Recargar notificaciones
                this.loadNotifications();
            }
        } catch (error) {
            console.error('Error marcando todas las notificaciones como leídas:', error);
        }
    }

    /**
     * Cerrar todos los dropdowns excepto el especificado
     */
    closeAllDropdowns(except = null) {
        const dropdowns = document.querySelectorAll('.profile-dropdown, .notifications-dropdown');
        
        dropdowns.forEach(dropdown => {
            if (dropdown !== except && dropdown.classList.contains('show')) {
                dropdown.classList.remove('show');
                
                // Restaurar icono del chevron si es el dropdown de perfil
                if (dropdown.id === 'profileDropdown') {
                    const profileBtn = document.getElementById('profileBtn');
                    const chevron = profileBtn?.querySelector('.fa-chevron-up');
                    if (chevron) {
                        chevron.className = 'fas fa-chevron-down';
                    }
                }
            }
        });
    }

    /**
     * Manejar clics globales para cerrar dropdowns
     */
    initGlobalClickHandler() {
        document.addEventListener('click', (e) => {
            // No cerrar si el clic es dentro de un dropdown
            if (e.target.closest('.profile-dropdown, .notifications-dropdown, .profile-btn, .notification-btn')) {
                return;
            }
            
            // Cerrar todos los dropdowns
            this.closeAllDropdowns();
        });

        // Cerrar dropdowns con tecla Escape
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeAllDropdowns();
            }
        });
    }

    /**
     * Manejar responsive y eventos de redimensión
     */
    initResponsiveHandlers() {
        let resizeTimeout;
        
        window.addEventListener('resize', () => {
            clearTimeout(resizeTimeout);
            resizeTimeout = setTimeout(() => {
                this.handleResize();
            }, 250);
        });

        // Manejo inicial
        this.handleResize();
    }

    /**
     * Manejar cambios de tamaño de ventana
     */
    handleResize() {
        const adminSidebar = document.getElementById('adminSidebar');
        const adminContent = document.querySelector('.admin-content');
        
        // En móviles, siempre colapsar la sidebar
        if (window.innerWidth <= 1024) {
            if (adminSidebar && !adminSidebar.classList.contains('collapsed')) {
                adminSidebar.classList.add('collapsed');
                if (adminContent) {
                    adminContent.classList.add('sidebar-collapsed');
                }
            }
        }
        
        // Cerrar dropdowns en cambio de tamaño
        this.closeAllDropdowns();
    }

    /**
     * Métodos públicos para uso externo
     */
    toggleSidebar() {
        const sidebarToggle = document.getElementById('sidebarToggle');
        if (sidebarToggle) {
            sidebarToggle.click();
        }
    }

    openProfileDropdown() {
        const profileDropdown = document.getElementById('profileDropdown');
        if (profileDropdown && !profileDropdown.classList.contains('show')) {
            const profileBtn = document.getElementById('profileBtn');
            if (profileBtn) {
                profileBtn.click();
            }
        }
    }

    closeProfileDropdown() {
        const profileDropdown = document.getElementById('profileDropdown');
        if (profileDropdown && profileDropdown.classList.contains('show')) {
            this.closeAllDropdowns();
        }
    }

    /**
     * Inicializar búsqueda global
     */
    initGlobalSearch() {
        const searchInput = document.getElementById('globalSearch');
        const searchResults = document.getElementById('searchResults');
        
        if (!searchInput || !searchResults) return;

        let searchTimeout;
        let currentRequest;

        // Evento de input para búsqueda en tiempo real
        searchInput.addEventListener('input', (e) => {
            const query = e.target.value.trim();
            
            // Cancelar búsqueda anterior
            if (currentRequest) {
                currentRequest.abort();
            }
            
            // Limpiar timeout anterior
            clearTimeout(searchTimeout);
            
            // Si no hay query, ocultar resultados
            if (query.length < 2) {
                this.hideSearchResults();
                return;
            }
            
            // Debounce: esperar 300ms antes de buscar
            searchTimeout = setTimeout(() => {
                this.performGlobalSearch(query);
            }, 300);
        });

        // Manejar teclas especiales
        searchInput.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.hideSearchResults();
                searchInput.blur();
            } else if (e.key === 'Enter') {
                e.preventDefault();
                const firstResult = searchResults.querySelector('.search-result-item');
                if (firstResult) {
                    firstResult.click();
                }
            }
        });

        // Ocultar resultados al hacer clic fuera
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.search-box')) {
                this.hideSearchResults();
            }
        });
    }

    /**
     * Realizar búsqueda global
     */
    async performGlobalSearch(query) {
        const searchResults = document.getElementById('searchResults');
        if (!searchResults) return;

        try {
            // Mostrar indicador de carga
            this.showSearchLoading();

            const response = await fetch(`api/search.php?q=${encodeURIComponent(query)}&limit=20`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const data = await response.json();

            if (data.success) {
                this.displaySearchResults(data.results, query);
            } else {
                this.showSearchError(data.message || 'Error en la búsqueda');
            }

        } catch (error) {
            console.error('Error en búsqueda global:', error);
            this.showSearchError('Error de conexión');
        }
    }

    /**
     * Mostrar indicador de carga en búsqueda
     */
    showSearchLoading() {
        const searchResults = document.getElementById('searchResults');
        if (!searchResults) return;

        searchResults.innerHTML = `
            <div class="search-loading">
                <i class="fas fa-spinner fa-spin"></i>
                <span>Buscando...</span>
            </div>
        `;
        searchResults.classList.add('show');
    }

    /**
     * Mostrar error en búsqueda
     */
    showSearchError(message) {
        const searchResults = document.getElementById('searchResults');
        if (!searchResults) return;

        searchResults.innerHTML = `
            <div class="search-error">
                <i class="fas fa-exclamation-triangle"></i>
                <span>${message}</span>
            </div>
        `;
        searchResults.classList.add('show');
    }

    /**
     * Mostrar resultados de búsqueda
     */
    displaySearchResults(results, query) {
        const searchResults = document.getElementById('searchResults');
        if (!searchResults) return;

        if (results.length === 0) {
            searchResults.innerHTML = `
                <div class="search-no-results">
                    <i class="fas fa-search"></i>
                    <span>No se encontraron resultados para "${query}"</span>
                </div>
            `;
        } else {
            let html = '<div class="search-results-list">';
            
            results.forEach(result => {
                html += this.renderSearchResult(result, query);
            });
            
            html += '</div>';
            
            if (results.length >= 20) {
                html += `
                    <div class="search-more">
                        <span>Mostrando los primeros 20 resultados</span>
                    </div>
                `;
            }
            
            searchResults.innerHTML = html;
        }

        searchResults.classList.add('show');
    }

    /**
     * Renderizar un resultado de búsqueda
     */
    renderSearchResult(result, query) {
        const preview = Object.values(result.preview).join(' • ');
        const matches = result.matches.length > 0 ? result.matches[0].highlighted : preview;
        
        return `
            <div class="search-result-item" onclick="window.adminUI.selectSearchResult('${result.table}', '${result.id || ''}')">
                <div class="search-result-icon">
                    <i class="fas ${result.icon}"></i>
                </div>
                <div class="search-result-content">
                    <div class="search-result-title">${result.table_display}</div>
                    <div class="search-result-preview">${matches}</div>
                </div>
                <div class="search-result-actions">
                    <i class="fas fa-chevron-right"></i>
                </div>
            </div>
        `;
    }

    /**
     * Seleccionar un resultado de búsqueda
     */
    selectSearchResult(table, id) {
        this.hideSearchResults();
        
        // Limpiar input de búsqueda
        const searchInput = document.getElementById('globalSearch');
        if (searchInput) {
            searchInput.value = '';
        }
        
        // Navegar a la tabla
        if (window.loadTable && typeof window.loadTable === 'function') {
            window.loadTable(table);
        } else {
            // Fallback: cambiar URL
            window.location.hash = table;
        }
        
        // Si hay ID, podrías abrir directamente el editor
        if (id && window.loadEditForm && typeof window.loadEditForm === 'function') {
            setTimeout(() => {
                window.loadEditForm(table, id);
            }, 500);
        }
    }

    /**
     * Ocultar resultados de búsqueda
     */
    hideSearchResults() {
        const searchResults = document.getElementById('searchResults');
        if (searchResults) {
            searchResults.classList.remove('show');
            setTimeout(() => {
                searchResults.innerHTML = '';
            }, 300);
        }
    }
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    // Crear instancia global de AdminUI
    window.adminUI = new AdminUI();
    
    // Mensaje de confirmación en consola (solo en desarrollo)
    if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
        console.log('🎨 ObelisIA Admin UI cargado correctamente');
    }
});

// Exportar para uso como módulo si es necesario
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AdminUI;
}
