/**
 * JavaScript específico para el dashboard
 */

class Dashboard {
    constructor() {
        this.charts = {};
        this.init();
    }

    init() {
        this.initCharts();
        this.loadRealtimeData();
        this.startRealtimeUpdates();
    }

    initCharts() {
        this.initUsersChart();
        this.initToolsChart();
    }

    initUsersChart() {
        const ctx = document.getElementById('usersChart');
        if (!ctx) return;

        this.charts.users = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Hace 7 días', 'Hace 6 días', 'Hace 5 días', 'Hace 4 días', 'Hace 3 días', 'Ayer', 'Hoy'],
                datasets: [{
                    label: 'Nuevos Usuarios',
                    data: [12, 19, 8, 15, 22, 18, 25],
                    borderColor: '#6366f1',
                    backgroundColor: 'rgba(99, 102, 241, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#6366f1',
                    pointBorderColor: '#1e293b',
                    pointBorderWidth: 2,
                    pointRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: 'rgba(71, 85, 105, 0.2)'
                        },
                        ticks: {
                            color: '#94a3b8'
                        }
                    },
                    y: {
                        grid: {
                            color: 'rgba(71, 85, 105, 0.2)'
                        },
                        ticks: {
                            color: '#94a3b8'
                        },
                        beginAtZero: true
                    }
                },
                elements: {
                    point: {
                        hoverRadius: 8
                    }
                },
                interaction: {
                    intersect: false
                }
            }
        });
    }

    initToolsChart() {
        const ctx = document.getElementById('toolsChart');
        if (!ctx) return;

        this.charts.tools = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Generador de Imágenes', 'Asistente de Escritura', 'Editor de Fotos', 'Compositor Musical'],
                datasets: [{
                    data: [45, 25, 20, 10],
                    backgroundColor: [
                        '#6366f1',
                        '#8b5cf6',
                        '#10b981',
                        '#f59e0b'
                    ],
                    borderWidth: 0,
                    hoverOffset: 10
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: '#94a3b8',
                            padding: 20,
                            usePointStyle: true,
                            pointStyle: 'circle'
                        }
                    },
                    tooltip: {
                        backgroundColor: '#1e293b',
                        titleColor: '#f8fafc',
                        bodyColor: '#f8fafc',
                        borderColor: '#475569',
                        borderWidth: 1,
                        cornerRadius: 8,
                        callbacks: {
                            label: function(context) {
                                return context.label + ': ' + context.parsed + '%';
                            }
                        }
                    }
                },
                cutout: '60%'
            }
        });
    }

    async loadRealtimeData() {
        try {
            const response = await fetch('api/dashboard-stats.php');
            const data = await response.json();
            
            if (data.success) {
                this.updateStats(data.stats);
                this.updateCharts(data.charts);
                this.updateActivity(data.activity);
            }
        } catch (error) {
            console.error('Error cargando datos en tiempo real:', error);
        }
    }

    updateStats(stats) {
        // Actualizar contadores con animación
        Object.keys(stats).forEach(key => {
            const element = document.querySelector(`[data-stat="${key}"]`);
            if (element) {
                this.animateNumber(element, parseInt(element.textContent.replace(/\D/g, '')), stats[key]);
            }
        });
    }

    animateNumber(element, start, end) {
        const duration = 1000;
        const startTime = performance.now();
        
        const animate = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            const current = Math.floor(start + (end - start) * this.easeOutCubic(progress));
            element.textContent = this.formatNumber(current);
            
            if (progress < 1) {
                requestAnimationFrame(animate);
            }
        };
        
        requestAnimationFrame(animate);
    }

    easeOutCubic(t) {
        return 1 - Math.pow(1 - t, 3);
    }

    formatNumber(num) {
        return new Intl.NumberFormat('es-ES').format(num);
    }

    updateCharts(chartData) {
        if (chartData.users && this.charts.users) {
            this.charts.users.data.datasets[0].data = chartData.users;
            this.charts.users.update('none');
        }
        
        if (chartData.tools && this.charts.tools) {
            this.charts.tools.data.datasets[0].data = chartData.tools;
            this.charts.tools.update('none');
        }
    }

    updateActivity(activityData) {
        const activityList = document.querySelector('.activity-list');
        if (!activityList || !activityData) return;

        activityList.innerHTML = activityData.map(activity => `
            <div class="activity-item">
                <div class="activity-icon">
                    <i class="fas fa-${this.getActivityIcon(activity.action)}"></i>
                </div>
                <div class="activity-content">
                    <p>${activity.description}</p>
                    <small>${this.formatTimeAgo(activity.created_at)}</small>
                </div>
            </div>
        `).join('');
    }

    getActivityIcon(action) {
        const icons = {
            'login': 'sign-in-alt',
            'logout': 'sign-out-alt',
            'create': 'plus-circle',
            'edit': 'edit',
            'delete': 'trash',
            'view': 'eye',
            'upload': 'upload',
            'download': 'download',
            'payment': 'credit-card',
            'register': 'user-plus',
            'Navegación': 'mouse-pointer',
            'Guardado de creación': 'save',
            'Uso de herramienta': 'magic',
            'Búsqueda': 'search'
        };
        
        return icons[action] || 'circle';
    }

    formatTimeAgo(dateString) {
        const now = new Date();
        const date = new Date(dateString);
        const diff = now - date;
        
        const minutes = Math.floor(diff / 60000);
        const hours = Math.floor(diff / 3600000);
        const days = Math.floor(diff / 86400000);
        
        if (minutes < 1) return 'hace un momento';
        if (minutes < 60) return `hace ${minutes} minutos`;
        if (hours < 24) return `hace ${hours} horas`;
        return `hace ${days} días`;
    }

    startRealtimeUpdates() {
        // Actualizar cada 30 segundos
        setInterval(() => {
            this.loadRealtimeData();
        }, 30000);
    }

    // Funciones de exportación
    exportStats() {
        const stats = this.getCurrentStats();
        this.downloadJSON(stats, 'dashboard-stats.json');
    }

    getCurrentStats() {
        return {
            timestamp: new Date().toISOString(),
            stats: {
                users: document.querySelector('[data-stat="users"]')?.textContent || '0',
                creations: document.querySelector('[data-stat="creations"]')?.textContent || '0',
                revenue: document.querySelector('[data-stat="revenue"]')?.textContent || '0',
                activity: document.querySelector('[data-stat="activity"]')?.textContent || '0'
            }
        };
    }

    downloadJSON(data, filename) {
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    // Función para generar reportes
    generateReport(type) {
        const reportWindow = window.open('', '_blank');
        reportWindow.document.write(this.getReportHTML(type));
        reportWindow.document.close();
    }

    getReportHTML(type) {
        const now = new Date().toLocaleDateString('es-ES');
        
        return `
            <!DOCTYPE html>
            <html>
            <head>
                <title>Reporte ${type} - ${now}</title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 20px; }
                    .header { text-align: center; margin-bottom: 30px; }
                    .stats { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; }
                    .stat-card { padding: 20px; border: 1px solid #ddd; border-radius: 8px; }
                    .stat-number { font-size: 2em; font-weight: bold; color: #6366f1; }
                    .stat-label { color: #666; margin-top: 5px; }
                </style>
            </head>
            <body>
                <div class="header">
                    <h1>Reporte de Dashboard</h1>
                    <p>Generado el ${now}</p>
                </div>
                <div class="stats">
                    <div class="stat-card">
                        <div class="stat-number">${document.querySelector('[data-stat="users"]')?.textContent || '0'}</div>
                        <div class="stat-label">Usuarios Totales</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number">${document.querySelector('[data-stat="creations"]')?.textContent || '0'}</div>
                        <div class="stat-label">Creaciones Totales</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number">${document.querySelector('[data-stat="revenue"]')?.textContent || '0'}</div>
                        <div class="stat-label">Ingresos Totales</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number">${document.querySelector('[data-stat="activity"]')?.textContent || '0'}</div>
                        <div class="stat-label">Actividad Hoy</div>
                    </div>
                </div>
            </body>
            </html>
        `;
    }
}

// Inicializar dashboard cuando esté listo
document.addEventListener('DOMContentLoaded', () => {
    window.dashboard = new Dashboard();
});

// Agregar botones de acción al dashboard
document.addEventListener('DOMContentLoaded', () => {
    const dashboardHeader = document.querySelector('.dashboard-header');
    if (dashboardHeader) {
        const actionsDiv = document.createElement('div');
        actionsDiv.className = 'dashboard-actions';
        actionsDiv.innerHTML = `
            <button class="btn btn-outline" onclick="window.dashboard.exportStats()">
                <i class="fas fa-download"></i> Exportar Datos
            </button>
            <button class="btn btn-outline" onclick="window.dashboard.generateReport('dashboard')">
                <i class="fas fa-file-pdf"></i> Generar Reporte
            </button>
        `;
        dashboardHeader.appendChild(actionsDiv);
    }
});

// Estilos adicionales para botones
const additionalStyles = `
.dashboard-actions {
    margin-top: 1rem;
    display: flex;
    gap: 1rem;
}

.btn {
    padding: 0.5rem 1rem;
    border-radius: 0.5rem;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.9rem;
    font-weight: 500;
    transition: var(--transition-fast);
    cursor: pointer;
    border: none;
}

.btn-outline {
    background: transparent;
    border: 1px solid var(--border-color);
    color: var(--light-text);
}

.btn-outline:hover {
    background: var(--dark-card);
    border-color: var(--primary-color);
}
`;

const style = document.createElement('style');
style.textContent = additionalStyles;
document.head.appendChild(style);
