<?php
/**
 * Obelis Studio - Página Principal
 * Editor visual de proyectos multimedia
 */

// Debug temporal
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Iniciar sesión solo si no está activa
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Determinar la ruta base según cómo se está incluyendo el archivo
$base_path = dirname(__DIR__);

require_once $base_path . '/helpers/db.php';
require_once $base_path . '/src/Auth/Auth.php';

// Inicializar Auth para verificación independiente
$auth = new \ObelisIA\Auth\Auth($db);

// Compatibilidad: normalizar variables de sesión
if (!isset($_SESSION['user_id']) && isset($_SESSION['user']['id'])) {
    $_SESSION['user_id'] = $_SESSION['user']['id'];
    $_SESSION['username'] = $_SESSION['user']['username'] ?? '';
}

// Verificar autenticación
if (!$auth->isLoggedIn()) {
    header('Location: /acceso');
    exit;
}

require_once $base_path . '/src/ObelisStudio/ObelisStudio.php';
require_once $base_path . '/src/ObelisStudio/ProjectManager.php';

// Debug temporal
echo "<!-- Debug: Usuario autenticado: " . ($_SESSION['user_id'] ?? 'NO') . " -->\n";

$studio = new \ObelisIA\ObelisStudio\ObelisStudio($_SESSION['user_id']);
$projectManager = new \ObelisIA\ObelisStudio\ProjectManager($_SESSION['user_id']);

// Debug
echo "<!-- Debug: Studio y ProjectManager creados -->\n";

// Verificar acceso
if (!$studio->hasAccess()) {
    header('Location: /panel?error=no_access');
    exit;
}

echo "<!-- Debug: Acceso verificado -->\n";

// Obtener estadísticas y proyectos del usuario
try {
    $stats = $studio->getUserStats();
    echo "<!-- Debug: Stats obtenidas: " . json_encode($stats) . " -->\n";
    
    $projects = $projectManager->getUserProjects();
    echo "<!-- Debug: Proyectos obtenidos: " . count($projects) . " -->\n";
} catch (Exception $e) {
    echo "<!-- Debug Error: " . $e->getMessage() . " -->\n";
    $stats = ['total_projects' => 0, 'published_projects' => 0];
    $projects = [];
}

$page_title = "Obelis Studio";
$page_description = "Editor visual de proyectos multimedia";
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> | ObelisIA</title>
    <meta name="description" content="<?php echo $page_description; ?>">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="/assets/studio/css/studio.css" rel="stylesheet">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="/panel">
                <i class="fas fa-arrow-left me-2"></i>
                <strong>ObelisIA</strong>
            </a>
            <div class="navbar-nav ms-auto">
                <span class="navbar-text text-white">
                    <i class="fas fa-palette me-2"></i>
                    Obelis Studio
                </span>
            </div>
        </div>
    </nav>

    <!-- Header -->
    <div class="studio-header bg-gradient-primary text-white py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h1 class="display-4 fw-bold mb-3 animate__animated animate__fadeInUp">
                        <i class="fas fa-magic me-3"></i>
                        Obelis Studio
                    </h1>
                    <p class="lead mb-4 animate__animated animate__fadeInUp animate__delay-1s">
                        Crea proyectos multimedia interactivos combinando todas tus creaciones de IA en un editor visual intuitivo.
                    </p>
                    <button class="btn btn-light btn-lg me-3 animate__animated animate__fadeInUp animate__delay-2s" onclick="createNewProject()">
                        <i class="fas fa-plus me-2"></i>
                        Nuevo Proyecto
                    </button>
                    <button class="btn btn-outline-light btn-lg animate__animated animate__fadeInUp animate__delay-2s" onclick="showTutorial()">
                        <i class="fas fa-question-circle me-2"></i>
                        Tutorial
                    </button>
                </div>
                <div class="col-lg-4 text-center">
                    <div class="stats-card bg-white bg-opacity-10 rounded-3 p-4 animate__animated animate__fadeInRight">
                        <h3 class="mb-3">Tus Estadísticas</h3>
                        <div class="row text-center">
                            <div class="col-6">
                                <div class="stat-number"><?php echo $stats['total_projects'] ?? 0; ?></div>
                                <div class="stat-label">Proyectos</div>
                            </div>
                            <div class="col-6">
                                <div class="stat-number"><?php echo $stats['published_projects'] ?? 0; ?></div>
                                <div class="stat-label">Publicados</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="container py-5">
        <!-- Projects Section -->
        <div class="row">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 class="mb-0">
                        <i class="fas fa-folder-open me-2 text-primary"></i>
                        Mis Proyectos
                    </h2>
                    <div class="btn-group" role="group">
                        <button type="button" class="btn btn-outline-secondary active" data-filter="all">
                            <i class="fas fa-th me-1"></i> Todos
                        </button>
                        <button type="button" class="btn btn-outline-secondary" data-filter="published">
                            <i class="fas fa-globe me-1"></i> Publicados
                        </button>
                        <button type="button" class="btn btn-outline-secondary" data-filter="draft">
                            <i class="fas fa-edit me-1"></i> Borradores
                        </button>
                    </div>
                </div>

                <!-- Projects Grid -->
                <div class="row" id="projectsGrid">
                    <?php if (empty($projects)): ?>
                    <!-- Empty State -->
                    <div class="col-12">
                        <div class="empty-state text-center py-5">
                            <div class="empty-icon mb-4">
                                <i class="fas fa-magic fa-4x text-muted"></i>
                            </div>
                            <h3 class="text-muted mb-3">¡Crea tu primer proyecto!</h3>
                            <p class="text-muted mb-4">
                                Combina tus imágenes, textos y audios generados por IA en proyectos visuales increíbles.
                            </p>
                            <button class="btn btn-primary btn-lg" onclick="createNewProject()">
                                <i class="fas fa-plus me-2"></i>
                                Comenzar Ahora
                            </button>
                        </div>
                    </div>
                    <?php else: ?>
                    <!-- New Project Card -->
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="project-card new-project-card" onclick="createNewProject()">
                            <div class="card h-100 border-2 border-dashed">
                                <div class="card-body d-flex flex-column justify-content-center align-items-center text-center">
                                    <div class="new-project-icon mb-3">
                                        <i class="fas fa-plus fa-3x text-primary"></i>
                                    </div>
                                    <h5 class="card-title text-primary mb-2">Nuevo Proyecto</h5>
                                    <p class="card-text text-muted">
                                        Crea un nuevo proyecto multimedia
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Existing Projects -->
                    <?php foreach ($projects as $project): ?>
                    <div class="col-lg-4 col-md-6 mb-4 project-item" data-status="<?php echo $project['status']; ?>">
                        <div class="project-card">
                            <div class="card h-100">
                                <?php if ($project['thumbnail']): ?>
                                <img src="<?php echo htmlspecialchars($project['thumbnail']); ?>" class="card-img-top" alt="Thumbnail">
                                <?php else: ?>
                                <div class="card-img-top bg-light d-flex align-items-center justify-content-center" style="height: 200px;">
                                    <i class="fas fa-image fa-3x text-muted"></i>
                                </div>
                                <?php endif; ?>
                                
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <h5 class="card-title mb-0"><?php echo htmlspecialchars($project['title']); ?></h5>
                                        <div class="dropdown">
                                            <button class="btn btn-sm btn-outline-secondary" type="button" data-bs-toggle="dropdown">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="/studio/editor.php?id=<?php echo $project['id']; ?>">
                                                    <i class="fas fa-edit me-2"></i>Editar
                                                </a></li>
                                                <li><a class="dropdown-item" href="/studio/viewer.php?id=<?php echo $project['id']; ?>">
                                                    <i class="fas fa-eye me-2"></i>Ver
                                                </a></li>
                                                <li><hr class="dropdown-divider"></li>
                                                <li><a class="dropdown-item" href="#" onclick="duplicateProject(<?php echo $project['id']; ?>)">
                                                    <i class="fas fa-copy me-2"></i>Duplicar
                                                </a></li>
                                                <li><a class="dropdown-item text-danger" href="#" onclick="deleteProject(<?php echo $project['id']; ?>)">
                                                    <i class="fas fa-trash me-2"></i>Eliminar
                                                </a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    
                                    <p class="card-text text-muted small">
                                        <?php echo htmlspecialchars(substr($project['description'], 0, 100)); ?>
                                        <?php if (strlen($project['description']) > 100) echo '...'; ?>
                                    </p>
                                    
                                    <div class="d-flex justify-content-between align-items-center">
                                        <small class="text-muted">
                                            <?php echo date('d/m/Y', strtotime($project['updated_at'])); ?>
                                        </small>
                                        <span class="badge bg-<?php echo $project['status'] === 'published' ? 'success' : 'secondary'; ?>">
                                            <?php echo $project['status'] === 'published' ? 'Publicado' : 'Borrador'; ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Create Project Modal -->
    <div class="modal fade" id="createProjectModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-plus me-2"></i>
                        Nuevo Proyecto
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="createProjectForm">
                        <div class="mb-3">
                            <label for="projectTitle" class="form-label">Título del Proyecto *</label>
                            <input type="text" class="form-control" id="projectTitle" required maxlength="255">
                        </div>
                        <div class="mb-3">
                            <label for="projectDescription" class="form-label">Descripción</label>
                            <textarea class="form-control" id="projectDescription" rows="3" maxlength="500"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" onclick="submitCreateProject()">
                        <i class="fas fa-magic me-2"></i>
                        Crear Proyecto
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JS -->
    <script src="/assets/studio/js/studio.js"></script>
</body>
</html>
