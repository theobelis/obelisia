<?php
/**
 * Obelis Studio - Editor Visual
 * Editor de proyectos multimedia con drag & drop
 */

// Debug temporal
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Determinar la ruta base según cómo se está incluyendo el archivo
$base_path = dirname(__DIR__);

require_once $base_path . '/helpers/db.php';
require_once $base_path . '/src/Auth/Auth.php';

// Inicializar Auth para verificación independiente
$auth = new \ObelisIA\Auth\Auth($db);

// Compatibilidad: normalizar variables de sesión
if (!isset($_SESSION['user_id']) && isset($_SESSION['user']['id'])) {
    $_SESSION['user_id'] = $_SESSION['user']['id'];
    $_SESSION['username'] = $_SESSION['user']['username'] ?? '';
}

// Verificar autenticación
if (!$auth->isLoggedIn()) {
    header('Location: /acceso');
    exit;
}

require_once $base_path . '/src/ObelisStudio/ProjectManager.php';
require_once $base_path . '/src/ObelisStudio/ElementManager.php';

$projectManager = new \ObelisIA\ObelisStudio\ProjectManager($_SESSION['user_id']);
$elementManager = new \ObelisIA\ObelisStudio\ElementManager($_SESSION['user_id']);

// Obtener ID del proyecto
$project_id = $_GET['id'] ?? null;

if (!$project_id) {
    header('Location: /studio');
    exit;
}

// Cargar proyecto
$project = $projectManager->getProject($project_id);

// Verificar si se está importando una creación
$import_creation = $_GET['import_creation'] ?? null;
$creation_to_import = null;

if ($import_creation) {
    try {
        $creation_to_import = json_decode(urldecode($import_creation), true);
        if (!$creation_to_import || !isset($creation_to_import['id'])) {
            $creation_to_import = null;
        }
    } catch (Exception $e) {
        $creation_to_import = null;
    }
}

if (!$project) {
    header('Location: /studio?error=project_not_found');
    exit;
}

// Verificar permisos
if ($project['user_id'] != $_SESSION['user_id']) {
    header('Location: /studio?error=no_permission');
    exit;
}

// Obtener biblioteca del usuario
$library = $elementManager->getUserLibrary();

$page_title = "Editor - " . htmlspecialchars($project['title']);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> | Obelis Studio</title>
    
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.0/Sortable.min.css" rel="stylesheet">
    <link href="/assets/studio/css/studio.css" rel="stylesheet">
    <link href="/assets/studio/css/editor.css" rel="stylesheet">
</head>
<body class="editor-body">
    
    <!-- Top Toolbar -->
    <nav class="editor-toolbar navbar navbar-expand-lg navbar-dark bg-dark border-bottom">
        <div class="container-fluid">
            <!-- Left Section -->
            <div class="d-flex align-items-center">
                <a href="/studio" class="btn btn-outline-light me-3">
                    <i class="fas fa-arrow-left"></i>
                </a>
                <div class="project-info">
                    <h5 class="mb-0 text-white" id="projectTitle"><?php echo htmlspecialchars($project['title']); ?></h5>
                    <small class="text-muted" id="lastSaved">
                        Guardado: <span id="lastSavedTime">Hace un momento</span>
                    </small>
                </div>
            </div>

            <!-- Center Section -->
            <div class="d-flex align-items-center mx-auto">
                <div class="btn-group" role="group">
                    <button type="button" class="btn btn-outline-light" id="undoBtn" title="Deshacer">
                        <i class="fas fa-undo"></i>
                    </button>
                    <button type="button" class="btn btn-outline-light" id="redoBtn" title="Rehacer">
                        <i class="fas fa-redo"></i>
                    </button>
                </div>
                
                <div class="btn-group ms-3" role="group">
                    <button type="button" class="btn btn-outline-light" id="previewBtn" title="Vista Previa">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button type="button" class="btn btn-outline-light" id="fullscreenBtn" title="Pantalla Completa">
                        <i class="fas fa-expand"></i>
                    </button>
                </div>
            </div>

            <!-- Right Section -->
            <div class="d-flex align-items-center">
                <div class="save-status me-3">
                    <span class="badge bg-success" id="saveStatus">
                        <i class="fas fa-check"></i> Guardado
                    </span>
                </div>
                
                <div class="btn-group" role="group">
                    <button type="button" class="btn btn-success" id="publishBtn">
                        <i class="fas fa-globe me-2"></i>
                        <?php echo $project['is_public'] ? 'Despublicar' : 'Publicar'; ?>
                    </button>
                    <button type="button" class="btn btn-primary" id="saveBtn">
                        <i class="fas fa-save me-2"></i>
                        Guardar
                    </button>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Editor Layout -->
    <div class="editor-layout">
        
        <!-- Left Sidebar - Library -->
        <div class="sidebar sidebar-left" id="librarySidebar">
            <div class="sidebar-header">
                <h6 class="mb-0">
                    <i class="fas fa-images me-2"></i>
                    Biblioteca Personal
                </h6>
                <button class="btn btn-sm btn-outline-secondary" id="toggleLibraryBtn">
                    <i class="fas fa-chevron-left"></i>
                </button>
            </div>
            
            <div class="sidebar-content">
                <!-- Library Tabs -->
                <ul class="nav nav-pills mb-3" id="libraryTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="images-tab" data-bs-toggle="pill" data-bs-target="#images" type="button">
                            <i class="fas fa-image"></i>
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="texts-tab" data-bs-toggle="pill" data-bs-target="#texts" type="button">
                            <i class="fas fa-file-text"></i>
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="audios-tab" data-bs-toggle="pill" data-bs-target="#audios" type="button">
                            <i class="fas fa-music"></i>
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="elements-tab" data-bs-toggle="pill" data-bs-target="#elements" type="button">
                            <i class="fas fa-plus"></i>
                        </button>
                    </li>
                </ul>

                <!-- Library Content -->
                <div class="tab-content" id="libraryTabContent">
                    <!-- Images Tab -->
                    <div class="tab-pane fade show active" id="images" role="tabpanel">
                        <div class="library-search mb-3">
                            <input type="text" class="form-control form-control-sm" placeholder="Buscar imágenes..." id="searchImages">
                        </div>
                        <div class="library-items" id="imagesLibrary">
                            <?php foreach ($library as $item): ?>
                                <?php if ($item['type'] === 'image'): ?>
                                <div class="library-item" draggable="true" data-type="image" data-id="<?php echo $item['id']; ?>">
                                    <div class="library-item-preview">
                                        <img src="<?php echo htmlspecialchars($item['file_path']); ?>" alt="<?php echo htmlspecialchars($item['title']); ?>">
                                    </div>
                                    <div class="library-item-info">
                                        <div class="library-item-title"><?php echo htmlspecialchars(substr($item['title'], 0, 20)); ?></div>
                                        <div class="library-item-date"><?php echo date('d/m', strtotime($item['created_at'])); ?></div>
                                    </div>
                                </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Texts Tab -->
                    <div class="tab-pane fade" id="texts" role="tabpanel">
                        <div class="library-search mb-3">
                            <input type="text" class="form-control form-control-sm" placeholder="Buscar textos..." id="searchTexts">
                        </div>
                        <div class="library-items" id="textsLibrary">
                            <?php foreach ($library as $item): ?>
                                <?php if ($item['type'] === 'text'): ?>
                                <div class="library-item" draggable="true" data-type="text" data-id="<?php echo $item['id']; ?>">
                                    <div class="library-item-preview text-preview">
                                        <i class="fas fa-file-text fa-2x"></i>
                                    </div>
                                    <div class="library-item-info">
                                        <div class="library-item-title"><?php echo htmlspecialchars(substr($item['title'], 0, 20)); ?></div>
                                        <div class="library-item-date"><?php echo date('d/m', strtotime($item['created_at'])); ?></div>
                                    </div>
                                </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Audios Tab -->
                    <div class="tab-pane fade" id="audios" role="tabpanel">
                        <div class="library-search mb-3">
                            <input type="text" class="form-control form-control-sm" placeholder="Buscar audios..." id="searchAudios">
                        </div>
                        <div class="library-items" id="audiosLibrary">
                            <?php foreach ($library as $item): ?>
                                <?php if ($item['type'] === 'audio'): ?>
                                <div class="library-item" draggable="true" data-type="audio" data-id="<?php echo $item['id']; ?>">
                                    <div class="library-item-preview audio-preview">
                                        <i class="fas fa-music fa-2x"></i>
                                    </div>
                                    <div class="library-item-info">
                                        <div class="library-item-title"><?php echo htmlspecialchars(substr($item['title'], 0, 20)); ?></div>
                                        <div class="library-item-date"><?php echo date('d/m', strtotime($item['created_at'])); ?></div>
                                    </div>
                                </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Elements Tab -->
                    <div class="tab-pane fade" id="elements" role="tabpanel">
                        <div class="elements-palette">
                            <div class="element-category">
                                <h6>Estructura</h6>
                                <div class="palette-item" draggable="true" data-type="heading">
                                    <i class="fas fa-heading"></i>
                                    <span>Título</span>
                                </div>
                                <div class="palette-item" draggable="true" data-type="paragraph">
                                    <i class="fas fa-paragraph"></i>
                                    <span>Párrafo</span>
                                </div>
                                <div class="palette-item" draggable="true" data-type="divider">
                                    <i class="fas fa-minus"></i>
                                    <span>Separador</span>
                                </div>
                            </div>
                            
                            <div class="element-category">
                                <h6>Multimedia</h6>
                                <div class="palette-item" draggable="true" data-type="video">
                                    <i class="fas fa-video"></i>
                                    <span>Video</span>
                                </div>
                                <div class="palette-item" draggable="true" data-type="gallery">
                                    <i class="fas fa-images"></i>
                                    <span>Galería</span>
                                </div>
                            </div>
                            
                            <div class="element-category">
                                <h6>Layout</h6>
                                <div class="palette-item" draggable="true" data-type="columns">
                                    <i class="fas fa-columns"></i>
                                    <span>Columnas</span>
                                </div>
                                <div class="palette-item" draggable="true" data-type="spacer">
                                    <i class="fas fa-arrows-alt-v"></i>
                                    <span>Espacio</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Canvas -->
        <div class="editor-canvas">
            <div class="canvas-container">
                <div class="canvas-header">
                    <div class="canvas-title">
                        <input type="text" class="form-control" id="canvasTitle" value="<?php echo htmlspecialchars($project['title']); ?>">
                    </div>
                    <div class="canvas-description">
                        <textarea class="form-control" id="canvasDescription" placeholder="Descripción del proyecto..."><?php echo htmlspecialchars($project['description']); ?></textarea>
                    </div>
                </div>

                <!-- Editor Content Area -->
                <div class="editor-content" id="editorContent">
                    <div class="drop-zone" id="dropZone">
                        <div class="drop-zone-message">
                            <i class="fas fa-magic fa-3x mb-3"></i>
                            <h4>Arrastra elementos aquí para comenzar</h4>
                            <p>Selecciona imágenes, textos o audios de tu biblioteca y arrástralos a esta área</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Sidebar - Properties -->
        <div class="sidebar sidebar-right" id="propertiesSidebar">
            <div class="sidebar-header">
                <h6 class="mb-0">
                    <i class="fas fa-cogs me-2"></i>
                    Propiedades
                </h6>
                <button class="btn btn-sm btn-outline-secondary" id="togglePropertiesBtn">
                    <i class="fas fa-chevron-right"></i>
                </button>
            </div>
            
            <div class="sidebar-content" id="propertiesContent">
                <div class="no-selection-message">
                    <i class="fas fa-mouse-pointer fa-2x mb-3"></i>
                    <p>Selecciona un elemento para ver sus propiedades</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Modals -->
    
    <!-- Preview Modal -->
    <div class="modal fade" id="previewModal" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Vista Previa del Proyecto</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-0">
                    <div class="preview-container" id="previewContainer">
                        <!-- Preview content will be loaded here -->
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <button type="button" class="btn btn-primary" onclick="openInNewTab()">
                        <i class="fas fa-external-link-alt me-2"></i>
                        Abrir en Nueva Pestaña
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Element Settings Modal -->
    <div class="modal fade" id="elementSettingsModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Configuración del Elemento</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="elementSettingsBody">
                    <!-- Dynamic content -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="saveElementSettings">Guardar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.0/Sortable.min.js"></script>
    
    <!-- Editor Configuration -->
    <script>
        // Global configuration
        window.EditorConfig = {
            projectId: <?php echo $project_id; ?>,
            projectData: <?php echo json_encode($project); ?>,
            libraryData: <?php echo json_encode($library); ?>,
            userId: <?php echo $_SESSION['user_id']; ?>,
            autoSaveInterval: 30000, // 30 seconds
            importedCreation: <?php echo $creation_to_import ? json_encode($creation_to_import) : 'null'; ?>
        };
    </script>
    
    <!-- Custom Scripts -->
    <script src="/assets/studio/js/editor.js"></script>
    <script src="/assets/studio/js/drag-drop.js"></script>
    <script src="/assets/studio/js/wysiwyg.js"></script>
</body>
</html>
