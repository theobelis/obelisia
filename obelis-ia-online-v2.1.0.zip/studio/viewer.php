<?php
/**
 * Obelis Studio - Visor de Proyectos
 * Visualización de proyectos publicados y privados
 */

session_start();
require_once '../helpers/db.php';
require_once '../src/Auth/Auth.php';
require_once '../src/ObelisStudio/ProjectManager.php';

// Inicializar Auth para verificación independiente
$auth = new \ObelisIA\Auth\Auth($db);

// Compatibilidad: normalizar variables de sesión
if (!isset($_SESSION['user_id']) && isset($_SESSION['user']['id'])) {
    $_SESSION['user_id'] = $_SESSION['user']['id'];
    $_SESSION['username'] = $_SESSION['user']['username'] ?? '';
}

// Obtener ID del proyecto
$project_id = $_GET['id'] ?? null;

if (!$project_id) {
    header('Location: /studio');
    exit;
}

$user_id = $_SESSION['user_id'] ?? null;
$projectManager = new \ObelisIA\ObelisStudio\ProjectManager($user_id);

// Cargar proyecto
$project = $projectManager->getProject($project_id);

if (!$project) {
    header('Location: /studio?error=project_not_found');
    exit;
}

// Verificar permisos para proyectos privados
if (!$project['is_public'] && (!$user_id || $project['user_id'] != $user_id)) {
    header('Location: /studio?error=no_permission');
    exit;
}

// Obtener información del autor si no es el propietario
$author_info = null;
if ($project['user_id'] != $user_id) {
    $stmt = $conn->prepare("SELECT username, profile_pic FROM users WHERE id = ?");
    $stmt->bind_param("i", $project['user_id']);
    $stmt->execute();
    $author_info = $stmt->get_result()->fetch_assoc();
}

$is_owner = ($user_id && $project['user_id'] == $user_id);
$page_title = htmlspecialchars($project['title']);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> | Obelis Studio</title>
    <meta name="description" content="<?php echo htmlspecialchars($project['description']); ?>">
    
    <!-- Open Graph Meta Tags -->
    <meta property="og:title" content="<?php echo $page_title; ?>">
    <meta property="og:description" content="<?php echo htmlspecialchars($project['description']); ?>">
    <meta property="og:type" content="article">
    <meta property="og:url" content="<?php echo 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>">
    <?php if ($project['thumbnail']): ?>
    <meta property="og:image" content="<?php echo htmlspecialchars($project['thumbnail']); ?>">
    <?php endif; ?>
    
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="/assets/studio/css/studio.css" rel="stylesheet">
    <link href="/assets/studio/css/viewer.css" rel="stylesheet">
</head>
<body class="viewer-body">
    
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom">
        <div class="container">
            <div class="d-flex align-items-center">
                <a href="/studio" class="btn btn-outline-primary me-3">
                    <i class="fas fa-arrow-left me-2"></i>
                    Volver al Studio
                </a>
                
                <div class="project-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a href="/studio">Obelis Studio</a></li>
                            <li class="breadcrumb-item active"><?php echo $page_title; ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
            
            <div class="d-flex align-items-center">
                <?php if ($is_owner): ?>
                <a href="/studio/editor?id=<?php echo $project['id']; ?>" class="btn btn-primary me-2">
                    <i class="fas fa-edit me-2"></i>
                    Editar
                </a>
                <?php endif; ?>
                
                <div class="dropdown">
                    <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="fas fa-share-alt me-2"></i>
                        Compartir
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#" onclick="shareOnSocial('twitter')">
                            <i class="fab fa-twitter me-2"></i>Twitter
                        </a></li>
                        <li><a class="dropdown-item" href="#" onclick="shareOnSocial('facebook')">
                            <i class="fab fa-facebook me-2"></i>Facebook
                        </a></li>
                        <li><a class="dropdown-item" href="#" onclick="copyProjectLink()">
                            <i class="fas fa-link me-2"></i>Copiar enlace
                        </a></li>
                        <?php if ($is_owner): ?>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="#" onclick="exportProject('html')">
                            <i class="fas fa-code me-2"></i>Exportar HTML
                        </a></li>
                        <li><a class="dropdown-item" href="#" onclick="exportProject('pdf')">
                            <i class="fas fa-file-pdf me-2"></i>Exportar PDF
                        </a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <!-- Project Header -->
    <div class="project-header bg-light py-4">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h1 class="display-6 fw-bold mb-3"><?php echo $page_title; ?></h1>
                    <?php if ($project['description']): ?>
                    <p class="lead text-muted mb-3"><?php echo htmlspecialchars($project['description']); ?></p>
                    <?php endif; ?>
                    
                    <div class="project-meta">
                        <?php if ($author_info): ?>
                        <div class="d-flex align-items-center mb-2">
                            <img src="<?php echo $author_info['profile_pic'] ?: '/assets/img/default-avatar.png'; ?>" 
                                 class="rounded-circle me-2" width="24" height="24" alt="Avatar">
                            <span class="text-muted">Por <strong><?php echo htmlspecialchars($author_info['username']); ?></strong></span>
                        </div>
                        <?php endif; ?>
                        
                        <div class="d-flex align-items-center text-muted small">
                            <i class="fas fa-calendar me-2"></i>
                            <span class="me-3">Publicado el <?php echo date('d/m/Y', strtotime($project['updated_at'])); ?></span>
                            
                            <i class="fas fa-eye me-2"></i>
                            <span class="me-3">
                                <span id="viewCount">Cargando...</span> visualizaciones
                            </span>
                            
                            <?php if ($project['is_public']): ?>
                            <span class="badge bg-success">
                                <i class="fas fa-globe me-1"></i>Público
                            </span>
                            <?php else: ?>
                            <span class="badge bg-secondary">
                                <i class="fas fa-lock me-1"></i>Privado
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-4 text-end">
                    <?php if ($project['thumbnail']): ?>
                    <img src="<?php echo htmlspecialchars($project['thumbnail']); ?>" 
                         class="img-fluid rounded shadow" alt="Vista previa del proyecto" 
                         style="max-height: 200px;">
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Project Content -->
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <article class="project-content" id="projectContent">
                    <!-- El contenido del proyecto se cargará aquí -->
                    <div class="loading-container text-center py-5">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Cargando...</span>
                        </div>
                        <p class="mt-3 text-muted">Cargando proyecto...</p>
                    </div>
                </article>
            </div>
        </div>
    </div>

    <!-- Project Actions (para proyectos públicos) -->
    <?php if ($project['is_public'] && $user_id && !$is_owner): ?>
    <div class="project-actions bg-light py-4">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <button class="btn btn-outline-primary" id="likeBtn" onclick="toggleLike()">
                                <i class="far fa-heart me-2"></i>
                                <span id="likeText">Me gusta</span>
                                (<span id="likeCount">0</span>)
                            </button>
                            
                            <button class="btn btn-outline-secondary ms-2" onclick="showComments()">
                                <i class="far fa-comment me-2"></i>
                                Comentarios (<span id="commentCount">0</span>)
                            </button>
                        </div>
                        
                        <div>
                            <button class="btn btn-success" onclick="showCreateSimilar()">
                                <i class="fas fa-plus me-2"></i>
                                Crear Similar
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Related Projects -->
    <?php if ($project['is_public']): ?>
    <div class="related-projects py-5 bg-light">
        <div class="container">
            <h3 class="text-center mb-4">Proyectos Relacionados</h3>
            <div class="row" id="relatedProjects">
                <!-- Se cargarán dinámicamente -->
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Comments Section (para proyectos públicos) -->
    <?php if ($project['is_public']): ?>
    <div class="comments-section py-5" id="commentsSection" style="display: none;">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <h4 class="mb-4">Comentarios</h4>
                    
                    <?php if ($user_id): ?>
                    <div class="comment-form mb-4">
                        <div class="d-flex">
                            <img src="<?php echo $_SESSION['profile_pic'] ?? '/assets/img/default-avatar.png'; ?>" 
                                 class="rounded-circle me-3" width="40" height="40" alt="Tu avatar">
                            <div class="flex-grow-1">
                                <textarea class="form-control" id="commentText" rows="3" 
                                          placeholder="Escribe un comentario..."></textarea>
                                <div class="text-end mt-2">
                                    <button class="btn btn-primary" onclick="submitComment()">
                                        <i class="fas fa-paper-plane me-2"></i>Comentar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <div id="commentsList">
                        <!-- Los comentarios se cargarán aquí -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Configuration -->
    <script>
        window.ViewerConfig = {
            projectId: <?php echo $project['id']; ?>,
            projectData: <?php echo json_encode($project); ?>,
            isOwner: <?php echo $is_owner ? 'true' : 'false'; ?>,
            userId: <?php echo $user_id ? $user_id : 'null'; ?>,
            isPublic: <?php echo $project['is_public'] ? 'true' : 'false'; ?>
        };
    </script>
    
    <!-- Custom Scripts -->
    <script src="/assets/studio/js/viewer.js"></script>
</body>
</html>
