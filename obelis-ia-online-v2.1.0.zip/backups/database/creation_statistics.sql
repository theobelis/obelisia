-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 07-08-2025 a las 14:31:43
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `if0_39552758_obelisia_db`
--

-- --------------------------------------------------------

--
-- Estructura para la vista `creation_statistics`
--

-- VISTA DESHABILITADA: No se pueden crear vistas en este hosting
-- Error: CREATE VIEW comando denegado
-- Usar en su lugar: helpers/creation_statistics.php

/*
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `creation_statistics`  AS SELECT `uc`.`id` AS `id`, `uc`.`user_id` AS `user_id`, `uc`.`title` AS `title`, `uc`.`type` AS `type`, `uc`.`tool_used` AS `tool_used`, `uc`.`created_at` AS `created_at`, coalesce(`likes`.`like_count`,0) AS `like_count`, coalesce(`comments`.`comment_count`,0) AS `comment_count`, coalesce(`reports`.`report_count`,0) AS `report_count`, coalesce(`likes`.`like_count`,0) + coalesce(`comments`.`comment_count`,0) * 2 AS `engagement_score` FROM (((`user_creations` `uc` left join (select `creation_likes`.`creation_id` AS `creation_id`,count(0) AS `like_count` from `creation_likes` group by `creation_likes`.`creation_id`) `likes` on(`uc`.`id` = `likes`.`creation_id`)) left join (select `creation_comments`.`creation_id` AS `creation_id`,count(0) AS `comment_count` from `creation_comments` where `creation_comments`.`status` = 'active' group by `creation_comments`.`creation_id`) `comments` on(`uc`.`id` = `comments`.`creation_id`)) left join (select `content_reports`.`creation_id` AS `creation_id`,count(0) AS `report_count` from `content_reports` where `content_reports`.`creation_id` is not null and `content_reports`.`status` <> 'dismissed' group by `content_reports`.`creation_id`) `reports` on(`uc`.`id` = `reports`.`creation_id`)) WHERE `uc`.`status` = 'completed' ;
*/

--
-- VIEW `creation_statistics`
-- Datos: Ninguna
--

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
