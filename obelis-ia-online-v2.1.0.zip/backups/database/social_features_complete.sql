-- Tablas adicionales para funcionalidades sociales de Obelis Studio
-- Ejecutar después de la estructura principal

USE if0_39552758_obelisia_db;

-- Tabla para registrar likes en proyectos
CREATE TABLE IF NOT EXISTS project_likes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    user_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_like (project_id, user_id),
    INDEX idx_project_likes (project_id),
    INDEX idx_user_likes (user_id),
    FOREIGN KEY (project_id) REFERENCES obelis_studio_projects(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabla para registrar visualizaciones detalladas
CREATE TABLE IF NOT EXISTS project_views (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    user_id INT NULL, -- NULL para visitantes anónimos
    viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_address VARCHAR(45) NULL,
    user_agent TEXT NULL,
    INDEX idx_project_views (project_id),
    INDEX idx_user_views (user_id),
    INDEX idx_view_date (viewed_at),
    UNIQUE KEY unique_user_view (project_id, user_id),
    FOREIGN KEY (project_id) REFERENCES obelis_studio_projects(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Tabla para comentarios en proyectos
CREATE TABLE IF NOT EXISTS project_comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    user_id INT NOT NULL,
    parent_id INT NULL, -- Para respuestas a comentarios
    content TEXT NOT NULL,
    is_edited BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_project_comments (project_id),
    INDEX idx_user_comments (user_id),
    INDEX idx_parent_comments (parent_id),
    INDEX idx_comment_date (created_at),
    FOREIGN KEY (project_id) REFERENCES obelis_studio_projects(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (parent_id) REFERENCES project_comments(id) ON DELETE CASCADE
);

-- Tabla para tags de proyectos (normalizada)
CREATE TABLE IF NOT EXISTS project_tags (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    tag VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_project_tags (project_id),
    INDEX idx_tag_name (tag),
    UNIQUE KEY unique_project_tag (project_id, tag),
    FOREIGN KEY (project_id) REFERENCES obelis_studio_projects(id) ON DELETE CASCADE
);

-- Tabla para seguir usuarios/autores
CREATE TABLE IF NOT EXISTS user_follows (
    id INT AUTO_INCREMENT PRIMARY KEY,
    follower_id INT NOT NULL,
    following_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_follower (follower_id),
    INDEX idx_following (following_id),
    UNIQUE KEY unique_follow (follower_id, following_id),
    FOREIGN KEY (follower_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (following_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabla para proyectos destacados/favoritos
CREATE TABLE IF NOT EXISTS project_favorites (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    user_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_project_favorites (project_id),
    INDEX idx_user_favorites (user_id),
    UNIQUE KEY unique_favorite (project_id, user_id),
    FOREIGN KEY (project_id) REFERENCES obelis_studio_projects(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabla para reportes de proyectos
CREATE TABLE IF NOT EXISTS project_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    user_id INT NOT NULL,
    reason ENUM('spam', 'inappropriate', 'copyright', 'other') NOT NULL,
    description TEXT,
    status ENUM('pending', 'reviewed', 'resolved', 'dismissed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_project_reports (project_id),
    INDEX idx_user_reports (user_id),
    INDEX idx_report_status (status),
    FOREIGN KEY (project_id) REFERENCES obelis_studio_projects(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabla para estadísticas agregadas de proyectos (para optimización)
CREATE TABLE IF NOT EXISTS project_stats_cache (
    project_id INT PRIMARY KEY,
    views_count INT DEFAULT 0,
    likes_count INT DEFAULT 0,
    comments_count INT DEFAULT 0,
    favorites_count INT DEFAULT 0,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES obelis_studio_projects(id) ON DELETE CASCADE
);

-- Triggers para mantener actualizada la cache de estadísticas

DELIMITER ;;

-- Trigger para actualizar likes_count
CREATE TRIGGER update_likes_count_insert 
AFTER INSERT ON project_likes 
FOR EACH ROW 
BEGIN
    INSERT INTO project_stats_cache (project_id, likes_count) 
    VALUES (NEW.project_id, 1)
    ON DUPLICATE KEY UPDATE 
    likes_count = likes_count + 1,
    last_updated = CURRENT_TIMESTAMP;
END;;

CREATE TRIGGER update_likes_count_delete 
AFTER DELETE ON project_likes 
FOR EACH ROW 
BEGIN
    UPDATE project_stats_cache 
    SET likes_count = GREATEST(0, likes_count - 1),
        last_updated = CURRENT_TIMESTAMP
    WHERE project_id = OLD.project_id;
END;;

-- Trigger para actualizar comments_count
CREATE TRIGGER update_comments_count_insert 
AFTER INSERT ON project_comments 
FOR EACH ROW 
BEGIN
    INSERT INTO project_stats_cache (project_id, comments_count) 
    VALUES (NEW.project_id, 1)
    ON DUPLICATE KEY UPDATE 
    comments_count = comments_count + 1,
    last_updated = CURRENT_TIMESTAMP;
END;;

CREATE TRIGGER update_comments_count_delete 
AFTER DELETE ON project_comments 
FOR EACH ROW 
BEGIN
    UPDATE project_stats_cache 
    SET comments_count = GREATEST(0, comments_count - 1),
        last_updated = CURRENT_TIMESTAMP
    WHERE project_id = OLD.project_id;
END;;

-- Trigger para actualizar favorites_count
CREATE TRIGGER update_favorites_count_insert 
AFTER INSERT ON project_favorites 
FOR EACH ROW 
BEGIN
    INSERT INTO project_stats_cache (project_id, favorites_count) 
    VALUES (NEW.project_id, 1)
    ON DUPLICATE KEY UPDATE 
    favorites_count = favorites_count + 1,
    last_updated = CURRENT_TIMESTAMP;
END;;

CREATE TRIGGER update_favorites_count_delete 
AFTER DELETE ON project_favorites 
FOR EACH ROW 
BEGIN
    UPDATE project_stats_cache 
    SET favorites_count = GREATEST(0, favorites_count - 1),
        last_updated = CURRENT_TIMESTAMP
    WHERE project_id = OLD.project_id;
END;;

DELIMITER ;

-- Insertar estadísticas iniciales para proyectos existentes
INSERT INTO project_stats_cache (project_id, views_count)
SELECT id, COALESCE(views, 0)
FROM obelis_studio_projects
ON DUPLICATE KEY UPDATE views_count = VALUES(views_count);

-- Índices adicionales para optimización
CREATE INDEX idx_projects_public_recent ON obelis_studio_projects(is_public, created_at DESC);
CREATE INDEX idx_projects_category_public ON obelis_studio_projects(category, is_public);
CREATE INDEX idx_projects_user_public ON obelis_studio_projects(user_id, is_public);

-- Agregar columna de tags si no existe (migración segura)
ALTER TABLE obelis_studio_projects 
ADD COLUMN IF NOT EXISTS tags VARCHAR(500) NULL 
AFTER description;

-- Agregar columna de categoría si no existe
ALTER TABLE obelis_studio_projects 
ADD COLUMN IF NOT EXISTS category ENUM('personal', 'education', 'business', 'creative', 'other') DEFAULT 'personal' 
AFTER tags;
