-- Tabla para posts del blog de ObelisIA
CREATE TABLE IF NOT EXISTS blog_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    headline VARCHAR(255) NOT NULL,
    alt_headline VARCHAR(255) DEFAULT NULL,
    image VARCHAR(512) DEFAULT NULL,
    description TEXT NOT NULL,
    content LONGTEXT NOT NULL,
    author VARCHAR(128) DEFAULT 'Equipo ObelisIA',
    date_published DATE NOT NULL,
    keywords VARCHAR(255) DEFAULT NULL,
    genre VARCHAR(128) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status ENUM('publicado','borrador','oculto') DEFAULT 'publicado'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
