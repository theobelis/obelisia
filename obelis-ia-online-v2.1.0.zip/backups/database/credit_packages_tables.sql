-- Tabla de paquetes de créditos
CREATE TABLE IF NOT EXISTS credit_packages (
    id INT PRIMARY KEY AUTO_INCREMENT,
    package_name VARCHAR(100) NOT NULL,
    credits_amount INT NOT NULL,
    bonus_credits INT DEFAULT 0,
    price DECIMAL(10,2) NOT NULL,
    original_price DECIMAL(10,2) NULL,
    discount_percentage INT DEFAULT 0,
    is_popular BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    sort_order INT DEFAULT 0,
    features JSON NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insertar paquetes de créditos por defecto
INSERT INTO credit_packages (package_name, credits_amount, bonus_credits, price, original_price, discount_percentage, is_popular, sort_order) VALUES
('Pack Starter', 100, 0, 9.99, NULL, 0, FALSE, 1),
('Pack Popular', 250, 25, 19.99, 24.99, 20, TRUE, 2),
('Pack Pro', 500, 75, 34.99, 49.99, 30, FALSE, 3),
('Pack Business', 1000, 200, 59.99, 99.99, 40, FALSE, 4),
('Pack Enterprise', 2500, 500, 119.99, 199.99, 40, FALSE, 5);

-- Tabla de historial de compras de créditos
CREATE TABLE IF NOT EXISTS credit_purchases (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    package_id INT NOT NULL,
    credits_purchased INT NOT NULL,
    bonus_credits INT DEFAULT 0,
    amount_paid DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    payment_id VARCHAR(255) NULL,
    payment_status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
    payment_date TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (package_id) REFERENCES credit_packages(id) ON DELETE RESTRICT
);

-- Tabla de transacciones de créditos (log detallado)
CREATE TABLE IF NOT EXISTS credit_transactions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    transaction_type ENUM('purchase', 'usage', 'bonus', 'refund', 'adjustment') NOT NULL,
    credits_amount INT NOT NULL,
    credits_before INT NOT NULL,
    credits_after INT NOT NULL,
    description TEXT NULL,
    reference_id INT NULL,
    reference_type VARCHAR(50) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_date (user_id, created_at),
    INDEX idx_type (transaction_type)
);

-- Procedimiento para añadir créditos de forma segura
DELIMITER //
CREATE PROCEDURE AddCredits(
    IN p_user_id INT,
    IN p_credits INT,
    IN p_transaction_type VARCHAR(50),
    IN p_description TEXT,
    IN p_reference_id INT,
    IN p_reference_type VARCHAR(50)
)
BEGIN
    DECLARE v_current_credits INT DEFAULT 0;
    DECLARE v_new_credits INT;
    
    START TRANSACTION;
    
    -- Obtener créditos actuales con lock
    SELECT credits INTO v_current_credits 
    FROM users 
    WHERE id = p_user_id 
    FOR UPDATE;
    
    -- Calcular nuevos créditos
    SET v_new_credits = v_current_credits + p_credits;
    
    -- Validar que no sea negativo (excepto para ajustes administrativos)
    IF v_new_credits < 0 AND p_transaction_type != 'adjustment' THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Créditos insuficientes';
    END IF;
    
    -- Actualizar créditos del usuario
    UPDATE users 
    SET credits = v_new_credits,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = p_user_id;
    
    -- Registrar transacción
    INSERT INTO credit_transactions (
        user_id, transaction_type, credits_amount, 
        credits_before, credits_after, description,
        reference_id, reference_type
    ) VALUES (
        p_user_id, p_transaction_type, p_credits,
        v_current_credits, v_new_credits, p_description,
        p_reference_id, p_reference_type
    );
    
    COMMIT;
END //
DELIMITER ;

-- Trigger para actualizar experiencia cuando se usan créditos
DELIMITER //
CREATE TRIGGER update_experience_on_credit_use 
AFTER INSERT ON credit_transactions
FOR EACH ROW
BEGIN
    -- Solo dar experiencia por uso de herramientas, no por compras
    IF NEW.transaction_type = 'usage' AND NEW.credits_amount < 0 THEN
        -- Dar 1 punto de experiencia por cada crédito usado
        UPDATE users 
        SET experience = experience + ABS(NEW.credits_amount)
        WHERE id = NEW.user_id;
    END IF;
END //
DELIMITER ;

-- Vista para estadísticas de créditos
CREATE VIEW user_credit_stats AS
SELECT 
    u.id as user_id,
    u.username,
    u.credits as current_credits,
    COALESCE(total_purchased.total_purchased, 0) as total_credits_purchased,
    COALESCE(total_used.total_used, 0) as total_credits_used,
    COALESCE(total_spent.total_spent, 0.00) as total_money_spent,
    COALESCE(purchase_count.purchase_count, 0) as total_purchases
FROM users u
LEFT JOIN (
    SELECT user_id, SUM(credits_purchased + bonus_credits) as total_purchased
    FROM credit_purchases 
    WHERE payment_status = 'completed'
    GROUP BY user_id
) total_purchased ON u.id = total_purchased.user_id
LEFT JOIN (
    SELECT user_id, SUM(ABS(credits_amount)) as total_used
    FROM credit_transactions 
    WHERE transaction_type = 'usage'
    GROUP BY user_id
) total_used ON u.id = total_used.user_id
LEFT JOIN (
    SELECT user_id, SUM(amount_paid) as total_spent
    FROM credit_purchases 
    WHERE payment_status = 'completed'
    GROUP BY user_id
) total_spent ON u.id = total_spent.user_id
LEFT JOIN (
    SELECT user_id, COUNT(*) as purchase_count
    FROM credit_purchases 
    WHERE payment_status = 'completed'
    GROUP BY user_id
) purchase_count ON u.id = purchase_count.user_id;
