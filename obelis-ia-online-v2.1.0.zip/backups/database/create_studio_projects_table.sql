-- Crear tabla obelis_studio_projects si no existe

CREATE TABLE IF NOT EXISTS `obelis_studio_projects` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `user_id` int(11) NOT NULL,
    `title` varchar(255) NOT NULL,
    `description` text,
    `content` longtext,
    `thumbnail` varchar(500) DEFAULT NULL,
    `status` enum('draft','published') DEFAULT 'draft',
    `is_public` tinyint(1) DEFAULT 0,
    `views` int(11) DEFAULT 0,
    `tags` varchar(500) DEFAULT NULL,
    `category` enum('personal','education','business','creative','other') DEFAULT 'personal',
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `user_id` (`user_id`),
    KEY `status` (`status`),
    KEY `is_public` (`is_public`),
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
