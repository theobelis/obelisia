-- Agregar campos al sistema de usuarios para créditos y gamificación
ALTER TABLE users ADD COLUMN IF NOT EXISTS credits INT DEFAULT 100;
ALTER TABLE users ADD COLUMN IF NOT EXISTS level INT DEFAULT 1;
ALTER TABLE users ADD COLUMN IF NOT EXISTS total_experience INT DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS total_generations INT DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS daily_generations INT DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS monthly_generations INT DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS last_generation_date DATE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS last_monthly_reset DATE;

-- Tabla para logs de generaciones
CREATE TABLE IF NOT EXISTS generation_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    tool_type VARCHAR(50) NOT NULL,
    credits_cost INT NOT NULL,
    experience_gained INT NOT NULL,
    generation_data JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_tool (user_id, tool_type),
    INDEX idx_created_at (created_at),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabla para visualizaciones de anuncios
CREATE TABLE IF NOT EXISTS ad_views (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    ad_id VARCHAR(100) NOT NULL,
    tool_type VARCHAR(50) NOT NULL,
    view_duration INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_date (user_id, created_at),
    INDEX idx_tool_type (tool_type),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabla para logros/achievements
CREATE TABLE IF NOT EXISTS user_achievements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    achievement_type VARCHAR(50) NOT NULL,
    achievement_data JSON,
    credits_reward INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_user_achievement (user_id, achievement_type),
    INDEX idx_user_id (user_id),
    INDEX idx_achievement_type (achievement_type),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabla para compras de créditos
CREATE TABLE IF NOT EXISTS credit_purchases (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    credits_amount INT NOT NULL,
    price_paid DECIMAL(10,2),
    currency VARCHAR(3) DEFAULT 'USD',
    transaction_id VARCHAR(255),
    payment_method VARCHAR(50),
    status ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_transaction_id (transaction_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabla para configuración de precios de créditos
CREATE TABLE IF NOT EXISTS credit_packages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    package_name VARCHAR(100) NOT NULL,
    credits_amount INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'USD',
    bonus_credits INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insertar paquetes de créditos por defecto
INSERT INTO credit_packages (package_name, credits_amount, price, bonus_credits, sort_order) VALUES
('Paquete Básico', 100, 9.99, 0, 1),
('Paquete Estándar', 250, 19.99, 25, 2),
('Paquete Premium', 500, 34.99, 75, 3),
('Paquete Pro', 1000, 59.99, 200, 4),
('Mega Paquete', 2500, 119.99, 500, 5)
ON DUPLICATE KEY UPDATE package_name=VALUES(package_name);

-- Tabla para límites de herramientas por plan
CREATE TABLE IF NOT EXISTS tool_limits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    plan_type ENUM('free', 'premium') NOT NULL,
    tool_type VARCHAR(50) NOT NULL,
    daily_limit INT,
    monthly_limit INT,
    requires_credits BOOLEAN DEFAULT TRUE,
    requires_ads BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_plan_tool (plan_type, tool_type)
);

-- Insertar límites por defecto
INSERT INTO tool_limits (plan_type, tool_type, daily_limit, monthly_limit, requires_credits, requires_ads) VALUES
('free', 'text_generation', 10, 50, TRUE, TRUE),
('free', 'image_generation', 3, 20, TRUE, TRUE),
('free', 'audio_generation', 2, 10, TRUE, TRUE),
('free', 'translation', 20, 100, TRUE, TRUE),
('free', 'text_improvement', 5, 30, TRUE, TRUE),
('free', 'seo_optimization', 3, 15, TRUE, TRUE),
('premium', 'text_generation', 200, 5000, FALSE, FALSE),
('premium', 'image_generation', 50, 1000, FALSE, FALSE),
('premium', 'audio_generation', 30, 300, FALSE, FALSE),
('premium', 'translation', 500, 10000, FALSE, FALSE),
('premium', 'text_improvement', 100, 2000, FALSE, FALSE),
('premium', 'seo_optimization', 50, 1000, FALSE, FALSE)
ON DUPLICATE KEY UPDATE daily_limit=VALUES(daily_limit), monthly_limit=VALUES(monthly_limit);

-- Tabla para estadísticas de uso
CREATE TABLE IF NOT EXISTS usage_stats (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    tool_type VARCHAR(50) NOT NULL,
    usage_date DATE NOT NULL,
    usage_count INT DEFAULT 1,
    credits_spent INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_user_tool_date (user_id, tool_type, usage_date),
    INDEX idx_usage_date (usage_date),
    INDEX idx_tool_type (tool_type),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Otorgar créditos iniciales a usuarios existentes sin créditos
UPDATE users SET credits = 100 WHERE credits IS NULL OR credits = 0;
