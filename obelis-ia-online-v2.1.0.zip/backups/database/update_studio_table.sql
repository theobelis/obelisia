-- Migración: Actualizar tabla obelis_studio_projects para características sociales

USE if0_39552758_obelisia_db;

-- Agregar columnas faltantes
ALTER TABLE obelis_studio_projects 
ADD COLUMN IF NOT EXISTS views INT DEFAULT 0 AFTER is_public,
ADD COLUMN IF NOT EXISTS tags VARCHAR(500) NULL AFTER description,
ADD COLUMN IF NOT EXISTS category ENUM('personal', 'education', 'business', 'creative', 'other') DEFAULT 'personal' AFTER tags;

-- Actualizar tabla para que tenga todos los campos necesarios
SELECT 'Tabla obelis_studio_projects actualizada correctamente' as resultado;
