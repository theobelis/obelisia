-- Tabla para sistema de likes en creaciones
CREATE TABLE `creation_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `creation_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_creation_like` (`user_id`, `creation_id`),
  KEY `idx_creation_likes_user_id` (`user_id`),
  KEY `idx_creation_likes_creation_id` (`creation_id`),
  KEY `idx_creation_likes_created_at` (`created_at`),
  CONSTRAINT `creation_likes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `creation_likes_ibfk_2` FOREIGN KEY (`creation_id`) REFERENCES `user_creations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla para comentarios en creaciones
CREATE TABLE `creation_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `creation_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `comment` text NOT NULL,
  `status` enum('active','hidden','deleted') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_creation_comments_user_id` (`user_id`),
  KEY `idx_creation_comments_creation_id` (`creation_id`),
  KEY `idx_creation_comments_parent_id` (`parent_id`),
  KEY `idx_creation_comments_created_at` (`created_at`),
  KEY `idx_creation_comments_status` (`status`),
  CONSTRAINT `creation_comments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `creation_comments_ibfk_2` FOREIGN KEY (`creation_id`) REFERENCES `user_creations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `creation_comments_ibfk_3` FOREIGN KEY (`parent_id`) REFERENCES `creation_comments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla para seguimiento de usuarios (followers/following)
CREATE TABLE `user_follows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `follower_id` int(11) NOT NULL COMMENT 'Usuario que sigue',
  `following_id` int(11) NOT NULL COMMENT 'Usuario seguido',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_follow_relationship` (`follower_id`, `following_id`),
  KEY `idx_user_follows_follower_id` (`follower_id`),
  KEY `idx_user_follows_following_id` (`following_id`),
  KEY `idx_user_follows_created_at` (`created_at`),
  CONSTRAINT `user_follows_ibfk_1` FOREIGN KEY (`follower_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_follows_ibfk_2` FOREIGN KEY (`following_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chk_no_self_follow` CHECK (`follower_id` != `following_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla para reportes de contenido
CREATE TABLE IF NOT EXISTS content_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    creation_id INT NOT NULL,
    reason ENUM('spam', 'inappropriate', 'copyright', 'other') NOT NULL,
    description TEXT,
    status ENUM('pending', 'reviewed', 'resolved') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (creation_id) REFERENCES user_creations(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_creation_report (user_id, creation_id)
);

-- Tabla para notificaciones sociales
CREATE TABLE IF NOT EXISTS social_notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    from_user_id INT NOT NULL,
    type ENUM('like', 'comment', 'follow') NOT NULL,
    creation_id INT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    read_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (from_user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (creation_id) REFERENCES user_creations(id) ON DELETE CASCADE,
    INDEX idx_user_notifications (user_id, created_at DESC),
    INDEX idx_user_unread (user_id, is_read)
);

-- Vista para estadísticas de creaciones con engagement
CREATE OR REPLACE VIEW `creation_statistics` AS
SELECT 
    uc.id,
    uc.user_id,
    uc.title,
    uc.type,
    uc.tool_used,
    uc.created_at,
    COALESCE(likes.like_count, 0) as like_count,
    COALESCE(comments.comment_count, 0) as comment_count,
    COALESCE(reports.report_count, 0) as report_count,
    (COALESCE(likes.like_count, 0) + COALESCE(comments.comment_count, 0) * 2) as engagement_score
FROM user_creations uc
LEFT JOIN (
    SELECT creation_id, COUNT(*) as like_count
    FROM creation_likes
    GROUP BY creation_id
) likes ON uc.id = likes.creation_id
LEFT JOIN (
    SELECT creation_id, COUNT(*) as comment_count
    FROM creation_comments
    WHERE status = 'active'
    GROUP BY creation_id
) comments ON uc.id = comments.creation_id
LEFT JOIN (
    SELECT creation_id, COUNT(*) as report_count
    FROM content_reports
    WHERE creation_id IS NOT NULL AND status != 'dismissed'
    GROUP BY creation_id
) reports ON uc.id = reports.creation_id
WHERE uc.status = 'completed';
