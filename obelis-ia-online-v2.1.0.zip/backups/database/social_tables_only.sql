-- Solo las tablas sociales sin triggers (para evitar duplicados)

USE if0_39552758_obelisia_db;

-- Tabla para registrar likes en proyectos
CREATE TABLE IF NOT EXISTS project_likes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    user_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_like (project_id, user_id),
    INDEX idx_project_likes (project_id),
    INDEX idx_user_likes (user_id),
    FOREIGN KEY (project_id) REFERENCES obelis_studio_projects(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabla para registrar visualizaciones detalladas
CREATE TABLE IF NOT EXISTS project_views (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    user_id INT NULL, -- NULL para visitantes anónimos
    viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_address VARCHAR(45) NULL,
    user_agent TEXT NULL,
    INDEX idx_project_views (project_id),
    INDEX idx_user_views (user_id),
    INDEX idx_view_date (viewed_at),
    UNIQUE KEY unique_user_view (project_id, user_id),
    FOREIGN KEY (project_id) REFERENCES obelis_studio_projects(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Tabla para comentarios en proyectos
CREATE TABLE IF NOT EXISTS project_comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    user_id INT NOT NULL,
    parent_id INT NULL, -- Para respuestas a comentarios
    content TEXT NOT NULL,
    is_edited BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_project_comments (project_id),
    INDEX idx_user_comments (user_id),
    INDEX idx_parent_comments (parent_id),
    INDEX idx_comment_date (created_at),
    FOREIGN KEY (project_id) REFERENCES obelis_studio_projects(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (parent_id) REFERENCES project_comments(id) ON DELETE CASCADE
);

-- Tabla para estadísticas agregadas de proyectos (para optimización)
CREATE TABLE IF NOT EXISTS project_stats_cache (
    project_id INT PRIMARY KEY,
    views_count INT DEFAULT 0,
    likes_count INT DEFAULT 0,
    comments_count INT DEFAULT 0,
    favorites_count INT DEFAULT 0,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES obelis_studio_projects(id) ON DELETE CASCADE
);

-- Índices adicionales para optimización
CREATE INDEX IF NOT EXISTS idx_projects_public_recent ON obelis_studio_projects(is_public, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_projects_category_public ON obelis_studio_projects(category, is_public);
CREATE INDEX IF NOT EXISTS idx_projects_user_public ON obelis_studio_projects(user_id, is_public);

SELECT 'Tablas sociales creadas correctamente' as resultado;
