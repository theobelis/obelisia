-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 06-08-2025 a las 09:03:44
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `if0_39552758_obelisia_db`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `role` enum('admin','moderator','user') DEFAULT 'user',
  `status` enum('active','suspended','deleted') DEFAULT 'active',
  `language` varchar(5) NOT NULL DEFAULT 'es',
  `email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `newsletter_subscribed` tinyint(1) NOT NULL DEFAULT 1,
  `notifications_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `max_monthly_usage` int(11) DEFAULT NULL,
  `api_rate_limit` int(11) NOT NULL DEFAULT 60,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_login` timestamp NULL DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `membership_type` enum('free','premium') DEFAULT 'free',
  `subscription_start` date DEFAULT NULL,
  `subscription_end` date DEFAULT NULL,
  `membership_expires_at` timestamp NULL DEFAULT NULL,
  `credits_remaining` int(11) DEFAULT 10,
  `verification_token` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `full_name`, `role`, `status`, `language`, `email_verified`, `newsletter_subscribed`, `notifications_enabled`, `max_monthly_usage`, `api_rate_limit`, `notes`, `created_at`, `updated_at`, `last_login`, `profile_image`, `bio`, `phone`, `address`, `membership_type`, `subscription_start`, `subscription_end`, `membership_expires_at`, `credits_remaining`, `verification_token`) VALUES
(9, 'admin', 'theobeliscorp@gmail.com', '$2y$10$DrvMk05K9vw3QJMG5LVoCeyZc7zpb9gBJ2cr1d6NWr2nRJV8PRNZe', 'ObelisIA', 'admin', 'active', 'es', 1, 1, 1, NULL, 60, NULL, '2025-07-25 23:53:20', '2025-08-05 06:11:45', '2025-07-30 23:09:56', NULL, 'Administrador, Desarrollador, CEO', '951774812', 'Puente Piedra, Lima\r\nLas Orquideas', 'premium', NULL, NULL, '2025-08-26 00:11:03', 10, NULL),
(10, 'peppecanto@hotmail.com', 'peppecanto@hotmail.com', '$2y$10$EH7HCAe3rNOg0ajrfBsGFecNONUYxsiuQuqgqv7ExDgDWa74wv9ka', 'Samuel Canto', 'admin', 'active', 'es', 1, 1, 1, NULL, 60, NULL, '2025-07-27 06:51:57', '2025-08-06 00:21:13', '2025-08-05 04:30:23', NULL, NULL, NULL, NULL, 'free', NULL, NULL, '2025-08-31 06:59:07', 10, NULL),
(15, 'ppkntoo', 'peppecanto18@gmail.com', '$2y$10$E/FIDqHW6peMOC.Ehvrs/.NYoctP8IXbjnDTCty60YQBpwiLM/Ani', 'Samuel Rondón', 'admin', 'active', 'es', 1, 1, 1, NULL, 60, NULL, '2025-08-05 06:50:32', '2025-08-06 00:21:19', NULL, NULL, NULL, NULL, NULL, 'free', NULL, NULL, NULL, 10, 'd2a7d81db4af1e986c320327b806a22fdee22f66a12c8639396f8464ed7a26d7'),
(1001, 'admin_demo', 'admin_demo@demo.com', 'demo123', 'Admin Demo', 'admin', 'active', 'es', 1, 1, 1, 100, 60, NULL, '2025-08-05 20:45:22', '2025-08-05 20:45:22', '2025-08-05 20:45:22', NULL, NULL, NULL, NULL, 'premium', '2025-08-01', '2025-09-01', NULL, 100, NULL),
(1002, 'usuario_demo', 'usuario_demo@demo.com', 'demo456', 'Usuario Prueba', 'user', 'deleted', 'es', 1, 1, 1, 50, 60, NULL, '2025-08-05 20:45:22', '2025-08-06 06:37:05', '2025-08-05 20:45:22', NULL, NULL, NULL, NULL, 'free', NULL, NULL, NULL, 10, NULL),
(1003, 'admin_obelis@obelis.ia', 'asdasdads@gmail.com', '$2y$10$sSbOX53GkndnyoCVAMDM3.7ffpFyi2.IRHTr0H0GFXfXf/KfPk5Bq', 'asdasdads', 'user', 'deleted', 'es', 0, 1, 1, NULL, 60, '', '2025-08-06 06:15:59', '2025-08-06 06:46:58', NULL, NULL, NULL, NULL, NULL, 'free', NULL, NULL, NULL, 0, NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_users_email` (`email`),
  ADD KEY `idx_users_username` (`username`),
  ADD KEY `idx_users_status` (`status`),
  ADD KEY `idx_users_created_at` (`created_at`),
  ADD KEY `idx_users_membership_status` (`membership_type`,`status`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1004;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
