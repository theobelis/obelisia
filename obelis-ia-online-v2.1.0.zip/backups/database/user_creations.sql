-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 07-08-2025 a las 09:38:28
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `if0_39552758_obelisia_db`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user_creations`
--

CREATE TABLE `user_creations` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` enum('image','video','music','text','utility') NOT NULL,
  `tool_used` varchar(100) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int(11) DEFAULT NULL,
  `file_type` varchar(100) DEFAULT NULL,
  `prompt` text DEFAULT NULL,
  `settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`settings`)),
  `credits_used` int(11) DEFAULT 1,
  `is_public` tinyint(1) DEFAULT 0,
  `status` enum('processing','completed','failed') DEFAULT 'completed',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `privacy` enum('public','private') NOT NULL DEFAULT 'private'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `user_creations`
--

INSERT INTO `user_creations` (`id`, `user_id`, `type`, `tool_used`, `title`, `description`, `file_path`, `file_size`, `file_type`, `prompt`, `settings`, `credits_used`, `is_public`, `status`, `created_at`, `updated_at`, `privacy`) VALUES
(2, 1, 'image', 'ia-img', NULL, NULL, '/api/tools/proxy-crop-image.php?url=https%3A%2F%2Fimage.pollinations.ai%2Fprompt%2Fasdasdasd%3Fwidth%3D768%26height%3D768%26seed%3D1754542535729%26attempt%3D0&crop=60', NULL, NULL, NULL, NULL, 1, 0, 'completed', '2025-08-07 04:55:51', '2025-08-07 04:55:51', 'private'),
(3, 1, 'image', 'ia-img', 'Dragon Celeste', 'Dragon Japones Celeste', '/api/tools/proxy-crop-image.php?url=https%3A%2F%2Fimage.pollinations.ai%2Fprompt%2FDragon%2520celeste%252C%2520realistic%2520style%3Fwidth%3D576%26height%3D1024%26seed%3D1754543400615%26attempt%3D1&crop=60', NULL, NULL, NULL, NULL, 1, 0, 'completed', '2025-08-07 05:11:05', '2025-08-07 05:11:05', 'private'),
(4, 1, 'image', 'ia-img', 'asdasd', 'asdasd', '/api/tools/proxy-crop-image.php?url=https%3A%2F%2Fimage.pollinations.ai%2Fprompt%2Fasdasd%3Fwidth%3D768%26height%3D768%26seed%3D1754547103279%26attempt%3D0&crop=60', NULL, NULL, NULL, NULL, 1, 0, 'completed', '2025-08-07 06:12:00', '2025-08-07 06:12:00', 'public');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `user_creations`
--
ALTER TABLE `user_creations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_creation_type` (`type`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `user_creations`
--
ALTER TABLE `user_creations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `user_creations`
--
ALTER TABLE `user_creations`
  ADD CONSTRAINT `user_creations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
