<?php
require_once __DIR__ . '/../../helpers/db.php';
require_once __DIR__ . '/../../helpers/social_functions.php';


// Asegurar que $pdo esté disponible
global $pdo;
if (!isset($pdo)) {
    $pdo = getPdoConnection();
}

// Verificar autenticación
if (!isset($_SESSION['user_id'])) {
    header('Location: /acceso');
    exit;
}

$user_id = filter_var($_GET['id'] ?? $_SESSION['user_id'], FILTER_VALIDATE_INT);

if (!$user_id) {
    header('Location: /error/404');
    exit;
}

$current_user_id = $_SESSION['user_id'];
$is_own_profile = ($user_id == $current_user_id);

try {
    // Obtener información del usuario
    $stmt = $pdo->prepare("
        SELECT 
            id, 
            username, 
            full_name, 
            bio, 
            profile_image, 
            created_at,
            membership_type,
            level,
            exp_total
        FROM users 
        WHERE id = ? AND status = 'active'
    ");
    $stmt->execute([$user_id]);
    $profile_user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$profile_user) {
        header('Location: /error/404');
        exit;
    }

    // Obtener estadísticas del usuario
    $stats_sql = "
        SELECT 
            COUNT(DISTINCT uc.id) as total_creations,
            COUNT(DISTINCT CASE WHEN uc.privacy = 'public' THEN uc.id END) as public_creations,
            COALESCE(SUM(likes.like_count), 0) as total_likes,
            COUNT(DISTINCT uc.type) as creation_types,
            (SELECT COUNT(*) FROM user_follows WHERE following_id = ?) as followers_count,
            (SELECT COUNT(*) FROM user_follows WHERE follower_id = ?) as following_count
        FROM user_creations uc
        LEFT JOIN (
            SELECT creation_id, COUNT(*) as like_count
            FROM creation_likes 
            GROUP BY creation_id
        ) likes ON uc.id = likes.creation_id
        WHERE uc.user_id = ? AND uc.status = 'completed'
    ";
    $stmt = $pdo->prepare($stats_sql);
    $stmt->execute([$user_id, $user_id, $user_id]);
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);

    // Verificar si el usuario actual sigue a este perfil
    $is_following = false;
    if (!$is_own_profile) {
        $stmt = $pdo->prepare("SELECT id FROM user_follows WHERE follower_id = ? AND following_id = ?");
        $stmt->execute([$current_user_id, $user_id]);
        $is_following = $stmt->fetch() !== false;
    }

    // Configuración de paginación para creaciones
    $page = max(1, intval($_GET['page'] ?? 1));
    $limit = 12;
    $offset = ($page - 1) * $limit;

    // Obtener creaciones del usuario
    $creations_where = $is_own_profile 
        ? "uc.user_id = ? AND uc.status = 'completed'" 
        : "uc.user_id = ? AND uc.privacy = 'public' AND uc.status = 'completed'";

    $creations_sql = "
        SELECT 
            uc.id,
            uc.title,
            uc.description,
            uc.file_path,
            uc.type,
            uc.tool_used,
            uc.privacy,
            uc.created_at,
            COALESCE(likes.like_count, 0) as like_count,
            COALESCE(comments.comment_count, 0) as comment_count
        FROM user_creations uc
        LEFT JOIN (
            SELECT creation_id, COUNT(*) as like_count
            FROM creation_likes 
            GROUP BY creation_id
        ) likes ON uc.id = likes.creation_id
        LEFT JOIN (
            SELECT creation_id, COUNT(*) as comment_count
            FROM creation_comments 
            WHERE status = 'active'
            GROUP BY creation_id
        ) comments ON uc.id = comments.creation_id
        WHERE {$creations_where}
        ORDER BY uc.created_at DESC
        LIMIT " . intval($limit) . " OFFSET " . intval($offset) . "
    ";

    $stmt = $pdo->prepare($creations_sql);
    $stmt->execute([$user_id]);
    $creations = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Contar total de creaciones para paginación
    $count_sql = "SELECT COUNT(*) FROM user_creations uc WHERE {$creations_where}";
    $stmt = $pdo->prepare($count_sql);
    $stmt->execute([$user_id]);
    $total_creations = $stmt->fetchColumn();
    $total_pages = ceil($total_creations / $limit);

    // Obtener creaciones populares (últimos 30 días)
    $popular_sql = "
        SELECT 
            uc.id,
            uc.title,
            uc.file_path,
            uc.type,
            COALESCE(likes.like_count, 0) as like_count
        FROM user_creations uc
        LEFT JOIN (
            SELECT creation_id, COUNT(*) as like_count
            FROM creation_likes 
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            GROUP BY creation_id
        ) likes ON uc.id = likes.creation_id
        WHERE {$creations_where}
        AND uc.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        ORDER BY like_count DESC, uc.created_at DESC
        LIMIT 3
    ";
    $stmt = $pdo->prepare($popular_sql);
    $stmt->execute([$user_id]);
    $popular_creations = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    error_log("Error en perfil de usuario: " . $e->getMessage());
    $profile_user = null;
}
?>

<?php if (!$profile_user): ?>
    <div class="container py-5">
        <div class="text-center">
            <h2>Usuario no encontrado</h2>
            <p class="text-muted">El usuario que buscas no existe o no está disponible.</p>
            <a href="/comunidad" class="btn btn-primary">Volver a la comunidad</a>
        </div>
    </div>
<?php else: ?>

<div class="container-fluid py-4">
    <!-- Header del perfil -->
    <div class="row">
        <div class="col-12">
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <div class="row align-items-center">
                        <!-- Avatar y info básica -->
                        <div class="col-lg-8">
                            <div class="d-flex align-items-center">
                                <div class="me-4">
                                    <?php if (!empty($profile_user['profile_image'])): ?>
                                        <img src="<?= htmlspecialchars($profile_user['profile_image']) ?>" 
                                             class="rounded-circle shadow" width="100" height="100"
                                             style="object-fit: cover;">
                                    <?php else: ?>
                                        <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center text-white shadow" 
                                             style="width: 100px; height: 100px; font-size: 2rem;">
                                            <?= strtoupper(substr($profile_user['username'], 0, 1)) ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div>
                                    <h2 class="mb-1"><?= htmlspecialchars($profile_user['full_name']) ?></h2>
                                    <p class="text-muted mb-1">@<?= htmlspecialchars($profile_user['username']) ?></p>
                                    <?php if (!empty($profile_user['bio'])): ?>
                                        <p class="mb-2"><?= htmlspecialchars($profile_user['bio']) ?></p>
                                    <?php endif; ?>
                                    <div class="d-flex align-items-center gap-3 text-muted small">
                                        <span><i class="fas fa-calendar-alt me-1"></i>Se unió <?= date('M Y', strtotime($profile_user['created_at'])) ?></span>
                                        <span class="badge bg-<?= $profile_user['membership_type'] === 'premium' ? 'warning' : 'secondary' ?>">
                                            <?= ucfirst($profile_user['membership_type']) ?>
                                        </span>
                                        <span class="badge bg-info">Nivel <?= $profile_user['level'] ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Acciones -->
                        <div class="col-lg-4 text-lg-end mt-3 mt-lg-0">
                            <?php if ($is_own_profile): ?>
                                <a href="/perfil" class="btn btn-outline-primary me-2">
                                    <i class="fas fa-edit me-1"></i>Editar perfil
                                </a>
                                <a href="/mis-creaciones" class="btn btn-primary">
                                    <i class="fas fa-plus me-1"></i>Nueva creación
                                </a>
                            <?php else: ?>
                                <button class="btn btn-outline-secondary me-2" onclick="shareProfile()">
                                    <i class="fas fa-share me-1"></i>Compartir
                                </button>
                                <button class="btn btn-<?= $is_following ? 'danger' : 'primary' ?> follow-btn" 
                                        data-user-id="<?= $user_id ?>"
                                        data-following="<?= $is_following ? '1' : '0' ?>">
                                    <i class="fas fa-<?= $is_following ? 'user-minus' : 'user-plus' ?> me-1"></i>
                                    <span class="follow-text"><?= $is_following ? 'Dejar de seguir' : 'Seguir' ?></span>
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Estadísticas -->
    <div class="row mb-4">
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="card text-center h-100">
                <div class="card-body">
                    <i class="fas fa-images fa-2x text-primary mb-2"></i>
                    <h4 class="mb-1"><?= number_format($stats['public_creations']) ?></h4>
                    <p class="text-muted mb-0">Creaciones públicas</p>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="card text-center h-100">
                <div class="card-body">
                    <i class="fas fa-heart fa-2x text-danger mb-2"></i>
                    <h4 class="mb-1"><?= number_format($stats['total_likes']) ?></h4>
                    <p class="text-muted mb-0">Likes recibidos</p>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="card text-center h-100">
                <div class="card-body">
                    <i class="fas fa-users fa-2x text-info mb-2"></i>
                    <h4 class="mb-1">
                        <a href="/seguidores?id=<?= $user_id ?>&tab=followers" class="text-decoration-none">
                            <?= number_format($stats['followers_count']) ?>
                        </a>
                    </h4>
                    <p class="text-muted mb-0">Seguidores</p>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="card text-center h-100">
                <div class="card-body">
                    <i class="fas fa-user-friends fa-2x text-success mb-2"></i>
                    <h4 class="mb-1">
                        <a href="/seguidores?id=<?= $user_id ?>&tab=following" class="text-decoration-none">
                            <?= number_format($stats['following_count']) ?>
                        </a>
                    </h4>
                    <p class="text-muted mb-0">Siguiendo</p>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Contenido principal -->
        <div class="col-lg-9">
            <!-- Tabs -->
            <ul class="nav nav-tabs mb-4" id="profileTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="creations-tab" data-bs-toggle="tab" data-bs-target="#creations" type="button" role="tab">
                        <i class="fas fa-images me-1"></i>Creaciones (<?= number_format($stats['public_creations']) ?>)
                    </button>
                </li>
                <?php if (!empty($popular_creations)): ?>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="popular-tab" data-bs-toggle="tab" data-bs-target="#popular" type="button" role="tab">
                        <i class="fas fa-fire me-1"></i>Populares
                    </button>
                </li>
                <?php endif; ?>
            </ul>

            <!-- Tab content -->
            <div class="tab-content" id="profileTabsContent">
                <!-- Todas las creaciones -->
                <div class="tab-pane fade show active" id="creations" role="tabpanel">
                    <?php if (empty($creations)): ?>
                        <div class="text-center py-5">
                            <i class="fas fa-images fa-3x text-muted mb-3"></i>
                            <h4 class="text-muted">
                                <?= $is_own_profile ? 'Aún no tienes creaciones públicas' : 'Este usuario no tiene creaciones públicas' ?>
                            </h4>
                            <?php if ($is_own_profile): ?>
                                <p class="text-muted">Crea tu primera obra maestra con nuestras herramientas de IA</p>
                                <a href="/herramientas" class="btn btn-primary">Empezar a crear</a>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <div class="row">
                            <?php foreach ($creations as $creation): ?>
                                <div class="col-lg-4 col-md-6 mb-4">
                                    <div class="card shadow-sm h-100 creation-card">
                                        <!-- Imagen/Preview -->
                                        <div class="creation-image-container">
                                            <?php if ($creation['type'] === 'image'): ?>
                                                <img src="<?= htmlspecialchars($creation['file_path']) ?>" 
                                                     class="card-img-top creation-image" 
                                                     alt="<?= htmlspecialchars($creation['title'] ?? 'Imagen') ?>">
                                            <?php else: ?>
                                                <div class="card-img-top bg-gradient-secondary d-flex align-items-center justify-content-center text-white" style="height: 200px;">
                                                    <div class="text-center">
                                                        <i class="fas fa-file fa-3x mb-2"></i>
                                                        <h6><?= ucfirst($creation['type']) ?></h6>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <!-- Overlay con estadísticas -->
                                            <div class="creation-overlay">
                                                <div class="creation-stats">
                                                    <span class="badge bg-dark bg-opacity-75">
                                                        <i class="fas fa-heart me-1"></i><?= $creation['like_count'] ?>
                                                    </span>
                                                    <span class="badge bg-dark bg-opacity-75">
                                                        <i class="fas fa-comment me-1"></i><?= $creation['comment_count'] ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="card-body">
                                            <!-- Título y descripción -->
                                            <?php if (!empty($creation['title'])): ?>
                                                <h6 class="card-title mb-1"><?= htmlspecialchars($creation['title']) ?></h6>
                                            <?php endif; ?>
                                            
                                            <?php if (!empty($creation['description'])): ?>
                                                <p class="card-text text-muted small mb-2">
                                                    <?= htmlspecialchars(substr($creation['description'], 0, 100)) ?>
                                                    <?= strlen($creation['description']) > 100 ? '...' : '' ?>
                                                </p>
                                            <?php endif; ?>

                                            <!-- Metadata -->
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div>
                                                    <span class="badge bg-primary"><?= ucfirst($creation['type']) ?></span>
                                                    <?php if ($is_own_profile): ?>
                                                        <span class="badge bg-<?= $creation['privacy'] === 'public' ? 'success' : 'secondary' ?>">
                                                            <?= $creation['privacy'] === 'public' ? 'Público' : 'Privado' ?>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <small class="text-muted"><?= timeAgo($creation['created_at']) ?></small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <!-- Paginación -->
                        <?php if ($total_pages > 1): ?>
                            <nav aria-label="Paginación de creaciones" class="mt-4">
                                <ul class="pagination justify-content-center">
                                    <?php if ($page > 1): ?>
                                        <li class="page-item">
                                            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>">
                                                <i class="fas fa-chevron-left"></i> Anterior
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                    <?php
                                    $start = max(1, $page - 2);
                                    $end = min($total_pages, $page + 2);
                                    
                                    for ($i = $start; $i <= $end; $i++):
                                    ?>
                                        <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                                            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>">
                                                <?= $i ?>
                                            </a>
                                        </li>
                                    <?php endfor; ?>

                                    <?php if ($page < $total_pages): ?>
                                        <li class="page-item">
                                            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>">
                                                Siguiente <i class="fas fa-chevron-right"></i>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </nav>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>

                <!-- Creaciones populares -->
                <?php if (!empty($popular_creations)): ?>
                <div class="tab-pane fade" id="popular" role="tabpanel">
                    <div class="row">
                        <?php foreach ($popular_creations as $creation): ?>
                            <div class="col-lg-4 col-md-6 mb-4">
                                <div class="card shadow-sm h-100">
                                    <?php if ($creation['type'] === 'image'): ?>
                                        <img src="<?= htmlspecialchars($creation['file_path']) ?>" 
                                             class="card-img-top" style="height: 200px; object-fit: cover;"
                                             alt="<?= htmlspecialchars($creation['title'] ?? 'Imagen') ?>">
                                    <?php endif; ?>
                                    <div class="card-body">
                                        <h6 class="card-title"><?= htmlspecialchars($creation['title'] ?? 'Sin título') ?></h6>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span class="badge bg-primary"><?= ucfirst($creation['type']) ?></span>
                                            <span class="text-danger">
                                                <i class="fas fa-heart me-1"></i><?= $creation['like_count'] ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-lg-3">
            <!-- Actividad reciente -->
            <div class="card shadow-sm mb-4">
                <div class="card-header">
                    <h6 class="mb-0"><i class="fas fa-clock me-2"></i>Actividad reciente</h6>
                </div>
                <div class="card-body">
                    <?php
                    try {
                        $activity_sql = "
                            SELECT action, description, created_at 
                            FROM activity_logs 
                            WHERE user_id = ? 
                            ORDER BY created_at DESC 
                            LIMIT 5
                        ";
                        $stmt = $pdo->prepare($activity_sql);
                        $stmt->execute([$user_id]);
                        $activities = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        
                        if (empty($activities)): ?>
                            <p class="text-muted text-center">Sin actividad reciente</p>
                        <?php else: ?>
                            <?php foreach ($activities as $activity): ?>
                                <div class="d-flex align-items-start mb-3">
                                    <div class="avatar-sm me-2">
                                        <div class="bg-light rounded-circle d-flex align-items-center justify-content-center" style="width: 32px; height: 32px;">
                                            <i class="fas fa-<?= $activity['action'] === 'Like' ? 'heart text-danger' : ($activity['action'] === 'Comentario' ? 'comment text-info' : 'activity text-muted') ?>"></i>
                                        </div>
                                    </div>
                                    <div class="flex-grow-1">
                                        <p class="mb-1 small"><?= htmlspecialchars($activity['description']) ?></p>
                                        <small class="text-muted"><?= timeAgo($activity['created_at']) ?></small>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    <?php } catch (Exception $e) { ?>
                        <p class="text-muted text-center">No se pudo cargar la actividad</p>
                    <?php } ?>
                </div>
            </div>

            <!-- Creadores similares -->
            <?php if (!$is_own_profile): ?>
            <div class="card shadow-sm">
                <div class="card-header">
                    <h6 class="mb-0"><i class="fas fa-users me-2"></i>Creadores similares</h6>
                </div>
                <div class="card-body">
                    <?php
                    try {
                        $similar_sql = "
                            SELECT DISTINCT u.id, u.username, u.full_name, u.profile_image,
                                   COUNT(uc.id) as creation_count
                            FROM users u
                            JOIN user_creations uc ON u.id = uc.user_id
                            WHERE u.id != ? AND u.id != ? AND u.status = 'active'
                            AND uc.privacy = 'public' AND uc.status = 'completed'
                            AND EXISTS (
                                SELECT 1 FROM user_creations uc2 
                                WHERE uc2.user_id = ? 
                                AND uc2.type = uc.type
                            )
                            GROUP BY u.id, u.username, u.full_name, u.profile_image
                            ORDER BY creation_count DESC
                            LIMIT 3
                        ";
                        $stmt = $pdo->prepare($similar_sql);
                        $stmt->execute([$current_user_id, $user_id, $user_id]);
                        $similar_users = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        
                        if (empty($similar_users)): ?>
                            <p class="text-muted text-center">No hay creadores similares</p>
                        <?php else: ?>
                            <?php foreach ($similar_users as $similar_user): ?>
                                <div class="d-flex align-items-center mb-3">
                                    <div class="me-3">
                                        <?php if (!empty($similar_user['profile_image'])): ?>
                                            <img src="<?= htmlspecialchars($similar_user['profile_image']) ?>" 
                                                 class="rounded-circle" width="40" height="40">
                                        <?php else: ?>
                                            <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center text-white" 
                                                 style="width: 40px; height: 40px;">
                                                <?= strtoupper(substr($similar_user['username'], 0, 1)) ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="flex-grow-1">
                                        <a href="/usuario?id=<?= $similar_user['id'] ?>" class="text-decoration-none">
                                            <h6 class="mb-0"><?= htmlspecialchars($similar_user['full_name']) ?></h6>
                                            <small class="text-muted">@<?= htmlspecialchars($similar_user['username']) ?></small>
                                        </a>
                                        <small class="text-info d-block"><?= $similar_user['creation_count'] ?> creaciones</small>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            <a href="/comunidad" class="btn btn-outline-primary btn-sm w-100">Ver más creadores</a>
                        <?php endif; ?>
                    <?php } catch (Exception $e) { ?>
                        <p class="text-muted text-center">No se pudieron cargar los creadores</p>
                    <?php } ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.creation-card {
    transition: transform 0.2s, box-shadow 0.2s;
    overflow: hidden;
}

.creation-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15) !important;
}

.creation-image-container {
    position: relative;
    overflow: hidden;
}

.creation-image {
    height: 200px;
    object-fit: cover;
    transition: transform 0.3s;
}

.creation-card:hover .creation-image {
    transform: scale(1.05);
}

.creation-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity 0.3s;
}

.creation-card:hover .creation-overlay {
    opacity: 1;
}

.creation-stats {
    display: flex;
    gap: 10px;
}

.avatar-sm img, .avatar-sm div {
    border: 2px solid #fff;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Manejar botón de seguir/dejar de seguir
    const followBtn = document.querySelector('.follow-btn');
    if (followBtn) {
        followBtn.addEventListener('click', toggleFollow);
    }
});

async function toggleFollow(e) {
    e.preventDefault();
    
    const btn = e.currentTarget;
    const userId = btn.getAttribute('data-user-id');
    const isFollowing = btn.getAttribute('data-following') === '1';
    
    try {
        const response = await fetch('/api/social/toggle_follow.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: userId,
                action: isFollowing ? 'unfollow' : 'follow'
            })
        });

        const result = await response.json();
        
        if (result.success) {
            const icon = btn.querySelector('i');
            const text = btn.querySelector('.follow-text');
            
            if (isFollowing) {
                btn.classList.remove('btn-danger');
                btn.classList.add('btn-primary');
                icon.className = 'fas fa-user-plus me-1';
                text.textContent = 'Seguir';
                btn.setAttribute('data-following', '0');
            } else {
                btn.classList.remove('btn-primary');
                btn.classList.add('btn-danger');
                icon.className = 'fas fa-user-minus me-1';
                text.textContent = 'Dejar de seguir';
                btn.setAttribute('data-following', '1');
            }
        }
    } catch (error) {
        console.error('Error al procesar seguimiento:', error);
    }
}

function shareProfile() {
    const url = window.location.href;
    
    if (navigator.share) {
        navigator.share({
            title: 'Perfil de <?= htmlspecialchars($profile_user['full_name']) ?>',
            text: 'Mira las increíbles creaciones de <?= htmlspecialchars($profile_user['full_name']) ?> en ObelisIA',
            url: url
        });
    } else {
        navigator.clipboard.writeText(url).then(() => {
            alert('¡Enlace del perfil copiado al portapapeles!');
        });
    }
}
</script>

<?php endif; ?>
