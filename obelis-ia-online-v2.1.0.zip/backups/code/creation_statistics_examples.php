<?php
/**
 * Ejemplo de implementación de las funciones de estadísticas
 * Reemplaza las consultas existentes en api/social/search.php y pages/social/profile.php
 */

require_once '../helpers/creation_statistics.php';

// === EJEMPLO 1: Reemplazar en api/social/search.php ===

// Antiguo código (líneas 72-73):
/*
(SELECT COUNT(*) FROM creation_likes WHERE creation_id = uc.id) as like_count,
(SELECT COUNT(*) FROM creation_comments WHERE creation_id = uc.id AND status = 'active') as comment_count
*/

// Nuevo código usando las funciones:
$search_options = [
    'type' => $_GET['type'] ?? null,
    'limit' => intval($_GET['limit'] ?? 20),
    'offset' => (intval($_GET['page'] ?? 1) - 1) * 20
];

$search_results = searchCreationsWithStats($pdo, $_GET['q'] ?? '', $search_options);

// Los resultados ya incluyen like_count, comment_count y engagement_score formateados

// === EJEMPLO 2: Reemplazar en pages/social/profile.php ===

// Antiguo código (líneas 47-62):
/*
$stats_sql = "
    SELECT 
        COUNT(DISTINCT uc.id) as total_creations,
        COUNT(DISTINCT CASE WHEN uc.privacy = 'public' THEN uc.id END) as public_creations,
        COALESCE(SUM(likes.like_count), 0) as total_likes,
        COUNT(DISTINCT uc.type) as creation_types,
        (SELECT COUNT(*) FROM user_follows WHERE following_id = ?) as followers_count,
        (SELECT COUNT(*) FROM user_follows WHERE follower_id = ?) as following_count
    FROM user_creations uc
    LEFT JOIN (
        SELECT creation_id, COUNT(*) as like_count
        FROM creation_likes 
        GROUP BY creation_id
    ) likes ON uc.id = likes.creation_id
    WHERE uc.user_id = ? AND uc.status = 'completed'
";
*/

// Nuevo código usando las funciones:
$user_stats = getUserCreationStats($pdo, $user_id);

// Para las creaciones del usuario:
$creation_options = [
    'user_id' => $user_id,
    'privacy' => $is_own_profile ? null : 'public',
    'limit' => 12,
    'offset' => ($page - 1) * 12,
    'order_by' => 'created_at',
    'order_dir' => 'DESC'
];

$user_creations = getCreationStatistics($pdo, $creation_options);

// === EJEMPLO 3: Dashboard con estadísticas ===
function getDashboardStats($pdo, $user_id) {
    $stats = getUserCreationStats($pdo, $user_id);
    $top_creations = getCreationStatistics($pdo, [
        'user_id' => $user_id,
        'limit' => 5,
        'order_by' => 'engagement_score'
    ]);
    
    return [
        'user_stats' => $stats,
        'top_creations' => $top_creations
    ];
}

// === EJEMPLO 4: Feed social con las mejores creaciones ===
function getSocialFeed($pdo, $limit = 20, $page = 1) {
    $offset = ($page - 1) * $limit;
    
    return getTopCreations($pdo, $limit, 7); // Últimos 7 días
}

// === EJEMPLO 5: Búsqueda avanzada ===
function advancedSearch($pdo, $filters) {
    $options = [
        'type' => $filters['type'] ?? null,
        'tool_used' => $filters['tool'] ?? null,
        'limit' => $filters['limit'] ?? 20,
        'offset' => $filters['offset'] ?? 0,
        'date_from' => $filters['date_from'] ?? null,
        'date_to' => $filters['date_to'] ?? null,
        'include_user' => true
    ];
    
    if (!empty($filters['search_term'])) {
        return searchCreationsWithStats($pdo, $filters['search_term'], $options);
    } else {
        return getCreationStatistics($pdo, $options);
    }
}

// === EJEMPLO DE USO EN HTML ===
/*
// En tu vista PHP:
$user_stats = getUserCreationStats($pdo, $current_user_id);
$trending = getTopCreations($pdo, 10, 7);
?>

<div class="stats-dashboard">
    <h3>Mis Estadísticas</h3>
    <div class="stat-cards">
        <div class="stat-card">
            <h4><?php echo number_format($user_stats['total_creations']); ?></h4>
            <p>Creaciones Totales</p>
        </div>
        <div class="stat-card">
            <h4><?php echo number_format($user_stats['total_likes']); ?></h4>
            <p>Likes Recibidos</p>
        </div>
        <div class="stat-card">
            <h4><?php echo number_format($user_stats['followers_count']); ?></h4>
            <p>Seguidores</p>
        </div>
        <div class="stat-card">
            <h4><?php echo number_format($user_stats['avg_engagement'], 1); ?></h4>
            <p>Engagement Promedio</p>
        </div>
    </div>
</div>

<div class="trending-section">
    <h3>Tendencias de la Semana</h3>
    <div class="creation-grid">
        <?php foreach ($trending as $creation): ?>
            <div class="creation-card">
                <h4><?php echo htmlspecialchars($creation['title']); ?></h4>
                <p>por @<?php echo htmlspecialchars($creation['username']); ?></p>
                <div class="stats">
                    <span>❤️ <?php echo $creation['like_count']; ?></span>
                    <span>💬 <?php echo $creation['comment_count']; ?></span>
                    <span>📊 <?php echo $creation['engagement_score']; ?></span>
                </div>
                <small><?php echo $creation['created_at_formatted']; ?></small>
            </div>
        <?php endforeach; ?>
    </div>
</div>
*/
?>
