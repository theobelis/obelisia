
<?php
// Mostrar errores PHP para depuración (solo en desarrollo)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Asegurar que tenemos acceso a las clases necesarias
if (!isset($auth)) {
    session_start();
    require_once __DIR__ . '/../../vendor/autoload.php';
    require_once __DIR__ . '/../../src/Config/config.php';
    
    $database = new \ObelisIA\Database\Database();
    $db = $database->getConnection();
    $auth = new \ObelisIA\Auth\Auth($db);
}

// Si ya está logueado, redirigir al dashboard
if ($auth->isLoggedIn()) {
    \ObelisIA\Router\MainRouter::redirect('panel');
}

$error_message = '';
$success_message = '';
$step = 1; // Pasos del registro: 1 = datos básicos, 2 = verificación email

if ($_POST) {
    if (isset($_POST['action']) && $_POST['action'] === 'check_availability') {
        // AJAX para verificar disponibilidad
        header('Content-Type: application/json');
        $type = $_POST['type'] ?? '';
        $value = $_POST['value'] ?? '';
        
        require_once __DIR__ . '/../../src/Auth/Register.php';
        $result = \ObelisIA\Auth\Register::checkAvailability($type, $value);
        echo json_encode($result);
        exit;
    }
    
    // Procesamiento del registro
    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $full_name = $_POST['full_name'] ?? '';
    $terms_accepted = isset($_POST['terms_accepted']);
    
    if (empty($username) || empty($email) || empty($password) || empty($confirm_password) || empty($full_name)) {
        $error_message = "Por favor, complete todos los campos.";
    } elseif (!$terms_accepted) {
        $error_message = "Debe aceptar los términos y condiciones.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Por favor, ingrese un email válido.";
    } elseif (strlen($password) < 6) {
        $error_message = "La contraseña debe tener al menos 6 caracteres.";
    } elseif ($password !== $confirm_password) {
        $error_message = "Las contraseñas no coinciden.";
    } else {
        require_once __DIR__ . '/../../src/Auth/Register.php';
        $site_url = SITE_URL;
        $result = \ObelisIA\Auth\Register::registerUser($username, $email, $password, $full_name, $site_url);
        if ($result['success']) {
            $success_message = $result['message'];
            $step = 2;
        } else {
            $error_message = $result['message'];
        }
    }
}

$page_title = "Crear Cuenta - ObelisIA";
$body_class = "bg-gray-200";
?>

<div class="auth-container">
    <!-- Elementos flotantes de fondo -->
    <div class="floating-elements">
        <div class="floating-element"></div>
        <div class="floating-element"></div>
        <div class="floating-element"></div>
        <div class="floating-element"></div>
        <div class="floating-element"></div>
        <div class="floating-element"></div>
    </div>
    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="auth-card modern-register-card">
                    <div class="auth-header">
                        <div class="brand-logo">
                            <img src="<?php echo \ObelisIA\Router\MainRouter::url('assets/img/logo.png'); ?>" 
                                 alt="ObelisIA" class="logo-img">
                            <h2>ObelisIA</h2>
                        </div>
                        
                        <?php if ($step == 1): ?>
                            <p class="welcome-text">Crear nueva cuenta</p>
                            <p class="step-description">Únete a nuestra comunidad de creadores</p>
                        <?php else: ?>
                            <p class="welcome-text">¡Cuenta creada!</p>
                            <p class="step-description">Verifica tu email para comenzar</p>
                        <?php endif; ?>
                    </div>

                    <div id="alert-container">
                        <?php if (!empty($error_message)): ?>
                            <div class="alert alert-danger alert-dismissible fade show modern-alert" role="alert">
                                <i class="material-icons me-2">error</i>
                                <?php echo htmlspecialchars($error_message); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($success_message)): ?>
                            <div class="alert alert-success alert-dismissible fade show modern-alert" role="alert">
                                <i class="material-icons me-2">check_circle</i>
                                <?php echo htmlspecialchars($success_message); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php if ($step == 1): ?>
                        <!-- Paso 1: Formulario de registro -->
                        <form method="POST" class="modern-form" id="registerForm">
                            <div class="form-group">
                                <div class="input-wrapper">
                                    <i class="material-icons input-icon">badge</i>
                                    <input type="text" 
                                           id="full_name" 
                                           name="full_name" 
                                           class="form-control modern-input" 
                                           placeholder="Nombre completo"
                                           autocomplete="name"
                                           value="<?php echo htmlspecialchars($full_name ?? ''); ?>"
                                           required>
                                </div>
                                <div class="invalid-feedback" id="fullNameError"></div>
                            </div>

                            <div class="form-group">
                                <div class="input-wrapper">
                                    <i class="material-icons input-icon">person</i>
                                    <input type="text" 
                                           id="username" 
                                           name="username" 
                                           class="form-control modern-input" 
                                           placeholder="Nombre de usuario"
                                           autocomplete="username"
                                           value="<?php echo htmlspecialchars($username ?? ''); ?>"
                                           required>
                                    <div class="availability-check" id="usernameCheck" style="display: none;">
                                        <i class="material-icons"></i>
                                    </div>
                                </div>
                                <div class="invalid-feedback" id="usernameError"></div>
                                <div class="field-hint">Solo letras, números y guiones. Mínimo 3 caracteres.</div>
                            </div>

                            <div class="form-group">
                                <div class="input-wrapper">
                                    <i class="material-icons input-icon">email</i>
                                    <input type="email" 
                                           id="email" 
                                           name="email" 
                                           class="form-control modern-input" 
                                           placeholder="Email"
                                           autocomplete="email"
                                           value="<?php echo htmlspecialchars($email ?? ''); ?>"
                                           required>
                                    <div class="availability-check" id="emailCheck" style="display: none;">
                                        <i class="material-icons"></i>
                                    </div>
                                </div>
                                <div class="invalid-feedback" id="emailError"></div>
                            </div>

                            <div class="form-group">
                                <div class="input-wrapper">
                                    <i class="material-icons input-icon">lock</i>
                                    <input type="password" 
                                           id="password" 
                                           name="password" 
                                           class="form-control modern-input" 
                                           placeholder="Contraseña"
                                           autocomplete="new-password"
                                           required>
                                    <button type="button" class="password-toggle" onclick="togglePassword('password')">
                                        <i class="material-icons" id="passwordToggleIcon">visibility</i>
                                    </button>
                                </div>
                                <div class="password-strength" id="passwordStrength"></div>
                                <div class="invalid-feedback" id="passwordError"></div>
                            </div>

                            <div class="form-group">
                                <div class="input-wrapper">
                                    <i class="material-icons input-icon">lock_outline</i>
                                    <input type="password" 
                                           id="confirm_password" 
                                           name="confirm_password" 
                                           class="form-control modern-input" 
                                           placeholder="Confirmar contraseña"
                                           autocomplete="new-password"
                                           required>
                                    <button type="button" class="password-toggle" onclick="togglePassword('confirm_password')">
                                        <i class="material-icons" id="confirmPasswordToggleIcon">visibility</i>
                                    </button>
                                </div>
                                <div class="password-match" id="passwordMatch"></div>
                                <div class="invalid-feedback" id="confirmPasswordError"></div>
                            </div>

                            <div class="form-group">
                                <div class="checkbox-wrapper">
                                    <input type="checkbox" id="terms_accepted" name="terms_accepted" required>
                                    <label for="terms_accepted" class="checkbox-label">
                                        <span class="checkbox-custom"></span>
                                        Acepto los <a href="#" class="terms-link">términos y condiciones</a> 
                                        y la <a href="#" class="terms-link">política de privacidad</a>
                                    </label>
                                </div>
                                <div class="invalid-feedback" id="termsError"></div>
                            </div>

                            <button type="submit" class="btn btn-primary-modern btn-block" id="registerBtn">
                                <span class="btn-text">Crear cuenta</span>
                                <i class="material-icons btn-icon">person_add</i>
                                <div class="btn-spinner" style="display: none;">
                                    <i class="material-icons rotating">refresh</i>
                                </div>
                            </button>

                            <div class="divider">
                                <span>¿Ya tienes cuenta?</span>
                            </div>

                            <a href="<?php echo \ObelisIA\Router\MainRouter::url('login'); ?>" 
                               class="btn btn-outline-modern btn-block">
                                <i class="material-icons me-2">login</i>
                                Iniciar sesión
                            </a>
                        </form>
                        
                    <?php else: ?>
                        <!-- Paso 2: Confirmación -->
                        <div class="confirmation-step">
                            <div class="success-icon">
                                <i class="material-icons">mark_email_read</i>
                            </div>
                            <h4>¡Bienvenido a ObelisIA!</h4>
                            <p>Tu cuenta ha sido creada exitosamente. Hemos enviado un email de verificación a <strong><?php echo htmlspecialchars($_POST['email'] ?? ''); ?></strong></p>
                            <p class="verification-note">
                                <i class="material-icons">info</i>
                                Debes verificar tu email antes de poder iniciar sesión.
                            </p>
                            
                            <div class="verification-actions">
                                <a href="<?php echo \ObelisIA\Router\MainRouter::url('login'); ?>" 
                                   class="btn btn-primary-modern btn-block">
                                    <i class="material-icons me-2">login</i>
                                    Ir al login
                                </a>
                                
                                <button type="button" class="btn btn-outline-modern btn-block" onclick="resendVerificationEmail()">
                                    <i class="material-icons me-2">refresh</i>
                                    Reenviar email
                                </button>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="auth-footer">
                        <p class="back-home">
                            <a href="<?php echo \ObelisIA\Router\MainRouter::url('inicio'); ?>" class="back-link">
                                <i class="material-icons">home</i>
                                Volver al inicio
                            </a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Elementos flotantes de fondo */
.floating-elements {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
    z-index: 1;
}

.floating-element {
    position: absolute;
    width: 100px;
    height: 100px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 50%;
    animation: float-random 20s infinite linear;
}

.floating-element:nth-child(1) {
    top: 20%;
    left: 10%;
    animation-delay: 0s;
    width: 80px;
    height: 80px;
}

.floating-element:nth-child(2) {
    top: 60%;
    left: 80%;
    animation-delay: 5s;
    width: 60px;
    height: 60px;
}

.floating-element:nth-child(3) {
    top: 80%;
    left: 20%;
    animation-delay: 10s;
    width: 120px;
    height: 120px;
}

.floating-element:nth-child(4) {
    top: 30%;
    left: 70%;
    animation-delay: 15s;
    width: 90px;
    height: 90px;
}

.floating-element:nth-child(5) {
    top: 10%;
    left: 50%;
    animation-delay: 3s;
    width: 70px;
    height: 70px;
}

.floating-element:nth-child(6) {
    top: 70%;
    left: 60%;
    animation-delay: 8s;
    width: 110px;
    height: 110px;
}

@keyframes float-random {
    0% { transform: translateY(0px) rotate(0deg); opacity: 0.3; }
    25% { transform: translateY(-20px) rotate(90deg); opacity: 0.6; }
    50% { transform: translateY(-40px) rotate(180deg); opacity: 0.3; }
    75% { transform: translateY(-20px) rotate(270deg); opacity: 0.6; }
    100% { transform: translateY(0px) rotate(360deg); opacity: 0.3; }
}

/* Card moderna */
.modern-register-card {
    background: rgba(255, 255, 255, 0.98);
    border-radius: 24px;
    padding: 3rem 2.5rem;
    box-shadow: 0 25px 60px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    position: relative;
    overflow: hidden;
    z-index: 10;
    margin: 2rem 0;
}

.modern-register-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: var(--degradado-one);
    border-radius: 24px 24px 0 0;
}

/* Header de la marca */
.brand-logo {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    margin-bottom: 1rem;
}

.logo-img {
    width: 48px;
    height: 48px;
    margin-bottom: 0.5rem;
}

.brand-logo h2 {
    color: var(--degradado-one);
    font-weight: 700;
    font-size: 1.8rem;
    margin: 0;
}

.welcome-text {
    color: #333;
    font-size: 1.1rem;
    margin: 0;
    font-weight: 600;
}

.step-description {
    color: #666;
    font-size: 0.9rem;
    margin: 0.5rem 0 0 0;
}

/* Formulario moderno */
.modern-form {
    margin-top: 2rem;
}

.form-group {
    margin-bottom: 1.5rem;
}

.input-wrapper {
    position: relative;
    display: flex;
    align-items: center;
}

.input-icon {
    position: absolute;
    left: 16px;
    color: #666;
    font-size: 20px;
    z-index: 2;
}

.modern-input {
    width: 100%;
    padding: 16px 16px 16px 52px;
    border: 2px solid #e1e5e9;
    border-radius: 12px;
    font-size: 16px;
    background: #fff;
    transition: all 0.3s ease;
}

.modern-input:focus {
    border-color: var(--primary-color);
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
    outline: none;
}

.modern-input.error {
    border-color: #dc3545;
}

.modern-input.success {
    border-color: #28a745;
}

.password-toggle {
    position: absolute;
    right: 16px;
    background: none;
    border: none;
    color: #666;
    cursor: pointer;
    padding: 0;
    z-index: 2;
}

.availability-check {
    position: absolute;
    right: 16px;
    z-index: 2;
}

.availability-check.checking i {
    color: #ffc107;
    animation: rotate 1s linear infinite;
}

.availability-check.available i {
    color: #28a745;
}

.availability-check.taken i {
    color: #dc3545;
}

@keyframes rotate {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

.field-hint {
    font-size: 0.8rem;
    color: #666;
    margin-top: 0.5rem;
    padding-left: 8px;
}

.password-strength, .password-match {
    font-size: 0.8rem;
    margin-top: 0.5rem;
    padding-left: 8px;
}

.password-strength.weak {
    color: #dc3545;
}

.password-strength.medium {
    color: #fd7e14;
}

.password-strength.strong {
    color: #28a745;
}

.password-match.match {
    color: #28a745;
}

.password-match.no-match {
    color: #dc3545;
}

/* Checkbox personalizado */
.checkbox-wrapper {
    display: flex;
    align-items: flex-start;
    gap: 0.75rem;
}

.checkbox-wrapper input[type="checkbox"] {
    display: none;
}

.checkbox-custom {
    width: 20px;
    height: 20px;
    border: 2px solid #e1e5e9;
    border-radius: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
    flex-shrink: 0;
}

.checkbox-wrapper input[type="checkbox"]:checked + .checkbox-label .checkbox-custom {
    background: var(--primary-color);
    border-color: var(--primary-color);
}

.checkbox-wrapper input[type="checkbox"]:checked + .checkbox-label .checkbox-custom::after {
    content: '✓';
    color: white;
    font-size: 12px;
    font-weight: bold;
}

.checkbox-label {
    font-size: 0.9rem;
    color: #666;
    line-height: 1.4;
    cursor: pointer;
    margin: 0;
}

.terms-link {
    color: var(--primary-color);
    text-decoration: none;
}

.terms-link:hover {
    text-decoration: underline;
}

/* Botones modernos */
.btn-primary-modern {
    background: var(--degradado-one);
    border: none;
    border-radius: 12px;
    padding: 16px 24px;
    font-weight: 600;
    font-size: 16px;
    color: white;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    overflow: hidden;
    transition: all 0.3s ease;
}

.btn-primary-modern:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 40px rgba(102, 126, 234, 0.3);
    color: white;
}

.btn-outline-modern {
    background: transparent;
    border: 2px solid #e1e5e9;
    border-radius: 12px;
    padding: 14px 24px;
    font-weight: 600;
    font-size: 16px;
    color: #666;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
}

.btn-outline-modern:hover {
    border-color: var(--primary-color);
    color: var(--primary-color);
    background: rgba(102, 126, 234, 0.05);
}

.btn-icon {
    margin-left: 8px;
}

.btn-spinner {
    position: absolute;
    right: 16px;
}

.rotating {
    animation: rotate 1s linear infinite;
}

/* Divider */
.divider {
    text-align: center;
    margin: 2rem 0;
    position: relative;
}

.divider::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    height: 1px;
    background: #e1e5e9;
}

.divider span {
    background: white;
    padding: 0 1rem;
    color: #666;
    font-size: 14px;
}

/* Confirmación */
.confirmation-step {
    text-align: center;
    padding: 2rem 0;
}

.success-icon {
    width: 80px;
    height: 80px;
    background: var(--degradado-one);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 1.5rem;
}

.success-icon i {
    font-size: 2.5rem;
    color: white;
}

.confirmation-step h4 {
    color: #333;
    margin-bottom: 1rem;
    font-weight: 600;
}

.confirmation-step p {
    color: #666;
    line-height: 1.6;
    margin-bottom: 1rem;
}

.verification-note {
    background: #f8f9fa;
    border-radius: 8px;
    padding: 1rem;
    margin: 1.5rem 0;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.9rem;
    color: #495057;
}

.verification-note i {
    color: #17a2b8;
}

.verification-actions {
    margin-top: 2rem;
}

.verification-actions .btn {
    margin-bottom: 1rem;
}

/* Footer */
.auth-footer {
    margin-top: 2rem;
    text-align: center;
}

.back-link {
    color: #666;
    text-decoration: none;
    font-size: 14px;
    display: inline-flex;
    align-items: center;
    transition: color 0.3s ease;
}

.back-link:hover {
    color: var(--primary-color);
}

.back-link i {
    margin-right: 4px;
    font-size: 16px;
}

/* Alertas modernas */
.modern-alert {
    border-radius: 12px;
    border: none;
    padding: 1rem 1.25rem;
    font-weight: 500;
}

/* Responsive */
@media (max-width: 768px) {
    .modern-register-card {
        margin: 1rem;
        padding: 2rem 1.5rem;
    }
    
    .brand-logo h2 {
        font-size: 1.5rem;
    }
}
</style>

<script>
let availabilityTimeout = {};

document.addEventListener('DOMContentLoaded', function() {
    const usernameInput = document.getElementById('username');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirm_password');
    
    // Verificar disponibilidad de usuario y email
    if (usernameInput) {
        usernameInput.addEventListener('input', function() {
            clearTimeout(availabilityTimeout.username);
            availabilityTimeout.username = setTimeout(() => {
                checkAvailability('username', this.value);
            }, 500);
        });
    }
    
    if (emailInput) {
        emailInput.addEventListener('input', function() {
            clearTimeout(availabilityTimeout.email);
            availabilityTimeout.email = setTimeout(() => {
                checkAvailability('email', this.value);
            }, 500);
        });
    }
    
    // Verificar fortaleza de contraseña
    if (passwordInput) {
        passwordInput.addEventListener('input', function() {
            checkPasswordStrength(this.value);
            if (confirmPasswordInput.value) {
                checkPasswordMatch(this.value, confirmPasswordInput.value);
            }
        });
    }
    
    if (confirmPasswordInput) {
        confirmPasswordInput.addEventListener('input', function() {
            if (passwordInput.value) {
                checkPasswordMatch(passwordInput.value, this.value);
            }
        });
    }
    
    // Validación del formulario
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            if (!validateForm()) {
                e.preventDefault();
                return false;
            }
            
            const registerBtn = document.getElementById('registerBtn');
            const btnText = registerBtn.querySelector('.btn-text');
            const btnSpinner = registerBtn.querySelector('.btn-spinner');
            
            registerBtn.disabled = true;
            btnText.style.opacity = '0.7';
            btnSpinner.style.display = 'block';
        });
    }
});

async function checkAvailability(type, value) {
    if (!value || value.length < 3) return;
    
    const checkElement = document.getElementById(type + 'Check');
    const inputElement = document.getElementById(type);
    
    // Mostrar loading
    checkElement.style.display = 'block';
    checkElement.className = 'availability-check checking';
    checkElement.innerHTML = '<i class="material-icons">refresh</i>';
    
    try {
        const formData = new FormData();
        formData.append('action', 'check_availability');
        formData.append('type', type);
        formData.append('value', value);
        
        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.available) {
            checkElement.className = 'availability-check available';
            checkElement.innerHTML = '<i class="material-icons">check_circle</i>';
            inputElement.classList.remove('error');
            inputElement.classList.add('success');
        } else {
            checkElement.className = 'availability-check taken';
            checkElement.innerHTML = '<i class="material-icons">cancel</i>';
            inputElement.classList.remove('success');
            inputElement.classList.add('error');
            showFieldError(type + 'Error', result.message);
        }
    } catch (error) {
        checkElement.style.display = 'none';
    }
}

function checkPasswordStrength(password) {
    const strengthDiv = document.getElementById('passwordStrength');
    let strength = 0;
    let message = '';
    
    if (password.length >= 6) strength++;
    if (password.match(/[a-z]/)) strength++;
    if (password.match(/[A-Z]/)) strength++;
    if (password.match(/[0-9]/)) strength++;
    if (password.match(/[^a-zA-Z0-9]/)) strength++;
    
    strengthDiv.className = 'password-strength';
    
    if (strength <= 2) {
        strengthDiv.className += ' weak';
        message = 'Débil';
    } else if (strength <= 3) {
        strengthDiv.className += ' medium';
        message = 'Media';
    } else {
        strengthDiv.className += ' strong';
        message = 'Fuerte';
    }
    
    strengthDiv.textContent = 'Fortaleza: ' + message;
}

function checkPasswordMatch(password, confirmPassword) {
    const matchDiv = document.getElementById('passwordMatch');
    const confirmInput = document.getElementById('confirm_password');
    
    matchDiv.className = 'password-match';
    
    if (password === confirmPassword) {
        matchDiv.className += ' match';
        matchDiv.textContent = '✓ Las contraseñas coinciden';
        confirmInput.classList.remove('error');
        confirmInput.classList.add('success');
    } else {
        matchDiv.className += ' no-match';
        matchDiv.textContent = '✗ Las contraseñas no coinciden';
        confirmInput.classList.remove('success');
        confirmInput.classList.add('error');
    }
}

function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const iconId = inputId === 'password' ? 'passwordToggleIcon' : 'confirmPasswordToggleIcon';
    const icon = document.getElementById(iconId);
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.textContent = 'visibility_off';
    } else {
        input.type = 'password';
        icon.textContent = 'visibility';
    }
}

function validateForm() {
    let isValid = true;
    const fields = ['full_name', 'username', 'email', 'password', 'confirm_password'];
    
    fields.forEach(field => {
        const input = document.getElementById(field);
        const error = document.getElementById(field.replace('_', '') + 'Error');
        
        if (!input.value.trim()) {
            showFieldError(error.id, 'Este campo es obligatorio');
            input.classList.add('error');
            isValid = false;
        }
    });
    
    // Verificar términos
    const termsCheckbox = document.getElementById('terms_accepted');
    if (!termsCheckbox.checked) {
        showFieldError('termsError', 'Debe aceptar los términos y condiciones');
        isValid = false;
    }
    
    return isValid;
}

function showFieldError(errorId, message) {
    const errorElement = document.getElementById(errorId);
    errorElement.textContent = message;
    errorElement.style.display = 'block';
}

function resendVerificationEmail() {
    // Implementar reenvío de email de verificación
    alert('Funcionalidad de reenvío de email en desarrollo');
}
</script>