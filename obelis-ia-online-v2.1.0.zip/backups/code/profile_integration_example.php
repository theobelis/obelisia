<?php
/**
 * Ejemplo de integración en pages/social/profile.php
 * Reemplaza las consultas existentes con las nuevas funciones
 */

// === ANTES (líneas 47-62 aproximadamente) ===
/*
$stats_sql = "
    SELECT 
        COUNT(DISTINCT uc.id) as total_creations,
        COUNT(DISTINCT CASE WHEN uc.privacy = 'public' THEN uc.id END) as public_creations,
        COALESCE(SUM(likes.like_count), 0) as total_likes,
        COUNT(DISTINCT uc.type) as creation_types,
        (SELECT COUNT(*) FROM user_follows WHERE following_id = ?) as followers_count,
        (SELECT COUNT(*) FROM user_follows WHERE follower_id = ?) as following_count
    FROM user_creations uc
    LEFT JOIN (
        SELECT creation_id, COUNT(*) as like_count
        FROM creation_likes 
        GROUP BY creation_id
    ) likes ON uc.id = likes.creation_id
    WHERE uc.user_id = ? AND uc.status = 'completed'
";
$stmt = $pdo->prepare($stats_sql);
$stmt->execute([$user_id, $user_id, $user_id]);
$stats = $stmt->fetch(PDO::FETCH_ASSOC);
*/

// === DESPUÉS (reemplaza el código anterior) ===
require_once __DIR__ . '/../../helpers/creation_statistics.php';

// Obtener estadísticas del usuario usando la nueva función
$stats = getUserCreationStats($pdo, $user_id);

// === ANTES (líneas 83-107 aproximadamente) ===
/*
$creations_sql = "
    SELECT 
        uc.id,
        uc.title,
        uc.description,
        uc.file_path,
        uc.type,
        uc.tool_used,
        uc.privacy,
        uc.created_at,
        COALESCE(likes.like_count, 0) as like_count,
        COALESCE(comments.comment_count, 0) as comment_count
    FROM user_creations uc
    LEFT JOIN (
        SELECT creation_id, COUNT(*) as like_count
        FROM creation_likes 
        GROUP BY creation_id
    ) likes ON uc.id = likes.creation_id
    LEFT JOIN (
        SELECT creation_id, COUNT(*) as comment_count
        FROM creation_comments 
        WHERE status = 'active'
        GROUP BY creation_id
    ) comments ON uc.id = comments.creation_id
    WHERE {$creations_where}
    ORDER BY uc.created_at DESC
    LIMIT {$limit} OFFSET {$offset}
";
*/

// === DESPUÉS (reemplaza el código anterior) ===
// Obtener creaciones del usuario usando la nueva función
$creation_options = [
    'user_id' => $user_id,
    'privacy' => $is_own_profile ? null : 'public',
    'limit' => $limit,
    'offset' => $offset,
    'order_by' => 'created_at',
    'order_dir' => 'DESC'
];

$user_creations = getCreationStatistics($pdo, $creation_options);

// Obtener conteo total para paginación
$total_count_options = [
    'user_id' => $user_id,
    'privacy' => $is_own_profile ? null : 'public'
];

$all_creations = getCreationStatistics($pdo, $total_count_options);
$total_creations = count($all_creations);

// === WIDGET DE ESTADÍSTICAS MEJORADO ===
// Agregar este HTML en la sección de estadísticas del perfil:
?>

<!-- Widget de estadísticas mejorado -->
<div class="stats-widget">
    <div class="row g-3">
        <div class="col-6 col-md-3">
            <div class="stat-card">
                <div class="stat-number"><?php echo number_format($stats['total_creations'] ?? 0); ?></div>
                <div class="stat-label">Creaciones</div>
                <div class="stat-sublabel">
                    <?php echo number_format($stats['public_creations'] ?? 0); ?> públicas
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stat-card">
                <div class="stat-number"><?php echo number_format($stats['total_likes'] ?? 0); ?></div>
                <div class="stat-label">Likes</div>
                <div class="stat-sublabel">Total recibidos</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stat-card">
                <div class="stat-number"><?php echo number_format($stats['followers_count'] ?? 0); ?></div>
                <div class="stat-label">Seguidores</div>
                <div class="stat-sublabel">
                    <?php echo number_format($stats['following_count'] ?? 0); ?> siguiendo
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stat-card">
                <div class="stat-number"><?php echo number_format($stats['avg_engagement'] ?? 0, 1); ?></div>
                <div class="stat-label">Engagement</div>
                <div class="stat-sublabel">Promedio</div>
            </div>
        </div>
    </div>
</div>

<style>
.stats-widget {
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(10px);
    border-radius: 12px;
    padding: 1.5rem;
    margin-bottom: 2rem;
    border: 1px solid rgba(0, 0, 0, 0.1);
}

.stat-card {
    text-align: center;
    padding: 1rem;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border-radius: 8px;
    transition: transform 0.2s ease;
}

.stat-card:hover {
    transform: translateY(-2px);
}

.stat-number {
    font-size: 1.8rem;
    font-weight: bold;
    margin-bottom: 0.25rem;
}

.stat-label {
    font-size: 0.9rem;
    font-weight: 500;
    margin-bottom: 0.125rem;
}

.stat-sublabel {
    font-size: 0.75rem;
    opacity: 0.8;
}

@media (max-width: 768px) {
    .stat-number {
        font-size: 1.4rem;
    }
    .stat-label {
        font-size: 0.8rem;
    }
    .stat-sublabel {
        font-size: 0.7rem;
    }
}
</style>

<?php
// === IMPLEMENTACIÓN COMPLETA ===
// Para implementar completamente en profile.php:

/*
1. Agregar al inicio del archivo (después de los requires existentes):
   require_once __DIR__ . '/../../helpers/creation_statistics.php';

2. Reemplazar la consulta de estadísticas (líneas ~47-62) con:
   $stats = getUserCreationStats($pdo, $user_id);

3. Reemplazar la consulta de creaciones (líneas ~83-107) con:
   $creation_options = [
       'user_id' => $user_id,
       'privacy' => $is_own_profile ? null : 'public',
       'limit' => $limit,
       'offset' => $offset,
       'order_by' => 'created_at',
       'order_dir' => 'DESC'
   ];
   $user_creations = getCreationStatistics($pdo, $creation_options);

4. En el bucle de mostrar creaciones, cambiar $creations por $user_creations

5. Agregar el widget de estadísticas en la sección apropiada del HTML
*/
?>
