<?php
// Incluir ObelisStudio para mostrar proyectos en la comunidad
require_once __DIR__ . '/../../src/ObelisStudio/ObelisStudio.php';
// Incluir conexión a la base de datos
require_once __DIR__ . '/../../helpers/db.php';
// Incluir funciones sociales
require_once __DIR__ . '/../../helpers/social_functions.php';

// Asegurar que $pdo esté disponible
global $pdo;
if (!isset($pdo)) {
    $pdo = getPdoConnection();
}

// Verificar autenticación
if (!isset($_SESSION['user_id'])) {
    header('Location: /acceso');
    exit;
}

// Configuración de paginación
$page = max(1, intval($_GET['page'] ?? 1));
$limit = 12;
$offset = ($page - 1) * $limit;

// Parámetros de búsqueda y filtros
$search = trim($_GET['search'] ?? '');
$type_filter = $_GET['type'] ?? '';
$tool_filter = $_GET['tool'] ?? '';
$sort_by = $_GET['sort'] ?? 'recent'; // recent, popular, liked

// Construir consulta SQL con filtros
$where_conditions = ["uc.privacy = 'public'", "uc.status = 'completed'", "u.status = 'active'"];
$params = [];

if (!empty($search)) {
    $where_conditions[] = "(uc.title LIKE ? OR uc.description LIKE ? OR u.username LIKE ?)";
    $search_term = "%{$search}%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
}

if (!empty($type_filter)) {
    $where_conditions[] = "uc.type = ?";
    $params[] = $type_filter;
}

if (!empty($tool_filter)) {
    $where_conditions[] = "uc.tool_used = ?";
    $params[] = $tool_filter;
}

$where_clause = implode(' AND ', $where_conditions);

// Determinar orden
$order_clause = match($sort_by) {
    'popular' => 'ORDER BY like_count DESC, uc.created_at DESC',
    'liked' => 'ORDER BY like_count DESC',
    'oldest' => 'ORDER BY uc.created_at ASC',
    default => 'ORDER BY uc.created_at DESC'
};

try {
    // Contar total de resultados usando PDO
    $count_sql = "
        SELECT COUNT(DISTINCT uc.id) 
        FROM user_creations uc 
        JOIN users u ON uc.user_id = u.id 
        WHERE {$where_clause}
    ";
    $count_stmt = $pdo->prepare($count_sql);
    $count_stmt->execute($params);
    $total_posts = $count_stmt->fetchColumn();
    $total_pages = ceil($total_posts / $limit);

    // Obtener creaciones con información del usuario y conteo de likes y comentarios
    $sql = "
        SELECT 
            uc.id,
            uc.title,
            uc.description,
            uc.file_path,
            uc.type,
            uc.tool_used,
            uc.created_at,
            u.id as user_id,
            u.username,
            u.full_name,
            u.profile_image,
            COALESCE(likes.like_count, 0) as like_count,
            COALESCE(comments.comment_count, 0) as comment_count,
            COALESCE(user_liked.has_liked, 0) as user_has_liked
        FROM user_creations uc
        JOIN users u ON uc.user_id = u.id
        LEFT JOIN (
            SELECT creation_id, COUNT(*) as like_count
            FROM creation_likes 
            GROUP BY creation_id
        ) likes ON uc.id = likes.creation_id
        LEFT JOIN (
            SELECT creation_id, COUNT(*) as comment_count
            FROM creation_comments 
            WHERE status = 'active'
            GROUP BY creation_id
        ) comments ON uc.id = comments.creation_id
        LEFT JOIN (
            SELECT creation_id, 1 as has_liked
            FROM creation_likes
            WHERE user_id = ?
        ) user_liked ON uc.id = user_liked.creation_id
        WHERE {$where_clause}
        {$order_clause}
        LIMIT " . intval($limit) . " OFFSET " . intval($offset) . "
    ";
    
    $final_params = array_merge([$_SESSION['user_id']], $params);
    $stmt = $pdo->prepare($sql);
    $stmt->execute($final_params);
    $creations = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Obtener también proyectos públicos del Studio
    try {
        $studio = new \ObelisIA\ObelisStudio\ObelisStudio();
        $studio_projects = $studio->getPublicProjects(6); // Obtener algunos proyectos del Studio
        
        // Formatear proyectos del Studio para que coincidan con el formato de creaciones
        foreach ($studio_projects as &$project) {
            $project['type'] = 'studio_project';
            $project['tool_used'] = 'Obelis Studio';
            $project['file_path'] = null; // Los proyectos del Studio no tienen file_path
            $project['like_count'] = 0; // TODO: Implementar likes para proyectos del Studio
            $project['comment_count'] = 0; // TODO: Implementar comentarios para proyectos del Studio
            $project['user_has_liked'] = 0;
            $project['full_name'] = $project['username']; // Fallback si no hay full_name
            $project['profile_image'] = $project['profile_pic'] ?? null;
        }
        
        // Mezclar creaciones normales con proyectos del Studio
        $all_content = array_merge($creations, $studio_projects);
        
        // Reordenar por fecha si es necesario
        if ($sort_by === 'recent') {
            usort($all_content, function($a, $b) {
                $time_a = isset($a['updated_at']) ? strtotime($a['updated_at']) : strtotime($a['created_at']);
                $time_b = isset($b['updated_at']) ? strtotime($b['updated_at']) : strtotime($b['created_at']);
                return $time_b - $time_a;
            });
        }
        
        $creations = $all_content;
        
    } catch (Exception $e) {
        error_log("Error al obtener proyectos del Studio: " . $e->getMessage());
        // Continuar solo con las creaciones normales si hay error
    }

    // Obtener herramientas únicas para el filtro
    $tools_sql = "SELECT DISTINCT tool_used FROM user_creations WHERE privacy = 'public' AND tool_used IS NOT NULL ORDER BY tool_used";
    $tools_stmt = $pdo->query($tools_sql);
    $available_tools = $tools_stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Agregar "Obelis Studio" a las herramientas disponibles
    if (!in_array('Obelis Studio', $available_tools)) {
        $available_tools[] = 'Obelis Studio';
        sort($available_tools);
    }

} catch (Exception $e) {
    error_log("Error en feed social: " . $e->getMessage());
    $creations = [];
    $total_pages = 0;
    $available_tools = [];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comunidad - ObelisIA</title>
    
    <!-- Estilos del sistema de diseño unificado -->
    <link rel="stylesheet" href="<?php echo \ObelisIA\Router\MainRouter::url('assets/css/tools/unified-design/main.css'); ?>">
    
    <!-- Font Awesome para iconos -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <!-- Bootstrap para algunos componentes -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <style>
        body {
            background: var(--bg-primary);
            min-height: 100vh;
        }
        
        .community-layout {
            display: flex;
            min-height: 100vh;
            background: var(--bg-primary);
        }
        
        .community-sidebar {
            width: 300px;
            background: var(--bg-card);
            border-right: 1px solid var(--border-primary);
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            backdrop-filter: blur(20px);
            box-shadow: var(--shadow-lg);
        }
        
        .community-main {
            flex: 1;
            margin-left: 300px;
            padding: var(--spacing-xl);
            min-height: 100vh;
        }
        
        .community-header {
            background: var(--bg-card);
            border-radius: var(--radius-xl);
            padding: var(--spacing-xl);
            margin-bottom: var(--spacing-xl);
            box-shadow: var(--shadow-md);
            border: 1px solid var(--border-primary);
            position: relative;
            overflow: hidden;
        }
        
        .community-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--accent-gradient);
        }
        
        .sidebar-section {
            padding: var(--spacing-xl);
            border-bottom: 1px solid var(--border-primary);
        }
        
        .sidebar-section:last-child {
            border-bottom: none;
        }
        
        .sidebar-section-title {
            font-size: var(--font-size-lg);
            font-weight: var(--font-weight-bold);
            color: var(--text-primary);
            margin-bottom: var(--spacing-lg);
            display: flex;
            align-items: center;
            gap: var(--spacing-sm);
        }
        
        .sidebar-section-title i {
            color: var(--accent-color);
        }
        
        .filter-form {
            display: flex;
            flex-direction: column;
            gap: var(--spacing-lg);
        }
        
        .filter-group {
            display: flex;
            flex-direction: column;
            gap: var(--spacing-sm);
        }
        
        .filter-label {
            font-weight: var(--font-weight-medium);
            color: var(--text-primary);
            font-size: var(--font-size-sm);
            display: flex;
            align-items: center;
            gap: var(--spacing-xs);
        }
        
        .filter-input {
            width: 100%;
            padding: var(--spacing-md);
            background: var(--bg-secondary);
            border: 1px solid var(--border-primary);
            border-radius: var(--radius-lg);
            color: var(--text-primary);
            font-size: var(--font-size-sm);
            transition: all var(--transition-normal);
        }
        
        .filter-input:focus {
            outline: none;
            border-color: var(--accent-color);
            box-shadow: 0 0 0 3px rgba(6, 182, 212, 0.1);
        }
        
        .filter-buttons {
            display: flex;
            gap: var(--spacing-sm);
        }
        
        .sort-pills {
            display: flex;
            flex-wrap: wrap;
            gap: var(--spacing-sm);
            margin-bottom: var(--spacing-md);
        }
        
        .sort-pill {
            padding: var(--spacing-sm) var(--spacing-md);
            background: var(--bg-secondary);
            border: 1px solid var(--border-primary);
            border-radius: var(--radius-full);
            color: var(--text-muted);
            text-decoration: none;
            font-size: var(--font-size-sm);
            font-weight: var(--font-weight-medium);
            transition: all var(--transition-normal);
            cursor: pointer;
        }
        
        .sort-pill:hover,
        .sort-pill.active {
            background: var(--accent-gradient);
            color: white;
            border-color: var(--accent-color);
            transform: translateY(-1px);
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: var(--spacing-md);
        }
        
        .stat-card {
            text-align: center;
            padding: var(--spacing-md);
            background: var(--bg-secondary);
            border-radius: var(--radius-lg);
            border: 1px solid var(--border-primary);
        }
        
        .stat-value {
            font-size: var(--font-size-xl);
            font-weight: var(--font-weight-bold);
            color: var(--accent-color);
            display: block;
        }
        
        .stat-label {
            font-size: var(--font-size-xs);
            color: var(--text-muted);
            margin-top: var(--spacing-xs);
        }
        
        .creations-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: var(--spacing-xl);
        }
        
        .creation-card {
            background: var(--bg-card);
            border-radius: var(--radius-xl);
            overflow: hidden;
            box-shadow: var(--shadow-md);
            border: 1px solid var(--border-primary);
            transition: all var(--transition-normal);
            height: fit-content;
        }
        
        .creation-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-xl);
        }
        
        .creation-image-container {
            position: relative;
            aspect-ratio: 16/9;
            overflow: hidden;
            background: var(--bg-secondary);
        }
        
        .creation-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: all var(--transition-normal);
        }
        
        .creation-image:hover {
            transform: scale(1.05);
        }
        
        .creation-placeholder {
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--accent-gradient);
            color: white;
            flex-direction: column;
            gap: var(--spacing-sm);
        }
        
        .creation-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: all var(--transition-normal);
        }
        
        .creation-card:hover .creation-overlay {
            opacity: 1;
        }
        
        .creation-actions {
            display: flex;
            gap: var(--spacing-sm);
        }
        
        .creation-content {
            padding: var(--spacing-lg);
        }
        
        .creation-header {
            display: flex;
            align-items: center;
            gap: var(--spacing-md);
            margin-bottom: var(--spacing-md);
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: 2px solid var(--accent-color);
            object-fit: cover;
        }
        
        .user-avatar-placeholder {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--accent-gradient);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: var(--font-weight-bold);
            font-size: var(--font-size-sm);
        }
        
        .user-info h4 {
            margin: 0;
            font-size: var(--font-size-md);
            font-weight: var(--font-weight-semibold);
            color: var(--text-primary);
        }
        
        .user-info .time {
            font-size: var(--font-size-xs);
            color: var(--text-muted);
        }
        
        .creation-title {
            font-size: var(--font-size-lg);
            font-weight: var(--font-weight-semibold);
            color: var(--text-primary);
            margin-bottom: var(--spacing-sm);
            line-height: 1.3;
        }
        
        .creation-description {
            color: var(--text-muted);
            font-size: var(--font-size-sm);
            line-height: 1.5;
            margin-bottom: var(--spacing-md);
        }
        
        .creation-tags {
            display: flex;
            flex-wrap: wrap;
            gap: var(--spacing-xs);
            margin-bottom: var(--spacing-md);
        }
        
        .creation-tag {
            padding: var(--spacing-xs) var(--spacing-sm);
            background: var(--bg-secondary);
            border: 1px solid var(--border-primary);
            border-radius: var(--radius-full);
            font-size: var(--font-size-xs);
            color: var(--text-muted);
        }
        
        .creation-tag.primary {
            background: var(--accent-gradient);
            color: white;
            border-color: var(--accent-color);
        }
        
        .creation-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: var(--spacing-md);
            border-top: 1px solid var(--border-primary);
        }
        
        .social-actions {
            display: flex;
            gap: var(--spacing-sm);
        }
        
        .social-btn {
            display: flex;
            align-items: center;
            gap: var(--spacing-xs);
            padding: var(--spacing-xs) var(--spacing-sm);
            background: var(--bg-secondary);
            border: 1px solid var(--border-primary);
            border-radius: var(--radius-md);
            color: var(--text-muted);
            text-decoration: none;
            font-size: var(--font-size-xs);
            transition: all var(--transition-normal);
            cursor: pointer;
        }
        
        .social-btn:hover {
            background: var(--accent-color);
            color: white;
            border-color: var(--accent-color);
        }
        
        .social-btn.liked {
            background: var(--error-color);
            color: white;
            border-color: var(--error-color);
        }
        
        .pagination-container {
            display: flex;
            justify-content: center;
            margin-top: var(--spacing-xl);
        }
        
        .pagination {
            display: flex;
            gap: var(--spacing-sm);
            align-items: center;
        }
        
        .pagination-btn {
            padding: var(--spacing-md) var(--spacing-lg);
            background: var(--bg-card);
            border: 1px solid var(--border-primary);
            border-radius: var(--radius-lg);
            color: var(--text-primary);
            text-decoration: none;
            font-weight: var(--font-weight-medium);
            transition: all var(--transition-normal);
        }
        
        .pagination-btn:hover {
            background: var(--accent-color);
            color: white;
            border-color: var(--accent-color);
        }
        
        .pagination-btn.active {
            background: var(--accent-gradient);
            color: white;
            border-color: var(--accent-color);
        }
        
        .pagination-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .empty-state {
            text-align: center;
            padding: var(--spacing-xl) 0;
            color: var(--text-muted);
        }
        
        .empty-state i {
            font-size: 4rem;
            margin-bottom: var(--spacing-lg);
            opacity: 0.5;
        }
        
        .empty-state h3 {
            margin-bottom: var(--spacing-md);
            color: var(--text-primary);
        }
        
        .search-results-info {
            background: var(--bg-card);
            border: 1px solid var(--border-primary);
            border-radius: var(--radius-lg);
            padding: var(--spacing-lg);
            margin-bottom: var(--spacing-xl);
            display: flex;
            align-items: center;
            gap: var(--spacing-md);
        }
        
        .search-results-info i {
            color: var(--accent-color);
            font-size: var(--font-size-lg);
        }
        
        @media (max-width: 768px) {
            .community-layout {
                flex-direction: column;
            }
            
            .community-sidebar {
                position: relative;
                width: 100%;
                height: auto;
            }
            
            .community-main {
                margin-left: 0;
            }
            
            .creations-grid {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
    </style>
</head>
<body>
    <div class="community-layout">
        ) likes ON uc.id = likes.creation_id
        LEFT JOIN (
            SELECT creation_id, COUNT(*) as comment_count
            FROM creation_comments 
            WHERE status = 'active'
            GROUP BY creation_id
        ) comments ON uc.id = comments.creation_id
        LEFT JOIN (
            SELECT creation_id, 1 as has_liked
            FROM creation_likes
            WHERE user_id = ?
        ) user_liked ON uc.id = user_liked.creation_id
        WHERE {$where_clause}
        {$order_clause}
        LIMIT " . intval($limit) . " OFFSET " . intval($offset) . "
    ";
    
    $final_params = array_merge([$_SESSION['user_id']], $params);
    $stmt = $pdo->prepare($sql);
    $stmt->execute($final_params);
    $creations = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Obtener también proyectos públicos del Studio
    try {
        $studio = new \ObelisIA\ObelisStudio\ObelisStudio();
        $studio_projects = $studio->getPublicProjects(6); // Obtener algunos proyectos del Studio
        
        // Formatear proyectos del Studio para que coincidan con el formato de creaciones
        foreach ($studio_projects as &$project) {
            $project['type'] = 'studio_project';
            $project['tool_used'] = 'Obelis Studio';
            $project['file_path'] = null; // Los proyectos del Studio no tienen file_path
            $project['like_count'] = 0; // TODO: Implementar likes para proyectos del Studio
            $project['comment_count'] = 0; // TODO: Implementar comentarios para proyectos del Studio
            $project['user_has_liked'] = 0;
            $project['full_name'] = $project['username']; // Fallback si no hay full_name
            $project['profile_image'] = $project['profile_pic'] ?? null;
        }
        
        // Mezclar creaciones normales con proyectos del Studio
        $all_content = array_merge($creations, $studio_projects);
        
        // Reordenar por fecha si es necesario
        if ($sort_by === 'recent') {
            usort($all_content, function($a, $b) {
                $time_a = isset($a['updated_at']) ? strtotime($a['updated_at']) : strtotime($a['created_at']);
                $time_b = isset($b['updated_at']) ? strtotime($b['updated_at']) : strtotime($b['created_at']);
                return $time_b - $time_a;
            });
        }
        
        $creations = $all_content;
        
    } catch (Exception $e) {
        error_log("Error al obtener proyectos del Studio: " . $e->getMessage());
        // Continuar solo con las creaciones normales si hay error
    }

    // Obtener herramientas únicas para el filtro
    $tools_sql = "SELECT DISTINCT tool_used FROM user_creations WHERE privacy = 'public' AND tool_used IS NOT NULL ORDER BY tool_used";
    $tools_stmt = $pdo->query($tools_sql);
    $available_tools = $tools_stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Agregar "Obelis Studio" a las herramientas disponibles
    if (!in_array('Obelis Studio', $available_tools)) {
        $available_tools[] = 'Obelis Studio';
        sort($available_tools);
    }

} catch (Exception $e) {
    error_log("Error en feed social: " . $e->getMessage());
    $creations = [];
    $total_pages = 0;
    $available_tools = [];
}
?>

        <!-- Sidebar -->
        <aside class="community-sidebar">
            <!-- Filtros y Búsqueda -->
            <div class="sidebar-section">
                <h3 class="sidebar-section-title">
                    <i class="fas fa-search"></i>
                    Explorar
                </h3>
                
                <form method="GET" action="/comunidad" class="filter-form" id="filterForm">
                    <div class="filter-group">
                        <label class="filter-label">
                            <i class="fas fa-search"></i>
                            Buscar contenido
                        </label>
                        <input type="text" class="filter-input" name="search" 
                               value="<?= htmlspecialchars($search) ?>" 
                               placeholder="Título, descripción o usuario...">
                    </div>

                    <div class="filter-group">
                        <label class="filter-label">
                            <i class="fas fa-layer-group"></i>
                            Tipo de contenido
                        </label>
                        <select class="filter-input" name="type">
                            <option value="">Todos los tipos</option>
                            <option value="image" <?= $type_filter === 'image' ? 'selected' : '' ?>>Imágenes</option>
                            <option value="text" <?= $type_filter === 'text' ? 'selected' : '' ?>>Texto</option>
                            <option value="music" <?= $type_filter === 'music' ? 'selected' : '' ?>>Música</option>
                            <option value="video" <?= $type_filter === 'video' ? 'selected' : '' ?>>Video</option>
                            <option value="studio_project" <?= $type_filter === 'studio_project' ? 'selected' : '' ?>>Proyectos Studio</option>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label class="filter-label">
                            <i class="fas fa-tools"></i>
                            Herramienta
                        </label>
                        <select class="filter-input" name="tool">
                            <option value="">Todas las herramientas</option>
                            <?php foreach ($available_tools as $tool): ?>
                                <option value="<?= htmlspecialchars($tool) ?>" 
                                        <?= $tool_filter === $tool ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($tool) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="filter-buttons">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-search"></i>
                            Buscar
                        </button>
                        <a href="/comunidad" class="btn btn-outline">
                            <i class="fas fa-times"></i>
                            Limpiar
                        </a>
                    </div>
                </form>
            </div>

            <!-- Ordenar -->
            <div class="sidebar-section">
                <h3 class="sidebar-section-title">
                    <i class="fas fa-sort"></i>
                    Ordenar por
                </h3>
                
                <div class="sort-pills">
                    <a href="?<?= http_build_query(array_merge($_GET, ['sort' => 'recent'])) ?>" 
                       class="sort-pill <?= $sort_by === 'recent' ? 'active' : '' ?>">
                        <i class="fas fa-clock"></i>
                        Recientes
                    </a>
                    <a href="?<?= http_build_query(array_merge($_GET, ['sort' => 'popular'])) ?>" 
                       class="sort-pill <?= $sort_by === 'popular' ? 'active' : '' ?>">
                        <i class="fas fa-fire"></i>
                        Populares
                    </a>
                    <a href="?<?= http_build_query(array_merge($_GET, ['sort' => 'liked'])) ?>" 
                       class="sort-pill <?= $sort_by === 'liked' ? 'active' : '' ?>">
                        <i class="fas fa-heart"></i>
                        Más liked
                    </a>
                    <a href="?<?= http_build_query(array_merge($_GET, ['sort' => 'oldest'])) ?>" 
                       class="sort-pill <?= $sort_by === 'oldest' ? 'active' : '' ?>">
                        <i class="fas fa-history"></i>
                        Antiguos
                    </a>
                </div>
            </div>

            <!-- Estadísticas -->
            <div class="sidebar-section">
                <h3 class="sidebar-section-title">
                    <i class="fas fa-chart-bar"></i>
                    Estadísticas
                </h3>
                
                <?php 
                try {
                    $stats = $pdo->query("
                        SELECT 
                            COUNT(DISTINCT uc.id) as total_creations,
                            COUNT(DISTINCT uc.user_id) as active_creators,
                            COUNT(DISTINCT CASE WHEN uc.created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR) THEN uc.id END) as today_creations
                        FROM user_creations uc 
                        WHERE uc.privacy = 'public' AND uc.status = 'completed'
                    ")->fetch(PDO::FETCH_ASSOC);
                ?>
                    <div class="stats-grid">
                        <div class="stat-card">
                            <span class="stat-value"><?= number_format($stats['total_creations']) ?></span>
                            <span class="stat-label">Creaciones</span>
                        </div>
                        <div class="stat-card">
                            <span class="stat-value"><?= number_format($stats['active_creators']) ?></span>
                            <span class="stat-label">Creadores</span>
                        </div>
                        <div class="stat-card">
                            <span class="stat-value"><?= number_format($stats['today_creations']) ?></span>
                            <span class="stat-label">Hoy</span>
                        </div>
                    </div>
                <?php } catch (Exception $e) { ?>
                    <p class="text-muted">Estadísticas no disponibles</p>
                <?php } ?>
            </div>

            <!-- Enlaces rápidos -->
            <div class="sidebar-section">
                <h3 class="sidebar-section-title">
                    <i class="fas fa-link"></i>
                    Enlaces rápidos
                </h3>
                
                <div style="display: flex; flex-direction: column; gap: var(--spacing-sm);">
                    <a href="/mis-creaciones" class="btn btn-outline">
                        <i class="fas fa-plus"></i>
                        Mis creaciones
                    </a>
                    <a href="/panel" class="btn btn-outline">
                        <i class="fas fa-home"></i>
                        Dashboard
                    </a>
                    <a href="/tools" class="btn btn-outline">
                        <i class="fas fa-magic"></i>
                        Herramientas IA
                    </a>
                </div>
            </div>
        </aside>

        <!-- Contenido principal -->
        <main class="community-main">
            <!-- Header -->
            <div class="community-header">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <h1 style="margin: 0; font-size: var(--font-size-2xl); font-weight: var(--font-weight-bold); color: var(--text-primary);">
                            <i class="fas fa-users" style="color: var(--accent-color); margin-right: var(--spacing-sm);"></i>
                            Comunidad ObelisIA
                        </h1>
                        <p style="margin: var(--spacing-sm) 0 0 0; color: var(--text-muted);">
                            Descubre las increíbles creaciones de nuestra comunidad de artistas IA
                        </p>
                    </div>
                    <div>
                        <a href="/mis-creaciones" class="btn btn-primary">
                            <i class="fas fa-plus"></i>
                            Crear contenido
                        </a>
                    </div>
                </div>
            </div>

            <!-- Información de resultados -->
            <?php if (!empty($search) || !empty($type_filter) || !empty($tool_filter)): ?>
                <div class="search-results-info">
                    <i class="fas fa-info-circle"></i>
                    <div>
                        <strong>Resultados de búsqueda:</strong> <?= number_format($total_posts) ?> creación(es) encontrada(s)
                        <?php if (!empty($search)): ?>
                            para "<strong><?= htmlspecialchars($search) ?></strong>"
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Grid de creaciones -->
            <?php if (empty($creations)): ?>
                <div class="empty-state">
                    <i class="fas fa-search"></i>
                    <h3>No se encontraron creaciones</h3>
                    <p>Prueba ajustando los filtros o términos de búsqueda</p>
                    <a href="/comunidad" class="btn btn-primary">Ver todas las creaciones</a>
                </div>
            <?php else: ?>
                <div class="creations-grid" id="creationsGrid">
                                <option value="text" <?= $type_filter === 'text' ? 'selected' : '' ?>>Texto</option>
                                <option value="video" <?= $type_filter === 'video' ? 'selected' : '' ?>>Videos</option>
                                <option value="music" <?= $type_filter === 'music' ? 'selected' : '' ?>>Música</option>
                                <option value="utility" <?= $type_filter === 'utility' ? 'selected' : '' ?>>Utilidades</option>
                            </select>
                        </div>

                        <!-- Herramienta utilizada -->
                        <div class="mb-3">
                            <label class="form-label"><i class="fas fa-tools me-1"></i>Herramienta</label>
                            <select class="form-select" name="tool">
                                <option value="">Todas las herramientas</option>
                                <?php foreach ($available_tools as $tool): ?>
                                    <option value="<?= htmlspecialchars($tool) ?>" <?= $tool_filter === $tool ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($tool) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Ordenamiento -->
                        <div class="mb-3">
                            <label class="form-label"><i class="fas fa-sort me-1"></i>Ordenar por</label>
                            <select class="form-select" name="sort">
                                <option value="recent" <?= $sort_by === 'recent' ? 'selected' : '' ?>>Más recientes</option>
                                <option value="popular" <?= $sort_by === 'popular' ? 'selected' : '' ?>>Más populares</option>
                                <option value="liked" <?= $sort_by === 'liked' ? 'selected' : '' ?>>Más gustados</option>
                                <option value="oldest" <?= $sort_by === 'oldest' ? 'selected' : '' ?>>Más antiguos</option>
                            </select>
                        </div>

                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-search me-1"></i>Aplicar filtros
                        </button>
                        
                        <a href="/comunidad" class="btn btn-outline-secondary w-100 mt-2">
                            <i class="fas fa-times me-1"></i>Limpiar filtros
                        </a>
                    </form>
                </div>
            </div>

            <!-- Estadísticas rápidas -->
            <div class="card shadow-sm mt-3">
                <div class="card-body text-center">
                    <h6 class="text-muted mb-3">Comunidad</h6>
                    <?php
                    try {
                        $stats = $pdo->query("
                            SELECT 
                                COUNT(DISTINCT uc.id) as total_creations,
                                COUNT(DISTINCT uc.user_id) as active_creators,
                                COUNT(DISTINCT CASE WHEN uc.created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR) THEN uc.id END) as today_creations
                            FROM user_creations uc 
                            WHERE uc.privacy = 'public' AND uc.status = 'completed'
                        ")->fetch(PDO::FETCH_ASSOC);
                    ?>
                        <div class="row text-center">
                            <div class="col-12 mb-2">
                                <small class="text-muted">Total creaciones</small>
                                <div class="fw-bold text-primary"><?= number_format($stats['total_creations']) ?></div>
                            </div>
                            <div class="col-12 mb-2">
                                <small class="text-muted">Creadores activos</small>
                                <div class="fw-bold text-success"><?= number_format($stats['active_creators']) ?></div>
                            </div>
                            <div class="col-12">
                                <small class="text-muted">Hoy</small>
                                <div class="fw-bold text-warning"><?= number_format($stats['today_creations']) ?></div>
                            </div>
                        </div>
                    <?php } catch (Exception $e) { ?>
                        <p class="text-muted">Estadísticas no disponibles</p>
                    <?php } ?>
                </div>
            </div>
        </div>

        <!-- Contenido principal -->
        <div class="col-lg-9 col-md-8">
            <!-- Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="mb-1"><i class="fas fa-users me-2 text-primary"></i>Comunidad</h2>
                    <p class="text-muted mb-0">Descubre las increíbles creaciones de nuestra comunidad</p>
                </div>
                <a href="/mis-creaciones" class="btn btn-outline-primary">
                    <i class="fas fa-plus me-1"></i>Mis creaciones
                </a>
            </div>

            <!-- Resultados -->
            <?php if (!empty($search) || !empty($type_filter) || !empty($tool_filter)): ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    Mostrando <?= number_format($total_posts) ?> resultado(s) 
                    <?php if (!empty($search)): ?>
                        para "<strong><?= htmlspecialchars($search) ?></strong>"
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <!-- Grid de creaciones -->
            <?php if (empty($creations)): ?>
                <div class="text-center py-5">
                    <i class="fas fa-search fa-3x text-muted mb-3"></i>
                    <h4 class="text-muted">No se encontraron creaciones</h4>
                    <p class="text-muted">Prueba ajustando los filtros o términos de búsqueda</p>
                    <a href="/comunidad" class="btn btn-primary">Ver todas las creaciones</a>
                </div>
            <?php else: ?>
                <div class="row" id="creationsGrid">
                    <?php foreach ($creations as $creation): ?>
                        <div class="col-lg-4 col-md-6 mb-4">
                            <div class="card shadow-sm h-100 creation-card" data-creation-id="<?= $creation['id'] ?>">
                                <!-- Imagen/Preview -->
                                <div class="creation-image-container">
                                    <?php if ($creation['type'] === 'studio_project'): ?>
                                        <!-- Vista especial para proyectos del Studio -->
                                        <div class="card-img-top bg-gradient-primary d-flex align-items-center justify-content-center text-white" style="height: 200px;">
                                            <div class="text-center">
                                                <i class="fas fa-magic fa-3x mb-2"></i>
                                                <h6>Proyecto del Studio</h6>
                                            </div>
                                        </div>
                                    <?php elseif ($creation['type'] === 'image'): ?>
                                        <img src="<?= htmlspecialchars($creation['file_path']) ?>" 
                                             class="card-img-top creation-image" 
                                             alt="<?= htmlspecialchars($creation['title'] ?? 'Imagen') ?>"
                                             data-bs-toggle="modal" 
                                             data-bs-target="#creationModal"
                                             data-creation-data='<?= json_encode($creation) ?>'>
                                    <?php elseif ($creation['type'] === 'text'): ?>
                                        <div class="card-img-top bg-gradient-info d-flex align-items-center justify-content-center text-white" style="height: 200px;">
                                            <div class="text-center">
                                                <i class="fas fa-file-text fa-3x mb-2"></i>
                                                <h6>Contenido de Texto</h6>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <div class="card-img-top bg-gradient-secondary d-flex align-items-center justify-content-center text-white" style="height: 200px;">
                                            <div class="text-center">
                                                <i class="fas fa-file fa-3x mb-2"></i>
                                                <h6><?= ucfirst($creation['type']) ?></h6>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <!-- Overlay con información -->
                                    <div class="creation-overlay">
                                        <div class="creation-actions">
                                            <button class="btn btn-sm btn-outline-light like-btn" 
                                                    data-creation-id="<?= $creation['id'] ?>"
                                                    data-liked="<?= $creation['user_has_liked'] ?>">
                                                <i class="fas fa-heart <?= $creation['user_has_liked'] ? 'text-danger' : '' ?>"></i>
                                                <span class="like-count"><?= $creation['like_count'] ?></span>
                                            </button>
                                            <button class="btn btn-sm btn-outline-light" 
                                                    onclick="shareCreation(<?= $creation['id'] ?>)">
                                                <i class="fas fa-share"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <div class="card-body">
                                    <!-- Header con usuario -->
                                    <div class="d-flex align-items-center mb-2">
                                        <div class="avatar-sm me-2">
                                            <?php if (!empty($creation['profile_image'])): ?>
                                                <img src="<?= htmlspecialchars($creation['profile_image']) ?>" 
                                                     class="rounded-circle" width="32" height="32">
                                            <?php else: ?>
                                                <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center text-white" 
                                                     style="width: 32px; height: 32px; font-size: 14px;">
                                                    <?= strtoupper(substr($creation['username'], 0, 1)) ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="flex-grow-1">
                                            <a href="/usuario?id=<?= $creation['user_id'] ?>" 
                                               class="text-decoration-none fw-bold text-dark">
                                                <?= htmlspecialchars($creation['username']) ?>
                                            </a>
                                            <div class="small text-muted"><?= timeAgo($creation['created_at']) ?></div>
                                        </div>
                                    </div>

                                    <!-- Título y descripción -->
                                    <?php if (!empty($creation['title'])): ?>
                                        <h6 class="card-title mb-1"><?= htmlspecialchars($creation['title']) ?></h6>
                                    <?php endif; ?>
                                    
                                    <?php if (!empty($creation['description'])): ?>
                                        <p class="card-text text-muted small mb-2 creation-description">
                                            <?= htmlspecialchars(substr($creation['description'], 0, 100)) ?>
                                            <?= strlen($creation['description']) > 100 ? '...' : '' ?>
                                        </p>
                                    <?php endif; ?>

                                    <!-- Acciones sociales -->
                                    <div class="d-flex justify-content-between align-items-center mt-3">
                                        <div class="d-flex gap-2">
                                            <?php if ($creation['type'] === 'studio_project'): ?>
                                                <!-- Botón especial para proyectos del Studio -->
                                                <a href="/studio/viewer.php?id=<?= $creation['id'] ?>" 
                                                   class="btn btn-sm btn-primary">
                                                    <i class="fas fa-eye me-1"></i>Ver Proyecto
                                                </a>
                                            <?php else: ?>
                                                <button class="btn btn-sm btn-outline-danger like-btn" 
                                                        data-creation-id="<?= $creation['id'] ?>"
                                                        data-liked="<?= $creation['user_has_liked'] ?>">
                                                    <i class="fas fa-heart <?= $creation['user_has_liked'] ? 'text-danger' : '' ?>"></i>
                                                    <span class="like-count"><?= $creation['like_count'] ?></span>
                                                </button>
                                                <button class="btn btn-sm btn-outline-primary comment-btn" 
                                                        data-creation-id="<?= $creation['id'] ?>"
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#commentsModal">
                                                    <i class="fas fa-comment"></i>
                                                    <span class="comment-count"><?= $creation['comment_count'] ?></span>
                                                </button>
                                            <?php endif; ?>
                                            <button class="btn btn-sm btn-outline-secondary" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#shareModal"
                                                    data-creation-id="<?= $creation['id'] ?>"
                                                    onclick="loadShareModal(<?= $creation['id'] ?>)">
                                                <i class="fas fa-share"></i>
                                            </button>
                                        </div>
                                        <small class="text-muted">
                                            <?= timeAgo($creation['created_at']) ?>
                                        </small>
                                    </div>

                                    <!-- Metadata -->
                                    <div class="d-flex justify-content-between align-items-center mt-2">
                                        <div>
                                            <span class="badge bg-<?= $creation['type'] === 'studio_project' ? 'success' : ($creation['type'] === 'image' ? 'primary' : ($creation['type'] === 'text' ? 'info' : 'secondary')) ?>">
                                                <?= $creation['type'] === 'studio_project' ? 'Proyecto Studio' : ucfirst($creation['type']) ?>
                                            </span>
                                            <?php if (!empty($creation['tool_used'])): ?>
                                                <span class="badge bg-light text-dark"><?= htmlspecialchars($creation['tool_used']) ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Paginación -->
                <?php if ($total_pages > 1): ?>
                    <nav aria-label="Paginación de creaciones" class="mt-4">
                        <ul class="pagination justify-content-center">
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>">
                                        <i class="fas fa-chevron-left"></i> Anterior
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php
                            $start = max(1, $page - 2);
                            $end = min($total_pages, $page + 2);
                            
                            for ($i = $start; $i <= $end; $i++):
                            ?>
                                <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                                    <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>">
                                        <?= $i ?>
                                    </a>
                                </li>
                            <?php endfor; ?>

                            <?php if ($page < $total_pages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>">
                                        Siguiente <i class="fas fa-chevron-right"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Modal para ver creación completa -->
<div class="modal fade" id="creationModal" tabindex="-1" aria-labelledby="creationModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="creationModalLabel">Creación</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body" id="creationModalBody">
                <!-- Contenido dinámico -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" onclick="shareCreation()">
                    <i class="fas fa-share me-1"></i>Compartir
                </button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal para comentarios -->
<div class="modal fade" id="commentsModal" tabindex="-1" aria-labelledby="commentsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="commentsModalLabel">
                    <i class="fas fa-comments me-2"></i>Comentarios
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body">
                <!-- Información de la creación -->
                <div id="commentCreationInfo" class="border-bottom mb-3 pb-3"></div>
                
                <!-- Lista de comentarios -->
                <div id="commentsList" class="mb-3" style="max-height: 300px; overflow-y: auto;">
                    <div class="text-center text-muted py-3">
                        <i class="fas fa-spinner fa-spin"></i> Cargando comentarios...
                    </div>
                </div>

                <!-- Formulario para nuevo comentario -->
                <div class="border-top pt-3">
                    <form id="newCommentForm">
                        <div class="d-flex gap-2">
                            <div class="flex-grow-1">
                                <textarea id="commentText" class="form-control" rows="2" 
                                          placeholder="Escribe un comentario... 😊" maxlength="1000"></textarea>
                                <div class="d-flex justify-content-between align-items-center mt-1">
                                    <div class="emoji-picker">
                                        <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle" 
                                                data-bs-toggle="dropdown" aria-expanded="false">
                                            😊 Emoji
                                        </button>
                                        <ul class="dropdown-menu">
                                            <li><a class="dropdown-item emoji-item" href="#" data-emoji="😊">😊 Sonrisa</a></li>
                                            <li><a class="dropdown-item emoji-item" href="#" data-emoji="❤️">❤️ Corazón</a></li>
                                            <li><a class="dropdown-item emoji-item" href="#" data-emoji="👍">👍 Me gusta</a></li>
                                            <li><a class="dropdown-item emoji-item" href="#" data-emoji="🎉">🎉 Celebración</a></li>
                                            <li><a class="dropdown-item emoji-item" href="#" data-emoji="🔥">🔥 Fuego</a></li>
                                            <li><a class="dropdown-item emoji-item" href="#" data-emoji="💯">💯 Perfecto</a></li>
                                            <li><a class="dropdown-item emoji-item" href="#" data-emoji="🤔">🤔 Pensativo</a></li>
                                            <li><a class="dropdown-item emoji-item" href="#" data-emoji="😮">😮 Sorpresa</a></li>
                                            <li><a class="dropdown-item emoji-item" href="#" data-emoji="🚀">🚀 Cohete</a></li>
                                            <li><a class="dropdown-item emoji-item" href="#" data-emoji="⭐">⭐ Estrella</a></li>
                                            <li><a class="dropdown-item emoji-item" href="#" data-emoji="🎨">🎨 Arte</a></li>
                                            <li><a class="dropdown-item emoji-item" href="#" data-emoji="💡">💡 Idea</a></li>
                                        </ul>
                                    </div>
                                    <small class="text-muted">Máximo 1000 caracteres</small>
                                </div>
                            </div>
                            <div class="d-flex align-items-end">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-paper-plane"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal para compartir -->
<div class="modal fade" id="shareModal" tabindex="-1" aria-labelledby="shareModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="shareModalLabel">
                    <i class="fas fa-share me-2"></i>Compartir creación
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body">
                <!-- Información de la creación -->
                <div id="shareCreationInfo" class="border-bottom mb-3 pb-3"></div>
                
                <!-- Opciones de compartir -->
                <div class="row g-2">
                    <div class="col-12 mb-3">
                        <label class="form-label">Enlace directo:</label>
                        <div class="input-group">
                            <input type="text" id="shareDirectLink" class="form-control" readonly>
                            <button class="btn btn-outline-secondary" type="button" onclick="copyToClipboard('shareDirectLink')">
                                <i class="fas fa-copy"></i> Copiar
                            </button>
                        </div>
                    </div>
                    
                    <div class="col-6">
                        <button class="btn btn-primary w-100 mb-2" onclick="shareToSocial('twitter')">
                            <i class="fab fa-twitter me-1"></i>Twitter
                        </button>
                    </div>
                    <div class="col-6">
                        <button class="btn btn-primary w-100 mb-2" onclick="shareToSocial('facebook')">
                            <i class="fab fa-facebook me-1"></i>Facebook
                        </button>
                    </div>
                    <div class="col-6">
                        <button class="btn btn-success w-100 mb-2" onclick="shareToSocial('whatsapp')">
                            <i class="fab fa-whatsapp me-1"></i>WhatsApp
                        </button>
                    </div>
                    <div class="col-6">
                        <button class="btn btn-info w-100 mb-2" onclick="shareToSocial('telegram')">
                            <i class="fab fa-telegram me-1"></i>Telegram
                        </button>
                    </div>
                    <div class="col-6">
                        <button class="btn btn-secondary w-100 mb-2" onclick="shareToEmail()">
                            <i class="fas fa-envelope me-1"></i>Email
                        </button>
                    </div>
                    <div class="col-6">
                        <button class="btn btn-outline-primary w-100 mb-2" onclick="shareNative()">
                            <i class="fas fa-share-alt me-1"></i>Compartir
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.creation-card {
    transition: transform 0.2s, box-shadow 0.2s;
    overflow: hidden;
}

.creation-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15) !important;
}

.creation-image-container {
    position: relative;
    overflow: hidden;
}

.creation-image {
    height: 200px;
    object-fit: cover;
    cursor: pointer;
    transition: transform 0.3s;
}

.creation-image:hover {
    transform: scale(1.05);
}

.creation-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity 0.3s;
}

.creation-card:hover .creation-overlay {
    opacity: 1;
}

.creation-actions {
    display: flex;
    gap: 10px;
}

.like-btn.liked {
    background-color: rgba(220, 53, 69, 0.2);
    border-color: #dc3545;
}

.creation-description {
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.avatar-sm img, .avatar-sm div {
    border: 2px solid #fff;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

@media (max-width: 768px) {
    .creation-overlay {
        opacity: 1;
        background: rgba(0,0,0,0.3);
    }
    
    .creation-actions {
        position: absolute;
        top: 10px;
        right: 10px;
        flex-direction: column;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Auto-submit del formulario al cambiar filtros
    const filterForm = document.getElementById('filterForm');
    const selects = filterForm.querySelectorAll('select');
    
    selects.forEach(select => {
        select.addEventListener('change', () => {
            filterForm.submit();
        });
    });

    // Manejar likes
    document.querySelectorAll('.like-btn').forEach(btn => {
        btn.addEventListener('click', toggleLike);
    });

    // Manejar modal de creación
    document.querySelectorAll('[data-bs-target="#creationModal"]').forEach(img => {
        img.addEventListener('click', function() {
            const creationData = JSON.parse(this.getAttribute('data-creation-data'));
            showCreationModal(creationData);
        });
    });

    // Manejar botones de comentarios
    document.querySelectorAll('.comment-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const creationId = this.getAttribute('data-creation-id');
            loadComments(creationId);
        });
    });

    // Manejar formulario de nuevo comentario
    document.getElementById('newCommentForm').addEventListener('submit', addComment);

    // Manejar selector de emojis
    document.querySelectorAll('.emoji-item').forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const emoji = this.getAttribute('data-emoji');
            const textarea = document.getElementById('commentText');
            const start = textarea.selectionStart;
            const end = textarea.selectionEnd;
            const text = textarea.value;
            
            textarea.value = text.slice(0, start) + emoji + text.slice(end);
            textarea.focus();
            textarea.setSelectionRange(start + emoji.length, start + emoji.length);
        });
    });
});

async function toggleLike(e) {
    e.preventDefault();
    e.stopPropagation();
    
    const btn = e.currentTarget;
    const creationId = btn.getAttribute('data-creation-id');
    const isLiked = btn.getAttribute('data-liked') === '1';
    
    try {
        const response = await fetch('/api/social/toggle_like.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                creation_id: creationId,
                action: isLiked ? 'unlike' : 'like'
            })
        });

        const result = await response.json();
        
        if (result.success) {
            const icon = btn.querySelector('i');
            const countSpan = btn.querySelector('.like-count');
            
            if (isLiked) {
                icon.classList.remove('text-danger');
                btn.setAttribute('data-liked', '0');
                btn.classList.remove('liked');
            } else {
                icon.classList.add('text-danger');
                btn.setAttribute('data-liked', '1');
                btn.classList.add('liked');
            }
            
            countSpan.textContent = result.like_count;
        }
    } catch (error) {
        console.error('Error al procesar like:', error);
    }
}

function showCreationModal(creation) {
    const modalBody = document.getElementById('creationModalBody');
    const modalTitle = document.getElementById('creationModalLabel');
    
    modalTitle.textContent = creation.title || 'Creación sin título';
    
    let content = '';
    
    if (creation.type === 'image') {
        content = `
            <div class="text-center mb-3">
                <img src="${creation.file_path}" class="img-fluid rounded" style="max-height: 400px;">
            </div>
        `;
    }
    
    content += `
        <div class="d-flex align-items-center mb-3">
            <div class="me-3">
                ${creation.profile_image ? 
                    `<img src="${creation.profile_image}" class="rounded-circle" width="48" height="48">` :
                    `<div class="bg-primary rounded-circle d-flex align-items-center justify-content-center text-white" style="width: 48px; height: 48px;">
                        ${creation.username.charAt(0).toUpperCase()}
                    </div>`
                }
            </div>
            <div>
                <h6 class="mb-0">${creation.username}</h6>
                <small class="text-muted">Publicado ${timeAgo(creation.created_at)}</small>
            </div>
        </div>
        
        ${creation.description ? `<p class="text-muted">${creation.description}</p>` : ''}
        
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <span class="badge bg-primary">${creation.type.charAt(0).toUpperCase() + creation.type.slice(1)}</span>
                ${creation.tool_used ? `<span class="badge bg-secondary">${creation.tool_used}</span>` : ''}
            </div>
            <div>
                <button class="btn btn-outline-danger btn-sm like-btn" 
                        data-creation-id="${creation.id}"
                        data-liked="${creation.user_has_liked}">
                    <i class="fas fa-heart ${creation.user_has_liked ? 'text-danger' : ''}"></i>
                    <span class="like-count">${creation.like_count}</span>
                </button>
            </div>
        </div>
    `;
    
    modalBody.innerHTML = content;
    
    // Agregar event listener al botón de like en el modal
    const likeBtn = modalBody.querySelector('.like-btn');
    if (likeBtn) {
        likeBtn.addEventListener('click', toggleLike);
    }
}

function shareCreation(creationId) {
    const url = `${window.location.origin}/comunidad#creation-${creationId}`;
    
    if (navigator.share) {
        navigator.share({
            title: 'Mira esta increíble creación',
            text: 'Descubre esta creación hecha con ObelisIA',
            url: url
        });
    } else {
        navigator.clipboard.writeText(url).then(() => {
            alert('¡Enlace copiado al portapapeles!');
        });
    }
}

let currentCreationId = null;
let currentShareData = null;

async function loadComments(creationId) {
    currentCreationId = creationId;
    const commentsList = document.getElementById('commentsList');
    const creationInfo = document.getElementById('commentCreationInfo');
    
    // Mostrar loader
    commentsList.innerHTML = '<div class="text-center text-muted py-3"><i class="fas fa-spinner fa-spin"></i> Cargando comentarios...</div>';
    
    try {
        // Cargar información de la creación
        const creationCard = document.querySelector(`[data-creation-id="${creationId}"]`).closest('.card');
        const title = creationCard.querySelector('.card-title')?.textContent || 'Creación sin título';
        const username = creationCard.querySelector('a[href*="/usuario"]').textContent;
        
        creationInfo.innerHTML = `
            <div class="d-flex align-items-center">
                <i class="fas fa-image me-2 text-primary"></i>
                <div>
                    <h6 class="mb-0">${title}</h6>
                    <small class="text-muted">por ${username}</small>
                </div>
            </div>
        `;

        // Cargar comentarios
        const response = await fetch(`/api/social/get_comments.php?creation_id=${creationId}`);
        const data = await response.json();
        
        if (data.success) {
            renderComments(data.comments);
        } else {
            commentsList.innerHTML = '<div class="alert alert-warning">Error al cargar comentarios</div>';
        }
    } catch (error) {
        console.error('Error cargando comentarios:', error);
        commentsList.innerHTML = '<div class="alert alert-danger">Error al cargar comentarios</div>';
    }
}

function renderComments(comments) {
    const commentsList = document.getElementById('commentsList');
    
    if (comments.length === 0) {
        commentsList.innerHTML = '<div class="text-center text-muted py-3">No hay comentarios aún.<br><small>¡Sé el primero en comentar!</small></div>';
        return;
    }

    let html = '';
    comments.forEach(comment => {
        html += `
            <div class="d-flex mb-3">
                <div class="me-2">
                    ${comment.profile_image 
                        ? `<img src="${comment.profile_image}" class="rounded-circle" width="32" height="32">`
                        : `<div class="bg-primary rounded-circle d-flex align-items-center justify-content-center text-white" style="width: 32px; height: 32px; font-size: 14px;">
                            ${comment.username.charAt(0).toUpperCase()}
                           </div>`
                    }
                </div>
                <div class="flex-grow-1">
                    <div class="bg-light rounded p-2">
                        <div class="d-flex justify-content-between align-items-start">
                            <strong class="text-primary">${comment.full_name || comment.username}</strong>
                            <small class="text-muted">${comment.created_at_formatted}</small>
                        </div>
                        <p class="mb-0 mt-1">${comment.comment}</p>
                    </div>
                </div>
            </div>
        `;
    });
    
    commentsList.innerHTML = html;
}

async function addComment(e) {
    e.preventDefault();
    
    const commentText = document.getElementById('commentText');
    const text = commentText.value.trim();
    
    if (!text) {
        alert('Por favor escribe un comentario');
        return;
    }

    if (!currentCreationId) {
        alert('Error: No se pudo identificar la creación');
        return;
    }

    try {
        const response = await fetch('/api/social/add_comment.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                creation_id: currentCreationId,
                comment: text
            })
        });

        const result = await response.json();
        
        if (result.success) {
            commentText.value = '';
            // Recargar comentarios
            loadComments(currentCreationId);
            
            // Actualizar contador en la tarjeta
            const commentBtn = document.querySelector(`[data-creation-id="${currentCreationId}"].comment-btn`);
            if (commentBtn) {
                const countSpan = commentBtn.querySelector('.comment-count');
                const currentCount = parseInt(countSpan.textContent) || 0;
                countSpan.textContent = currentCount + 1;
            }
        } else {
            alert(result.message || 'Error al agregar comentario');
        }
    } catch (error) {
        console.error('Error agregando comentario:', error);
        alert('Error al agregar comentario');
    }
}

async function loadShareModal(creationId) {
    currentCreationId = creationId;
    
    try {
        const response = await fetch('/api/social/share.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                creation_id: creationId,
                type: 'social'
            })
        });

        const data = await response.json();
        
        if (data.success) {
            currentShareData = data;
            
            // Actualizar información de la creación en el modal
            const shareInfo = document.getElementById('shareCreationInfo');
            shareInfo.innerHTML = `
                <div class="d-flex align-items-center">
                    <i class="fas fa-image me-2 text-primary"></i>
                    <div>
                        <h6 class="mb-0">${data.creation.title}</h6>
                        <small class="text-muted">por ${data.creation.creator}</small>
                    </div>
                </div>
            `;

            // Actualizar enlace directo
            document.getElementById('shareDirectLink').value = data.urls.direct;
        } else {
            alert('Error al cargar datos para compartir');
        }
    } catch (error) {
        console.error('Error cargando datos de compartir:', error);
        alert('Error al cargar datos para compartir');
    }
}

function shareToSocial(platform) {
    if (!currentShareData || !currentShareData.social_urls) {
        alert('Error: datos de compartir no disponibles');
        return;
    }

    const url = currentShareData.social_urls[platform];
    if (url) {
        window.open(url, '_blank', 'width=600,height=400');
    }
}

function shareToEmail() {
    if (!currentShareData) {
        alert('Error: datos de compartir no disponibles');
        return;
    }

    // Generar URL de email
    const subject = encodeURIComponent("Te comparto esta creación de ObelisIA");
    const body = encodeURIComponent(`Hola,

Quería compartir contigo esta increíble creación que encontré en ObelisIA:

Título: ${currentShareData.creation.title}
Creador: ${currentShareData.creation.creator}
Enlace: ${currentShareData.urls.direct}

¡Espero que te guste!

Saludos`);
    
    window.location.href = `mailto:?subject=${subject}&body=${body}`;
}

function shareNative() {
    if (!currentShareData) {
        alert('Error: datos de compartir no disponibles');
        return;
    }

    if (navigator.share) {
        navigator.share({
            title: currentShareData.creation.title,
            text: `Mira esta increíble creación de ${currentShareData.creation.creator} en ObelisIA`,
            url: currentShareData.urls.direct
        });
    } else {
        // Fallback: copiar al portapapeles
        copyToClipboard('shareDirectLink');
    }
}

function copyToClipboard(elementId) {
    const element = document.getElementById(elementId);
    element.select();
    element.setSelectionRange(0, 99999);
    navigator.clipboard.writeText(element.value).then(() => {
        // Mostrar feedback visual
        const button = element.nextElementSibling;
        const originalText = button.innerHTML;
        button.innerHTML = '<i class="fas fa-check"></i> ¡Copiado!';
        button.classList.remove('btn-outline-secondary');
        button.classList.add('btn-success');
        
        setTimeout(() => {
            button.innerHTML = originalText;
            button.classList.remove('btn-success');
            button.classList.add('btn-outline-secondary');
        }, 2000);
    });
}

function timeAgo(datetime) {
    const now = new Date();
    const time = new Date(datetime);
    const diff = Math.floor((now - time) / 1000);
    
    if (diff < 60) return 'hace unos segundos';
    if (diff < 3600) return `hace ${Math.floor(diff/60)} minutos`;
    if (diff < 86400) return `hace ${Math.floor(diff/3600)} horas`;
    if (diff < 2592000) return `hace ${Math.floor(diff/86400)} días`;
    
    return time.toLocaleDateString();
}
</script>
