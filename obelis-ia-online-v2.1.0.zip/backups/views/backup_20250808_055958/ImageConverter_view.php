
<?php // src/Tools/views/ImageConverter_view.php ?>


<link rel="stylesheet" href="<?php echo \ObelisIA\Router\MainRouter::url('assets/css/tools/convert-img/side-layout.css'); ?>">

<div class="imgconv-side-layout d-flex flex-row align-items-stretch px-4 my-4" style="gap:1.5rem; min-height:80vh;">
  <!-- Aside izquierdo: Opciones -->
  <aside class="imgconv-options-col d-flex flex-column">
    <div class="card shadow-sm mb-4 flex-grow-1">
      <div class="card-header bg-white border-0">
        <h5 class="mb-0">Opciones de Conversión</h5>
      </div>
      <div class="card-body">
        <form id="imgconvOptionsForm">
          <div class="mb-3">
            <label for="outputFormat" class="form-label text-muted">Formato de salida:</label>
            <select id="outputFormat" name="outputFormat" class="form-select">
              <option value="image/png">PNG</option>
              <option value="image/jpeg">JPG</option>
              <option value="image/webp">WEBP</option>
              <option value="image/bmp">BMP</option>
              <option value="image/gif">GIF (estático)</option>
            </select>
          </div>
          <div class="mb-3">
            <label for="quality" class="form-label text-muted">Calidad (JPG/WEBP):</label>
            <input type="range" id="quality" name="quality" min="10" max="100" value="90" class="form-range">
            <span id="qualityValue">90</span>
          </div>
          <div class="mb-3">
            <label for="resize" class="form-label text-muted">Redimensionar (opcional):</label>
            <input type="number" id="resize" name="resize" class="form-control" min="1" max="4096" placeholder="Ancho en px">
          </div>
          <button type="submit" class="btn btn-primary w-100">Aplicar Opciones</button>
        </form>
      </div>
    </div>
  </aside>

  <!-- Centro: Conversor principal -->
  <main class="imgconv-center-col d-flex flex-column flex-grow-1" style="min-width:0;">
    <div class="card shadow-sm flex-grow-1 d-flex flex-column">
      <div class="card-header bg-light border-0 p-3">
        <h3 class="mb-0 text-muted">Conversor de Imágenes</h3>
      </div>
      <div class="card-body d-flex flex-column justify-content-center align-items-center position-relative p-0" style="flex:1; min-height:400px;">
        <!-- Área de arrastrar y soltar/seleccionar imagen -->
        <div id="imgDropArea" class="w-100 h-100 d-flex flex-column justify-content-center align-items-center position-absolute top-0 start-0 bg-light" style="min-height:400px; height:100%; left:0; right:0; bottom:0; z-index:2; cursor:pointer; background:rgba(255,255,255,0.97);">
          <input type="file" id="imageUpload" class="d-none" accept="image/*">
          <div class="d-flex flex-column justify-content-center align-items-center w-100 h-100" style="pointer-events:none;">
            <i class="fas fa-upload mb-3" style="font-size:2.5rem; color:#6c757d;"></i>
            <span style="font-size:1.2rem;">Arrastra una imagen aquí o haz clic para seleccionar</span>
            <p id="fileName" class="text-muted mt-2 small">Ningún archivo seleccionado</p>
          </div>
        </div>
</script>
<script>
// Hacer que cualquier clic en el área de drop abra el input file
const imgDropArea = document.getElementById('imgDropArea');
const imageUpload = document.getElementById('imageUpload');
if (imgDropArea && imageUpload) {
  imgDropArea.addEventListener('click', function(e) {
    // Solo abrir si no se está seleccionando texto
    if (window.getSelection().toString().length === 0) {
      imageUpload.click();
    }
  });
}
</script>
        <!-- Canvas y controles de conversión, solo visibles si hay imagen -->
        <div id="imgConvWorkArea" class="px-4 w-100 d-none flex-column align-items-center">
          <div class="canvas-container mb-3 text-center">
            <canvas id="imageCanvas"></canvas>
            <p id="placeholderText">La previsualización aparecerá aquí</p>
          </div>
          <div class="row justify-content-center align-items-center w-100">
            <div class="col-md-6">
              <button id="convertBtn" class="btn btn-primary btn-lg w-100 mb-3 mb-md-0" disabled>
                <i class="fas fa-sync-alt me-2"></i>Convertir
              </button>
            </div>
            <div class="col-md-6">
              <button id="downloadBtn" class="btn btn-success btn-lg w-100" disabled>
                <i class="fas fa-download me-2"></i>Descargar Imagen Convertida
              </button>
            </div>
          </div>
          <div class="row mt-3 w-100">
            <div class="col">
              <p id="conversionCounterDisplay" class="text-muted">Conversiones gratuitas restantes: --</p>
              <button id="watchAdButton" class="btn btn-info btn-sm mt-2 d-none">
                Ver Anuncio para +3 Conversiones
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>

  <!-- Aside derecho: Historial -->
  <aside class="imgconv-history-col d-flex flex-column">
    <div class="card shadow-sm flex-grow-1">
      <div class="card-header d-flex justify-content-between align-items-center bg-white border-0">
        <h5 class="mb-0">Historial de Conversiones</h5>
        <button id="clearImgconvHistoryButton" class="btn btn-outline-danger btn-sm" title="Limpiar historial">
          <i class="fas fa-trash"></i>
        </button>
      </div>
      <div id="imgconvHistoryContainer" >
        <p class="text-muted text-center">No hay conversiones en el historial.</p>
      </div>
    </div>
  </aside>
</div>

<script type="module" src="<?php echo \ObelisIA\Router\MainRouter::url('assets/js/tools/convert-img/app.js'); ?>"></script>
<script>
// --- Opciones de conversión ---
const qualityInput = document.getElementById('quality');
const qualityValue = document.getElementById('qualityValue');
if (qualityInput && qualityValue) {
  qualityInput.addEventListener('input', () => {
    qualityValue.textContent = qualityInput.value;
  });
}

// --- Historial de conversiones ---
function getImgconvHistory() {
  return JSON.parse(localStorage.getItem('imgconvHistory') || '[]');
}
function saveImgconvHistory(history) {
  localStorage.setItem('imgconvHistory', JSON.stringify(history));
}
function addImgconvToHistory(item) {
  const history = getImgconvHistory();
  history.unshift(item);
  if (history.length > 20) history.length = 20;
  saveImgconvHistory(history);
}
function clearImgconvHistory() {
  saveImgconvHistory([]);
  renderImgconvHistory();
}
function renderImgconvHistory() {
  const container = document.getElementById('imgconvHistoryContainer');
  const history = getImgconvHistory();
  container.innerHTML = '';
  if (!history.length) {
    container.innerHTML = '<p class="text-muted text-center">No hay conversiones en el historial.</p>';
    return;
  }
  history.forEach(item => {
    const div = document.createElement('div');
    div.className = 'imgconv-history-item bg-light mx-2';
    div.innerHTML = `
      <img class="imgconv-history-thumb" src="${item.thumb}" alt="miniatura">
      <div class="imgconv-history-info">
        <span class="imgconv-history-title text-muted" title="${item.name}">${item.name}</span>
        <div class="imgconv-history-meta text-muted">
          <span>${item.format.toUpperCase()}</span>
          <span>${item.size}</span>
          <span>${item.date}</span>
        </div>
      </div>
      <div class="imgconv-history-actions">
        <a href="${item.downloadUrl}" download="${item.name}" class="imgconv-history-download" title="Descargar">
          <i class="fas fa-download me-1"></i>
        </a>
      </div>
    `;
    container.appendChild(div);
  });
}
document.getElementById('clearImgconvHistoryButton').addEventListener('click', clearImgconvHistory);
renderImgconvHistory();
</script>

<?php 
$premiumMessage = 'Accede a imágenes en máxima resolución, sin marca de agua, estilos y relaciones de aspecto exclusivos, y prioridad en la generación. ¡Hazte premium y lleva tus creaciones visuales con IA al siguiente nivel!';
include __DIR__ . '/../../../assets/banners/partials/premium_banner_for_tools.php'; 
?>