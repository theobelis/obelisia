<?php // src/Tools/views/VideoGenerator_view.php ?>

<link rel="stylesheet" href="<?php echo \ObelisIA\Router\MainRouter::url('assets/css/tools/ia-video/style.css'); ?>">

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-sm text-center">
                <div class="card-body p-4 p-md-5">
                    <div class="tool-icon-header">
                        <i class="fas fa-film"></i>
                    </div>
                    <h2 class="card-title h3 mb-3">Generador de Videos con IA</h2>
                    <p class="text-muted mb-4">Describe una escena, un concepto o una historia, y la IA creará un videoclip corto basado en tu descripción.</p>
                    
                    <form method="POST" action="#results">
                        <input type="hidden" name="tool_slug" value="<?php echo htmlspecialchars($current_tool['slug']); ?>">
                        
                        <div class="mb-3">
                            <textarea name="inputText" class="form-control form-control-lg" rows="4" placeholder="Ej: Un dron volando sobre una ciudad futurista al atardecer, estilo cyberpunk..."></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-primary btn-lg w-100">
                            <i class="fas fa-magic me-2"></i>Generar Video
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
$premiumMessage = 'videos de mayor duración, resoluciones superiores, estilos exclusivos y prioridad en la generación. ¡Hazte premium y lleva tus creaciones de video con IA al siguiente nivel!';
include __DIR__ . '/../../../assets/banners/partials/premium_banner_for_tools.php'; 
?>