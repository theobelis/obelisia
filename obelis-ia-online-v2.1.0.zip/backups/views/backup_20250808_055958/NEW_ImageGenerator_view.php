<?php
// src/Tools/views/NEW_ImageGenerator_view.php
use ObelisIA\Utils\Premium;

// Configuración de la herramienta
$tool_name = "Generador de Imágenes IA";
$tool_icon = "image";
$tool_description = "Crea imágenes increíbles con inteligencia artificial";
$tool_slug = "generador-de-imagenes-ia";
$is_premium = Premium::isPremium();
$show_history = true;
$show_export_button = true;

// Contenido del sidebar
$sidebar_content = '
<div class="form-group">
    <label class="form-label">Estilo de Imagen</label>
    <div class="style-selector">
        <div class="style-option" data-style="realistic">
            <div class="style-icon"><i class="fas fa-camera"></i></div>
            <div class="style-name">Realista</div>
        </div>
        <div class="style-option" data-style="cartoon">
            <div class="style-icon"><i class="fas fa-palette"></i></div>
            <div class="style-name">Cartoon</div>
        </div>
        <div class="style-option" data-style="anime">
            <div class="style-icon"><i class="fas fa-mask"></i></div>
            <div class="style-name">Anime</div>
        </div>
        <div class="style-option" data-style="digital-art">
            <div class="style-icon"><i class="fas fa-paint-brush"></i></div>
            <div class="style-name">Digital</div>
        </div>
        <div class="style-option" data-style="photographic">
            <div class="style-icon"><i class="fas fa-camera-retro"></i></div>
            <div class="style-name">Foto</div>
        </div>
        <div class="style-option" data-style="3d-render">
            <div class="style-icon"><i class="fas fa-cube"></i></div>
            <div class="style-name">3D</div>
        </div>
    </div>
</div>

<div class="form-group">
    <label class="form-label">Relación de Aspecto</label>
    <select id="aspectRatioSelect" class="form-control">
        <option value="1:1">1:1 (Cuadrado)</option>
        <option value="16:9">16:9 (Horizontal)</option>
        <option value="9:16">9:16 (Vertical)</option>
        <option value="4:3">4:3 (Clásico)</option>
        <option value="3:2">3:2 (Fotografía)</option>
        <option value="21:9">21:9 (Ultrawide)</option>
    </select>
</div>

<div class="range-container">
    <div class="range-label">
        <label class="form-label">Calidad</label>
        <span class="range-value" id="qualityValue">HD</span>
    </div>
    <input type="range" class="range-input" id="qualityRange" min="1" max="3" value="2" 
           data-labels=\'["Básica", "HD", "Ultra HD"]\'>
</div>

<div class="range-container">
    <div class="range-label">
        <label class="form-label">Creatividad</label>
        <span class="range-value" id="creativityValue">5</span>
    </div>
    <input type="range" class="range-input" id="creativityRange" min="1" max="10" value="5">
</div>

<div class="range-container">
    <div class="range-label">
        <label class="form-label">Pasos de Inferencia</label>
        <span class="range-value" id="stepsValue">25</span>
    </div>
    <input type="range" class="range-input" id="stepsRange" min="10" max="50" value="25">
</div>

' . ($is_premium ? '
<div class="form-group">
    <label class="form-label">Número de Imágenes</label>
    <select id="numImagesSelect" class="form-control">
        <option value="1">1 imagen</option>
        <option value="2">2 imágenes</option>
        <option value="4">4 imágenes</option>
        <option value="8">8 imágenes</option>
    </select>
</div>
' : '
<div class="premium-feature">
    <div class="premium-badge">PRO</div>
    <div class="form-group">
        <label class="form-label">Número de Imágenes</label>
        <select class="form-control" disabled>
            <option>1 imagen (Gratis)</option>
            <option>4 imágenes (Premium)</option>
            <option>8 imágenes (Premium)</option>
        </select>
    </div>
</div>
');

// Contenido principal
$main_content = '
<div class="tool-form fade-in-up">
    <div class="form-section">
        <div class="form-section-title">
            <i class="fas fa-edit"></i>
            Descripción de la Imagen
        </div>
        
        ' . ($is_premium ? '<div class="alert alert-success">
            <i class="fas fa-crown"></i>
            <strong>¡Usuario Premium!</strong> Disfruta de generaciones ilimitadas, máxima resolución y sin marca de agua.
        </div>' : '') . '
        
        <div class="prompt-input-container">
            <textarea 
                class="prompt-input" 
                placeholder="Describe detalladamente la imagen que quieres crear. Ejemplo: \'Un gato naranja sentado en una ventana con luz dorada del atardecer, estilo fotografía profesional, alta definición, 8K, cinematográfico\'"
                id="imagePrompt"
                maxlength="2000"
            ></textarea>
            <div class="prompt-counter">
                <span id="charCount">0</span>/2000
            </div>
        </div>
        
        <div class="form-group">
            <label class="form-label">
                <i class="fas fa-ban"></i>
                Prompt Negativo (opcional)
            </label>
            <input type="text" class="form-control" id="negativePrompt" 
                   placeholder="Elementos que NO quieres: blur, low quality, distorted, cropped, watermark...">
            <small class="text-muted">Especifica elementos a evitar en la imagen</small>
        </div>
        
        <div class="form-group">
            <label class="form-label">
                <i class="fas fa-seedling"></i>
                Semilla (Seed) - opcional
            </label>
            <div class="flex gap-sm">
                <input type="number" class="form-control" id="seedInput" 
                       placeholder="Déjalo vacío para aleatorio" min="0" max="4294967295">
                <button class="btn btn-secondary" onclick="generateRandomSeed()" type="button">
                    <i class="fas fa-dice"></i>
                </button>
            </div>
            <small class="text-muted">Usa la misma semilla para reproducir resultados</small>
        </div>
        
        <div class="flex gap-md">
            <button class="btn btn-primary flex-1" onclick="generateImage()" id="generateBtn">
                <i class="fas fa-magic"></i>
                Generar Imagen
            </button>
            <button class="btn btn-secondary" onclick="clearImageForm()">
                <i class="fas fa-trash"></i>
                Limpiar
            </button>
            <button class="btn btn-outline" onclick="useRandomPrompt()">
                <i class="fas fa-lightbulb"></i>
                Inspirar
            </button>
        </div>
    </div>
</div>

<!-- Área de vista previa y resultados -->
<div class="tool-canvas-container">
    <div class="tool-canvas">
        <div class="canvas-area" id="canvasArea">
            <div class="canvas-placeholder">
                <i class="fas fa-image fa-4x mb-4 pulse"></i>
                <h3>Área de Vista Previa</h3>
                <p class="text-muted">Las imágenes generadas aparecerán aquí</p>
                <div class="mt-4">
                    <div class="flex gap-md justify-center">
                        <div class="stat-item">
                            <span class="stat-number" id="totalGenerated">0</span>
                            <span class="stat-label">Generadas</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-number" id="remainingCredits">∞</span>
                            <span class="stat-label">Restantes</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Galería de resultados -->
<div class="results-container" id="imageResults" style="display: none;">
    <div class="results-header">
        <div class="results-title">
            <i class="fas fa-images"></i>
            Imágenes Generadas
            <span class="badge bg-accent" id="imageCount">0</span>
        </div>
        <div class="results-actions">
            <button class="btn btn-sm btn-outline" onclick="regenerateImages()">
                <i class="fas fa-redo"></i>
                Regenerar
            </button>
            <button class="btn btn-sm btn-secondary" onclick="selectAllImages()">
                <i class="fas fa-check-square"></i>
                Seleccionar Todo
            </button>
            <button class="btn btn-sm btn-accent" onclick="downloadSelected()">
                <i class="fas fa-download"></i>
                Descargar Seleccionadas
            </button>
        </div>
    </div>
    <div class="results-body">
        <div class="image-gallery" id="imageGallery">
            <!-- Las imágenes se mostrarán aquí -->
        </div>
    </div>
</div>

<!-- Sección de prompts sugeridos -->
<div class="card glass-card mt-4" id="promptSuggestions">
    <div class="card-header">
        <h4><i class="fas fa-lightbulb"></i> Prompts Sugeridos</h4>
    </div>
    <div class="card-body">
        <div class="options-grid" id="suggestedPrompts">
            <!-- Se cargarán dinámicamente -->
        </div>
    </div>
</div>';

// Contenido de ayuda
$help_content = '
<div class="help-section">
    <h4><i class="fas fa-magic"></i> Cómo usar el Generador de Imágenes</h4>
    <ol>
        <li><strong>Describe tu imagen:</strong> Sé específico con colores, estilos, emociones y detalles</li>
        <li><strong>Selecciona un estilo:</strong> Elige entre realista, cartoon, anime, digital art, etc.</li>
        <li><strong>Ajusta la configuración:</strong> Calidad, creatividad y relación de aspecto</li>
        <li><strong>Genera:</strong> Haz clic en "Generar Imagen" y espera el resultado</li>
    </ol>
    
    <h5><i class="fas fa-tips"></i> Consejos para mejores resultados:</h5>
    <ul>
        <li>Incluye detalles sobre iluminación: "luz dorada", "iluminación dramática"</li>
        <li>Especifica la calidad: "alta definición", "4K", "ultra detallado"</li>
        <li>Menciona el tipo de toma: "primer plano", "plano general", "vista aérea"</li>
        <li>Usa el prompt negativo para evitar elementos no deseados</li>
    </ul>
    
    <h5><i class="fas fa-crown"></i> Funciones Premium:</h5>
    <ul>
        <li>Generación de múltiples imágenes simultáneas</li>
        <li>Resolución Ultra HD sin marca de agua</li>
        <li>Estilos y filtros exclusivos</li>
        <li>Prioridad en la cola de generación</li>
    </ul>
</div>';

// JavaScript específico
$inline_js = '
let currentStyle = "realistic";
let isGenerating = false;
let generatedCount = 0;
let selectedImages = new Set();

// Prompts sugeridos por categoría
const promptSuggestions = {
    landscape: [
        "Montañas nevadas al amanecer con lago cristalino",
        "Bosque encantado con rayos de luz filtrados",
        "Playa tropical al atardecer con palmeras",
        "Campo de lavanda en Francia, estilo impresionista"
    ],
    portrait: [
        "Retrato profesional de una persona de negocios",
        "Anciano sabio con barba blanca, iluminación dramática",
        "Niña sonriente con flores en el cabello",
        "Guerrero medieval con armadura dorada"
    ],
    fantasy: [
        "Dragón majestuoso volando sobre un castillo",
        "Hada del bosque con alas brillantes",
        "Ciudad flotante en las nubes",
        "Mago invocando un hechizo de fuego"
    ],
    scifi: [
        "Nave espacial futurista en el espacio profundo",
        "Robot humanoide en una ciudad cyberpunk",
        "Portal interdimensional con luces neón",
        "Astronauta explorando planeta alienígena"
    ]
};

// Funciones específicas del generador de imágenes
function generateImage() {
    if (isGenerating) return;
    
    const prompt = document.getElementById("imagePrompt").value.trim();
    if (!prompt) {
        showAlert("Por favor, describe la imagen que quieres crear", "warning");
        return;
    }
    
    if (!window.toolConfig.isPremium && generatedCount >= 5) {
        showAlert("Has alcanzado el límite de generaciones gratuitas. Hazte Premium para generar sin límites.", "warning");
        return;
    }
    
    isGenerating = true;
    const generateBtn = document.getElementById("generateBtn");
    generateBtn.disabled = true;
    generateBtn.innerHTML = "<div class=\"spinner\"></div> Generando...";
    
    showLoading("Generando imagen... Esto puede tomar 30-60 segundos");
    
    // Datos del formulario
    const formData = new FormData();
    formData.append("tool_slug", "generador-de-imagenes-ia");
    formData.append("prompt", prompt);
    formData.append("negative_prompt", document.getElementById("negativePrompt").value);
    formData.append("style", currentStyle);
    formData.append("aspect_ratio", document.getElementById("aspectRatioSelect").value);
    formData.append("quality", document.getElementById("qualityRange").value);
    formData.append("creativity", document.getElementById("creativityRange").value);
    formData.append("steps", document.getElementById("stepsRange").value);
    formData.append("seed", document.getElementById("seedInput").value);
    
    if (window.toolConfig.isPremium) {
        formData.append("num_images", document.getElementById("numImagesSelect").value);
    }
    
    // Simular delay de generación
    setTimeout(() => {
        hideLoading();
        isGenerating = false;
        generateBtn.disabled = false;
        generateBtn.innerHTML = "<i class=\"fas fa-magic\"></i> Generar Imagen";
        
        // Simular resultado exitoso (en producción esto vendría del servidor)
        const numImages = window.toolConfig.isPremium ? 
            parseInt(document.getElementById("numImagesSelect").value) : 1;
        
        for (let i = 0; i < numImages; i++) {
            setTimeout(() => {
                const imageUrl = `https://picsum.photos/512/512?random=${Date.now() + i}`;
                showImageResult(imageUrl, prompt);
            }, i * 300);
        }
        
        generatedCount++;
        updateStats();
        
    }, 3000);
}

function showImageResult(imageUrl, prompt) {
    const canvasArea = document.getElementById("canvasArea");
    const resultsContainer = document.getElementById("imageResults");
    const gallery = document.getElementById("imageGallery");
    
    // Mostrar en canvas (primera imagen)
    if (!canvasArea.classList.contains("has-content")) {
        canvasArea.innerHTML = `
            <div class="canvas-content fade-in-up">
                <img src="${imageUrl}" alt="Imagen generada" class="canvas-content">
            </div>
        `;
        canvasArea.classList.add("has-content");
    }
    
    // Agregar a galería
    const imageId = Date.now() + Math.random();
    const imageItem = document.createElement("div");
    imageItem.className = "image-item fade-in-up";
    imageItem.dataset.imageId = imageId;
    imageItem.innerHTML = `
        <img src="${imageUrl}" alt="Imagen generada" loading="lazy">
        <div class="image-overlay">
            <div class="image-actions">
                <button class="btn btn-sm btn-primary" onclick="downloadImage(\'${imageUrl}\', \'${imageId}\')" title="Descargar">
                    <i class="fas fa-download"></i>
                </button>
                <button class="btn btn-sm btn-secondary" onclick="shareImage(\'${imageUrl}\')" title="Compartir">
                    <i class="fas fa-share"></i>
                </button>
                <button class="btn btn-sm btn-accent" onclick="toggleImageSelection(\'${imageId}\')" title="Seleccionar">
                    <i class="fas fa-check"></i>
                </button>
                <button class="btn btn-sm btn-ghost" onclick="removeImage(\'${imageId}\')" title="Eliminar">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
            <div class="image-info">
                <small class="text-truncate">${prompt.substring(0, 30)}...</small>
            </div>
        </div>
        <div class="image-selection-indicator" style="display: none;">
            <i class="fas fa-check-circle"></i>
        </div>
    `;
    
    gallery.insertBefore(imageItem, gallery.firstChild);
    resultsContainer.style.display = "block";
    
    // Actualizar contador
    updateImageCount();
    
    // Scroll suave a resultados
    setTimeout(() => {
        resultsContainer.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 300);
}

function clearImageForm() {
    document.getElementById("imagePrompt").value = "";
    document.getElementById("negativePrompt").value = "";
    document.getElementById("seedInput").value = "";
    updateCharCount();
    
    // Reset canvas
    const canvasArea = document.getElementById("canvasArea");
    canvasArea.classList.remove("has-content");
    canvasArea.innerHTML = `
        <div class="canvas-placeholder">
            <i class="fas fa-image fa-4x mb-4 pulse"></i>
            <h3>Área de Vista Previa</h3>
            <p class="text-muted">Las imágenes generadas aparecerán aquí</p>
            <div class="mt-4">
                <div class="flex gap-md justify-center">
                    <div class="stat-item">
                        <span class="stat-number" id="totalGenerated">${generatedCount}</span>
                        <span class="stat-label">Generadas</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number" id="remainingCredits">${window.toolConfig.isPremium ? "∞" : Math.max(0, 5 - generatedCount)}</span>
                        <span class="stat-label">Restantes</span>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function regenerateImages() {
    if (!document.getElementById("imagePrompt").value.trim()) {
        showAlert("Necesitas un prompt para regenerar", "warning");
        return;
    }
    generateImage();
}

function downloadImage(url, imageId) {
    const a = document.createElement("a");
    a.href = url;
    a.download = `obelisia_imagen_${imageId}.png`;
    a.click();
    showAlert("Descarga iniciada", "success");
}

function downloadSelected() {
    if (selectedImages.size === 0) {
        showAlert("Selecciona al menos una imagen", "warning");
        return;
    }
    
    selectedImages.forEach(imageId => {
        const imageElement = document.querySelector(`[data-image-id="${imageId}"] img`);
        if (imageElement) {
            setTimeout(() => downloadImage(imageElement.src, imageId), 100);
        }
    });
    
    showAlert(`Descargando ${selectedImages.size} imágenes`, "success");
}

function shareImage(url) {
    if (navigator.share) {
        navigator.share({
            title: "Imagen generada con ObelisIA",
            url: url
        });
    } else {
        navigator.clipboard.writeText(url).then(() => {
            showAlert("URL copiada al portapapeles", "success");
        });
    }
}

function toggleImageSelection(imageId) {
    const imageItem = document.querySelector(`[data-image-id="${imageId}"]`);
    const indicator = imageItem.querySelector(".image-selection-indicator");
    
    if (selectedImages.has(imageId)) {
        selectedImages.delete(imageId);
        imageItem.classList.remove("selected");
        indicator.style.display = "none";
    } else {
        selectedImages.add(imageId);
        imageItem.classList.add("selected");
        indicator.style.display = "block";
    }
    
    updateSelectionUI();
}

function selectAllImages() {
    const imageItems = document.querySelectorAll(".image-item");
    imageItems.forEach(item => {
        const imageId = item.dataset.imageId;
        if (imageId) {
            selectedImages.add(imageId);
            item.classList.add("selected");
            item.querySelector(".image-selection-indicator").style.display = "block";
        }
    });
    updateSelectionUI();
}

function removeImage(imageId) {
    if (confirm("¿Estás seguro de que quieres eliminar esta imagen?")) {
        const imageItem = document.querySelector(`[data-image-id="${imageId}"]`);
        imageItem.remove();
        selectedImages.delete(imageId);
        updateImageCount();
        updateSelectionUI();
        showAlert("Imagen eliminada", "info");
    }
}

function generateRandomSeed() {
    const seed = Math.floor(Math.random() * 4294967295);
    document.getElementById("seedInput").value = seed;
}

function useRandomPrompt() {
    const categories = Object.keys(promptSuggestions);
    const randomCategory = categories[Math.floor(Math.random() * categories.length)];
    const prompts = promptSuggestions[randomCategory];
    const randomPrompt = prompts[Math.floor(Math.random() * prompts.length)];
    
    document.getElementById("imagePrompt").value = randomPrompt;
    updateCharCount();
    showAlert("Prompt de inspiración aplicado", "info");
}

function updateStats() {
    document.getElementById("totalGenerated").textContent = generatedCount;
    document.getElementById("remainingCredits").textContent = 
        window.toolConfig.isPremium ? "∞" : Math.max(0, 5 - generatedCount);
}

function updateImageCount() {
    const count = document.querySelectorAll(".image-item").length;
    document.getElementById("imageCount").textContent = count;
}

function updateSelectionUI() {
    const selectedCount = selectedImages.size;
    const downloadBtn = document.querySelector("[onclick=\"downloadSelected()\"]");
    const selectAllBtn = document.querySelector("[onclick=\"selectAllImages()\"]");
    
    if (downloadBtn) {
        downloadBtn.textContent = selectedCount > 0 ? 
            `Descargar (${selectedCount})` : "Descargar Seleccionadas";
    }
}

function showAlert(message, type = "info") {
    // Crear alert temporal
    const alert = document.createElement("div");
    alert.className = `alert alert-${type} position-fixed top-0 end-0 m-3`;
    alert.style.zIndex = "9999";
    alert.innerHTML = `
        <i class="fas fa-${type === "success" ? "check" : type === "warning" ? "exclamation-triangle" : "info-circle"}"></i>
        ${message}
    `;
    
    document.body.appendChild(alert);
    
    setTimeout(() => {
        alert.remove();
    }, 3000);
}

function loadPromptSuggestions() {
    const container = document.getElementById("suggestedPrompts");
    container.innerHTML = "";
    
    Object.entries(promptSuggestions).forEach(([category, prompts]) => {
        prompts.slice(0, 2).forEach(prompt => {
            const option = document.createElement("div");
            option.className = "option-card";
            option.innerHTML = `
                <div class="option-title">
                    <i class="fas fa-${category === "landscape" ? "mountain" : 
                                      category === "portrait" ? "user" :
                                      category === "fantasy" ? "dragon" : "rocket"}"></i>
                    ${category.charAt(0).toUpperCase() + category.slice(1)}
                </div>
                <div class="option-description">${prompt}</div>
            `;
            
            option.addEventListener("click", () => {
                document.getElementById("imagePrompt").value = prompt;
                updateCharCount();
                showAlert("Prompt aplicado", "success");
            });
            
            container.appendChild(option);
        });
    });
}

// Event listeners
document.addEventListener("DOMContentLoaded", function() {
    // Style selector
    document.querySelectorAll(".style-option").forEach(option => {
        option.addEventListener("click", function() {
            document.querySelectorAll(".style-option").forEach(o => o.classList.remove("selected"));
            this.classList.add("selected");
            currentStyle = this.dataset.style;
        });
    });
    
    // Range inputs
    const ranges = [
        { id: "qualityRange", valueId: "qualityValue", hasLabels: true },
        { id: "creativityRange", valueId: "creativityValue" },
        { id: "stepsRange", valueId: "stepsValue" }
    ];
    
    ranges.forEach(range => {
        const input = document.getElementById(range.id);
        const valueSpan = document.getElementById(range.valueId);
        
        if (input && valueSpan) {
            input.addEventListener("input", function() {
                if (range.hasLabels) {
                    const labels = JSON.parse(this.dataset.labels);
                    valueSpan.textContent = labels[this.value - 1];
                } else {
                    valueSpan.textContent = this.value;
                }
            });
        }
    });
    
    // Character counter
    const imagePrompt = document.getElementById("imagePrompt");
    imagePrompt.addEventListener("input", updateCharCount);
    
    // Keyboard shortcuts
    document.addEventListener("keydown", function(e) {
        if (e.ctrlKey && e.key === "Enter") {
            generateImage();
        }
        if (e.key === "Escape" && isGenerating) {
            // Implementar cancelación si es necesario
        }
    });
    
    // Seleccionar primer estilo por defecto
    document.querySelector(".style-option").click();
    
    // Cargar sugerencias de prompts
    loadPromptSuggestions();
    
    // Inicializar stats
    updateStats();
    
    // Auto-resize textarea
    imagePrompt.addEventListener("input", function() {
        this.style.height = "auto";
        this.style.height = Math.min(this.scrollHeight, 200) + "px";
    });
});

function updateCharCount() {
    const textarea = document.getElementById("imagePrompt");
    const counter = document.getElementById("charCount");
    if (textarea && counter) {
        counter.textContent = textarea.value.length;
        
        // Cambiar color según longitud
        const length = textarea.value.length;
        if (length > 1800) {
            counter.style.color = "var(--danger-color)";
        } else if (length > 1500) {
            counter.style.color = "var(--warning-color)";
        } else {
            counter.style.color = "var(--text-muted)";
        }
    }
}
';

// Incluir el template base
include 'base_template.php';
