<?php
// src/Tools/views/NEW_ColorPaletteGenerator_view.php
use ObelisIA\Utils\Premium;

// Configuración de la herramienta
$tool_name = "Generador de Paletas";
$tool_icon = "palette";
$tool_description = "Crea paletas de colores profesionales con IA";
$tool_slug = "color-palette-generator";
$is_premium = Premium::isPremium();
$show_history = true;
$show_export_button = true;
$show_save_button = true;

// Contenido del sidebar
$sidebar_content = '
<div class="sidebar-section">
    <div class="sidebar-header">
        <i class="fas fa-palette"></i> Método de Generación
    </div>
    <div class="sidebar-content">
        <div class="generation-methods">
            <label class="method-option">
                <input type="radio" name="method" value="ai" checked onchange="changeGenerationMethod()">
                <div class="method-card">
                    <i class="fas fa-magic"></i>
                    <span>IA Automática</span>
                </div>
            </label>
            <label class="method-option">
                <input type="radio" name="method" value="image" onchange="changeGenerationMethod()">
                <div class="method-card">
                    <i class="fas fa-image"></i>
                    <span>Desde Imagen</span>
                </div>
            </label>
            <label class="method-option">
                <input type="radio" name="method" value="color" onchange="changeGenerationMethod()">
                <div class="method-card">
                    <i class="fas fa-eyedropper"></i>
                    <span>Color Base</span>
                </div>
            </label>
            <label class="method-option">
                <input type="radio" name="method" value="harmony" onchange="changeGenerationMethod()">
                <div class="method-card">
                    <i class="fas fa-adjust"></i>
                    <span>Armonía</span>
                </div>
            </label>
        </div>
    </div>
</div>

<div class="sidebar-section" id="aiSection">
    <div class="sidebar-header">
        <i class="fas fa-magic"></i> Configuración IA
    </div>
    <div class="sidebar-content">
        <div class="form-group mb-3">
            <label class="form-label">Estilo</label>
            <select class="form-control" id="aiStyle">
                <option value="modern">Moderno</option>
                <option value="vintage">Vintage</option>
                <option value="nature">Natural</option>
                <option value="corporate">Corporativo</option>
                <option value="creative">Creativo</option>
                <option value="minimal">Minimalista</option>
                <option value="vibrant">Vibrante</option>
                <option value="monochrome">Monocromático</option>
            </select>
        </div>
        
        <div class="form-group mb-3">
            <label class="form-label">Mood</label>
            <select class="form-control" id="aiMood">
                <option value="energetic">Energético</option>
                <option value="calm">Calmado</option>
                <option value="professional">Profesional</option>
                <option value="playful">Divertido</option>
                <option value="elegant">Elegante</option>
                <option value="bold">Audaz</option>
                <option value="soft">Suave</option>
                <option value="warm">Cálido</option>
                <option value="cool">Frío</option>
            </select>
        </div>
        
        <div class="form-group">
            <label class="form-label">Número de Colores</label>
            <select class="form-control" id="colorCount">
                <option value="3">3 colores</option>
                <option value="4">4 colores</option>
                <option value="5" selected>5 colores</option>
                <option value="6">6 colores</option>
                ' . ($is_premium ? '<option value="8">8 colores (Premium)</option>
                <option value="10">10 colores (Premium)</option>' : '') . '
            </select>
        </div>
    </div>
</div>

<div class="sidebar-section" id="imageSection" style="display: none;">
    <div class="sidebar-header">
        <i class="fas fa-image"></i> Subir Imagen
    </div>
    <div class="sidebar-content">
        <div class="image-upload-area" onclick="uploadImage()">
            <i class="fas fa-cloud-upload-alt fa-2x mb-2"></i>
            <p>Haz clic para subir una imagen</p>
            <small class="text-muted">JPG, PNG hasta 5MB</small>
        </div>
        <div class="uploaded-image" id="uploadedImagePreview" style="display: none;">
            <img id="previewImage" alt="Preview">
            <button class="btn btn-sm btn-danger" onclick="removeImage()">
                <i class="fas fa-trash"></i>
            </button>
        </div>
        
        <div class="form-group mt-3">
            <label class="form-label">Método de Extracción</label>
            <select class="form-control" id="extractionMethod">
                <option value="dominant">Colores Dominantes</option>
                <option value="vibrant">Más Vibrantes</option>
                <option value="muted">Más Apagados</option>
                <option value="average">Promedio de Zonas</option>
            </select>
        </div>
    </div>
</div>

<div class="sidebar-section" id="colorSection" style="display: none;">
    <div class="sidebar-header">
        <i class="fas fa-eyedropper"></i> Color Base
    </div>
    <div class="sidebar-content">
        <div class="form-group mb-3">
            <label class="form-label">Color Principal</label>
            <input type="color" class="form-control form-control-color" id="baseColor" value="#3498db">
        </div>
        
        <div class="form-group">
            <label class="form-label">Tipo de Paleta</label>
            <select class="form-control" id="paletteType">
                <option value="monochromatic">Monocromática</option>
                <option value="analogous">Análoga</option>
                <option value="complementary">Complementaria</option>
                <option value="triadic">Triádica</option>
                <option value="tetradic">Tetrádica</option>
                <option value="split-complementary">Complementaria Dividida</option>
            </select>
        </div>
    </div>
</div>

<div class="sidebar-section" id="harmonySection" style="display: none;">
    <div class="sidebar-header">
        <i class="fas fa-adjust"></i> Armonía de Colores
    </div>
    <div class="sidebar-content">
        <div class="harmony-options">
            <label class="harmony-option">
                <input type="radio" name="harmony" value="warm">
                <div class="harmony-preview warm"></div>
                <span>Cálidos</span>
            </label>
            <label class="harmony-option">
                <input type="radio" name="harmony" value="cool">
                <div class="harmony-preview cool"></div>
                <span>Fríos</span>
            </label>
            <label class="harmony-option">
                <input type="radio" name="harmony" value="earth">
                <div class="harmony-preview earth"></div>
                <span>Tierra</span>
            </label>
            <label class="harmony-option">
                <input type="radio" name="harmony" value="pastel">
                <div class="harmony-preview pastel"></div>
                <span>Pastel</span>
            </label>
        </div>
        
        <div class="form-group mt-3">
            <label class="form-label">Saturación</label>
            <input type="range" class="form-control-range" min="20" max="100" value="70" id="saturation">
            <div class="range-labels">
                <span>Apagado</span>
                <span>Vibrante</span>
            </div>
        </div>
        
        <div class="form-group">
            <label class="form-label">Luminosidad</label>
            <input type="range" class="form-control-range" min="20" max="80" value="50" id="lightness">
            <div class="range-labels">
                <span>Oscuro</span>
                <span>Claro</span>
            </div>
        </div>
    </div>
</div>

' . ($is_premium ? '
<div class="sidebar-section">
    <div class="sidebar-header">
        <i class="fas fa-crown"></i> Premium
    </div>
    <div class="sidebar-content">
        <div class="premium-features">
            <button class="btn btn-sm btn-accent w-100 mb-2" onclick="generateAdvancedPalette()">
                <i class="fas fa-magic"></i> Paleta IA Avanzada
            </button>
            <button class="btn btn-sm btn-accent w-100 mb-2" onclick="analyzeAccessibility()">
                <i class="fas fa-universal-access"></i> Análisis Accesibilidad
            </button>
            <button class="btn btn-sm btn-accent w-100" onclick="generateBrandPalette()">
                <i class="fas fa-stamp"></i> Paleta de Marca
            </button>
        </div>
    </div>
</div>
' : '
<div class="premium-feature">
    <div class="premium-badge">PRO</div>
    <div class="sidebar-content">
        <div class="text-muted">
            <p><i class="fas fa-magic"></i> IA Avanzada</p>
            <p><i class="fas fa-palette"></i> Hasta 20 colores</p>
            <p><i class="fas fa-universal-access"></i> Análisis de accesibilidad</p>
        </div>
    </div>
</div>
');

// Contenido de la toolbar
$toolbar_content = '
<div class="toolbar-section">
    <button class="btn btn-sm btn-primary" onclick="generatePalette()">
        <i class="fas fa-magic"></i> Generar
    </button>
    <button class="btn btn-sm btn-outline" onclick="randomizePalette()">
        <i class="fas fa-random"></i> Aleatorio
    </button>
</div>

<div class="toolbar-divider"></div>

<div class="toolbar-section">
    <button class="btn btn-sm btn-ghost" onclick="copyPaletteHex()">
        <i class="fas fa-copy"></i> Copiar HEX
    </button>
    <button class="btn btn-sm btn-ghost" onclick="copyPaletteRGB()">
        <i class="fas fa-copy"></i> Copiar RGB
    </button>
</div>

<div class="toolbar-divider"></div>

<div class="toolbar-section">
    <select class="form-control form-control-sm" id="viewMode" onchange="changeViewMode()">
        <option value="grid">Vista Cuadrícula</option>
        <option value="list">Vista Lista</option>
        <option value="swatch">Vista Muestras</option>
        <option value="gradient">Vista Degradado</option>
    </select>
</div>';

// Contenido principal
$main_content = '
<div class="color-palette-container">
    ' . ($is_premium ? '<div class="alert alert-success mb-4">
        <i class="fas fa-crown"></i>
        <strong>¡Usuario Premium!</strong> Accede a IA avanzada, análisis de accesibilidad y paletas de hasta 20 colores.
    </div>' : '') . '
    
    <!-- Paleta principal -->
    <div class="main-palette-container">
        <div class="palette-header">
            <h3><i class="fas fa-palette"></i> Paleta Generada</h3>
            <div class="palette-actions">
                <button class="btn btn-sm btn-outline" onclick="favoritePalette()">
                    <i class="fas fa-heart"></i>
                </button>
                <button class="btn btn-sm btn-outline" onclick="sharePalette()">
                    <i class="fas fa-share"></i>
                </button>
            </div>
        </div>
        
        <div class="palette-display" id="paletteDisplay">
            <div class="empty-palette">
                <i class="fas fa-palette fa-3x text-muted mb-3"></i>
                <p class="text-muted">Genera una paleta para comenzar</p>
            </div>
        </div>
        
        <!-- Información de colores -->
        <div class="color-info-panel" id="colorInfoPanel" style="display: none;">
            <div class="color-details">
                <div class="selected-color-preview" id="selectedColorPreview"></div>
                <div class="color-values" id="colorValues">
                    <!-- Valores del color seleccionado -->
                </div>
            </div>
            
            <div class="color-variations" id="colorVariations">
                <!-- Variaciones del color seleccionado -->
            </div>
        </div>
    </div>
    
    <!-- Paletas sugeridas -->
    <div class="suggestions-container">
        <div class="suggestions-header">
            <h4><i class="fas fa-lightbulb"></i> Paletas Sugeridas</h4>
            <button class="btn btn-sm btn-ghost" onclick="refreshSuggestions()">
                <i class="fas fa-sync"></i>
            </button>
        </div>
        
        <div class="suggestions-grid" id="suggestionsGrid">
            <!-- Paletas sugeridas se cargan aquí -->
        </div>
    </div>
    
    <!-- Historial de paletas -->
    <div class="history-container">
        <div class="history-header">
            <h4><i class="fas fa-history"></i> Historial</h4>
            <button class="btn btn-sm btn-ghost" onclick="clearHistory()">
                <i class="fas fa-trash"></i>
            </button>
        </div>
        
        <div class="history-list" id="historyList">
            <div class="empty-history">
                <i class="fas fa-clock text-muted mb-2"></i>
                <p class="text-muted">No hay paletas en el historial</p>
            </div>
        </div>
    </div>
</div>

<!-- Modal de exportación -->
<div class="modal" id="exportModal" style="display: none;">
    <div class="modal-overlay" onclick="closeExportModal()"></div>
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-download"></i> Exportar Paleta</h3>
            <button class="btn btn-ghost" onclick="closeExportModal()">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="modal-body">
            <div class="export-formats">
                <h5>Formato de Exportación</h5>
                <div class="format-options">
                    <label class="format-option">
                        <input type="radio" name="exportFormat" value="ase" checked>
                        <span>Adobe Swatch (.ase)</span>
                    </label>
                    <label class="format-option">
                        <input type="radio" name="exportFormat" value="aco">
                        <span>Adobe Color (.aco)</span>
                    </label>
                    <label class="format-option">
                        <input type="radio" name="exportFormat" value="css">
                        <span>CSS Variables</span>
                    </label>
                    <label class="format-option">
                        <input type="radio" name="exportFormat" value="json">
                        <span>JSON</span>
                    </label>
                    <label class="format-option">
                        <input type="radio" name="exportFormat" value="png">
                        <span>Imagen PNG</span>
                    </label>
                </div>
                
                <div class="export-options mt-3">
                    <label class="checkbox-option">
                        <input type="checkbox" id="includeNames" checked>
                        <span>Incluir nombres de colores</span>
                    </label>
                    <label class="checkbox-option">
                        <input type="checkbox" id="includeValues">
                        <span>Incluir valores HEX/RGB</span>
                    </label>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeExportModal()">
                Cancelar
            </button>
            <button class="btn btn-primary" onclick="startExport()">
                <i class="fas fa-download"></i>
                Exportar
            </button>
        </div>
    </div>
</div>';

// Contenido de ayuda
$help_content = '
<div class="help-section">
    <h4><i class="fas fa-palette"></i> Cómo generar paletas de colores</h4>
    <ol>
        <li><strong>Elige el método:</strong> IA automática, desde imagen, color base o armonía</li>
        <li><strong>Configura parámetros:</strong> Estilo, mood, número de colores</li>
        <li><strong>Genera la paleta:</strong> Haz clic en "Generar" para crear tu paleta</li>
        <li><strong>Explora variaciones:</strong> Haz clic en cualquier color para ver variaciones</li>
        <li><strong>Copia valores:</strong> Usa los botones para copiar códigos HEX o RGB</li>
        <li><strong>Exporta:</strong> Descarga la paleta en el formato que necesites</li>
    </ol>
    
    <h5><i class="fas fa-magic"></i> Métodos de Generación:</h5>
    <ul>
        <li><strong>IA Automática:</strong> La inteligencia artificial crea paletas basadas en estilo y mood</li>
        <li><strong>Desde Imagen:</strong> Extrae colores dominantes de una imagen subida</li>
        <li><strong>Color Base:</strong> Genera paletas armónicas desde un color específico</li>
        <li><strong>Armonía:</strong> Crea paletas usando teoría del color tradicional</li>
    </ul>
    
    <h5><i class="fas fa-crown"></i> Funciones Premium:</h5>
    <ul>
        <li>IA avanzada con algoritmos mejorados</li>
        <li>Paletas de hasta 20 colores</li>
        <li>Análisis de accesibilidad (WCAG)</li>
        <li>Generación de paletas de marca</li>
        <li>Exportación a formatos profesionales</li>
    </ul>
    
    <h5><i class="fas fa-lightbulb"></i> Consejos:</h5>
    <ul>
        <li>Usa paletas monocromáticas para diseños elegantes</li>
        <li>Las paletas complementarias crean contraste dramático</li>
        <li>Las paletas análogas son armónicas y relajantes</li>
        <li>Siempre verifica la accesibilidad para texto</li>
    </ul>
</div>';

// JavaScript específico
$inline_js = '
let currentPalette = [];
let paletteHistory = [];
let selectedColor = null;
let currentMethod = "ai";

// Colores predefinidos para sugerencias
const suggestedPalettes = [
    { name: "Ocean Breeze", colors: ["#006994", "#0085C3", "#00A8CC", "#7DD3FC", "#B8E6FF"] },
    { name: "Sunset Glow", colors: ["#FF6B35", "#F7931E", "#FFD23F", "#06FFA5", "#118AB2"] },
    { name: "Forest Deep", colors: ["#2D5016", "#3A5F2A", "#607D3B", "#A4AC86", "#C6D57E"] },
    { name: "Royal Purple", colors: ["#4C0070", "#7209B7", "#A663CC", "#CD93FF", "#E5CCFF"] },
    { name: "Minimal Gray", colors: ["#212121", "#424242", "#757575", "#BDBDBD", "#F5F5F5"] }
];

// Inicializar generador de paletas
function initializePaletteGenerator() {
    loadSuggestions();
    loadHistory();
    changeGenerationMethod();
    showAlert("Generador de paletas listo", "success");
}

// Cambio de método de generación
function changeGenerationMethod() {
    const method = document.querySelector("input[name=\"method\"]:checked").value;
    currentMethod = method;
    
    // Ocultar todas las secciones
    document.getElementById("aiSection").style.display = "none";
    document.getElementById("imageSection").style.display = "none";
    document.getElementById("colorSection").style.display = "none";
    document.getElementById("harmonySection").style.display = "none";
    
    // Mostrar sección correspondiente
    switch (method) {
        case "ai":
            document.getElementById("aiSection").style.display = "block";
            break;
        case "image":
            document.getElementById("imageSection").style.display = "block";
            break;
        case "color":
            document.getElementById("colorSection").style.display = "block";
            break;
        case "harmony":
            document.getElementById("harmonySection").style.display = "block";
            break;
    }
}

// Generación de paletas
function generatePalette() {
    switch (currentMethod) {
        case "ai":
            generateAIPalette();
            break;
        case "image":
            generateImagePalette();
            break;
        case "color":
            generateColorBasedPalette();
            break;
        case "harmony":
            generateHarmonyPalette();
            break;
    }
}

function generateAIPalette() {
    const style = document.getElementById("aiStyle").value;
    const mood = document.getElementById("aiMood").value;
    const count = parseInt(document.getElementById("colorCount").value);
    
    showAlert("Generando paleta con IA...", "info");
    
    // Simular generación IA
    setTimeout(() => {
        currentPalette = generatePaletteByStyle(style, mood, count);
        displayPalette(currentPalette);
        addToHistory(currentPalette, `IA: ${style} - ${mood}`);
        showAlert("¡Paleta generada con IA!", "success");
    }, 1500);
}

function generateImagePalette() {
    const imagePreview = document.getElementById("previewImage");
    if (!imagePreview.src) {
        showAlert("Sube una imagen primero", "warning");
        return;
    }
    
    const method = document.getElementById("extractionMethod").value;
    showAlert("Extrayendo colores de la imagen...", "info");
    
    // Simular extracción de colores
    setTimeout(() => {
        currentPalette = extractColorsFromImage(imagePreview, method);
        displayPalette(currentPalette);
        addToHistory(currentPalette, `Imagen: ${method}`);
        showAlert("¡Colores extraídos de la imagen!", "success");
    }, 2000);
}

function generateColorBasedPalette() {
    const baseColor = document.getElementById("baseColor").value;
    const type = document.getElementById("paletteType").value;
    
    showAlert("Generando paleta basada en color...", "info");
    
    setTimeout(() => {
        currentPalette = generateHarmoniousPalette(baseColor, type);
        displayPalette(currentPalette);
        addToHistory(currentPalette, `Base: ${type}`);
        showAlert("¡Paleta armónica generada!", "success");
    }, 1000);
}

function generateHarmonyPalette() {
    const harmony = document.querySelector("input[name=\"harmony\"]:checked")?.value;
    const saturation = document.getElementById("saturation").value;
    const lightness = document.getElementById("lightness").value;
    
    if (!harmony) {
        showAlert("Selecciona un tipo de armonía", "warning");
        return;
    }
    
    showAlert("Creando armonía de colores...", "info");
    
    setTimeout(() => {
        currentPalette = generateHarmonyColors(harmony, saturation, lightness);
        displayPalette(currentPalette);
        addToHistory(currentPalette, `Armonía: ${harmony}`);
        showAlert("¡Armonía de colores creada!", "success");
    }, 1000);
}

// Algoritmos de generación
function generatePaletteByStyle(style, mood, count) {
    const styleColors = {
        modern: ["#1A1A1A", "#0077BE", "#00A8CC", "#7DD3FC", "#F8F9FA"],
        vintage: ["#8B4513", "#D2691E", "#F4A460", "#DEB887", "#F5DEB3"],
        nature: ["#2D5016", "#228B22", "#32CD32", "#90EE90", "#F0FFF0"],
        corporate: ["#003366", "#0066CC", "#4A90E2", "#87CEEB", "#F0F8FF"],
        creative: ["#FF6B35", "#7209B7", "#00D4AA", "#FFC107", "#FF5722"],
        minimal: ["#000000", "#333333", "#666666", "#CCCCCC", "#FFFFFF"],
        vibrant: ["#FF0080", "#FF4500", "#FFD700", "#00FF7F", "#1E90FF"],
        monochrome: ["#000000", "#404040", "#808080", "#C0C0C0", "#FFFFFF"]
    };
    
    const moodAdjustments = {
        energetic: (colors) => colors.map(c => adjustBrightness(c, 20)),
        calm: (colors) => colors.map(c => adjustSaturation(c, -20)),
        professional: (colors) => colors.map(c => adjustSaturation(c, -10)),
        playful: (colors) => colors.map(c => adjustSaturation(c, 30)),
        elegant: (colors) => colors.map(c => adjustSaturation(c, -15)),
        bold: (colors) => colors.map(c => adjustSaturation(c, 40)),
        soft: (colors) => colors.map(c => adjustBrightness(c, 15)),
        warm: (colors) => colors.map(c => adjustHue(c, 15)),
        cool: (colors) => colors.map(c => adjustHue(c, -15))
    };
    
    let baseColors = styleColors[style] || styleColors.modern;
    baseColors = moodAdjustments[mood] ? moodAdjustments[mood](baseColors) : baseColors;
    
    return baseColors.slice(0, count);
}

function extractColorsFromImage(image, method) {
    // Simular extracción de colores (en implementación real usaría canvas para analizar píxeles)
    const mockColors = [
        ["#2C3E50", "#34495E", "#7F8C8D", "#BDC3C7", "#ECF0F1"], // dominant
        ["#E74C3C", "#F39C12", "#F1C40F", "#2ECC71", "#3498DB"], // vibrant
        ["#95A5A6", "#7F8C8D", "#BDC3C7", "#D5DBDB", "#EAEDED"], // muted
        ["#5D6D7E", "#85929E", "#AEB6BF", "#D5D8DC", "#EBEDEF"]  // average
    ];
    
    const methodIndex = ["dominant", "vibrant", "muted", "average"].indexOf(method);
    return mockColors[methodIndex] || mockColors[0];
}

function generateHarmoniousPalette(baseColor, type) {
    const hsl = hexToHsl(baseColor);
    const colors = [baseColor];
    
    switch (type) {
        case "monochromatic":
            for (let i = 1; i < 5; i++) {
                colors.push(hslToHex(hsl.h, hsl.s, Math.max(10, hsl.l - i * 15)));
            }
            break;
        case "analogous":
            for (let i = 1; i < 5; i++) {
                colors.push(hslToHex((hsl.h + i * 30) % 360, hsl.s, hsl.l));
            }
            break;
        case "complementary":
            colors.push(hslToHex((hsl.h + 180) % 360, hsl.s, hsl.l));
            colors.push(hslToHex(hsl.h, hsl.s * 0.8, hsl.l + 20));
            colors.push(hslToHex((hsl.h + 180) % 360, hsl.s * 0.8, hsl.l + 20));
            colors.push(hslToHex(hsl.h, hsl.s * 0.5, hsl.l + 40));
            break;
        case "triadic":
            colors.push(hslToHex((hsl.h + 120) % 360, hsl.s, hsl.l));
            colors.push(hslToHex((hsl.h + 240) % 360, hsl.s, hsl.l));
            colors.push(hslToHex(hsl.h, hsl.s * 0.7, hsl.l + 20));
            colors.push(hslToHex((hsl.h + 120) % 360, hsl.s * 0.7, hsl.l + 20));
            break;
    }
    
    return colors;
}

function generateHarmonyColors(harmony, saturation, lightness) {
    const baseHues = {
        warm: [0, 30, 60, 90, 120],
        cool: [180, 210, 240, 270, 300],
        earth: [30, 45, 60, 75, 90],
        pastel: [0, 60, 120, 180, 240]
    };
    
    const hues = baseHues[harmony] || baseHues.warm;
    return hues.map(hue => hslToHex(hue, saturation, lightness));
}

// Mostrar paleta
function displayPalette(palette) {
    const display = document.getElementById("paletteDisplay");
    const viewMode = document.getElementById("viewMode").value;
    
    display.innerHTML = "";
    
    switch (viewMode) {
        case "grid":
            displayGridView(palette, display);
            break;
        case "list":
            displayListView(palette, display);
            break;
        case "swatch":
            displaySwatchView(palette, display);
            break;
        case "gradient":
            displayGradientView(palette, display);
            break;
    }
}

function displayGridView(palette, container) {
    const grid = document.createElement("div");
    grid.className = "palette-grid";
    
    palette.forEach((color, index) => {
        const colorCard = document.createElement("div");
        colorCard.className = "color-card";
        colorCard.style.backgroundColor = color;
        colorCard.innerHTML = `
            <div class="color-overlay">
                <div class="color-actions">
                    <button class="btn btn-sm btn-ghost" onclick="copyColor(\'${color}\')">
                        <i class="fas fa-copy"></i>
                    </button>
                    <button class="btn btn-sm btn-ghost" onclick="selectColor(\'${color}\', ${index})">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn btn-sm btn-ghost" onclick="favoriteColor(\'${color}\')">
                        <i class="fas fa-heart"></i>
                    </button>
                </div>
            </div>
            <div class="color-label">
                <span class="color-hex">${color.toUpperCase()}</span>
            </div>
        `;
        
        colorCard.addEventListener("click", () => selectColor(color, index));
        grid.appendChild(colorCard);
    });
    
    container.appendChild(grid);
}

function displayListView(palette, container) {
    const list = document.createElement("div");
    list.className = "palette-list";
    
    palette.forEach((color, index) => {
        const rgb = hexToRgb(color);
        const hsl = hexToHsl(color);
        
        const listItem = document.createElement("div");
        listItem.className = "color-list-item";
        listItem.innerHTML = `
            <div class="color-swatch" style="background-color: ${color}"></div>
            <div class="color-info">
                <div class="color-name">Color ${index + 1}</div>
                <div class="color-values">
                    <span class="color-value">HEX: ${color.toUpperCase()}</span>
                    <span class="color-value">RGB: ${rgb.r}, ${rgb.g}, ${rgb.b}</span>
                    <span class="color-value">HSL: ${Math.round(hsl.h)}°, ${Math.round(hsl.s)}%, ${Math.round(hsl.l)}%</span>
                </div>
            </div>
            <div class="color-actions">
                <button class="btn btn-sm btn-outline" onclick="copyColor(\'${color}\')">
                    <i class="fas fa-copy"></i>
                </button>
            </div>
        `;
        
        listItem.addEventListener("click", () => selectColor(color, index));
        list.appendChild(listItem);
    });
    
    container.appendChild(list);
}

function displaySwatchView(palette, container) {
    const swatches = document.createElement("div");
    swatches.className = "palette-swatches";
    
    palette.forEach((color, index) => {
        const swatch = document.createElement("div");
        swatch.className = "color-swatch-large";
        swatch.style.backgroundColor = color;
        swatch.title = color.toUpperCase();
        swatch.addEventListener("click", () => selectColor(color, index));
        swatches.appendChild(swatch);
    });
    
    container.appendChild(swatches);
}

function displayGradientView(palette, container) {
    const gradient = document.createElement("div");
    gradient.className = "palette-gradient";
    
    const gradientString = `linear-gradient(90deg, ${palette.join(", ")})`;
    gradient.style.background = gradientString;
    
    const gradientInfo = document.createElement("div");
    gradientInfo.className = "gradient-info";
    gradientInfo.innerHTML = `
        <div class="gradient-code">
            <label>CSS Gradient:</label>
            <input type="text" class="form-control" value="${gradientString}" readonly onclick="this.select()">
        </div>
    `;
    
    container.appendChild(gradient);
    container.appendChild(gradientInfo);
}

// Selección de color
function selectColor(color, index) {
    selectedColor = { color, index };
    showColorInfo(color);
    generateColorVariations(color);
}

function showColorInfo(color) {
    const panel = document.getElementById("colorInfoPanel");
    const preview = document.getElementById("selectedColorPreview");
    const values = document.getElementById("colorValues");
    
    preview.style.backgroundColor = color;
    
    const rgb = hexToRgb(color);
    const hsl = hexToHsl(color);
    const cmyk = rgbToCmyk(rgb.r, rgb.g, rgb.b);
    
    values.innerHTML = `
        <div class="value-group">
            <label>HEX</label>
            <input type="text" class="form-control form-control-sm" value="${color.toUpperCase()}" readonly onclick="this.select()">
        </div>
        <div class="value-group">
            <label>RGB</label>
            <input type="text" class="form-control form-control-sm" value="${rgb.r}, ${rgb.g}, ${rgb.b}" readonly onclick="this.select()">
        </div>
        <div class="value-group">
            <label>HSL</label>
            <input type="text" class="form-control form-control-sm" value="${Math.round(hsl.h)}°, ${Math.round(hsl.s)}%, ${Math.round(hsl.l)}%" readonly onclick="this.select()">
        </div>
        <div class="value-group">
            <label>CMYK</label>
            <input type="text" class="form-control form-control-sm" value="${cmyk.c}%, ${cmyk.m}%, ${cmyk.y}%, ${cmyk.k}%" readonly onclick="this.select()">
        </div>
    `;
    
    panel.style.display = "block";
}

function generateColorVariations(color) {
    const variations = document.getElementById("colorVariations");
    const hsl = hexToHsl(color);
    
    const variationTypes = [
        { name: "Tintes", colors: Array.from({length: 5}, (_, i) => hslToHex(hsl.h, hsl.s, Math.min(100, hsl.l + (i + 1) * 10))) },
        { name: "Sombras", colors: Array.from({length: 5}, (_, i) => hslToHex(hsl.h, hsl.s, Math.max(0, hsl.l - (i + 1) * 10))) },
        { name: "Tonos", colors: Array.from({length: 5}, (_, i) => hslToHex(hsl.h, Math.max(0, hsl.s - (i + 1) * 15), hsl.l)) }
    ];
    
    variations.innerHTML = "";
    
    variationTypes.forEach(type => {
        const section = document.createElement("div");
        section.className = "variation-section";
        section.innerHTML = `
            <h6>${type.name}</h6>
            <div class="variation-colors">
                ${type.colors.map(c => `
                    <div class="variation-color" style="background-color: ${c}" 
                         title="${c.toUpperCase()}" onclick="copyColor(\'${c}\')"></div>
                `).join("")}
            </div>
        `;
        variations.appendChild(section);
    });
}

// Utilidades de color
function hexToRgb(hex) {
    const result = /^#?([a-f\\d]{2})([a-f\\d]{2})([a-f\\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}

function hexToHsl(hex) {
    const rgb = hexToRgb(hex);
    const r = rgb.r / 255;
    const g = rgb.g / 255;
    const b = rgb.b / 255;
    
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h, s, l = (max + min) / 2;
    
    if (max === min) {
        h = s = 0;
    } else {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
            case r: h = (g - b) / d + (g < b ? 6 : 0); break;
            case g: h = (b - r) / d + 2; break;
            case b: h = (r - g) / d + 4; break;
        }
        h /= 6;
    }
    
    return { h: h * 360, s: s * 100, l: l * 100 };
}

function hslToHex(h, s, l) {
    h = h % 360;
    s = Math.max(0, Math.min(100, s)) / 100;
    l = Math.max(0, Math.min(100, l)) / 100;
    
    const c = (1 - Math.abs(2 * l - 1)) * s;
    const x = c * (1 - Math.abs((h / 60) % 2 - 1));
    const m = l - c / 2;
    let r = 0, g = 0, b = 0;
    
    if (0 <= h && h < 60) {
        r = c; g = x; b = 0;
    } else if (60 <= h && h < 120) {
        r = x; g = c; b = 0;
    } else if (120 <= h && h < 180) {
        r = 0; g = c; b = x;
    } else if (180 <= h && h < 240) {
        r = 0; g = x; b = c;
    } else if (240 <= h && h < 300) {
        r = x; g = 0; b = c;
    } else if (300 <= h && h < 360) {
        r = c; g = 0; b = x;
    }
    
    r = Math.round((r + m) * 255);
    g = Math.round((g + m) * 255);
    b = Math.round((b + m) * 255);
    
    return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
}

function rgbToCmyk(r, g, b) {
    r = r / 255;
    g = g / 255;
    b = b / 255;
    
    const k = 1 - Math.max(r, Math.max(g, b));
    const c = (1 - r - k) / (1 - k) || 0;
    const m = (1 - g - k) / (1 - k) || 0;
    const y = (1 - b - k) / (1 - k) || 0;
    
    return {
        c: Math.round(c * 100),
        m: Math.round(m * 100),
        y: Math.round(y * 100),
        k: Math.round(k * 100)
    };
}

function adjustBrightness(hex, amount) {
    const hsl = hexToHsl(hex);
    return hslToHex(hsl.h, hsl.s, Math.max(0, Math.min(100, hsl.l + amount)));
}

function adjustSaturation(hex, amount) {
    const hsl = hexToHsl(hex);
    return hslToHex(hsl.h, Math.max(0, Math.min(100, hsl.s + amount)), hsl.l);
}

function adjustHue(hex, amount) {
    const hsl = hexToHsl(hex);
    return hslToHex((hsl.h + amount + 360) % 360, hsl.s, hsl.l);
}

// Acciones
function copyColor(color) {
    navigator.clipboard.writeText(color.toUpperCase()).then(() => {
        showAlert(`Color ${color.toUpperCase()} copiado`, "success");
    });
}

function copyPaletteHex() {
    if (currentPalette.length === 0) {
        showAlert("No hay paleta para copiar", "warning");
        return;
    }
    
    const hexValues = currentPalette.map(c => c.toUpperCase()).join(", ");
    navigator.clipboard.writeText(hexValues).then(() => {
        showAlert("Códigos HEX copiados", "success");
    });
}

function copyPaletteRGB() {
    if (currentPalette.length === 0) {
        showAlert("No hay paleta para copiar", "warning");
        return;
    }
    
    const rgbValues = currentPalette.map(color => {
        const rgb = hexToRgb(color);
        return `rgb(${rgb.r}, ${rgb.g}, ${rgb.b})`;
    }).join(", ");
    
    navigator.clipboard.writeText(rgbValues).then(() => {
        showAlert("Códigos RGB copiados", "success");
    });
}

function randomizePalette() {
    showAlert("Generando paleta aleatoria...", "info");
    
    setTimeout(() => {
        const randomPalette = suggestedPalettes[Math.floor(Math.random() * suggestedPalettes.length)];
        currentPalette = [...randomPalette.colors];
        displayPalette(currentPalette);
        addToHistory(currentPalette, "Aleatorio");
        showAlert("¡Paleta aleatoria generada!", "success");
    }, 500);
}

function changeViewMode() {
    if (currentPalette.length > 0) {
        displayPalette(currentPalette);
    }
}

// Sugerencias y historial
function loadSuggestions() {
    const grid = document.getElementById("suggestionsGrid");
    grid.innerHTML = "";
    
    suggestedPalettes.forEach(palette => {
        const suggestion = document.createElement("div");
        suggestion.className = "suggestion-palette";
        suggestion.innerHTML = `
            <div class="suggestion-colors">
                ${palette.colors.map(color => `
                    <div class="suggestion-color" style="background-color: ${color}"></div>
                `).join("")}
            </div>
            <div class="suggestion-name">${palette.name}</div>
        `;
        
        suggestion.addEventListener("click", () => {
            currentPalette = [...palette.colors];
            displayPalette(currentPalette);
            addToHistory(currentPalette, palette.name);
            showAlert(`Paleta "${palette.name}" aplicada`, "success");
        });
        
        grid.appendChild(suggestion);
    });
}

function loadHistory() {
    const historyList = document.getElementById("historyList");
    
    if (paletteHistory.length === 0) {
        historyList.innerHTML = `
            <div class="empty-history">
                <i class="fas fa-clock text-muted mb-2"></i>
                <p class="text-muted">No hay paletas en el historial</p>
            </div>
        `;
        return;
    }
    
    historyList.innerHTML = "";
    
    paletteHistory.slice(-10).reverse().forEach((item, index) => {
        const historyItem = document.createElement("div");
        historyItem.className = "history-item";
        historyItem.innerHTML = `
            <div class="history-colors">
                ${item.palette.map(color => `
                    <div class="history-color" style="background-color: ${color}"></div>
                `).join("")}
            </div>
            <div class="history-info">
                <div class="history-name">${item.name}</div>
                <div class="history-date">${new Date(item.timestamp).toLocaleString()}</div>
            </div>
        `;
        
        historyItem.addEventListener("click", () => {
            currentPalette = [...item.palette];
            displayPalette(currentPalette);
            showAlert("Paleta del historial aplicada", "success");
        });
        
        historyList.appendChild(historyItem);
    });
}

function addToHistory(palette, name) {
    paletteHistory.push({
        palette: [...palette],
        name: name,
        timestamp: new Date()
    });
    
    loadHistory();
}

function clearHistory() {
    if (confirm("¿Estás seguro de que quieres borrar el historial?")) {
        paletteHistory = [];
        loadHistory();
        showAlert("Historial borrado", "info");
    }
}

// Subida de imagen
function uploadImage() {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    input.onchange = function(e) {
        const file = e.target.files[0];
        if (file) {
            if (file.size > 5 * 1024 * 1024) {
                showAlert("La imagen es muy grande (máx. 5MB)", "warning");
                return;
            }
            
            const reader = new FileReader();
            reader.onload = function(event) {
                const img = document.getElementById("previewImage");
                img.src = event.target.result;
                
                document.getElementById("uploadedImagePreview").style.display = "block";
                showAlert("Imagen cargada correctamente", "success");
            };
            reader.readAsDataURL(file);
        }
    };
    input.click();
}

function removeImage() {
    document.getElementById("uploadedImagePreview").style.display = "none";
    document.getElementById("previewImage").src = "";
}

// Funciones globales requeridas por el template
function generateContent() {
    generatePalette();
}

function saveWork() {
    if (currentPalette.length === 0) {
        showAlert("No hay paleta para guardar", "warning");
        return;
    }
    
    const paletteData = {
        palette: currentPalette,
        method: currentMethod,
        timestamp: new Date(),
        settings: {
            style: document.getElementById("aiStyle")?.value,
            mood: document.getElementById("aiMood")?.value,
            colorCount: document.getElementById("colorCount")?.value
        }
    };
    
    const blob = new Blob([JSON.stringify(paletteData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement("a");
    a.href = url;
    a.download = `palette_${Date.now()}.json`;
    a.click();
    
    URL.revokeObjectURL(url);
    showAlert("Paleta guardada", "success");
}

function exportWork() {
    if (currentPalette.length === 0) {
        showAlert("No hay paleta para exportar", "warning");
        return;
    }
    
    document.getElementById("exportModal").style.display = "flex";
}

function closeExportModal() {
    document.getElementById("exportModal").style.display = "none";
}

function startExport() {
    const format = document.querySelector("input[name=\"exportFormat\"]:checked").value;
    const includeNames = document.getElementById("includeNames").checked;
    const includeValues = document.getElementById("includeValues").checked;
    
    let content = "";
    let fileName = `palette_${Date.now()}`;
    let mimeType = "text/plain";
    
    switch (format) {
        case "css":
            content = generateCSSExport(includeNames, includeValues);
            fileName += ".css";
            mimeType = "text/css";
            break;
        case "json":
            content = generateJSONExport(includeNames, includeValues);
            fileName += ".json";
            mimeType = "application/json";
            break;
        case "png":
            generatePNGExport();
            closeExportModal();
            return;
        default:
            content = generateGenericExport(format, includeNames, includeValues);
            fileName += `.${format}`;
    }
    
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement("a");
    a.href = url;
    a.download = fileName;
    a.click();
    
    URL.revokeObjectURL(url);
    closeExportModal();
    showAlert(`Paleta exportada como ${format.toUpperCase()}`, "success");
}

function generateCSSExport(includeNames, includeValues) {
    let css = ":root {\n";
    currentPalette.forEach((color, index) => {
        css += `  --color-${index + 1}: ${color};\n`;
    });
    css += "}\n";
    return css;
}

function generateJSONExport(includeNames, includeValues) {
    const data = {
        colors: currentPalette.map((color, index) => ({
            name: `Color ${index + 1}`,
            hex: color,
            rgb: hexToRgb(color),
            hsl: hexToHsl(color)
        })),
        metadata: {
            generated: new Date(),
            method: currentMethod,
            count: currentPalette.length
        }
    };
    
    return JSON.stringify(data, null, 2);
}

function generatePNGExport() {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    
    canvas.width = currentPalette.length * 100;
    canvas.height = 100;
    
    currentPalette.forEach((color, index) => {
        ctx.fillStyle = color;
        ctx.fillRect(index * 100, 0, 100, 100);
    });
    
    canvas.toBlob(blob => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `palette_${Date.now()}.png`;
        a.click();
        URL.revokeObjectURL(url);
    });
}

function showAlert(message, type = "info") {
    const alert = document.createElement("div");
    alert.className = `alert alert-${type} position-fixed top-0 end-0 m-3`;
    alert.style.zIndex = "9999";
    alert.innerHTML = `
        <i class="fas fa-${type === "success" ? "check" : type === "warning" ? "exclamation-triangle" : "info-circle"}"></i>
        ${message}
    `;
    
    document.body.appendChild(alert);
    setTimeout(() => alert.remove(), 3000);
}

// Inicializar cuando el DOM esté listo
document.addEventListener("DOMContentLoaded", function() {
    initializePaletteGenerator();
});
';

// Incluir el template base
include 'base_template.php';
