<?php
// src/Tools/views/ImageGenerator_view.php
use ObelisIA\Utils\Premium;
// Mostrar beneficios premium y exponer variable JS global
$isPremium = Premium::isPremium();
?>
<script>
window.isPremiumUser = <?php echo $isPremium ? 'true' : 'false'; ?>;
</script>
<?php if ($isPremium): ?>
<div class="alert alert-success text-center mb-4">
    <i class="fas fa-crown me-2"></i>
    <strong>¡Eres usuario Premium!</strong> Disfruta de generaciones ilimitadas, máxima resolución y sin marca de agua.
</div>
<?php endif; ?>

<link rel="stylesheet" href="<?php echo \ObelisIA\Router\MainRouter::url('assets/css/tools/ia-img/style.css'); ?>">
  
<div class="container-fluid">
    <div class="row">

        <div class="col-lg-3">
            <div class="card bg-light p-3 h-100">
                <h4 class="mb-4"><i class="fas fa-sliders-h text-info me-2"></i>Opciones Avanzadas</h4>
                
                <div class="mb-3">
                    <label for="styleSelect" class="form-label">Estilo de Imagen</label>
                    <select id="styleSelect" class="form-select">
                        <option value="none">Por Defecto</option>
                        <option value="realistic">Realista</option>
                        <option value="cartoon">Dibujo Animado</option>
                        <option value="anime">Anime</option>
                        <option value="digital-art">Arte Digital</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="aspectRatioSelect" class="form-label">Relación de Aspecto</label>
                    <select id="aspectRatioSelect" class="form-select">
                        <option value="1:1">1:1 (Cuadrado)</option>
                        <option value="16:9">16:9 (Horizontal)</option>
                        <option value="9:16">9:16 (Vertical)</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card bg-light p-4 text-center">
                <h1 class="display-5 fw-bold">Generador de Imágenes con <span class="text-info">IA</span></h1>
                <p class="lead text-muted mb-4">Describe la imagen que te gustaría generar.</p>

                <textarea id="promptInput" class="form-control mb-3" rows="3" placeholder="Ej: Un dragón volando sobre un castillo..."></textarea>
                
                <div class="d-flex justify-content-center align-items-center gap-2 mb-3">
                     <select id="toneSelect" class="form-select w-auto">
                        <option value="Neutro">Tono: Neutro</option>
                        <option value="Creativo">Tono: Creativo</option>
                        <option value="Dramático">Tono: Dramático</option>
                    </select>
                    <button id="improvePromptButton" class="btn btn-secondary">Mejorar Prompt</button>
                </div>
                
                  <button id="generateButton" class="btn btn-info btn-lg w-100 mb-2">Generar Imagen</button>
                    <p id="generationCounter" class="text-muted small">Generaciones restantes: --</p>
                  <button id="watchAdButton" class="btn btn-primary btn-sm d-none">Ver Anuncio para +3</button>

                <div id="imageDisplay" class="mt-4">
                    <img id="generatedImage" src="https://placehold.co/512x512/343a40/dee2e6?text=Tu+imagen+aparecerá+aquí" alt="Imagen generada" class="img-fluid rounded shadow">
                      <p id="imagePlaceholderText" class="text-muted mt-2 small">Ingresa una descripción y haz clic en "Generar Imagen".</p>
                    <div class="d-flex justify-content-center gap-5">
                      <div class="justify-content-center">
                          <h4 class="mb-3"><i class="fas fa-download text-info me-2"></i>Descarga Rápida</h4>
                          <button id="downloadMainImageButton" class="btn btn-success w-100">Descargar Imagen</button>
                      </div>
                      <div class="justify-content-center">
                          <h4 class="mb-3"><i class="fas fa-download text-info me-2"></i>Guardar Creación</h4>
                          <button id="saveCreationButton" class="btn btn-info w-100">Guardar Creación</button>
                      </div>
                    </div>
                </div>
              </div>
        </div>

        <div class="col-lg-3">
            <div class="card bg-light p-3 h-100">
                <h4 class="mb-4"><i class="fas fa-history text-info me-2"></i>Historial Reciente</h4>
                <div id="recentGenerationsGallery" class="recent-generations-grid">
                    <p class="text-muted small text-center">Aquí aparecerán tus últimas imágenes.</p>
                </div>
                <hr class="my-4">
                <h4 class="mb-3"><i class="fas fa-download text-info me-2"></i>Descarga Rápida</h4>
                <button id="downloadMainImageButton" class="btn btn-success mt-2 d-none w-100" disabled>Descargar Última Imagen</button>
            </div>
        </div>

        <div class="mt-4">
          <?php 
            $premiumMessage = 'Accede a imágenes en máxima resolución, sin marca de agua, estilos y relaciones de aspecto exclusivos, y prioridad en la generación. ¡Hazte premium y lleva tus creaciones visuales con IA al siguiente nivel!';
            include __DIR__ . '/../../../assets/banners/partials/premium_banner_for_tools.php'; 
          ?>
        </div>

        <div class="col-12">
            <div class="card bg-light p-4">
                 <h2 class="text-center mb-4">Tu Galería de Imágenes</h2>
                 <div class="d-flex justify-content-center flex-wrap gap-2 mb-3">
                    <button id="selectAllButton" class="btn btn-secondary btn-sm">Seleccionar Todo</button>
                    <button id="downloadSelectedButton" class="btn btn-info btn-sm" disabled>Descargar</button>
                    <button id="clearSelectionButton" class="btn btn-secondary btn-sm" disabled>Limpiar</button>
                    <button id="deleteSelectedButton" class="btn btn-danger btn-sm" disabled>Eliminar</button>
                 </div>
                  <div id="localStorageUsage" class="text-center text-muted small mb-3">Uso: --</div>
                <div id="galleryContainer" class="row row-cols-2 row-cols-md-3 row-cols-lg-4 g-3"></div>
            </div>
        </div>

    </div>
</div>

<script type="module" src="<?php echo \ObelisIA\Router\MainRouter::url('assets/js/tools/ia-img/app.js'); ?>"></script>

<!-- Lightbox -->
<div class="modal fade" id="lightbox" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-xl">
    <div class="modal-content bg-transparent border-0">
      
      <button type="button" class="btn-close btn-close-white" id="lightboxCloseButton" data-bs-dismiss="modal" aria-label="Close" style="position: absolute; top: 1rem; right: 1rem; z-index: 2000;"></button>

      <div class="modal-body p-0">
        <div id="lightboxCarousel" class="carousel slide">
          
          <div class="carousel-inner" id="lightboxContent">
            <div class="carousel-item active">
              <img src="..." class="d-block w-100" alt="Imagen en grande del lightbox" id="lightboxImage">
            </div>
            </div>

          <button class="carousel-control-prev" type="button" id="lightboxPrevButton">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next" type="button" id="lightboxNextButton">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>

          <div class="carousel-indicators" id="lightboxThumbnails" style="position: relative; margin-top: 1rem;">
            </div>

        </div>
      </div>
    </div>
  </div>
</div>

<!-- Editor de Imágenes -->
<div class="modal fade" id="imageEditorModal" tabindex="-1" aria-labelledby="imageEditorModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-fullscreen">
    <div class="modal-content bg-dark text-light">
      
      <div class="modal-header border-secondary">
        <h5 class="modal-title" id="imageEditorModalLabel">Editar Imagen</h5>
        <button type="button" class="btn-close btn-close-white" id="editorCloseButton" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body">
        <div class="container-fluid h-100">
          <div class="row h-100">

            <div class="col-md-2 d-flex flex-column gap-3">
              <div>
                <h4 class="fs-5 text-info">Historial / Capas</h4>
                <p class="text-secondary small">Funcionalidad de historial y capas (próximamente).</p>
                <div class="d-grid gap-2 mt-3">
                  <button class="btn btn-secondary btn-sm" disabled><i class="fas fa-undo me-2"></i>Deshacer</button>
                  <button class="btn btn-secondary btn-sm" disabled><i class="fas fa-redo me-2"></i>Rehacer</button>
                </div>
              </div>
              <hr>
              <div>
                <h5 class="fs-6">Capas</h5>
                <p class="text-secondary small">Gestión de capas (próximamente).</p>
                <div class="d-grid mt-2">
                  <button class="btn btn-secondary btn-sm" disabled><i class="fas fa-plus me-2"></i>Añadir Capa</button>
                </div>
              </div>
            </div>

            <div class="col-md-8 d-flex justify-content-center align-items-center bg-black bg-opacity-25 rounded-3">
              <canvas id="editorCanvas" style="max-width: 100%; max-height: 100%;"></canvas>
            </div>

            <div class="col-md-2 d-flex flex-column gap-4">
              <div>
                <h4 class="fs-5 text-info">Filtros</h4>
                <div id="filterThumbnails" class="d-flex overflow-x-auto gap-2 pb-2"></div>
              </div>

              <div>
                <h4 class="fs-5 text-info">Añadir Texto</h4>
                <div class="d-flex flex-column gap-2">
                  <input type="text" id="editorTextInput" placeholder="Escribe tu texto aquí" class="form-control form-control-sm bg-dark text-light border-secondary">
                  <div class="d-flex justify-content-between align-items-center">
                    <input type="color" id="editorTextColor" value="#FFFFFF" class="form-control form-control-color">
                    <input type="number" id="editorTextSize" value="30" min="10" max="100" class="form-control form-control-sm w-50 text-center bg-dark text-light border-secondary">
                    <select id="editorTextPosition" class="form-select form-select-sm bg-dark text-light border-secondary">
                      <option value="bottomRight">Abajo Der.</option>
                      <option value="topLeft">Arriba Izq.</option>
                      <option value="topRight">Arriba Der.</option>
                      <option value="bottomLeft">Abajo Izq.</option>
                      <option value="center">Centro</option>
                    </select>
                  </div>
                  <button id="addTextToCanvasButton" class="btn btn-primary btn-sm w-100">Aplicar Texto</button>
                </div>
              </div>
              
              <div>
                <h4 class="fs-5 text-info">Recorte</h4>
                <div class="d-flex flex-column gap-2">
                  <p class="text-secondary small">Recorte centrado. Ingresa las nuevas dimensiones.</p>
                  <div class="d-flex gap-2">
                    <input type="number" id="cropWidthInput" placeholder="Ancho" class="form-control form-control-sm text-center bg-dark text-light border-secondary">
                    <input type="number" id="cropHeightInput" placeholder="Alto" class="form-control form-control-sm text-center bg-dark text-light border-secondary">
                  </div>
                  <button id="applyCropButton" class="btn btn-primary btn-sm w-100">Aplicar Recorte</button>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
      
      <div class="modal-footer border-secondary">
        <button id="cancelEditButton" type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
        <button id="saveEditedImageButton" type="button" class="btn btn-info">Guardar Edición</button>
      </div>
    </div>
  </div>
</div>

