<?php
// src/Tools/views/NEW_TextGenerator_view.php
use ObelisIA\Utils\Premium;

// Configuración de la herramienta
$tool_name = "Generador de Texto IA";
$tool_icon = "pen-fancy";
$tool_description = "Genera textos creativos y profesionales con inteligencia artificial";
$tool_slug = "generador-de-texto-ia";
$is_premium = Premium::isPremium();
$show_history = true;
$show_export_button = true;

// Contenido del sidebar
$sidebar_content = '
<div class="form-group">
    <label class="form-label">Tipo de Contenido</label>
    <div class="style-selector">
        <div class="style-option" data-type="article">
            <div class="style-icon"><i class="fas fa-newspaper"></i></div>
            <div class="style-name">Artículo</div>
        </div>
        <div class="style-option" data-type="story">
            <div class="style-icon"><i class="fas fa-book"></i></div>
            <div class="style-name">Historia</div>
        </div>
        <div class="style-option" data-type="email">
            <div class="style-icon"><i class="fas fa-envelope"></i></div>
            <div class="style-name">Email</div>
        </div>
        <div class="style-option" data-type="post">
            <div class="style-icon"><i class="fas fa-comment"></i></div>
            <div class="style-name">Post</div>
        </div>
        <div class="style-option" data-type="script">
            <div class="style-icon"><i class="fas fa-film"></i></div>
            <div class="style-name">Guión</div>
        </div>
        <div class="style-option" data-type="poem">
            <div class="style-icon"><i class="fas fa-feather"></i></div>
            <div class="style-name">Poema</div>
        </div>
    </div>
</div>

<div class="form-group">
    <label class="form-label">Tono</label>
    <select id="toneSelect" class="form-control">
        <option value="professional">Profesional</option>
        <option value="casual">Casual</option>
        <option value="friendly">Amigable</option>
        <option value="formal">Formal</option>
        <option value="humorous">Humorístico</option>
        <option value="persuasive">Persuasivo</option>
        <option value="dramatic">Dramático</option>
        <option value="poetic">Poético</option>
    </select>
</div>

<div class="form-group">
    <label class="form-label">Idioma</label>
    <select id="languageSelect" class="form-control">
        <option value="es">Español</option>
        <option value="en">Inglés</option>
        <option value="fr">Francés</option>
        <option value="it">Italiano</option>
        <option value="pt">Portugués</option>
        <option value="de">Alemán</option>
    </select>
</div>

<div class="range-container">
    <div class="range-label">
        <label class="form-label">Longitud</label>
        <span class="range-value" id="lengthValue">Medio</span>
    </div>
    <input type="range" class="range-input" id="lengthRange" min="1" max="5" value="3" 
           data-labels=\'["Muy Corto", "Corto", "Medio", "Largo", "Muy Largo"]\'>
</div>

<div class="range-container">
    <div class="range-label">
        <label class="form-label">Creatividad</label>
        <span class="range-value" id="creativityValue">5</span>
    </div>
    <input type="range" class="range-input" id="creativityRange" min="1" max="10" value="5">
</div>

' . ($is_premium ? '
<div class="form-group">
    <label class="form-label">Plantillas Premium</label>
    <select id="templateSelect" class="form-control">
        <option value="">Sin plantilla</option>
        <option value="business_proposal">Propuesta de Negocio</option>
        <option value="press_release">Nota de Prensa</option>
        <option value="sales_copy">Copy de Ventas</option>
        <option value="technical_doc">Documentación Técnica</option>
        <option value="creative_brief">Brief Creativo</option>
    </select>
</div>
' : '
<div class="premium-feature">
    <div class="premium-badge">PRO</div>
    <div class="form-group">
        <label class="form-label">Plantillas Premium</label>
        <select class="form-control" disabled>
            <option>Plantillas profesionales (Premium)</option>
        </select>
    </div>
</div>
');

// Contenido principal
$main_content = '
<div class="tool-form fade-in-up">
    <div class="form-section">
        <div class="form-section-title">
            <i class="fas fa-edit"></i>
            Descripción del Contenido
        </div>
        
        ' . ($is_premium ? '<div class="alert alert-success">
            <i class="fas fa-crown"></i>
            <strong>¡Usuario Premium!</strong> Accede a plantillas profesionales y generación ilimitada.
        </div>' : '') . '
        
        <div class="prompt-input-container">
            <textarea 
                class="prompt-input" 
                placeholder="Describe el contenido que quieres generar. Ejemplo: \'Escribe un artículo sobre los beneficios de la inteligencia artificial en la educación, dirigido a profesores de secundaria\'"
                id="textPrompt"
                maxlength="1500"
            ></textarea>
            <div class="prompt-counter">
                <span id="charCount">0</span>/1500
            </div>
        </div>
        
        <div class="form-group">
            <label class="form-label">
                <i class="fas fa-bullseye"></i>
                Audiencia Objetivo (opcional)
            </label>
            <input type="text" class="form-control" id="targetAudience" 
                   placeholder="Ejemplo: estudiantes universitarios, profesionales de marketing, amas de casa...">
        </div>
        
        <div class="form-group">
            <label class="form-label">
                <i class="fas fa-key"></i>
                Palabras Clave (opcional)
            </label>
            <input type="text" class="form-control" id="keywords" 
                   placeholder="Separadas por comas: tecnología, innovación, futuro...">
        </div>
        
        <div class="flex gap-md">
            <button class="btn btn-primary flex-1" onclick="generateText()" id="generateBtn">
                <i class="fas fa-magic"></i>
                Generar Texto
            </button>
            <button class="btn btn-secondary" onclick="clearTextForm()">
                <i class="fas fa-trash"></i>
                Limpiar
            </button>
            <button class="btn btn-outline" onclick="useTemplatePrompt()">
                <i class="fas fa-template"></i>
                Plantilla
            </button>
        </div>
    </div>
</div>

<!-- Editor de texto y vista previa -->
<div class="tool-canvas-container">
    <div class="tool-canvas">
        <div class="canvas-area" id="textCanvas">
            <div class="canvas-placeholder">
                <i class="fas fa-file-alt fa-4x mb-4 pulse"></i>
                <h3>Editor de Texto</h3>
                <p class="text-muted">El contenido generado aparecerá aquí para que puedas editarlo</p>
                <div class="mt-4">
                    <div class="flex gap-md justify-center">
                        <div class="stat-item">
                            <span class="stat-number" id="wordCount">0</span>
                            <span class="stat-label">Palabras</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-number" id="charCountDisplay">0</span>
                            <span class="stat-label">Caracteres</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Área de resultados y editor -->
<div class="results-container" id="textResults" style="display: none;">
    <div class="results-header">
        <div class="results-title">
            <i class="fas fa-edit"></i>
            Editor de Texto
        </div>
        <div class="results-actions">
            <button class="btn btn-sm btn-outline" onclick="regenerateText()">
                <i class="fas fa-redo"></i>
                Regenerar
            </button>
            <button class="btn btn-sm btn-secondary" onclick="formatText()">
                <i class="fas fa-magic"></i>
                Formatear
            </button>
            <button class="btn btn-sm btn-accent" onclick="copyToClipboard()">
                <i class="fas fa-copy"></i>
                Copiar
            </button>
            <button class="btn btn-sm btn-primary" onclick="exportText()">
                <i class="fas fa-download"></i>
                Exportar
            </button>
        </div>
    </div>
    <div class="results-body">
        <div class="text-editor-container">
            <div class="text-editor-toolbar">
                <div class="editor-tools">
                    <button class="btn btn-sm btn-ghost" onclick="formatSelection(\'bold\')" title="Negrita">
                        <i class="fas fa-bold"></i>
                    </button>
                    <button class="btn btn-sm btn-ghost" onclick="formatSelection(\'italic\')" title="Cursiva">
                        <i class="fas fa-italic"></i>
                    </button>
                    <button class="btn btn-sm btn-ghost" onclick="formatSelection(\'underline\')" title="Subrayado">
                        <i class="fas fa-underline"></i>
                    </button>
                    <div class="separator"></div>
                    <button class="btn btn-sm btn-ghost" onclick="insertList(\'ul\')" title="Lista">
                        <i class="fas fa-list-ul"></i>
                    </button>
                    <button class="btn btn-sm btn-ghost" onclick="insertList(\'ol\')" title="Lista Numerada">
                        <i class="fas fa-list-ol"></i>
                    </button>
                    <div class="separator"></div>
                    <button class="btn btn-sm btn-ghost" onclick="adjustFontSize(-1)" title="Reducir Tamaño">
                        <i class="fas fa-minus"></i>
                    </button>
                    <button class="btn btn-sm btn-ghost" onclick="adjustFontSize(1)" title="Aumentar Tamaño">
                        <i class="fas fa-plus"></i>
                    </button>
                </div>
                <div class="editor-stats">
                    <span id="editorWordCount">0 palabras</span>
                    <span id="editorCharCount">0 caracteres</span>
                </div>
            </div>
            <div class="text-editor" id="textEditor" contenteditable="true" 
                 placeholder="El texto generado aparecerá aquí..."></div>
        </div>
    </div>
</div>

<!-- Historial de versiones -->
<div class="card glass-card mt-4" id="versionHistory" style="display: none;">
    <div class="card-header">
        <h4><i class="fas fa-history"></i> Historial de Versiones</h4>
    </div>
    <div class="card-body">
        <div id="versionsContainer">
            <!-- Las versiones se mostrarán aquí -->
        </div>
    </div>
</div>';

// Contenido de ayuda
$help_content = '
<div class="help-section">
    <h4><i class="fas fa-pen-fancy"></i> Cómo usar el Generador de Texto</h4>
    <ol>
        <li><strong>Describe tu contenido:</strong> Explica qué tipo de texto necesitas</li>
        <li><strong>Selecciona el tipo:</strong> Artículo, historia, email, post, etc.</li>
        <li><strong>Ajusta el tono:</strong> Profesional, casual, formal, humorístico, etc.</li>
        <li><strong>Configura opciones:</strong> Longitud, creatividad e idioma</li>
        <li><strong>Genera y edita:</strong> Usa el editor integrado para perfeccionar</li>
    </ol>
    
    <h5><i class="fas fa-lightbulb"></i> Consejos para mejores resultados:</h5>
    <ul>
        <li>Sé específico sobre el propósito del texto</li>
        <li>Menciona la audiencia objetivo</li>
        <li>Incluye palabras clave importantes</li>
        <li>Especifica el formato deseado (párrafos, listas, etc.)</li>
    </ul>
    
    <h5><i class="fas fa-crown"></i> Funciones Premium:</h5>
    <ul>
        <li>Plantillas profesionales predefinidas</li>
        <li>Generación de textos más largos</li>
        <li>Exportación en múltiples formatos</li>
        <li>Análisis avanzado de legibilidad</li>
    </ul>
</div>';

// JavaScript específico
$inline_js = '
let currentType = "article";
let isGenerating = false;
let textVersions = [];
let currentVersion = -1;

// Plantillas de prompts
const promptTemplates = {
    article: "Escribe un artículo informativo sobre [TEMA] dirigido a [AUDIENCIA]. Incluye introducción, desarrollo y conclusión.",
    story: "Escribe una historia creativa sobre [TEMA] con personajes interesantes y un final sorprendente.",
    email: "Redacta un email profesional sobre [TEMA] dirigido a [AUDIENCIA] con un tono [TONO].",
    post: "Crea un post atractivo para redes sociales sobre [TEMA] que genere engagement.",
    script: "Escribe un guión para un video sobre [TEMA] con diálogos naturales y indicaciones escénicas.",
    poem: "Compone un poema sobre [TEMA] con métrica y rima apropiadas."
};

function generateText() {
    if (isGenerating) return;
    
    const prompt = document.getElementById("textPrompt").value.trim();
    if (!prompt) {
        showAlert("Por favor, describe el contenido que quieres generar", "warning");
        return;
    }
    
    isGenerating = true;
    const generateBtn = document.getElementById("generateBtn");
    generateBtn.disabled = true;
    generateBtn.innerHTML = "<div class=\"spinner\"></div> Generando...";
    
    showLoading("Generando texto... Esto puede tomar unos momentos");
    
    // Datos del formulario
    const formData = new FormData();
    formData.append("tool_slug", "generador-de-texto-ia");
    formData.append("prompt", prompt);
    formData.append("type", currentType);
    formData.append("tone", document.getElementById("toneSelect").value);
    formData.append("language", document.getElementById("languageSelect").value);
    formData.append("length", document.getElementById("lengthRange").value);
    formData.append("creativity", document.getElementById("creativityRange").value);
    formData.append("target_audience", document.getElementById("targetAudience").value);
    formData.append("keywords", document.getElementById("keywords").value);
    
    if (window.toolConfig.isPremium) {
        formData.append("template", document.getElementById("templateSelect").value);
    }
    
    // Simular generación de texto
    setTimeout(() => {
        hideLoading();
        isGenerating = false;
        generateBtn.disabled = false;
        generateBtn.innerHTML = "<i class=\"fas fa-magic\"></i> Generar Texto";
        
        // Texto de ejemplo (en producción vendría del servidor)
        const sampleText = generateSampleText(prompt, currentType);
        showTextResult(sampleText);
        
    }, 2500);
}

function generateSampleText(prompt, type) {
    const samples = {
        article: `# ${prompt}

La evolución de la tecnología ha transformado radicalmente nuestra forma de vivir, trabajar y relacionarnos. En este artículo exploraremos los aspectos más importantes de este fenómeno.

## Introducción

En las últimas décadas, hemos sido testigos de una revolución tecnológica sin precedentes. Desde la invención de Internet hasta el desarrollo de la inteligencia artificial, cada avance ha abierto nuevas posibilidades y desafíos.

## Desarrollo

Los beneficios de esta transformación son evidentes en múltiples sectores:

- **Comunicación**: Las distancias se han acortado
- **Educación**: El conocimiento es más accesible
- **Medicina**: Diagnósticos más precisos y tratamientos innovadores
- **Transporte**: Soluciones más eficientes y sostenibles

## Conclusión

El futuro promete aún más innovaciones que continuarán moldeando nuestra sociedad. Es fundamental adaptarse a estos cambios manteniendo siempre el factor humano en el centro de toda evolución tecnológica.`,
        
        story: `Había una vez, en un pequeño pueblo perdido entre montañas, una historia que nadie se atrevía a contar. María, la bibliotecaria del lugar, guardaba un secreto que cambiaría todo.

Cada mañana, al abrir la biblioteca, encontraba un libro nuevo en el estante principal. Un libro que no había estado ahí la noche anterior. Al principio pensó que alguien los dejaba como donación, pero pronto se dio cuenta de que estos libros contenían historias que aún no habían ocurrido.

El día que encontró un libro con su propia historia fue cuando comprendió que el tiempo, en ese pequeño rincón del mundo, funcionaba de manera diferente. Y que ella tenía el poder de escribir el futuro...`,
        
        email: `Asunto: ${prompt}

Estimado/a [Nombre],

Espero que este mensaje le encuentre bien. Me dirijo a usted para compartir información importante sobre [tema específico].

Como parte de nuestro compromiso con la excelencia, queremos asegurar que usted esté al tanto de los últimos desarrollos en este ámbito. Los puntos clave a considerar son:

• Punto importante número uno
• Beneficio directo para usted
• Próximos pasos a seguir

Estaré encantado/a de responder cualquier pregunta que pueda tener al respecto. No dude en contactarme cuando sea conveniente para usted.

Cordialmente,
[Su nombre]`,
        
        post: `🚀 ¿Sabías que ${prompt}? 

✨ Esta información puede cambiar tu perspectiva sobre muchas cosas. Aquí te comparto los datos más impresionantes:

🔹 Dato fascinante #1
🔹 Información sorprendente #2  
🔹 Insights que no conocías #3

💡 La conclusión es clara: estamos viviendo tiempos extraordinarios donde cada día trae nuevas posibilidades.

¿Qué opinas? ¡Comparte tu punto de vista en los comentarios! 👇

#Innovación #Tecnología #Futuro #Conocimiento`,
        
        script: `FADE IN:

INT. OFICINA MODERNA - DÍA

MARÍA (30s, profesional, determinada) revisa documentos en su escritorio. Su teléfono suena.

MARÍA
(contestando)
Oficina de María, buenos días.

VOZ EN OFF
Tenemos noticias importantes sobre el proyecto.

María se incorpora, alerta. Sus ojos muestran una mezcla de expectativa y preocupación.

MARÍA
¿Buenas o malas?

PAUSA dramática.

VOZ EN OFF
Eso dependerá de cómo lo manejes.

CLOSE-UP en el rostro de María. Toma una decisión.

MARÍA
(decidida)
Estoy lista.

FADE OUT.`,
        
        poem: `En el silencio de la madrugada,
cuando el mundo descansa en calma,
surgen los versos como olas
que abrazan la orilla del alma.

Cada palabra encuentra su lugar,
cada verso su melodía,
en la danza eterna del crear
donde vive la poesía.

${prompt} se convierte en canción,
en susurro de viento suave,
en el latido del corazón
que solo el poeta sabe.

Así nace el poema eterno,
así florece la inspiración,
en el jardín más tierno
de nuestra imaginación.`
    };
    
    return samples[type] || samples.article;
}

function showTextResult(text) {
    const canvas = document.getElementById("textCanvas");
    const resultsContainer = document.getElementById("textResults");
    const editor = document.getElementById("textEditor");
    const versionHistory = document.getElementById("versionHistory");
    
    // Mostrar en canvas
    canvas.innerHTML = `
        <div class="canvas-content fade-in-up">
            <div class="text-preview">
                <h3>Vista Previa del Texto</h3>
                <div class="text-content">${text.substring(0, 200)}...</div>
                <button class="btn btn-primary mt-3" onclick="openFullEditor()">
                    <i class="fas fa-edit"></i> Abrir Editor Completo
                </button>
            </div>
        </div>
    `;
    canvas.classList.add("has-content");
    
    // Cargar en editor
    editor.innerHTML = text.replace(/\n/g, "<br>");
    
    // Guardar versión
    textVersions.push({
        text: text,
        timestamp: new Date(),
        type: currentType
    });
    currentVersion = textVersions.length - 1;
    
    // Mostrar resultados
    resultsContainer.style.display = "block";
    versionHistory.style.display = "block";
    
    // Actualizar estadísticas
    updateTextStats();
    updateVersionHistory();
    
    // Scroll suave
    setTimeout(() => {
        resultsContainer.scrollIntoView({ behavior: "smooth" });
    }, 300);
}

function openFullEditor() {
    const resultsContainer = document.getElementById("textResults");
    resultsContainer.scrollIntoView({ behavior: "smooth" });
}

function clearTextForm() {
    document.getElementById("textPrompt").value = "";
    document.getElementById("targetAudience").value = "";
    document.getElementById("keywords").value = "";
    updateCharCount();
    
    // Reset canvas
    const canvas = document.getElementById("textCanvas");
    canvas.classList.remove("has-content");
    canvas.innerHTML = `
        <div class="canvas-placeholder">
            <i class="fas fa-file-alt fa-4x mb-4 pulse"></i>
            <h3>Editor de Texto</h3>
            <p class="text-muted">El contenido generado aparecerá aquí para que puedas editarlo</p>
            <div class="mt-4">
                <div class="flex gap-md justify-center">
                    <div class="stat-item">
                        <span class="stat-number" id="wordCount">0</span>
                        <span class="stat-label">Palabras</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number" id="charCountDisplay">0</span>
                        <span class="stat-label">Caracteres</span>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function regenerateText() {
    if (!document.getElementById("textPrompt").value.trim()) {
        showAlert("Necesitas una descripción para regenerar", "warning");
        return;
    }
    generateText();
}

function copyToClipboard() {
    const editor = document.getElementById("textEditor");
    const text = editor.innerText;
    
    navigator.clipboard.writeText(text).then(() => {
        showAlert("Texto copiado al portapapeles", "success");
    });
}

function exportText() {
    const editor = document.getElementById("textEditor");
    const text = editor.innerText;
    const blob = new Blob([text], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement("a");
    a.href = url;
    a.download = `obelisia_texto_${Date.now()}.txt`;
    a.click();
    
    URL.revokeObjectURL(url);
    showAlert("Archivo descargado", "success");
}

function formatText() {
    // Auto-formatear el texto (agregar saltos de línea, mayúsculas, etc.)
    const editor = document.getElementById("textEditor");
    let text = editor.innerText;
    
    // Formatear párrafos
    text = text.replace(/\. ([A-Z])/g, ".\n\n$1");
    text = text.replace(/\n{3,}/g, "\n\n");
    
    editor.innerHTML = text.replace(/\n/g, "<br>");
    updateTextStats();
    showAlert("Texto formateado", "success");
}

function formatSelection(command) {
    document.execCommand(command, false, null);
    updateTextStats();
}

function insertList(type) {
    document.execCommand("insertHTML", false, 
        type === "ul" ? "<ul><li>Elemento de lista</li></ul>" : 
                       "<ol><li>Elemento numerado</li></ol>");
    updateTextStats();
}

function adjustFontSize(delta) {
    const selection = window.getSelection();
    if (selection.rangeCount > 0) {
        const span = document.createElement("span");
        span.style.fontSize = delta > 0 ? "1.1em" : "0.9em";
        
        try {
            const range = selection.getRangeAt(0);
            range.surroundContents(span);
        } catch (e) {
            console.log("No se pudo cambiar el tamaño de fuente");
        }
    }
}

function useTemplatePrompt() {
    const template = promptTemplates[currentType];
    const currentPrompt = document.getElementById("textPrompt").value;
    
    if (!currentPrompt) {
        document.getElementById("textPrompt").value = template;
        updateCharCount();
        showAlert("Plantilla aplicada. Personaliza los campos [TEMA], [AUDIENCIA], etc.", "info");
    } else {
        if (confirm("¿Quieres reemplazar el prompt actual con la plantilla?")) {
            document.getElementById("textPrompt").value = template;
            updateCharCount();
            showAlert("Plantilla aplicada", "success");
        }
    }
}

function updateTextStats() {
    const editor = document.getElementById("textEditor");
    const text = editor.innerText || "";
    const words = text.trim() ? text.trim().split(/\s+/).length : 0;
    const chars = text.length;
    
    // Actualizar en canvas
    const wordCountDisplay = document.getElementById("wordCount");
    const charCountDisplay = document.getElementById("charCountDisplay");
    if (wordCountDisplay) wordCountDisplay.textContent = words;
    if (charCountDisplay) charCountDisplay.textContent = chars;
    
    // Actualizar en editor
    document.getElementById("editorWordCount").textContent = `${words} palabras`;
    document.getElementById("editorCharCount").textContent = `${chars} caracteres`;
}

function updateVersionHistory() {
    const container = document.getElementById("versionsContainer");
    container.innerHTML = "";
    
    textVersions.forEach((version, index) => {
        const versionItem = document.createElement("div");
        versionItem.className = `version-item ${index === currentVersion ? "active" : ""}`;
        versionItem.innerHTML = `
            <div class="version-info">
                <strong>Versión ${index + 1}</strong>
                <small>${version.timestamp.toLocaleString()}</small>
                <span class="badge">${version.type}</span>
            </div>
            <div class="version-preview">${version.text.substring(0, 100)}...</div>
            <div class="version-actions">
                <button class="btn btn-sm btn-outline" onclick="loadVersion(${index})">
                    Cargar
                </button>
                <button class="btn btn-sm btn-ghost" onclick="deleteVersion(${index})">
                    Eliminar
                </button>
            </div>
        `;
        container.appendChild(versionItem);
    });
}

function loadVersion(index) {
    const version = textVersions[index];
    const editor = document.getElementById("textEditor");
    editor.innerHTML = version.text.replace(/\n/g, "<br>");
    currentVersion = index;
    updateTextStats();
    updateVersionHistory();
    showAlert(`Versión ${index + 1} cargada`, "success");
}

function deleteVersion(index) {
    if (confirm("¿Estás seguro de eliminar esta versión?")) {
        textVersions.splice(index, 1);
        if (currentVersion >= index) currentVersion--;
        updateVersionHistory();
        showAlert("Versión eliminada", "info");
    }
}

function showAlert(message, type = "info") {
    const alert = document.createElement("div");
    alert.className = `alert alert-${type} position-fixed top-0 end-0 m-3`;
    alert.style.zIndex = "9999";
    alert.innerHTML = `
        <i class="fas fa-${type === "success" ? "check" : type === "warning" ? "exclamation-triangle" : "info-circle"}"></i>
        ${message}
    `;
    
    document.body.appendChild(alert);
    setTimeout(() => alert.remove(), 3000);
}

// Event listeners
document.addEventListener("DOMContentLoaded", function() {
    // Type selector
    document.querySelectorAll(".style-option").forEach(option => {
        option.addEventListener("click", function() {
            document.querySelectorAll(".style-option").forEach(o => o.classList.remove("selected"));
            this.classList.add("selected");
            currentType = this.dataset.type;
        });
    });
    
    // Range inputs
    const lengthRange = document.getElementById("lengthRange");
    const creativityRange = document.getElementById("creativityRange");
    
    lengthRange.addEventListener("input", function() {
        const labels = JSON.parse(this.dataset.labels);
        document.getElementById("lengthValue").textContent = labels[this.value - 1];
    });
    
    creativityRange.addEventListener("input", function() {
        document.getElementById("creativityValue").textContent = this.value;
    });
    
    // Character counter
    document.getElementById("textPrompt").addEventListener("input", updateCharCount);
    
    // Editor stats
    document.getElementById("textEditor").addEventListener("input", updateTextStats);
    
    // Keyboard shortcuts
    document.addEventListener("keydown", function(e) {
        if (e.ctrlKey && e.key === "Enter") {
            generateText();
        }
        if (e.ctrlKey && e.key === "s") {
            e.preventDefault();
            exportText();
        }
    });
    
    // Seleccionar primer tipo por defecto
    document.querySelector(".style-option").click();
});

function updateCharCount() {
    const textarea = document.getElementById("textPrompt");
    const counter = document.getElementById("charCount");
    if (textarea && counter) {
        counter.textContent = textarea.value.length;
    }
}
';

// Incluir el template base
include 'base_template.php';
