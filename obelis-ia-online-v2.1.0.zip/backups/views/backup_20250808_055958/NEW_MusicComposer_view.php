<?php
// src/Tools/views/NEW_MusicComposer_view.php
use ObelisIA\Utils\Premium;

// Configuración de la herramienta
$tool_name = "Compositor de Música IA";
$tool_icon = "music";
$tool_description = "Crea música original con inteligencia artificial";
$tool_slug = "compositor-de-musica-ia";
$is_premium = Premium::isPremium();
$show_history = true;
$show_export_button = true;

// Contenido del sidebar
$sidebar_content = '
<div class="form-group">
    <label class="form-label">Género Musical</label>
    <div class="style-selector">
        <div class="style-option" data-genre="pop">
            <div class="style-icon"><i class="fas fa-star"></i></div>
            <div class="style-name">Pop</div>
        </div>
        <div class="style-option" data-genre="rock">
            <div class="style-icon"><i class="fas fa-guitar"></i></div>
            <div class="style-name">Rock</div>
        </div>
        <div class="style-option" data-genre="jazz">
            <div class="style-icon"><i class="fas fa-saxophone"></i></div>
            <div class="style-name">Jazz</div>
        </div>
        <div class="style-option" data-genre="classical">
            <div class="style-icon"><i class="fas fa-piano"></i></div>
            <div class="style-name">Clásica</div>
        </div>
        <div class="style-option" data-genre="electronic">
            <div class="style-icon"><i class="fas fa-laptop"></i></div>
            <div class="style-name">Electrónica</div>
        </div>
        <div class="style-option" data-genre="ambient">
            <div class="style-icon"><i class="fas fa-cloud"></i></div>
            <div class="style-name">Ambient</div>
        </div>
    </div>
</div>

<div class="form-group">
    <label class="form-label">Estado de Ánimo</label>
    <select id="moodSelect" class="form-control">
        <option value="happy">Alegre</option>
        <option value="sad">Melancólico</option>
        <option value="energetic">Energético</option>
        <option value="calm">Tranquilo</option>
        <option value="mysterious">Misterioso</option>
        <option value="dramatic">Dramático</option>
        <option value="romantic">Romántico</option>
        <option value="epic">Épico</option>
    </select>
</div>

<div class="form-group">
    <label class="form-label">Tempo (BPM)</label>
    <select id="tempoSelect" class="form-control">
        <option value="slow">Lento (60-80 BPM)</option>
        <option value="moderate">Moderado (80-120 BPM)</option>
        <option value="fast">Rápido (120-140 BPM)</option>
        <option value="very-fast">Muy Rápido (140+ BPM)</option>
    </select>
</div>

<div class="range-container">
    <div class="range-label">
        <label class="form-label">Duración (minutos)</label>
        <span class="range-value" id="durationValue">2</span>
    </div>
    <input type="range" class="range-input" id="durationRange" min="1" max="10" value="2">
</div>

<div class="range-container">
    <div class="range-label">
        <label class="form-label">Complejidad</label>
        <span class="range-value" id="complexityValue">5</span>
    </div>
    <input type="range" class="range-input" id="complexityRange" min="1" max="10" value="5">
</div>

' . ($is_premium ? '
<div class="form-group">
    <label class="form-label">Calidad de Audio</label>
    <select id="qualitySelect" class="form-control">
        <option value="standard">Estándar (128 kbps)</option>
        <option value="high">Alta (320 kbps)</option>
        <option value="lossless">Sin Pérdida (FLAC)</option>
    </select>
</div>

<div class="form-group">
    <label class="form-label">Instrumentos Principales</label>
    <div class="instrument-selector">
        <label class="checkbox-item">
            <input type="checkbox" value="piano" checked>
            <span>Piano</span>
        </label>
        <label class="checkbox-item">
            <input type="checkbox" value="guitar">
            <span>Guitarra</span>
        </label>
        <label class="checkbox-item">
            <input type="checkbox" value="strings">
            <span>Cuerdas</span>
        </label>
        <label class="checkbox-item">
            <input type="checkbox" value="drums">
            <span>Batería</span>
        </label>
        <label class="checkbox-item">
            <input type="checkbox" value="synthesizer">
            <span>Sintetizador</span>
        </label>
    </div>
</div>
' : '
<div class="premium-feature">
    <div class="premium-badge">PRO</div>
    <div class="form-group">
        <label class="form-label">Opciones Avanzadas</label>
        <div class="text-muted">
            <p>• Calidad de audio superior</p>
            <p>• Selección de instrumentos</p>
            <p>• Composiciones más largas</p>
            <p>• Exportación sin límites</p>
        </div>
    </div>
</div>
');

// Contenido principal
$main_content = '
<div class="tool-form fade-in-up">
    <div class="form-section">
        <div class="form-section-title">
            <i class="fas fa-music"></i>
            Descripción Musical
        </div>
        
        ' . ($is_premium ? '<div class="alert alert-success">
            <i class="fas fa-crown"></i>
            <strong>¡Usuario Premium!</strong> Accede a calidad superior, instrumentos avanzados y exportación ilimitada.
        </div>' : '') . '
        
        <div class="prompt-input-container">
            <textarea 
                class="prompt-input" 
                placeholder="Describe la música que quieres crear. Ejemplo: \'Una melodía relajante de piano para meditar, con toques de cuerdas suaves y sonidos de la naturaleza\'"
                id="musicPrompt"
                maxlength="1000"
            ></textarea>
            <div class="prompt-counter">
                <span id="charCount">0</span>/1000
            </div>
        </div>
        
        <div class="form-group">
            <label class="form-label">
                <i class="fas fa-tag"></i>
                Etiquetas de Estilo (opcional)
            </label>
            <input type="text" class="form-control" id="styleTags" 
                   placeholder="Ejemplo: cinematic, uplifting, nostalgic, dreamy...">
        </div>
        
        <div class="form-group">
            <label class="form-label">
                <i class="fas fa-seedling"></i>
                Semilla Musical (opcional)
            </label>
            <div class="flex gap-sm">
                <input type="number" class="form-control" id="musicSeed" 
                       placeholder="Para reproducir resultados" min="0" max="999999">
                <button class="btn btn-secondary" onclick="generateRandomSeed()" type="button">
                    <i class="fas fa-dice"></i>
                </button>
            </div>
        </div>
        
        <div class="flex gap-md">
            <button class="btn btn-primary flex-1" onclick="generateMusic()" id="generateBtn">
                <i class="fas fa-magic"></i>
                Componer Música
            </button>
            <button class="btn btn-secondary" onclick="clearMusicForm()">
                <i class="fas fa-trash"></i>
                Limpiar
            </button>
            <button class="btn btn-outline" onclick="useRandomPrompt()">
                <i class="fas fa-shuffle"></i>
                Sorprender
            </button>
        </div>
    </div>
</div>

<!-- Reproductor de música y visualizador -->
<div class="tool-canvas-container">
    <div class="tool-canvas">
        <div class="canvas-area" id="musicCanvas">
            <div class="canvas-placeholder">
                <i class="fas fa-headphones fa-4x mb-4 pulse"></i>
                <h3>Estudio de Composición</h3>
                <p class="text-muted">La música generada se reproducirá aquí</p>
                <div class="mt-4">
                    <div class="flex gap-md justify-center">
                        <div class="stat-item">
                            <span class="stat-number" id="tracksCreated">0</span>
                            <span class="stat-label">Composiciones</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-number" id="totalDuration">0:00</span>
                            <span class="stat-label">Duración Total</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Reproductor de audio avanzado -->
<div class="results-container" id="musicResults" style="display: none;">
    <div class="results-header">
        <div class="results-title">
            <i class="fas fa-play-circle"></i>
            Reproductor Musical
            <span class="badge bg-accent" id="trackCount">0</span>
        </div>
        <div class="results-actions">
            <button class="btn btn-sm btn-outline" onclick="regenerateMusic()">
                <i class="fas fa-redo"></i>
                Recomponer
            </button>
            <button class="btn btn-sm btn-secondary" onclick="toggleVisualization()">
                <i class="fas fa-wave-square"></i>
                Visualización
            </button>
            <button class="btn btn-sm btn-accent" onclick="downloadCurrentTrack()">
                <i class="fas fa-download"></i>
                Descargar
            </button>
        </div>
    </div>
    <div class="results-body">
        <!-- Reproductor principal -->
        <div class="music-player" id="musicPlayer">
            <div class="player-info">
                <div class="track-title" id="trackTitle">Composición Sin Título</div>
                <div class="track-details" id="trackDetails">Generando...</div>
            </div>
            
            <div class="player-controls">
                <button class="control-btn" onclick="previousTrack()" id="prevBtn" disabled>
                    <i class="fas fa-step-backward"></i>
                </button>
                <button class="control-btn control-btn-main" onclick="togglePlayback()" id="playBtn">
                    <i class="fas fa-play"></i>
                </button>
                <button class="control-btn" onclick="nextTrack()" id="nextBtn" disabled>
                    <i class="fas fa-step-forward"></i>
                </button>
                <button class="control-btn" onclick="toggleLoop()" id="loopBtn">
                    <i class="fas fa-redo"></i>
                </button>
            </div>
            
            <div class="player-progress">
                <span class="time-display" id="currentTime">0:00</span>
                <div class="progress-container">
                    <div class="progress-bar" id="progressBar">
                        <div class="progress-fill" id="progressFill"></div>
                    </div>
                </div>
                <span class="time-display" id="totalTime">0:00</span>
            </div>
            
            <div class="player-volume">
                <i class="fas fa-volume-up"></i>
                <input type="range" class="volume-slider" id="volumeSlider" min="0" max="100" value="70">
            </div>
            
            <audio id="audioPlayer" preload="metadata"></audio>
        </div>
        
        <!-- Visualizador de audio -->
        <div class="audio-visualizer" id="audioVisualizer" style="display: none;">
            <canvas id="visualizerCanvas"></canvas>
        </div>
        
        <!-- Lista de pistas -->
        <div class="track-list" id="trackList">
            <!-- Las pistas se mostrarán aquí -->
        </div>
    </div>
</div>

<!-- Biblioteca musical -->
<div class="card glass-card mt-4" id="musicLibrary">
    <div class="card-header">
        <h4><i class="fas fa-music"></i> Tu Biblioteca Musical</h4>
        <div class="library-actions">
            <button class="btn btn-sm btn-outline" onclick="clearLibrary()">
                <i class="fas fa-trash"></i>
                Limpiar Todo
            </button>
            <button class="btn btn-sm btn-accent" onclick="exportPlaylist()">
                <i class="fas fa-download"></i>
                Exportar Playlist
            </button>
        </div>
    </div>
    <div class="card-body">
        <div class="music-grid" id="musicGrid">
            <div class="empty-library">
                <i class="fas fa-music fa-3x text-muted mb-3"></i>
                <p class="text-muted">Tu biblioteca musical está vacía</p>
                <p class="text-muted">Crea tu primera composición para comenzar</p>
            </div>
        </div>
    </div>
</div>';

// Contenido de ayuda
$help_content = '
<div class="help-section">
    <h4><i class="fas fa-music"></i> Cómo usar el Compositor Musical</h4>
    <ol>
        <li><strong>Describe tu música:</strong> Explica el estilo, ánimo y características</li>
        <li><strong>Selecciona género:</strong> Pop, Rock, Jazz, Clásica, etc.</li>
        <li><strong>Ajusta parámetros:</strong> Tempo, duración y complejidad</li>
        <li><strong>Compón:</strong> Haz clic en "Componer Música" y espera</li>
        <li><strong>Escucha y descarga:</strong> Usa el reproductor integrado</li>
    </ol>
    
    <h5><i class="fas fa-lightbulb"></i> Consejos para mejores composiciones:</h5>
    <ul>
        <li>Sé específico sobre instrumentos y atmosfera</li>
        <li>Menciona referencias musicales conocidas</li>
        <li>Describe el uso previsto (relajación, ejercicio, etc.)</li>
        <li>Experimenta con diferentes semillas para variaciones</li>
    </ul>
    
    <h5><i class="fas fa-crown"></i> Funciones Premium:</h5>
    <ul>
        <li>Calidad de audio superior (320kbps, FLAC)</li>
        <li>Composiciones más largas (hasta 10 minutos)</li>
        <li>Selección avanzada de instrumentos</li>
        <li>Descarga ilimitada sin marca de agua</li>
    </ul>
</div>';

// JavaScript específico
$inline_js = '
let currentGenre = "pop";
let isGenerating = false;
let musicLibrary = [];
let currentTrackIndex = 0;
let isPlaying = false;
let isLooping = false;
let audioContext = null;
let analyser = null;

// Prompts musicales sugeridos
const musicPrompts = [
    "Una melodía relajante de piano para estudiar",
    "Música épica de orquesta para una película de aventuras",
    "Ritmo electrónico energético para hacer ejercicio",
    "Jazz suave para una noche romántica",
    "Música ambiental con sonidos de la naturaleza",
    "Rock alternativo con guitarra emotiva",
    "Música clásica minimalista y contemplativa",
    "Pop alegre y pegadizo estilo años 80"
];

function generateMusic() {
    if (isGenerating) return;
    
    const prompt = document.getElementById("musicPrompt").value.trim();
    if (!prompt) {
        showAlert("Por favor, describe la música que quieres crear", "warning");
        return;
    }
    
    isGenerating = true;
    const generateBtn = document.getElementById("generateBtn");
    generateBtn.disabled = true;
    generateBtn.innerHTML = "<div class=\"spinner\"></div> Componiendo...";
    
    showLoading("Componiendo música... Esto puede tomar 30-90 segundos");
    
    // Datos del formulario
    const compositionData = {
        prompt: prompt,
        genre: currentGenre,
        mood: document.getElementById("moodSelect").value,
        tempo: document.getElementById("tempoSelect").value,
        duration: document.getElementById("durationRange").value,
        complexity: document.getElementById("complexityRange").value,
        styleTags: document.getElementById("styleTags").value,
        seed: document.getElementById("musicSeed").value
    };
    
    if (window.toolConfig.isPremium) {
        compositionData.quality = document.getElementById("qualitySelect").value;
        compositionData.instruments = getSelectedInstruments();
    }
    
    // Simular generación musical
    setTimeout(() => {
        hideLoading();
        isGenerating = false;
        generateBtn.disabled = false;
        generateBtn.innerHTML = "<i class=\"fas fa-magic\"></i> Componer Música";
        
        // Crear composición simulada
        const track = createSimulatedTrack(compositionData);
        showMusicResult(track);
        
    }, 4000);
}

function createSimulatedTrack(data) {
    const trackId = Date.now();
    const duration = parseInt(data.duration) * 60; // Convertir a segundos
    
    return {
        id: trackId,
        title: `Composición ${currentGenre.charAt(0).toUpperCase() + currentGenre.slice(1)}`,
        description: data.prompt.substring(0, 100),
        genre: data.genre,
        mood: data.mood,
        duration: duration,
        tempo: data.tempo,
        timestamp: new Date(),
        url: `https://www.soundjay.com/misc/sounds-relax/relax-${Math.floor(Math.random() * 5) + 1}.mp3`, // URL simulada
        waveform: generateWaveformData()
    };
}

function generateWaveformData() {
    // Generar datos simulados de forma de onda
    const data = [];
    for (let i = 0; i < 100; i++) {
        data.push(Math.random() * 0.8 + 0.1);
    }
    return data;
}

function showMusicResult(track) {
    const canvas = document.getElementById("musicCanvas");
    const resultsContainer = document.getElementById("musicResults");
    
    // Mostrar en canvas
    canvas.innerHTML = `
        <div class="canvas-content fade-in-up">
            <div class="track-preview">
                <div class="track-artwork">
                    <i class="fas fa-music fa-4x"></i>
                </div>
                <h3>${track.title}</h3>
                <p class="track-info">${track.genre} • ${track.mood} • ${formatDuration(track.duration)}</p>
                <button class="btn btn-primary mt-3" onclick="playTrack(${musicLibrary.length})">
                    <i class="fas fa-play"></i> Reproducir
                </button>
            </div>
        </div>
    `;
    canvas.classList.add("has-content");
    
    // Agregar a biblioteca
    musicLibrary.push(track);
    updateMusicLibrary();
    
    // Cargar en reproductor
    loadTrack(track);
    
    // Mostrar resultados
    resultsContainer.style.display = "block";
    
    // Actualizar estadísticas
    updateMusicStats();
    
    // Scroll suave
    setTimeout(() => {
        resultsContainer.scrollIntoView({ behavior: "smooth" });
    }, 300);
}

function loadTrack(track) {
    const player = document.getElementById("audioPlayer");
    const trackTitle = document.getElementById("trackTitle");
    const trackDetails = document.getElementById("trackDetails");
    
    trackTitle.textContent = track.title;
    trackDetails.textContent = `${track.genre} • ${track.mood} • ${formatDuration(track.duration)}`;
    
    // En un entorno real, cargarías el archivo de audio aquí
    // player.src = track.url;
    
    // Simular carga
    document.getElementById("totalTime").textContent = formatDuration(track.duration);
    
    updateTrackList();
}

function togglePlayback() {
    const playBtn = document.getElementById("playBtn");
    const audioPlayer = document.getElementById("audioPlayer");
    
    if (isPlaying) {
        // audioPlayer.pause();
        playBtn.innerHTML = "<i class=\"fas fa-play\"></i>";
        isPlaying = false;
        stopVisualization();
    } else {
        // audioPlayer.play();
        playBtn.innerHTML = "<i class=\"fas fa-pause\"></i>";
        isPlaying = true;
        startVisualization();
        simulatePlayback();
    }
}

function simulatePlayback() {
    if (!isPlaying) return;
    
    // Simular progreso de reproducción
    let currentSeconds = 0;
    const totalSeconds = musicLibrary[currentTrackIndex]?.duration || 120;
    
    const interval = setInterval(() => {
        if (!isPlaying) {
            clearInterval(interval);
            return;
        }
        
        currentSeconds++;
        updateProgress(currentSeconds, totalSeconds);
        
        if (currentSeconds >= totalSeconds) {
            clearInterval(interval);
            if (isLooping) {
                setTimeout(() => {
                    if (isPlaying) togglePlayback();
                    setTimeout(() => togglePlayback(), 100);
                }, 500);
            } else {
                togglePlayback();
            }
        }
    }, 1000);
}

function updateProgress(current, total) {
    const progressFill = document.getElementById("progressFill");
    const currentTime = document.getElementById("currentTime");
    
    const percentage = (current / total) * 100;
    progressFill.style.width = percentage + "%";
    currentTime.textContent = formatDuration(current);
}

function previousTrack() {
    if (currentTrackIndex > 0) {
        currentTrackIndex--;
        loadTrack(musicLibrary[currentTrackIndex]);
        updateTrackList();
    }
}

function nextTrack() {
    if (currentTrackIndex < musicLibrary.length - 1) {
        currentTrackIndex++;
        loadTrack(musicLibrary[currentTrackIndex]);
        updateTrackList();
    }
}

function toggleLoop() {
    const loopBtn = document.getElementById("loopBtn");
    isLooping = !isLooping;
    loopBtn.classList.toggle("active", isLooping);
    showAlert(isLooping ? "Repetición activada" : "Repetición desactivada", "info");
}

function playTrack(index) {
    currentTrackIndex = index;
    loadTrack(musicLibrary[index]);
    if (!isPlaying) togglePlayback();
}

function toggleVisualization() {
    const visualizer = document.getElementById("audioVisualizer");
    const isVisible = visualizer.style.display !== "none";
    visualizer.style.display = isVisible ? "none" : "block";
    
    if (!isVisible) {
        initializeVisualizer();
    }
}

function initializeVisualizer() {
    const canvas = document.getElementById("visualizerCanvas");
    const ctx = canvas.getContext("2d");
    
    canvas.width = canvas.offsetWidth;
    canvas.height = 200;
    
    // Visualización simulada
    function drawVisualization() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        const barWidth = canvas.width / 50;
        for (let i = 0; i < 50; i++) {
            const barHeight = Math.random() * canvas.height * 0.8;
            const hue = (i * 7) % 360;
            
            ctx.fillStyle = `hsl(${hue}, 70%, 60%)`;
            ctx.fillRect(i * barWidth, canvas.height - barHeight, barWidth - 2, barHeight);
        }
        
        if (isPlaying) {
            requestAnimationFrame(drawVisualization);
        }
    }
    
    if (isPlaying) {
        drawVisualization();
    }
}

function startVisualization() {
    const visualizer = document.getElementById("audioVisualizer");
    if (visualizer.style.display !== "none") {
        initializeVisualizer();
    }
}

function stopVisualization() {
    // La animación se detiene automáticamente cuando isPlaying = false
}

function clearMusicForm() {
    document.getElementById("musicPrompt").value = "";
    document.getElementById("styleTags").value = "";
    document.getElementById("musicSeed").value = "";
    updateCharCount();
    
    // Reset canvas
    const canvas = document.getElementById("musicCanvas");
    canvas.classList.remove("has-content");
    canvas.innerHTML = `
        <div class="canvas-placeholder">
            <i class="fas fa-headphones fa-4x mb-4 pulse"></i>
            <h3>Estudio de Composición</h3>
            <p class="text-muted">La música generada se reproducirá aquí</p>
            <div class="mt-4">
                <div class="flex gap-md justify-center">
                    <div class="stat-item">
                        <span class="stat-number" id="tracksCreated">${musicLibrary.length}</span>
                        <span class="stat-label">Composiciones</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number" id="totalDuration">${formatTotalDuration()}</span>
                        <span class="stat-label">Duración Total</span>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function regenerateMusic() {
    if (!document.getElementById("musicPrompt").value.trim()) {
        showAlert("Necesitas una descripción para recomponer", "warning");
        return;
    }
    generateMusic();
}

function downloadCurrentTrack() {
    if (musicLibrary.length === 0) {
        showAlert("No hay pistas para descargar", "warning");
        return;
    }
    
    const track = musicLibrary[currentTrackIndex];
    showAlert(`Descargando: ${track.title}`, "success");
    
    // En un entorno real, iniciarías la descarga aquí
    // const a = document.createElement("a");
    // a.href = track.url;
    // a.download = `${track.title}.mp3`;
    // a.click();
}

function generateRandomSeed() {
    const seed = Math.floor(Math.random() * 999999);
    document.getElementById("musicSeed").value = seed;
}

function useRandomPrompt() {
    const randomPrompt = musicPrompts[Math.floor(Math.random() * musicPrompts.length)];
    document.getElementById("musicPrompt").value = randomPrompt;
    updateCharCount();
    showAlert("Prompt musical aplicado", "info");
}

function getSelectedInstruments() {
    const checkboxes = document.querySelectorAll(".checkbox-item input:checked");
    return Array.from(checkboxes).map(cb => cb.value);
}

function updateMusicStats() {
    document.getElementById("tracksCreated").textContent = musicLibrary.length;
    document.getElementById("totalDuration").textContent = formatTotalDuration();
    document.getElementById("trackCount").textContent = musicLibrary.length;
    
    // Habilitar/deshabilitar controles
    const prevBtn = document.getElementById("prevBtn");
    const nextBtn = document.getElementById("nextBtn");
    
    prevBtn.disabled = currentTrackIndex === 0;
    nextBtn.disabled = currentTrackIndex === musicLibrary.length - 1;
}

function updateTrackList() {
    const trackList = document.getElementById("trackList");
    trackList.innerHTML = "";
    
    musicLibrary.forEach((track, index) => {
        const trackItem = document.createElement("div");
        trackItem.className = `track-item ${index === currentTrackIndex ? "active" : ""}`;
        trackItem.innerHTML = `
            <div class="track-info">
                <div class="track-name">${track.title}</div>
                <div class="track-meta">${track.genre} • ${formatDuration(track.duration)}</div>
            </div>
            <div class="track-actions">
                <button class="btn btn-sm btn-ghost" onclick="playTrack(${index})" title="Reproducir">
                    <i class="fas fa-play"></i>
                </button>
                <button class="btn btn-sm btn-ghost" onclick="downloadTrack(${index})" title="Descargar">
                    <i class="fas fa-download"></i>
                </button>
                <button class="btn btn-sm btn-ghost" onclick="removeTrack(${index})" title="Eliminar">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;
        trackList.appendChild(trackItem);
    });
}

function updateMusicLibrary() {
    const musicGrid = document.getElementById("musicGrid");
    
    if (musicLibrary.length === 0) {
        musicGrid.innerHTML = `
            <div class="empty-library">
                <i class="fas fa-music fa-3x text-muted mb-3"></i>
                <p class="text-muted">Tu biblioteca musical está vacía</p>
                <p class="text-muted">Crea tu primera composición para comenzar</p>
            </div>
        `;
        return;
    }
    
    musicGrid.innerHTML = "";
    musicLibrary.forEach((track, index) => {
        const trackCard = document.createElement("div");
        trackCard.className = "music-card";
        trackCard.innerHTML = `
            <div class="music-card-artwork">
                <i class="fas fa-music"></i>
                <div class="play-overlay" onclick="playTrack(${index})">
                    <i class="fas fa-play"></i>
                </div>
            </div>
            <div class="music-card-info">
                <h5>${track.title}</h5>
                <p>${track.genre} • ${formatDuration(track.duration)}</p>
                <small class="text-muted">${track.timestamp.toLocaleDateString()}</small>
            </div>
            <div class="music-card-actions">
                <button class="btn btn-sm btn-outline" onclick="downloadTrack(${index})">
                    <i class="fas fa-download"></i>
                </button>
                <button class="btn btn-sm btn-ghost" onclick="removeTrack(${index})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;
        musicGrid.appendChild(trackCard);
    });
}

function downloadTrack(index) {
    const track = musicLibrary[index];
    showAlert(`Descargando: ${track.title}`, "success");
}

function removeTrack(index) {
    if (confirm("¿Estás seguro de eliminar esta composición?")) {
        musicLibrary.splice(index, 1);
        if (currentTrackIndex >= index) currentTrackIndex = Math.max(0, currentTrackIndex - 1);
        updateMusicLibrary();
        updateTrackList();
        updateMusicStats();
        showAlert("Composición eliminada", "info");
    }
}

function clearLibrary() {
    if (confirm("¿Estás seguro de eliminar toda tu biblioteca musical?")) {
        musicLibrary = [];
        currentTrackIndex = 0;
        updateMusicLibrary();
        updateTrackList();
        updateMusicStats();
        showAlert("Biblioteca musical limpiada", "info");
    }
}

function exportPlaylist() {
    if (musicLibrary.length === 0) {
        showAlert("No hay composiciones para exportar", "warning");
        return;
    }
    
    const playlist = {
        name: "Mi Playlist ObelisIA",
        created: new Date(),
        tracks: musicLibrary
    };
    
    const blob = new Blob([JSON.stringify(playlist, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement("a");
    a.href = url;
    a.download = "obelisia_playlist.json";
    a.click();
    
    URL.revokeObjectURL(url);
    showAlert("Playlist exportada", "success");
}

function formatDuration(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
}

function formatTotalDuration() {
    const total = musicLibrary.reduce((sum, track) => sum + track.duration, 0);
    return formatDuration(total);
}

function showAlert(message, type = "info") {
    const alert = document.createElement("div");
    alert.className = `alert alert-${type} position-fixed top-0 end-0 m-3`;
    alert.style.zIndex = "9999";
    alert.innerHTML = `
        <i class="fas fa-${type === "success" ? "check" : type === "warning" ? "exclamation-triangle" : "info-circle"}"></i>
        ${message}
    `;
    
    document.body.appendChild(alert);
    setTimeout(() => alert.remove(), 3000);
}

// Event listeners
document.addEventListener("DOMContentLoaded", function() {
    // Genre selector
    document.querySelectorAll(".style-option").forEach(option => {
        option.addEventListener("click", function() {
            document.querySelectorAll(".style-option").forEach(o => o.classList.remove("selected"));
            this.classList.add("selected");
            currentGenre = this.dataset.genre;
        });
    });
    
    // Range inputs
    const durationRange = document.getElementById("durationRange");
    const complexityRange = document.getElementById("complexityRange");
    
    durationRange.addEventListener("input", function() {
        document.getElementById("durationValue").textContent = this.value;
    });
    
    complexityRange.addEventListener("input", function() {
        document.getElementById("complexityValue").textContent = this.value;
    });
    
    // Volume control
    const volumeSlider = document.getElementById("volumeSlider");
    volumeSlider.addEventListener("input", function() {
        const audioPlayer = document.getElementById("audioPlayer");
        audioPlayer.volume = this.value / 100;
    });
    
    // Progress bar click
    document.getElementById("progressBar").addEventListener("click", function(e) {
        // En un entorno real, buscarías en el audio aquí
        const rect = this.getBoundingClientRect();
        const clickX = e.clientX - rect.left;
        const percentage = clickX / rect.width;
        showAlert(`Buscando al ${Math.round(percentage * 100)}%`, "info");
    });
    
    // Character counter
    document.getElementById("musicPrompt").addEventListener("input", updateCharCount);
    
    // Keyboard shortcuts
    document.addEventListener("keydown", function(e) {
        if (e.code === "Space" && e.target.tagName !== "INPUT" && e.target.tagName !== "TEXTAREA") {
            e.preventDefault();
            togglePlayback();
        }
        if (e.ctrlKey && e.key === "Enter") {
            generateMusic();
        }
    });
    
    // Seleccionar primer género por defecto
    document.querySelector(".style-option").click();
    
    // Inicializar stats
    updateMusicStats();
    updateMusicLibrary();
});

function updateCharCount() {
    const textarea = document.getElementById("musicPrompt");
    const counter = document.getElementById("charCount");
    if (textarea && counter) {
        counter.textContent = textarea.value.length;
    }
}
';

// Incluir el template base
include 'base_template.php';
