<?php // src/Tools/views/MusicComposer_view.php ?>

<link rel="stylesheet" href="<?php echo \ObelisIA\Router\MainRouter::url('assets/css/tools/ia-audio/style.css'); ?>">

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-lg-4">
            <div class="card shadow-sm h-100">
                <div class="card-body">
                    <h4 class="card-title mb-4"><i class="fas fa-sliders-h text-primary me-2"></i>Opciones de Composición</h4>

                    <div class="options-group">
                        <label for="genre-select" class="form-label fw-bold">Género Musical:</label>
                        <select id="genre-select" class="form-select">
                            <option value="cinematic">Cinematográfico</option>
                            <option value="electronic">Electrónico</option>
                            <option value="orchestral">Orquestal</option>
                            <option value="lo-fi">Lo-Fi</option>
                            <option value="rock">Rock</option>
                            <option value="pop">Pop</option>
                        </select>
                    </div>

                    <div class="options-group">
                        <label for="mood-select" class="form-label fw-bold">Ambiente:</label>
                        <select id="mood-select" class="form-select">
                            <option value="epic">Épico</option>
                            <option value="happy">Alegre</option>
                            <option value="sad">Triste</option>
                            <option value="calm">Relajante</option>
                            <option value="energetic">Enérgico</option>
                        </select>
                    </div>

                    <div class="options-group">
                        <label for="duration-slider" class="form-label fw-bold">Duración: <span id="duration-value">30s</span></label>
                        <input type="range" id="duration-slider" class="form-range" min="10" max="180" value="30">
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-8 mt-4 mt-lg-0">
            <div class="card shadow-sm text-center">
                <div class="card-body p-4 p-md-5">
                    <div class="tool-icon-header">
                        <i class="fas fa-music"></i>
                    </div>
                    <h2 class="card-title h3 mb-3">Compositor Musical con IA</h2>
                    <p class="text-muted mb-4">Describe tu idea, ajusta las opciones y deja que la IA cree una pieza musical única para ti.</p>
                    
                    <div class="mb-3">
                        <textarea id="prompt-audio" class="form-control form-control-lg" rows="4" placeholder="Ej: Una melodía de piano melancólica con el sonido de la lluvia de fondo..."></textarea>
                    </div>
                    
                    <div class="d-grid gap-2 d-md-flex justify-content-md-center">
                        <button id="improve-prompt-btn" class="btn btn-secondary">
                            <i class="fas fa-brain me-2"></i>Mejorar Prompt
                        </button>
                        <button id="generate-audio-btn" class="btn btn-primary btn-lg">
                            <i class="fas fa-magic me-2"></i>Generar Música
                        </button>
                    </div>

                    <div id="audio-player-container" class="mt-4 d-none">
                        <audio id="audio-player" controls class="w-100"></audio>
                        <a href="#" id="download-audio-link" class="btn btn-success mt-3 d-none" download>
                            <i class="fas fa-download me-2"></i>Descargar Audio
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="module" src="<?php echo \ObelisIA\Router\MainRouter::url('assets/js/tools/ia-audio/app.js'); ?>"></script>

<?php 
$premiumMessage = 'composiciones musicales más largas, mayor calidad de audio, géneros y ambientes exclusivos, y prioridad en la generación. ¡Hazte premium y lleva tu música con IA al siguiente nivel!';
include __DIR__ . '/../../../assets/banners/partials/premium_banner_for_tools.php'; 
?>