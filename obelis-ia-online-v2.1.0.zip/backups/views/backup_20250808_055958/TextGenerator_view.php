<link rel="stylesheet" href="<?php echo \ObelisIA\Router\MainRouter::url('assets/css/tools/ia-text/style.css'); ?>">

<div class="container-fluid py-4">
    <div class="row">

        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-body p-4">
                    <h2 class="card-title h4 mb-3">Asistente de Escritura con IA</h2>
                    <form id="contentForm bg-light">
                        <div id="contentTypeOptions" class="mb-3">
                            <p class="form-label">¿Qué quieres crear?</p>
                            <div class="btn-group flex-wrap" role="group">
                                <input type="radio" class="btn-check" name="contentType" id="typeStory" value="story" checked>
                                <label class="btn btn-outline-primary" for="typeStory"><i class="fas fa-book me-1"></i> Historia</label>

                                <input type="radio" class="btn-check" name="contentType" id="typeScript" value="script">
                                <label class="btn btn-outline-primary" for="typeScript"><i class="fas fa-scroll me-1"></i> Guion</label>

                                <input type="radio" class="btn-check" name="contentType" id="typePoem" value="poem">
                                <label class="btn btn-outline-primary" for="typePoem"><i class="fas fa-feather-alt me-1"></i> Poema</label>

                                <input type="radio" class="btn-check" name="contentType" id="typeSong" value="song">
                                <label class="btn btn-outline-primary" for="typeSong"><i class="fas fa-music me-1"></i> Canción</label>

                                <input type="radio" class="btn-check" name="contentType" id="typeArticle" value="article">
                                <label class="btn btn-outline-primary" for="typeArticle"><i class="fas fa-newspaper me-1"></i> Artículo</label>

                                <input type="radio" class="btn-check" name="contentType" id="typeEmail" value="email">
                                <label class="btn btn-outline-primary" for="typeEmail"><i class="fas fa-envelope me-1"></i> Email</label>

                                <input type="radio" class="btn-check" name="contentType" id="typeProductDescription" value="product_description">
                                <label class="btn btn-outline-primary" for="typeProductDescription"><i class="fas fa-tag me-1"></i> Descripción de Producto</label>

                                <input type="radio" class="btn-check" name="contentType" id="typeSummary" value="summary">
                                <label class="btn btn-outline-primary" for="typeSummary"><i class="fas fa-align-left me-1"></i> Resumen</label>

                                <input type="radio" class="btn-check" name="contentType" id="typeArgumentativeParagraph" value="argumentative_paragraph">
                                <label class="btn btn-outline-primary" for="typeArgumentativeParagraph"><i class="fas fa-paragraph me-1"></i> Párrafo Argumentativo</label>

                                <input type="radio" class="btn-check" name="contentType" id="typeRecipe" value="recipe">
                                <label class="btn btn-outline-primary" for="typeRecipe"><i class="fas fa-utensils me-1"></i> Receta</label>

                                <input type="radio" class="btn-check" name="contentType" id="typeAiPrompt" value="ai_prompt">
                                <label class="btn btn-outline-primary" for="typeAiPrompt"><i class="fas fa-robot me-1"></i> Prompt para IA</label>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="prompt" class="form-label">Describe tu idea:</label>
                            <textarea id="prompt" class="form-control" rows="5" placeholder="Ej: Una historia de ciencia ficción sobre un robot que descubre emociones..."></textarea>
                        </div>

                        <div class="row align-items-end">
                            <div class="col-md-6 mb-3">
                                <label for="toneSelect" class="form-label">Tono del contenido:</label>
                                <select id="toneSelect" class="form-select">
                                    <option value="">Neutro</option>
                                    <option value="Creativo">Creativo</option>
                                    <option value="Formal">Formal</option>
                                    <option value="Humorístico">Humorístico</option>
                                    <option value="Técnico">Técnico</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <button type="submit" id="generateButton" class="btn btn-primary btn-lg w-100">
                                    <span id="spinner" class="spinner-border spinner-border-sm me-2 d-none" role="status" aria-hidden="true"></span>
                                    <span id="buttonText">Generar Contenido</span>
                                </button>
                            </div>
                        </div>
                    </form>
                    <div class="text-center mt-2">
                         <p id="generationCounterDisplay" class="text-muted small">Generaciones disponibles hoy: --</p>
                         <button id="watchAdButton" class="btn btn-info btn-sm mt-2 d-none">Ver Anuncio para +3 Generaciones</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4 mt-4 mt-lg-0">
            <div class="card shadow-sm">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Historial de Creaciones</h5>
                    <button id="clearHistoryButton" class="btn btn-outline-danger btn-sm" title="Limpiar historial">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
                <div id="contentHistoryContainer" class="card-body">
                    <p class="text-muted text-center">No hay contenido en el historial.</p>
                </div>
            </div>
        </div>

    </div>
</div>


<div class="modal fade" id="contentModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Contenido Generado</h5>
                <button type="button" id="modalCloseButton" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="generatedText" class="p-3 bg-light rounded"></div>
            </div>
            <div class="modal-footer justify-content-between">
                 <div class="audio-controls">
                    <button id="togglePlayPauseButton" class="btn btn-light"><i id="playIcon" class="fas fa-play"></i><i id="pauseIcon" class="fas fa-pause d-none"></i></button>
                    <select id="voiceLanguage" class="form-select d-inline-block w-auto"></select>
                    <select id="voiceSelect" class="form-select d-inline-block w-auto"></select>
                </div>
                <div>
                    <button id="copyTextButton" class="btn btn-secondary"><i class="fas fa-copy me-1"></i> Copiar</button>
                    <button id="downloadPdfButton" class="btn btn-primary"><i class="fas fa-file-pdf me-1"></i> PDF</button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- jsPDF para exportar a PDF -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script type="module" src="<?php echo \ObelisIA\Router\MainRouter::url('assets/js/tools/ia-text/app.js'); ?>"></script>

<?php 
$premiumMessage = 'textos más extensos, generación ultrarrápida, tonos y estilos exclusivos, historial ampliado y prioridad en el uso de la IA. ¡Hazte premium y potencia tu creatividad al máximo!';
include __DIR__ . '/../../../assets/banners/partials/premium_banner_for_tools.php'; 
?>