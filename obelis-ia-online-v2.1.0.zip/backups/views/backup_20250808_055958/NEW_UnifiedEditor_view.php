<?php
// src/Tools/views/NEW_UnifiedEditor_view.php
use ObelisIA\Utils\Premium;

// Configuración de la herramienta
$tool_name = "Editor Unificado";
$tool_icon = "layer-group";
$tool_description = "Combina y edita todos tus contenidos en un solo lugar";
$tool_slug = "editor-unificado";
$is_premium = Premium::isPremium();
$show_history = true;
$show_export_button = true;
$show_save_button = true;

// Contenido del sidebar
$sidebar_content = '
<div class="sidebar-section">
    <div class="sidebar-header">
        <i class="fas fa-layer-group"></i> Capas
    </div>
    <div class="sidebar-content">
        <div class="layer-list" id="layerList">
            <div class="empty-layers">
                <i class="fas fa-plus-circle fa-2x text-muted mb-2"></i>
                <p class="text-muted">Agrega elementos para comenzar</p>
            </div>
        </div>
        <div class="layer-actions">
            <button class="btn btn-sm btn-primary w-100" onclick="addNewLayer()">
                <i class="fas fa-plus"></i> Nueva Capa
            </button>
        </div>
    </div>
</div>

<div class="sidebar-section">
    <div class="sidebar-header">
        <i class="fas fa-palette"></i> Herramientas
    </div>
    <div class="sidebar-content">
        <div class="tool-grid">
            <button class="tool-btn" onclick="selectTool(\'text\')" data-tool="text">
                <i class="fas fa-font"></i>
                <span>Texto</span>
            </button>
            <button class="tool-btn" onclick="selectTool(\'image\')" data-tool="image">
                <i class="fas fa-image"></i>
                <span>Imagen</span>
            </button>
            <button class="tool-btn" onclick="selectTool(\'shape\')" data-tool="shape">
                <i class="fas fa-shapes"></i>
                <span>Formas</span>
            </button>
            <button class="tool-btn" onclick="selectTool(\'brush\')" data-tool="brush">
                <i class="fas fa-paint-brush"></i>
                <span>Pincel</span>
            </button>
            <button class="tool-btn" onclick="selectTool(\'select\')" data-tool="select">
                <i class="fas fa-mouse-pointer"></i>
                <span>Selección</span>
            </button>
            <button class="tool-btn" onclick="selectTool(\'crop\')" data-tool="crop">
                <i class="fas fa-crop"></i>
                <span>Recortar</span>
            </button>
        </div>
    </div>
</div>

<div class="sidebar-section">
    <div class="sidebar-header">
        <i class="fas fa-sliders-h"></i> Propiedades
    </div>
    <div class="sidebar-content">
        <div id="propertiesPanel">
            <p class="text-muted">Selecciona un elemento para ver sus propiedades</p>
        </div>
    </div>
</div>

' . ($is_premium ? '
<div class="sidebar-section">
    <div class="sidebar-header">
        <i class="fas fa-crown"></i> Premium
    </div>
    <div class="sidebar-content">
        <div class="premium-tools">
            <button class="btn btn-sm btn-accent w-100 mb-2" onclick="applyAIEffects()">
                <i class="fas fa-magic"></i> Efectos IA
            </button>
            <button class="btn btn-sm btn-accent w-100 mb-2" onclick="autoLayout()">
                <i class="fas fa-magic"></i> Auto Layout
            </button>
            <button class="btn btn-sm btn-accent w-100" onclick="smartResize()">
                <i class="fas fa-expand-arrows-alt"></i> Redimensión Inteligente
            </button>
        </div>
    </div>
</div>
' : '
<div class="premium-feature">
    <div class="premium-badge">PRO</div>
    <div class="sidebar-content">
        <div class="text-muted">
            <p><i class="fas fa-magic"></i> Efectos IA avanzados</p>
            <p><i class="fas fa-layer-group"></i> Capas ilimitadas</p>
            <p><i class="fas fa-download"></i> Exportación HD</p>
        </div>
    </div>
</div>
');

// Contenido de la toolbar
$toolbar_content = '
<div class="toolbar-section">
    <button class="btn btn-sm btn-ghost" onclick="undo()" id="undoBtn" disabled>
        <i class="fas fa-undo"></i>
    </button>
    <button class="btn btn-sm btn-ghost" onclick="redo()" id="redoBtn" disabled>
        <i class="fas fa-redo"></i>
    </button>
</div>

<div class="toolbar-divider"></div>

<div class="toolbar-section">
    <button class="btn btn-sm btn-outline" onclick="zoomOut()">
        <i class="fas fa-search-minus"></i>
    </button>
    <span class="zoom-display" id="zoomDisplay">100%</span>
    <button class="btn btn-sm btn-outline" onclick="zoomIn()">
        <i class="fas fa-search-plus"></i>
    </button>
    <button class="btn btn-sm btn-ghost" onclick="resetZoom()">
        <i class="fas fa-expand"></i>
    </button>
</div>

<div class="toolbar-divider"></div>

<div class="toolbar-section">
    <select class="form-control form-control-sm" id="canvasSize" onchange="changeCanvasSize()">
        <option value="custom">Personalizado</option>
        <option value="1920x1080">Full HD (1920×1080)</option>
        <option value="1280x720">HD (1280×720)</option>
        <option value="1080x1080">Instagram Post (1080×1080)</option>
        <option value="1200x630">Facebook Cover (1200×630)</option>
        <option value="1024x1024">Square (1024×1024)</option>
    </select>
</div>';

// Contenido principal
$main_content = '
<div class="unified-editor-container">
    ' . ($is_premium ? '<div class="alert alert-success mb-4">
        <i class="fas fa-crown"></i>
        <strong>¡Usuario Premium!</strong> Accede a todas las herramientas, efectos IA y exportación en alta calidad.
    </div>' : '') . '
    
    <!-- Canvas principal -->
    <div class="editor-canvas-wrapper">
        <div class="canvas-container" id="canvasContainer">
            <canvas id="mainCanvas" class="editor-canvas"></canvas>
            <div class="canvas-overlay" id="canvasOverlay">
                <!-- Herramientas de selección y manipulación -->
            </div>
        </div>
        
        <!-- Herramientas flotantes -->
        <div class="floating-tools" id="floatingTools" style="display: none;">
            <div class="tool-group">
                <button class="btn btn-sm btn-primary" onclick="duplicateSelected()" title="Duplicar">
                    <i class="fas fa-copy"></i>
                </button>
                <button class="btn btn-sm btn-secondary" onclick="deleteSelected()" title="Eliminar">
                    <i class="fas fa-trash"></i>
                </button>
                <button class="btn btn-sm btn-accent" onclick="bringToFront()" title="Al frente">
                    <i class="fas fa-angle-up"></i>
                </button>
                <button class="btn btn-sm btn-accent" onclick="sendToBack()" title="Atrás">
                    <i class="fas fa-angle-down"></i>
                </button>
            </div>
        </div>
    </div>
    
    <!-- Área de recursos y elementos -->
    <div class="resources-panel" id="resourcesPanel" style="display: none;">
        <div class="panel-header">
            <h4><i class="fas fa-folder"></i> Recursos</h4>
            <button class="btn btn-sm btn-ghost" onclick="toggleResourcesPanel()">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="panel-content">
            <div class="resource-tabs">
                <button class="resource-tab active" onclick="switchResourceTab(\'images\')">
                    <i class="fas fa-image"></i> Imágenes
                </button>
                <button class="resource-tab" onclick="switchResourceTab(\'shapes\')">
                    <i class="fas fa-shapes"></i> Formas
                </button>
                <button class="resource-tab" onclick="switchResourceTab(\'templates\')">
                    <i class="fas fa-layer-group"></i> Plantillas
                </button>
            </div>
            
            <div class="resource-content" id="resourceContent">
                <!-- Contenido de recursos -->
            </div>
        </div>
    </div>
</div>

<!-- Modal de exportación -->
<div class="modal" id="exportModal" style="display: none;">
    <div class="modal-overlay" onclick="closeExportModal()"></div>
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-download"></i> Exportar Creación</h3>
            <button class="btn btn-ghost" onclick="closeExportModal()">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="modal-body">
            <div class="export-options">
                <div class="option-group">
                    <label class="form-label">Formato</label>
                    <div class="format-selector">
                        <label class="format-option">
                            <input type="radio" name="format" value="png" checked>
                            <span>PNG (Transparencia)</span>
                        </label>
                        <label class="format-option">
                            <input type="radio" name="format" value="jpg">
                            <span>JPG (Menor tamaño)</span>
                        </label>
                        <label class="format-option">
                            <input type="radio" name="format" value="svg">
                            <span>SVG (Vectorial)</span>
                        </label>
                        ' . ($is_premium ? '
                        <label class="format-option">
                            <input type="radio" name="format" value="pdf">
                            <span>PDF (Premium)</span>
                        </label>' : '') . '
                    </div>
                </div>
                
                <div class="option-group">
                    <label class="form-label">Calidad</label>
                    <div class="quality-selector">
                        <label class="quality-option">
                            <input type="radio" name="quality" value="web">
                            <span>Web (Rápida)</span>
                        </label>
                        <label class="quality-option">
                            <input type="radio" name="quality" value="print" checked>
                            <span>Impresión (Recomendada)</span>
                        </label>
                        ' . ($is_premium ? '
                        <label class="quality-option">
                            <input type="radio" name="quality" value="ultra">
                            <span>Ultra HD (Premium)</span>
                        </label>' : '') . '
                    </div>
                </div>
                
                <div class="option-group">
                    <label class="form-label">Tamaño Personalizado (opcional)</label>
                    <div class="size-inputs">
                        <input type="number" class="form-control" placeholder="Ancho" id="exportWidth">
                        <span>×</span>
                        <input type="number" class="form-control" placeholder="Alto" id="exportHeight">
                        <span>px</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeExportModal()">
                Cancelar
            </button>
            <button class="btn btn-primary" onclick="startExport()">
                <i class="fas fa-download"></i>
                Exportar
            </button>
        </div>
    </div>
</div>';

// Contenido de ayuda
$help_content = '
<div class="help-section">
    <h4><i class="fas fa-layer-group"></i> Cómo usar el Editor Unificado</h4>
    <ol>
        <li><strong>Agrega elementos:</strong> Usa las herramientas del sidebar para añadir texto, imágenes, formas</li>
        <li><strong>Organiza en capas:</strong> Gestiona la superposición y organización de elementos</li>
        <li><strong>Edita propiedades:</strong> Selecciona elementos para modificar color, tamaño, posición</li>
        <li><strong>Aplica efectos:</strong> Usa filtros y transformaciones para mejorar tu diseño</li>
        <li><strong>Exporta:</strong> Guarda tu creación en el formato que necesites</li>
    </ol>
    
    <h5><i class="fas fa-keyboard"></i> Atajos de Teclado:</h5>
    <ul>
        <li><kbd>Ctrl + Z</kbd> - Deshacer</li>
        <li><kbd>Ctrl + Y</kbd> - Rehacer</li>
        <li><kbd>Ctrl + C</kbd> - Copiar</li>
        <li><kbd>Ctrl + V</kbd> - Pegar</li>
        <li><kbd>Delete</kbd> - Eliminar selección</li>
        <li><kbd>Ctrl + S</kbd> - Guardar proyecto</li>
        <li><kbd>Ctrl + E</kbd> - Exportar</li>
    </ul>
    
    <h5><i class="fas fa-crown"></i> Funciones Premium:</h5>
    <ul>
        <li>Efectos IA automáticos para mejorar diseños</li>
        <li>Auto-layout inteligente</li>
        <li>Redimensión automática para diferentes plataformas</li>
        <li>Exportación en ultra alta definición</li>
        <li>Plantillas profesionales exclusivas</li>
    </ul>
</div>';

// JavaScript específico
$inline_js = '
let canvas, ctx;
let elements = [];
let selectedElement = null;
let currentTool = "select";
let isDrawing = false;
let startX, startY;
let history = [];
let historyStep = -1;
let zoom = 1;
let panX = 0, panY = 0;

// Configuración del canvas
const canvasConfig = {
    width: 1920,
    height: 1080,
    backgroundColor: "#ffffff"
};

// Inicializar editor
function initializeEditor() {
    canvas = document.getElementById("mainCanvas");
    ctx = canvas.getContext("2d");
    
    // Configurar canvas
    setupCanvas();
    
    // Event listeners
    setupEventListeners();
    
    // Herramientas
    selectTool("select");
    
    // Estado inicial
    saveState();
    
    showAlert("Editor unificado listo para usar", "success");
}

function setupCanvas() {
    canvas.width = canvasConfig.width;
    canvas.height = canvasConfig.height;
    
    // Fondo
    ctx.fillStyle = canvasConfig.backgroundColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Ajustar tamaño visual
    resizeCanvasView();
}

function resizeCanvasView() {
    const container = document.getElementById("canvasContainer");
    const containerWidth = container.clientWidth - 40;
    const containerHeight = container.clientHeight - 40;
    
    const scaleX = containerWidth / canvasConfig.width;
    const scaleY = containerHeight / canvasConfig.height;
    const scale = Math.min(scaleX, scaleY, 1);
    
    canvas.style.width = (canvasConfig.width * scale) + "px";
    canvas.style.height = (canvasConfig.height * scale) + "px";
    
    zoom = scale;
    updateZoomDisplay();
}

function setupEventListeners() {
    // Canvas events
    canvas.addEventListener("mousedown", handleMouseDown);
    canvas.addEventListener("mousemove", handleMouseMove);
    canvas.addEventListener("mouseup", handleMouseUp);
    canvas.addEventListener("wheel", handleWheel);
    
    // Keyboard shortcuts
    document.addEventListener("keydown", handleKeyDown);
    
    // Window resize
    window.addEventListener("resize", resizeCanvasView);
    
    // File drop
    canvas.addEventListener("dragover", handleDragOver);
    canvas.addEventListener("drop", handleFileDrop);
}

function handleMouseDown(e) {
    const rect = canvas.getBoundingClientRect();
    startX = (e.clientX - rect.left) / zoom;
    startY = (e.clientY - rect.top) / zoom;
    
    if (currentTool === "select") {
        selectedElement = findElementAt(startX, startY);
        updateFloatingTools();
        updatePropertiesPanel();
    } else if (currentTool === "text") {
        addTextElement(startX, startY);
    } else if (currentTool === "shape") {
        startDrawingShape(startX, startY);
    }
    
    isDrawing = true;
    redrawCanvas();
}

function handleMouseMove(e) {
    if (!isDrawing) return;
    
    const rect = canvas.getBoundingClientRect();
    const currentX = (e.clientX - rect.left) / zoom;
    const currentY = (e.clientY - rect.top) / zoom;
    
    if (currentTool === "select" && selectedElement) {
        // Mover elemento seleccionado
        selectedElement.x = currentX - (selectedElement.width / 2);
        selectedElement.y = currentY - (selectedElement.height / 2);
        redrawCanvas();
    } else if (currentTool === "brush") {
        drawBrushStroke(currentX, currentY);
    }
}

function handleMouseUp(e) {
    if (isDrawing) {
        isDrawing = false;
        saveState();
        updateLayerList();
    }
}

function handleWheel(e) {
    e.preventDefault();
    const zoomFactor = e.deltaY > 0 ? 0.9 : 1.1;
    adjustZoom(zoomFactor);
}

function handleKeyDown(e) {
    if (e.ctrlKey) {
        switch (e.key) {
            case "z":
                e.preventDefault();
                undo();
                break;
            case "y":
                e.preventDefault();
                redo();
                break;
            case "c":
                e.preventDefault();
                copySelected();
                break;
            case "v":
                e.preventDefault();
                pasteSelected();
                break;
            case "s":
                e.preventDefault();
                saveWork();
                break;
            case "e":
                e.preventDefault();
                exportWork();
                break;
        }
    } else if (e.key === "Delete" && selectedElement) {
        deleteSelected();
    }
}

function handleDragOver(e) {
    e.preventDefault();
    canvas.classList.add("drag-over");
}

function handleFileDrop(e) {
    e.preventDefault();
    canvas.classList.remove("drag-over");
    
    const files = Array.from(e.dataTransfer.files);
    files.forEach(file => {
        if (file.type.startsWith("image/")) {
            loadImageFile(file);
        }
    });
}

// Herramientas
function selectTool(tool) {
    currentTool = tool;
    
    // Actualizar UI
    document.querySelectorAll(".tool-btn").forEach(btn => {
        btn.classList.remove("active");
    });
    document.querySelector(`[data-tool="${tool}"]`).classList.add("active");
    
    // Cambiar cursor
    canvas.style.cursor = getCursorForTool(tool);
    
    showAlert(`Herramienta seleccionada: ${getToolName(tool)}`, "info");
}

function getCursorForTool(tool) {
    const cursors = {
        select: "default",
        text: "text",
        image: "crosshair",
        shape: "crosshair",
        brush: "crosshair",
        crop: "crosshair"
    };
    return cursors[tool] || "default";
}

function getToolName(tool) {
    const names = {
        select: "Selección",
        text: "Texto",
        image: "Imagen",
        shape: "Formas",
        brush: "Pincel",
        crop: "Recortar"
    };
    return names[tool] || tool;
}

// Elementos
function addTextElement(x, y) {
    const text = prompt("Ingresa el texto:");
    if (!text) return;
    
    const element = {
        id: Date.now(),
        type: "text",
        content: text,
        x: x,
        y: y,
        width: 200,
        height: 40,
        fontSize: 24,
        fontFamily: "Arial",
        color: "#000000",
        rotation: 0,
        opacity: 1
    };
    
    elements.push(element);
    selectedElement = element;
    redrawCanvas();
    updateLayerList();
    updatePropertiesPanel();
}

function loadImageFile(file) {
    const reader = new FileReader();
    reader.onload = function(e) {
        const img = new Image();
        img.onload = function() {
            const element = {
                id: Date.now(),
                type: "image",
                content: img,
                x: 100,
                y: 100,
                width: Math.min(img.width, 400),
                height: Math.min(img.height, 400),
                rotation: 0,
                opacity: 1
            };
            
            elements.push(element);
            selectedElement = element;
            redrawCanvas();
            updateLayerList();
            updatePropertiesPanel();
        };
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
}

function startDrawingShape(x, y) {
    const shapeType = prompt("Tipo de forma (rectangle, circle, triangle):", "rectangle");
    if (!shapeType) return;
    
    const element = {
        id: Date.now(),
        type: "shape",
        shapeType: shapeType,
        x: x,
        y: y,
        width: 100,
        height: 100,
        fillColor: "#3498db",
        strokeColor: "#2980b9",
        strokeWidth: 2,
        rotation: 0,
        opacity: 1
    };
    
    elements.push(element);
    selectedElement = element;
    redrawCanvas();
    updateLayerList();
    updatePropertiesPanel();
}

function drawBrushStroke(x, y) {
    if (!selectedElement || selectedElement.type !== "brush") {
        selectedElement = {
            id: Date.now(),
            type: "brush",
            strokes: [],
            color: "#000000",
            width: 5,
            opacity: 1
        };
        elements.push(selectedElement);
    }
    
    selectedElement.strokes.push({ x, y });
    redrawCanvas();
}

// Renderizado
function redrawCanvas() {
    // Limpiar canvas
    ctx.fillStyle = canvasConfig.backgroundColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Dibujar elementos
    elements.forEach(element => {
        drawElement(element);
    });
    
    // Dibujar selección
    if (selectedElement) {
        drawSelectionBox(selectedElement);
    }
}

function drawElement(element) {
    ctx.save();
    
    // Aplicar transformaciones
    ctx.globalAlpha = element.opacity;
    
    if (element.rotation) {
        ctx.translate(element.x + element.width / 2, element.y + element.height / 2);
        ctx.rotate(element.rotation * Math.PI / 180);
        ctx.translate(-(element.x + element.width / 2), -(element.y + element.height / 2));
    }
    
    switch (element.type) {
        case "text":
            drawTextElement(element);
            break;
        case "image":
            drawImageElement(element);
            break;
        case "shape":
            drawShapeElement(element);
            break;
        case "brush":
            drawBrushElement(element);
            break;
    }
    
    ctx.restore();
}

function drawTextElement(element) {
    ctx.font = `${element.fontSize}px ${element.fontFamily}`;
    ctx.fillStyle = element.color;
    ctx.textBaseline = "top";
    ctx.fillText(element.content, element.x, element.y);
}

function drawImageElement(element) {
    if (element.content.complete) {
        ctx.drawImage(element.content, element.x, element.y, element.width, element.height);
    }
}

function drawShapeElement(element) {
    ctx.fillStyle = element.fillColor;
    ctx.strokeStyle = element.strokeColor;
    ctx.lineWidth = element.strokeWidth;
    
    switch (element.shapeType) {
        case "rectangle":
            ctx.fillRect(element.x, element.y, element.width, element.height);
            ctx.strokeRect(element.x, element.y, element.width, element.height);
            break;
        case "circle":
            ctx.beginPath();
            ctx.ellipse(
                element.x + element.width / 2,
                element.y + element.height / 2,
                element.width / 2,
                element.height / 2,
                0, 0, 2 * Math.PI
            );
            ctx.fill();
            ctx.stroke();
            break;
    }
}

function drawBrushElement(element) {
    if (element.strokes.length < 2) return;
    
    ctx.strokeStyle = element.color;
    ctx.lineWidth = element.width;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    
    ctx.beginPath();
    ctx.moveTo(element.strokes[0].x, element.strokes[0].y);
    
    for (let i = 1; i < element.strokes.length; i++) {
        ctx.lineTo(element.strokes[i].x, element.strokes[i].y);
    }
    
    ctx.stroke();
}

function drawSelectionBox(element) {
    const padding = 5;
    ctx.strokeStyle = "#007bff";
    ctx.lineWidth = 2;
    ctx.setLineDash([5, 5]);
    ctx.strokeRect(
        element.x - padding,
        element.y - padding,
        element.width + padding * 2,
        element.height + padding * 2
    );
    ctx.setLineDash([]);
}

// Utilidades
function findElementAt(x, y) {
    // Buscar desde el último elemento (más arriba)
    for (let i = elements.length - 1; i >= 0; i--) {
        const element = elements[i];
        if (x >= element.x && x <= element.x + element.width &&
            y >= element.y && y <= element.y + element.height) {
            return element;
        }
    }
    return null;
}

function saveState() {
    historyStep++;
    if (historyStep < history.length) {
        history.length = historyStep;
    }
    history.push(JSON.stringify(elements));
    
    // Limitar historial
    if (history.length > 50) {
        history.shift();
        historyStep--;
    }
    
    updateUndoRedoButtons();
}

function undo() {
    if (historyStep > 0) {
        historyStep--;
        elements = JSON.parse(history[historyStep]);
        selectedElement = null;
        redrawCanvas();
        updateLayerList();
        updateUndoRedoButtons();
        showAlert("Deshecho", "info");
    }
}

function redo() {
    if (historyStep < history.length - 1) {
        historyStep++;
        elements = JSON.parse(history[historyStep]);
        selectedElement = null;
        redrawCanvas();
        updateLayerList();
        updateUndoRedoButtons();
        showAlert("Rehecho", "info");
    }
}

function updateUndoRedoButtons() {
    document.getElementById("undoBtn").disabled = historyStep <= 0;
    document.getElementById("redoBtn").disabled = historyStep >= history.length - 1;
}

// UI Updates
function updateLayerList() {
    const layerList = document.getElementById("layerList");
    
    if (elements.length === 0) {
        layerList.innerHTML = `
            <div class="empty-layers">
                <i class="fas fa-plus-circle fa-2x text-muted mb-2"></i>
                <p class="text-muted">Agrega elementos para comenzar</p>
            </div>
        `;
        return;
    }
    
    layerList.innerHTML = "";
    elements.forEach((element, index) => {
        const layerItem = document.createElement("div");
        layerItem.className = `layer-item ${element === selectedElement ? "active" : ""}`;
        layerItem.innerHTML = `
            <div class="layer-preview">
                <i class="fas fa-${getElementIcon(element.type)}"></i>
            </div>
            <div class="layer-info">
                <div class="layer-name">${getElementName(element)}</div>
                <div class="layer-type">${element.type}</div>
            </div>
            <div class="layer-actions">
                <button class="btn btn-sm btn-ghost" onclick="toggleElementVisibility(${index})">
                    <i class="fas fa-eye${element.visible === false ? "-slash" : ""}"></i>
                </button>
                <button class="btn btn-sm btn-ghost" onclick="removeElement(${index})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;
        
        layerItem.addEventListener("click", () => {
            selectedElement = element;
            updateLayerList();
            updatePropertiesPanel();
            updateFloatingTools();
            redrawCanvas();
        });
        
        layerList.appendChild(layerItem);
    });
}

function getElementIcon(type) {
    const icons = {
        text: "font",
        image: "image",
        shape: "shapes",
        brush: "paint-brush"
    };
    return icons[type] || "layer-group";
}

function getElementName(element) {
    switch (element.type) {
        case "text":
            return element.content.substring(0, 20) || "Texto";
        case "image":
            return "Imagen";
        case "shape":
            return element.shapeType || "Forma";
        case "brush":
            return "Trazo";
        default:
            return "Elemento";
    }
}

function updatePropertiesPanel() {
    const panel = document.getElementById("propertiesPanel");
    
    if (!selectedElement) {
        panel.innerHTML = "<p class=\"text-muted\">Selecciona un elemento para ver sus propiedades</p>";
        return;
    }
    
    let html = `<h5>${getElementName(selectedElement)}</h5>`;
    
    // Propiedades comunes
    html += `
        <div class="property-group">
            <label class="form-label">Posición</label>
            <div class="property-row">
                <input type="number" class="form-control form-control-sm" value="${Math.round(selectedElement.x)}" 
                       onchange="updateElementProperty(\'x\', parseFloat(this.value))">
                <input type="number" class="form-control form-control-sm" value="${Math.round(selectedElement.y)}" 
                       onchange="updateElementProperty(\'y\', parseFloat(this.value))">
            </div>
        </div>
        
        <div class="property-group">
            <label class="form-label">Tamaño</label>
            <div class="property-row">
                <input type="number" class="form-control form-control-sm" value="${Math.round(selectedElement.width)}" 
                       onchange="updateElementProperty(\'width\', parseFloat(this.value))">
                <input type="number" class="form-control form-control-sm" value="${Math.round(selectedElement.height)}" 
                       onchange="updateElementProperty(\'height\', parseFloat(this.value))">
            </div>
        </div>
        
        <div class="property-group">
            <label class="form-label">Opacidad</label>
            <input type="range" class="form-control-range" min="0" max="1" step="0.1" value="${selectedElement.opacity}" 
                   onchange="updateElementProperty(\'opacity\', parseFloat(this.value))">
        </div>
    `;
    
    // Propiedades específicas por tipo
    if (selectedElement.type === "text") {
        html += `
            <div class="property-group">
                <label class="form-label">Texto</label>
                <textarea class="form-control form-control-sm" onchange="updateElementProperty(\'content\', this.value)">${selectedElement.content}</textarea>
            </div>
            
            <div class="property-group">
                <label class="form-label">Tamaño de Fuente</label>
                <input type="number" class="form-control form-control-sm" value="${selectedElement.fontSize}" 
                       onchange="updateElementProperty(\'fontSize\', parseFloat(this.value))">
            </div>
            
            <div class="property-group">
                <label class="form-label">Color</label>
                <input type="color" class="form-control form-control-color" value="${selectedElement.color}" 
                       onchange="updateElementProperty(\'color\', this.value)">
            </div>
        `;
    } else if (selectedElement.type === "shape") {
        html += `
            <div class="property-group">
                <label class="form-label">Color de Relleno</label>
                <input type="color" class="form-control form-control-color" value="${selectedElement.fillColor}" 
                       onchange="updateElementProperty(\'fillColor\', this.value)">
            </div>
            
            <div class="property-group">
                <label class="form-label">Color de Borde</label>
                <input type="color" class="form-control form-control-color" value="${selectedElement.strokeColor}" 
                       onchange="updateElementProperty(\'strokeColor\', this.value)">
            </div>
        `;
    }
    
    panel.innerHTML = html;
}

function updateElementProperty(property, value) {
    if (selectedElement) {
        selectedElement[property] = value;
        redrawCanvas();
        saveState();
    }
}

function updateFloatingTools() {
    const floatingTools = document.getElementById("floatingTools");
    floatingTools.style.display = selectedElement ? "block" : "none";
}

// Zoom y navegación
function zoomIn() {
    adjustZoom(1.2);
}

function zoomOut() {
    adjustZoom(0.8);
}

function resetZoom() {
    zoom = 1;
    resizeCanvasView();
}

function adjustZoom(factor) {
    zoom *= factor;
    zoom = Math.max(0.1, Math.min(5, zoom));
    
    canvas.style.width = (canvasConfig.width * zoom) + "px";
    canvas.style.height = (canvasConfig.height * zoom) + "px";
    
    updateZoomDisplay();
}

function updateZoomDisplay() {
    document.getElementById("zoomDisplay").textContent = Math.round(zoom * 100) + "%";
}

// Acciones de elementos
function duplicateSelected() {
    if (!selectedElement) return;
    
    const newElement = JSON.parse(JSON.stringify(selectedElement));
    newElement.id = Date.now();
    newElement.x += 20;
    newElement.y += 20;
    
    elements.push(newElement);
    selectedElement = newElement;
    
    redrawCanvas();
    updateLayerList();
    saveState();
    showAlert("Elemento duplicado", "success");
}

function deleteSelected() {
    if (!selectedElement) return;
    
    const index = elements.indexOf(selectedElement);
    if (index > -1) {
        elements.splice(index, 1);
        selectedElement = null;
        
        redrawCanvas();
        updateLayerList();
        updatePropertiesPanel();
        updateFloatingTools();
        saveState();
        showAlert("Elemento eliminado", "info");
    }
}

function bringToFront() {
    if (!selectedElement) return;
    
    const index = elements.indexOf(selectedElement);
    if (index > -1 && index < elements.length - 1) {
        elements.splice(index, 1);
        elements.push(selectedElement);
        
        redrawCanvas();
        updateLayerList();
        saveState();
        showAlert("Elemento al frente", "info");
    }
}

function sendToBack() {
    if (!selectedElement) return;
    
    const index = elements.indexOf(selectedElement);
    if (index > 0) {
        elements.splice(index, 1);
        elements.unshift(selectedElement);
        
        redrawCanvas();
        updateLayerList();
        saveState();
        showAlert("Elemento atrás", "info");
    }
}

// Exportación
function exportWork() {
    document.getElementById("exportModal").style.display = "flex";
}

function closeExportModal() {
    document.getElementById("exportModal").style.display = "none";
}

function startExport() {
    const format = document.querySelector("input[name=\"format\"]:checked").value;
    const quality = document.querySelector("input[name=\"quality\"]:checked").value;
    
    // Crear canvas temporal para exportación
    const exportCanvas = document.createElement("canvas");
    const exportCtx = exportCanvas.getContext("2d");
    
    // Configurar tamaño de exportación
    let exportWidth = canvasConfig.width;
    let exportHeight = canvasConfig.height;
    
    const customWidth = document.getElementById("exportWidth").value;
    const customHeight = document.getElementById("exportHeight").value;
    
    if (customWidth && customHeight) {
        exportWidth = parseInt(customWidth);
        exportHeight = parseInt(customHeight);
    }
    
    exportCanvas.width = exportWidth;
    exportCanvas.height = exportHeight;
    
    // Escalar contenido si es necesario
    const scaleX = exportWidth / canvasConfig.width;
    const scaleY = exportHeight / canvasConfig.height;
    exportCtx.scale(scaleX, scaleY);
    
    // Renderizar elementos
    exportCtx.fillStyle = canvasConfig.backgroundColor;
    exportCtx.fillRect(0, 0, canvasConfig.width, canvasConfig.height);
    
    elements.forEach(element => {
        const originalCtx = ctx;
        ctx = exportCtx;
        drawElement(element);
        ctx = originalCtx;
    });
    
    // Descargar
    const fileName = `obelisia_creation_${Date.now()}.${format}`;
    
    if (format === "png" || format === "jpg") {
        exportCanvas.toBlob(blob => {
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = fileName;
            a.click();
            URL.revokeObjectURL(url);
        }, `image/${format === "jpg" ? "jpeg" : format}`, quality === "ultra" ? 1 : 0.9);
    }
    
    closeExportModal();
    showAlert(`Exportando como ${format.toUpperCase()}`, "success");
}

// Funciones globales requeridas por el template
function generateContent() {
    showAlert("Use las herramientas del sidebar para crear contenido", "info");
}

function saveWork() {
    const projectData = {
        elements: elements,
        config: canvasConfig,
        timestamp: new Date()
    };
    
    const blob = new Blob([JSON.stringify(projectData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement("a");
    a.href = url;
    a.download = `obelisia_project_${Date.now()}.json`;
    a.click();
    
    URL.revokeObjectURL(url);
    showAlert("Proyecto guardado", "success");
}

function addNewLayer() {
    const layerTypes = ["text", "shape", "image"];
    const type = layerTypes[Math.floor(Math.random() * layerTypes.length)];
    
    switch (type) {
        case "text":
            addTextElement(canvas.width / 2, canvas.height / 2);
            break;
        case "shape":
            startDrawingShape(canvas.width / 2, canvas.height / 2);
            break;
        case "image":
            document.createElement("input").type = "file";
            const input = document.createElement("input");
            input.type = "file";
            input.accept = "image/*";
            input.onchange = e => {
                if (e.target.files[0]) {
                    loadImageFile(e.target.files[0]);
                }
            };
            input.click();
            break;
    }
}

function showAlert(message, type = "info") {
    const alert = document.createElement("div");
    alert.className = `alert alert-${type} position-fixed top-0 end-0 m-3`;
    alert.style.zIndex = "9999";
    alert.innerHTML = `
        <i class="fas fa-${type === "success" ? "check" : type === "warning" ? "exclamation-triangle" : "info-circle"}"></i>
        ${message}
    `;
    
    document.body.appendChild(alert);
    setTimeout(() => alert.remove(), 3000);
}

// Inicializar cuando el DOM esté listo
document.addEventListener("DOMContentLoaded", function() {
    initializeEditor();
});
';

// Incluir el template base
include 'base_template.php';
