    <!-- Fonts and icons -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo \ObelisIA\Router\MainRouter::url('assets/css/tools/bg-remover/style.css'); ?>">

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10 col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title mb-0"><i class="material-icons-round me-2">auto_fix_high</i>Removedor de Fondo Profesional</h4>
                        <p class="mb-0">Sube una imagen, haz clic en el color de fondo que quieres eliminar y ¡listo!</p>
                    </div>
                    <div class="card-body p-4">
                        <!-- Input Controls -->
                        <div class="row align-items-end mb-4">
                            <div class="col-md-5 mb-3 mb-md-0">
                                <label for="imageLoader" class="form-label">1. Elige un archivo de imagen</label>
                                <input type="file" id="imageLoader" class="form-control" accept="image/*">
                            </div>
                            <div class="col-md-3 mb-3 mb-md-0">
                                <label class="form-label">2. Elige el color</label>
                                <div class="color-picker-group">
                                    <div id="colorPreview"></div>
                                    <small id="colorHelp" class="form-text text-muted">Haz clic en la imagen original</small>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3 mb-md-0">
                                <label for="tolerance" class="form-label">3. Ajusta la Tolerancia: <span id="toleranceValue">20</span></label>
                                <input type="range" class="form-range" min="0" max="255" id="tolerance" value="20">
                            </div>
                        </div>
                         <div class="row mb-4">
                             <div class="col-12 d-grid">
                                <button id="removeBgBtn" class="btn btn-primary btn-lg" disabled>
                                    <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                                    <i class="material-icons-round me-1" style="font-size: 1.2rem; vertical-align: middle;">cut</i>
                                    <span class="button-text">Quitar Fondo</span>
                                </button>
                            </div>
                         </div>

                        <!-- Canvases -->
                        <div class="row">
                            <div class="col-md-6">
                                <h5 class="text-center mb-2">Imagen Original</h5>
                                <div class="canvas-container">
                                    <canvas id="originalCanvas"></canvas>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <h5 class="text-center mb-2">Resultado</h5>
                                <div class="canvas-container">
                                    <canvas id="resultCanvas"></canvas>
                                </div>
                            </div>
                        </div>

                        <!-- Download Button -->
                        <div class="row mt-4">
                            <div class="col-12 text-center">
                                <button id="downloadBtn" class="btn btn-secondary" disabled>
                                   <i class="material-icons-round me-1" style="font-size: 1.2rem;">download</i>Descargar Resultado
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Web Worker Script -->
    <script id="worker" type="javascript/worker">
        self.onmessage = function(e) {
            const { imageData, targetColor, tolerance } = e.data;
            const data = imageData.data;

            if (!targetColor) {
                // If no color is selected, do nothing.
                self.postMessage(imageData);
                return;
            }

            const { r: bgR, g: bgG, b: bgB } = targetColor;

            for (let i = 0; i < data.length; i += 4) {
                const r = data[i];
                const g = data[i + 1];
                const b = data[i + 2];

                // Calculate the Euclidean distance in the RGB color space
                const distance = Math.sqrt(
                    Math.pow(r - bgR, 2) +
                    Math.pow(g - bgG, 2) +
                    Math.pow(b - bgB, 2)
                );

                // If the color is within the tolerance, make it transparent
                if (distance < tolerance) {
                    data[i + 3] = 0; // Set Alpha to 0
                }
            }
            // Send the modified image data back to the main thread
            self.postMessage(imageData);
        };
    </script>
    <script src="<?php echo \ObelisIA\Router\MainRouter::url('assets/js/tools/bg-remover/app.js'); ?>"></script>
</html>

<?php 
$premiumMessage = 'Elimina fondos en imágenes de alta resolución, sin marcas de agua y con prioridad en el procesamiento. Accede a herramientas avanzadas de edición y descarga ilimitada. ¡Hazte premium y optimiza tu flujo de trabajo creativo!';
include __DIR__ . '/../../../assets/banners/partials/premium_banner_for_tools.php'; 
?>
