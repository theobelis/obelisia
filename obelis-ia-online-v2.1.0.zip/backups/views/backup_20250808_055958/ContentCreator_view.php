<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Creador de Creaciones - ObelisIA</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Quill Editor CSS -->
    <link href="https://cdn.quilljs.com/1.3.7/quill.snow.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo \ObelisIA\Router\MainRouter::url('assets/css/tools/content-creator/style.css'); ?>">
</head>
<body>
    <div class="content-creator-container">
        <!-- Header con toolbar -->
        <div class="creator-header">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <div class="creator-title">
                            <i class="fas fa-file-alt me-2"></i>
                            <span>Creador de Creaciones</span>
                        </div>
                    </div>
                    <div class="col-md-6 text-end">
                        <div class="creator-actions">
                            <button id="saveBtn" class="btn btn-success btn-sm">
                                <i class="fas fa-save me-1"></i>Guardar
                            </button>
                            <button id="publishBtn" class="btn btn-primary btn-sm">
                                <i class="fas fa-share me-1"></i>Publicar
                            </button>
                            <button id="previewBtn" class="btn btn-outline-secondary btn-sm">
                                <i class="fas fa-eye me-1"></i>Vista Previa
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="creator-body">
            <div class="container-fluid h-100">
                <div class="row h-100">
                    <!-- Sidebar izquierdo -->
                    <div class="col-md-2 creator-sidebar">
                        <div class="sidebar-section">
                            <h6><i class="fas fa-cogs me-2"></i>Herramientas</h6>
                            <div class="tool-buttons">
                                <button class="btn btn-outline-primary btn-sm w-100 mb-2" id="addHeadingBtn">
                                    <i class="fas fa-heading me-1"></i>Título
                                </button>
                                <button class="btn btn-outline-primary btn-sm w-100 mb-2" id="addImageBtn">
                                    <i class="fas fa-image me-1"></i>Imagen
                                </button>
                                <button class="btn btn-outline-primary btn-sm w-100 mb-2" id="addVideoBtn">
                                    <i class="fas fa-video me-1"></i>Video
                                </button>
                                <button class="btn btn-outline-primary btn-sm w-100 mb-2" id="addQuoteBtn">
                                    <i class="fas fa-quote-left me-1"></i>Cita
                                </button>
                                <button class="btn btn-outline-primary btn-sm w-100 mb-2" id="addDividerBtn">
                                    <i class="fas fa-minus me-1"></i>Separador
                                </button>
                                <button class="btn btn-outline-primary btn-sm w-100 mb-2" id="addGalleryBtn">
                                    <i class="fas fa-images me-1"></i>Galería
                                </button>
                            </div>
                        </div>

                        <div class="sidebar-section">
                            <h6><i class="fas fa-palette me-2"></i>Estilo</h6>
                            <div class="style-controls">
                                <label class="form-label">Tema:</label>
                                <select class="form-select form-select-sm mb-3" id="themeSelector">
                                    <option value="default">Por defecto</option>
                                    <option value="minimal">Minimalista</option>
                                    <option value="elegant">Elegante</option>
                                    <option value="dark">Oscuro</option>
                                </select>

                                <label class="form-label">Fuente:</label>
                                <select class="form-select form-select-sm mb-3" id="fontSelector">
                                    <option value="default">Por defecto</option>
                                    <option value="serif">Serif</option>
                                    <option value="sans-serif">Sans Serif</option>
                                    <option value="monospace">Monospace</option>
                                </select>
                            </div>
                        </div>

                        <div class="sidebar-section">
                            <h6><i class="fas fa-folder me-2"></i>Mis Recursos</h6>
                            <div id="userResources" class="user-resources">
                                <div class="text-muted small">Cargando recursos...</div>
                            </div>
                        </div>
                    </div>

                    <!-- Área principal del editor -->
                    <div class="col-md-8 creator-main">
                        <div class="editor-container">
                            <!-- Metadata de la creación -->
                            <div class="creation-metadata">
                                <input type="text" id="creationTitle" class="form-control form-control-lg mb-3" 
                                       placeholder="Título de tu creación..." maxlength="100">
                                <textarea id="creationDescription" class="form-control mb-3" rows="2" 
                                         placeholder="Descripción breve..." maxlength="300"></textarea>
                                <div class="metadata-tags">
                                    <input type="text" id="creationTags" class="form-control form-control-sm" 
                                           placeholder="Etiquetas (separadas por comas)">
                                </div>
                            </div>

                            <!-- Editor de contenido -->
                            <div class="content-editor">
                                <div id="editor-toolbar" class="editor-toolbar"></div>
                                <div id="editor-content" class="editor-content">
                                    <p>Comienza a escribir tu creación aquí...</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Sidebar derecho -->
                    <div class="col-md-2 creator-sidebar-right">
                        <div class="sidebar-section">
                            <h6><i class="fas fa-cog me-2"></i>Configuración</h6>
                            <div class="config-controls">
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" id="enableComments" checked>
                                    <label class="form-check-label" for="enableComments">
                                        Permitir comentarios
                                    </label>
                                </div>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" id="enableSharing" checked>
                                    <label class="form-check-label" for="enableSharing">
                                        Permitir compartir
                                    </label>
                                </div>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" id="showAuthor" checked>
                                    <label class="form-check-label" for="showAuthor">
                                        Mostrar autor
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="sidebar-section">
                            <h6><i class="fas fa-eye me-2"></i>Visibilidad</h6>
                            <div class="visibility-controls">
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="radio" name="visibility" id="private" value="private" checked>
                                    <label class="form-check-label" for="private">
                                        <i class="fas fa-lock me-1"></i>Privado
                                    </label>
                                </div>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="radio" name="visibility" id="public" value="public">
                                    <label class="form-check-label" for="public">
                                        <i class="fas fa-globe me-1"></i>Público
                                    </label>
                                </div>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="radio" name="visibility" id="unlisted" value="unlisted">
                                    <label class="form-check-label" for="unlisted">
                                        <i class="fas fa-link me-1"></i>Enlace oculto
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="sidebar-section">
                            <h6><i class="fas fa-chart-bar me-2"></i>Estadísticas</h6>
                            <div class="stats-display">
                                <div class="stat-item">
                                    <span class="stat-label">Palabras:</span>
                                    <span id="wordCount" class="stat-value">0</span>
                                </div>
                                <div class="stat-item">
                                    <span class="stat-label">Caracteres:</span>
                                    <span id="charCount" class="stat-value">0</span>
                                </div>
                                <div class="stat-item">
                                    <span class="stat-label">Tiempo de lectura:</span>
                                    <span id="readTime" class="stat-value">1 min</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para agregar imágenes -->
    <div class="modal fade" id="imageModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Agregar Imagen</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6>Subir nueva imagen</h6>
                            <div class="upload-area" id="uploadArea">
                                <i class="fas fa-cloud-upload-alt fa-3x text-muted mb-3"></i>
                                <p>Arrastra una imagen aquí o haz clic para seleccionar</p>
                                <input type="file" id="imageUpload" accept="image/*" class="d-none">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <h6>Mis imágenes</h6>
                            <div id="userImages" class="user-images">
                                <!-- Imágenes del usuario se cargarán aquí -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de vista previa -->
    <div class="modal fade" id="previewModal" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Vista Previa</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div id="previewContent" class="preview-content">
                        <!-- El contenido de la vista previa se generará aquí -->
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <button type="button" class="btn btn-primary" id="publishFromPreview">Publicar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.quilljs.com/1.3.7/quill.min.js"></script>
    <script src="<?php echo \ObelisIA\Router\MainRouter::url('assets/js/tools/content-creator/main.js'); ?>"></script>
</body>
</html>
