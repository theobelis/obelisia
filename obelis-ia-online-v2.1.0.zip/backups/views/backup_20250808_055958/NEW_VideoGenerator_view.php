<?php
// src/Tools/views/NEW_VideoGenerator_view.php
use ObelisIA\Utils\Premium;

// Configuración de la herramienta
$tool_name = "Generador de Videos";
$tool_icon = "video";
$tool_description = "Crea videos profesionales con IA";
$tool_slug = "video-generator";
$is_premium = Premium::isPremium();
$show_history = true;
$show_export_button = true;
$show_save_button = true;

// Contenido del sidebar
$sidebar_content = '
<div class="sidebar-section">
    <div class="sidebar-header">
        <i class="fas fa-video"></i> Tipo de Video
    </div>
    <div class="sidebar-content">
        <div class="video-type-grid">
            <label class="type-option">
                <input type="radio" name="videoType" value="animated" checked>
                <div class="type-card">
                    <i class="fas fa-play-circle"></i>
                    <span>Animado</span>
                </div>
            </label>
            <label class="type-option">
                <input type="radio" name="videoType" value="slideshow">
                <div class="type-card">
                    <i class="fas fa-images"></i>
                    <span>Presentación</span>
                </div>
            </label>
            <label class="type-option">
                <input type="radio" name="videoType" value="promo">
                <div class="type-card">
                    <i class="fas fa-bullhorn"></i>
                    <span>Promocional</span>
                </div>
            </label>
            <label class="type-option">
                <input type="radio" name="videoType" value="tutorial">
                <div class="type-card">
                    <i class="fas fa-chalkboard-teacher"></i>
                    <span>Tutorial</span>
                </div>
            </label>
        </div>
    </div>
</div>

<div class="sidebar-section">
    <div class="sidebar-header">
        <i class="fas fa-cogs"></i> Configuración
    </div>
    <div class="sidebar-content">
        <div class="form-group mb-3">
            <label class="form-label">Duración</label>
            <select class="form-control" id="videoDuration">
                <option value="15">15 segundos</option>
                <option value="30" selected>30 segundos</option>
                <option value="60">1 minuto</option>
                <option value="120">2 minutos</option>
                ' . ($is_premium ? '<option value="300">5 minutos (Premium)</option>' : '') . '
            </select>
        </div>
        
        <div class="form-group mb-3">
            <label class="form-label">Resolución</label>
            <select class="form-control" id="videoResolution">
                <option value="720p">HD (720p)</option>
                <option value="1080p" selected>Full HD (1080p)</option>
                ' . ($is_premium ? '<option value="4k">4K (Premium)</option>' : '') . '
            </select>
        </div>
        
        <div class="form-group mb-3">
            <label class="form-label">FPS</label>
            <select class="form-control" id="videoFPS">
                <option value="24">24 FPS</option>
                <option value="30" selected>30 FPS</option>
                ' . ($is_premium ? '<option value="60">60 FPS (Premium)</option>' : '') . '
            </select>
        </div>
        
        <div class="form-group mb-3">
            <label class="form-label">Estilo Visual</label>
            <select class="form-control" id="visualStyle">
                <option value="modern">Moderno</option>
                <option value="minimalist">Minimalista</option>
                <option value="corporate">Corporativo</option>
                <option value="creative">Creativo</option>
                <option value="elegant">Elegante</option>
            </select>
        </div>
    </div>
</div>

<div class="sidebar-section">
    <div class="sidebar-header">
        <i class="fas fa-music"></i> Audio
    </div>
    <div class="sidebar-content">
        <div class="form-group mb-3">
            <label class="form-label">Música de Fondo</label>
            <select class="form-control" id="backgroundMusic">
                <option value="none">Sin música</option>
                <option value="upbeat">Energética</option>
                <option value="calm">Relajante</option>
                <option value="corporate">Corporativa</option>
                <option value="cinematic">Cinematográfica</option>
            </select>
        </div>
        
        <div class="form-group mb-3">
            <label class="form-label">Volumen</label>
            <input type="range" class="form-control-range" min="0" max="100" value="30" id="musicVolume">
            <div class="range-labels">
                <span>Silencio</span>
                <span>Máximo</span>
            </div>
        </div>
        
        <div class="form-group">
            <label class="checkbox-option">
                <input type="checkbox" id="includeVoiceover">
                <span>Incluir narración</span>
            </label>
        </div>
    </div>
</div>

' . ($is_premium ? '
<div class="sidebar-section">
    <div class="sidebar-header">
        <i class="fas fa-crown"></i> Premium
    </div>
    <div class="sidebar-content">
        <div class="premium-features">
            <button class="btn btn-sm btn-accent w-100 mb-2" onclick="addAITransitions()">
                <i class="fas fa-magic"></i> Transiciones IA
            </button>
            <button class="btn btn-sm btn-accent w-100 mb-2" onclick="addCustomBranding()">
                <i class="fas fa-stamp"></i> Marca Personal
            </button>
            <button class="btn btn-sm btn-accent w-100" onclick="exportMultipleFormats()">
                <i class="fas fa-file-export"></i> Múltiples Formatos
            </button>
        </div>
    </div>
</div>
' : '
<div class="premium-feature">
    <div class="premium-badge">PRO</div>
    <div class="sidebar-content">
        <div class="text-muted">
            <p><i class="fas fa-magic"></i> Transiciones IA</p>
            <p><i class="fas fa-video"></i> Videos hasta 10 min</p>
            <p><i class="fas fa-4k"></i> Resolución 4K</p>
        </div>
    </div>
</div>
');

// Contenido de la toolbar
$toolbar_content = '
<div class="toolbar-section">
    <button class="btn btn-sm btn-primary" onclick="addScene()">
        <i class="fas fa-plus"></i> Escena
    </button>
    <button class="btn btn-sm btn-outline" onclick="addText()">
        <i class="fas fa-font"></i> Texto
    </button>
    <button class="btn btn-sm btn-outline" onclick="addImage()">
        <i class="fas fa-image"></i> Imagen
    </button>
</div>

<div class="toolbar-divider"></div>

<div class="toolbar-section">
    <button class="btn btn-sm btn-ghost" onclick="playPreview()" id="playBtn">
        <i class="fas fa-play"></i>
    </button>
    <button class="btn btn-sm btn-ghost" onclick="pausePreview()" id="pauseBtn" style="display: none;">
        <i class="fas fa-pause"></i>
    </button>
    <button class="btn btn-sm btn-ghost" onclick="stopPreview()">
        <i class="fas fa-stop"></i>
    </button>
</div>

<div class="toolbar-divider"></div>

<div class="toolbar-section">
    <span class="time-display" id="currentTime">00:00</span>
    <span>/</span>
    <span class="time-display" id="totalTime">00:30</span>
</div>';

// Contenido principal
$main_content = '
<div class="video-generator-container">
    ' . ($is_premium ? '<div class="alert alert-success mb-4">
        <i class="fas fa-crown"></i>
        <strong>¡Usuario Premium!</strong> Crea videos hasta 10 minutos en resolución 4K con efectos IA avanzados.
    </div>' : '') . '
    
    <!-- Área de preview del video -->
    <div class="video-preview-container">
        <div class="video-canvas-wrapper">
            <canvas id="videoCanvas" class="video-canvas"></canvas>
            <div class="video-overlay" id="videoOverlay">
                <div class="play-button" onclick="playPreview()">
                    <i class="fas fa-play fa-3x"></i>
                </div>
            </div>
        </div>
        
        <!-- Controles de reproducción -->
        <div class="video-controls">
            <div class="progress-container">
                <div class="progress-bar" id="progressBar">
                    <div class="progress-fill" id="progressFill"></div>
                    <div class="progress-handle" id="progressHandle"></div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Timeline de edición -->
    <div class="timeline-container">
        <div class="timeline-header">
            <h4><i class="fas fa-film"></i> Timeline</h4>
            <div class="timeline-controls">
                <button class="btn btn-sm btn-outline" onclick="zoomTimelineIn()">
                    <i class="fas fa-search-plus"></i>
                </button>
                <button class="btn btn-sm btn-outline" onclick="zoomTimelineOut()">
                    <i class="fas fa-search-minus"></i>
                </button>
            </div>
        </div>
        
        <div class="timeline-content" id="timelineContent">
            <div class="timeline-track" data-track="video">
                <div class="track-header">
                    <i class="fas fa-video"></i> Video
                </div>
                <div class="track-content" id="videoTrack">
                    <!-- Clips de video se agregan aquí -->
                </div>
            </div>
            
            <div class="timeline-track" data-track="audio">
                <div class="track-header">
                    <i class="fas fa-music"></i> Audio
                </div>
                <div class="track-content" id="audioTrack">
                    <!-- Clips de audio se agregan aquí -->
                </div>
            </div>
            
            <div class="timeline-track" data-track="text">
                <div class="track-header">
                    <i class="fas fa-font"></i> Texto
                </div>
                <div class="track-content" id="textTrack">
                    <!-- Clips de texto se agregan aquí -->
                </div>
            </div>
        </div>
        
        <!-- Playhead -->
        <div class="timeline-playhead" id="timelinePlayhead"></div>
    </div>
    
    <!-- Panel de contenido -->
    <div class="content-panel" id="contentPanel">
        <div class="panel-tabs">
            <button class="panel-tab active" onclick="switchContentTab(\'media\')">
                <i class="fas fa-photo-video"></i> Media
            </button>
            <button class="panel-tab" onclick="switchContentTab(\'templates\')">
                <i class="fas fa-layer-group"></i> Plantillas
            </button>
            <button class="panel-tab" onclick="switchContentTab(\'effects\')">
                <i class="fas fa-magic"></i> Efectos
            </button>
        </div>
        
        <div class="panel-content" id="panelContent">
            <!-- Contenido de pestañas -->
        </div>
    </div>
</div>

<!-- Modal de configuración de escena -->
<div class="modal" id="sceneModal" style="display: none;">
    <div class="modal-overlay" onclick="closeSceneModal()"></div>
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-cog"></i> Configurar Escena</h3>
            <button class="btn btn-ghost" onclick="closeSceneModal()">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="modal-body">
            <div class="form-group mb-3">
                <label class="form-label">Duración de la Escena</label>
                <input type="number" class="form-control" id="sceneDuration" value="5" min="1" max="30">
                <small class="text-muted">Duración en segundos</small>
            </div>
            
            <div class="form-group mb-3">
                <label class="form-label">Transición de Entrada</label>
                <select class="form-control" id="entryTransition">
                    <option value="none">Sin transición</option>
                    <option value="fade">Fade In</option>
                    <option value="slide">Deslizar</option>
                    <option value="zoom">Zoom In</option>
                    <option value="rotate">Rotar</option>
                </select>
            </div>
            
            <div class="form-group mb-3">
                <label class="form-label">Transición de Salida</label>
                <select class="form-control" id="exitTransition">
                    <option value="none">Sin transición</option>
                    <option value="fade">Fade Out</option>
                    <option value="slide">Deslizar</option>
                    <option value="zoom">Zoom Out</option>
                    <option value="rotate">Rotar</option>
                </select>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeSceneModal()">
                Cancelar
            </button>
            <button class="btn btn-primary" onclick="saveSceneConfig()">
                <i class="fas fa-save"></i>
                Guardar
            </button>
        </div>
    </div>
</div>';

// Contenido de ayuda
$help_content = '
<div class="help-section">
    <h4><i class="fas fa-video"></i> Cómo crear videos con IA</h4>
    <ol>
        <li><strong>Selecciona el tipo:</strong> Elige entre video animado, presentación, promocional o tutorial</li>
        <li><strong>Configura parámetros:</strong> Define duración, resolución y estilo visual</li>
        <li><strong>Agrega contenido:</strong> Usa el timeline para añadir escenas, texto e imágenes</li>
        <li><strong>Personaliza audio:</strong> Selecciona música de fondo y ajusta el volumen</li>
        <li><strong>Preview y edita:</strong> Reproduce el video para ver el resultado</li>
        <li><strong>Exporta:</strong> Descarga tu video en el formato deseado</li>
    </ol>
    
    <h5><i class="fas fa-film"></i> Timeline:</h5>
    <ul>
        <li>Arrastra elementos al timeline para organizarlos</li>
        <li>Ajusta la duración de cada clip</li>
        <li>Añade transiciones entre escenas</li>
        <li>Sincroniza audio y video</li>
    </ul>
    
    <h5><i class="fas fa-crown"></i> Funciones Premium:</h5>
    <ul>
        <li>Videos hasta 10 minutos de duración</li>
        <li>Resolución 4K para calidad profesional</li>
        <li>60 FPS para movimientos suaves</li>
        <li>Transiciones con efectos IA avanzados</li>
        <li>Marca personal personalizable</li>
        <li>Exportación en múltiples formatos</li>
    </ul>
    
    <h5><i class="fas fa-lightbulb"></i> Consejos:</h5>
    <ul>
        <li>Mantén las escenas cortas para mejor engagement</li>
        <li>Usa transiciones suaves entre elementos</li>
        <li>Ajusta el volumen de la música para no competir con narración</li>
        <li>Revisa el video completo antes de exportar</li>
    </ul>
</div>';

// JavaScript específico
$inline_js = '
let videoCanvas, videoCtx;
let scenes = [];
let currentScene = 0;
let isPlaying = false;
let currentTime = 0;
let totalDuration = 30;
let timelineZoom = 1;
let selectedClip = null;

// Configuración del video
const videoConfig = {
    width: 1920,
    height: 1080,
    fps: 30,
    backgroundColor: "#000000"
};

// Inicializar generador de video
function initializeVideoGenerator() {
    videoCanvas = document.getElementById("videoCanvas");
    videoCtx = videoCanvas.getContext("2d");
    
    // Configurar canvas
    setupVideoCanvas();
    
    // Inicializar timeline
    setupTimeline();
    
    // Cargar contenido de pestañas
    loadContentTabs();
    
    // Event listeners
    setupVideoEventListeners();
    
    showAlert("Generador de videos listo", "success");
}

function setupVideoCanvas() {
    videoCanvas.width = videoConfig.width;
    videoCanvas.height = videoConfig.height;
    
    // Fondo inicial
    videoCtx.fillStyle = videoConfig.backgroundColor;
    videoCtx.fillRect(0, 0, videoCanvas.width, videoCanvas.height);
    
    // Ajustar tamaño visual
    resizeVideoCanvas();
}

function resizeVideoCanvas() {
    const container = videoCanvas.parentElement;
    const containerWidth = container.clientWidth - 40;
    const containerHeight = container.clientHeight - 40;
    
    const scaleX = containerWidth / videoConfig.width;
    const scaleY = containerHeight / videoConfig.height;
    const scale = Math.min(scaleX, scaleY, 0.8);
    
    videoCanvas.style.width = (videoConfig.width * scale) + "px";
    videoCanvas.style.height = (videoConfig.height * scale) + "px";
}

function setupTimeline() {
    const duration = parseInt(document.getElementById("videoDuration").value);
    totalDuration = duration;
    document.getElementById("totalTime").textContent = formatTime(totalDuration);
    
    // Configurar escala del timeline
    updateTimelineScale();
}

function updateTimelineScale() {
    const timelineContent = document.getElementById("timelineContent");
    const totalWidth = timelineContent.clientWidth - 100; // Reservar espacio para headers
    const pixelsPerSecond = (totalWidth / totalDuration) * timelineZoom;
    
    // Actualizar CSS custom property para la escala
    timelineContent.style.setProperty("--pixels-per-second", pixelsPerSecond + "px");
}

function setupVideoEventListeners() {
    // Controles de reproducción
    document.getElementById("progressBar").addEventListener("click", seekVideo);
    
    // Timeline
    document.getElementById("timelineContent").addEventListener("click", handleTimelineClick);
    
    // Resize
    window.addEventListener("resize", resizeVideoCanvas);
    
    // Configuración
    document.getElementById("videoDuration").addEventListener("change", updateDuration);
    document.getElementById("videoResolution").addEventListener("change", updateResolution);
}

// Gestión de escenas
function addScene() {
    document.getElementById("sceneModal").style.display = "flex";
}

function closeSceneModal() {
    document.getElementById("sceneModal").style.display = "none";
}

function saveSceneConfig() {
    const duration = parseFloat(document.getElementById("sceneDuration").value);
    const entryTransition = document.getElementById("entryTransition").value;
    const exitTransition = document.getElementById("exitTransition").value;
    
    const scene = {
        id: Date.now(),
        duration: duration,
        startTime: scenes.length > 0 ? scenes[scenes.length - 1].startTime + scenes[scenes.length - 1].duration : 0,
        entryTransition: entryTransition,
        exitTransition: exitTransition,
        elements: [],
        backgroundColor: "#000000"
    };
    
    scenes.push(scene);
    updateTimeline();
    closeSceneModal();
    
    showAlert(`Escena de ${duration}s agregada`, "success");
}

function addText() {
    if (scenes.length === 0) {
        showAlert("Agrega una escena primero", "warning");
        return;
    }
    
    const text = prompt("Ingresa el texto:");
    if (!text) return;
    
    const textElement = {
        id: Date.now(),
        type: "text",
        content: text,
        x: videoConfig.width / 2,
        y: videoConfig.height / 2,
        fontSize: 48,
        fontFamily: "Arial",
        color: "#ffffff",
        duration: 3,
        animation: "fadeIn"
    };
    
    scenes[currentScene].elements.push(textElement);
    updateTimeline();
    renderCurrentFrame();
    
    showAlert("Texto agregado", "success");
}

function addImage() {
    if (scenes.length === 0) {
        showAlert("Agrega una escena primero", "warning");
        return;
    }
    
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    input.onchange = function(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(event) {
                const img = new Image();
                img.onload = function() {
                    const imageElement = {
                        id: Date.now(),
                        type: "image",
                        content: img,
                        x: videoConfig.width / 2 - img.width / 2,
                        y: videoConfig.height / 2 - img.height / 2,
                        width: Math.min(img.width, videoConfig.width * 0.8),
                        height: Math.min(img.height, videoConfig.height * 0.8),
                        duration: 5,
                        animation: "slideIn"
                    };
                    
                    scenes[currentScene].elements.push(imageElement);
                    updateTimeline();
                    renderCurrentFrame();
                    
                    showAlert("Imagen agregada", "success");
                };
                img.src = event.target.result;
            };
            reader.readAsDataURL(file);
        }
    };
    input.click();
}

// Reproducción
function playPreview() {
    if (scenes.length === 0) {
        showAlert("Agrega escenas para reproducir", "warning");
        return;
    }
    
    isPlaying = true;
    document.getElementById("playBtn").style.display = "none";
    document.getElementById("pauseBtn").style.display = "inline-block";
    document.getElementById("videoOverlay").style.display = "none";
    
    startVideoPlayback();
}

function pausePreview() {
    isPlaying = false;
    document.getElementById("playBtn").style.display = "inline-block";
    document.getElementById("pauseBtn").style.display = "none";
    
    stopVideoPlayback();
}

function stopPreview() {
    isPlaying = false;
    currentTime = 0;
    document.getElementById("playBtn").style.display = "inline-block";
    document.getElementById("pauseBtn").style.display = "none";
    document.getElementById("videoOverlay").style.display = "flex";
    
    updateTimeDisplay();
    updateProgressBar();
    renderCurrentFrame();
    stopVideoPlayback();
}

let playbackInterval;

function startVideoPlayback() {
    playbackInterval = setInterval(() => {
        currentTime += 1 / videoConfig.fps;
        
        if (currentTime >= totalDuration) {
            stopPreview();
            return;
        }
        
        updateTimeDisplay();
        updateProgressBar();
        renderCurrentFrame();
    }, 1000 / videoConfig.fps);
}

function stopVideoPlayback() {
    if (playbackInterval) {
        clearInterval(playbackInterval);
        playbackInterval = null;
    }
}

function seekVideo(e) {
    const rect = e.target.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const progress = clickX / rect.width;
    
    currentTime = progress * totalDuration;
    updateTimeDisplay();
    updateProgressBar();
    renderCurrentFrame();
}

// Renderizado
function renderCurrentFrame() {
    // Limpiar canvas
    videoCtx.fillStyle = videoConfig.backgroundColor;
    videoCtx.fillRect(0, 0, videoConfig.width, videoConfig.height);
    
    // Encontrar escena actual
    const scene = getCurrentScene();
    if (!scene) return;
    
    // Renderizar fondo de escena
    videoCtx.fillStyle = scene.backgroundColor;
    videoCtx.fillRect(0, 0, videoConfig.width, videoConfig.height);
    
    // Renderizar elementos de la escena
    const sceneTime = currentTime - scene.startTime;
    scene.elements.forEach(element => {
        if (sceneTime >= 0 && sceneTime <= element.duration) {
            renderElement(element, sceneTime);
        }
    });
}

function getCurrentScene() {
    for (const scene of scenes) {
        if (currentTime >= scene.startTime && currentTime < scene.startTime + scene.duration) {
            return scene;
        }
    }
    return scenes[0];
}

function renderElement(element, time) {
    videoCtx.save();
    
    // Aplicar animaciones
    const animationProgress = time / element.duration;
    applyAnimation(element, animationProgress);
    
    switch (element.type) {
        case "text":
            renderTextElement(element);
            break;
        case "image":
            renderImageElement(element);
            break;
    }
    
    videoCtx.restore();
}

function renderTextElement(element) {
    videoCtx.font = `${element.fontSize}px ${element.fontFamily}`;
    videoCtx.fillStyle = element.color;
    videoCtx.textAlign = "center";
    videoCtx.textBaseline = "middle";
    
    videoCtx.fillText(element.content, element.x, element.y);
}

function renderImageElement(element) {
    if (element.content.complete) {
        videoCtx.drawImage(
            element.content,
            element.x,
            element.y,
            element.width,
            element.height
        );
    }
}

function applyAnimation(element, progress) {
    switch (element.animation) {
        case "fadeIn":
            videoCtx.globalAlpha = progress;
            break;
        case "slideIn":
            element.x = videoConfig.width * (1 - progress) + element.x * progress;
            break;
        case "zoomIn":
            const scale = progress;
            videoCtx.scale(scale, scale);
            break;
    }
}

// Timeline
function updateTimeline() {
    const videoTrack = document.getElementById("videoTrack");
    const audioTrack = document.getElementById("audioTrack");
    const textTrack = document.getElementById("textTrack");
    
    // Limpiar tracks
    videoTrack.innerHTML = "";
    audioTrack.innerHTML = "";
    textTrack.innerHTML = "";
    
    // Agregar clips de escenas
    scenes.forEach((scene, index) => {
        const clip = createTimelineClip(scene, "scene");
        videoTrack.appendChild(clip);
        
        // Agregar elementos de la escena
        scene.elements.forEach(element => {
            const elementClip = createTimelineClip(element, element.type);
            
            if (element.type === "text") {
                textTrack.appendChild(elementClip);
            } else {
                videoTrack.appendChild(elementClip);
            }
        });
    });
    
    updateTimelineScale();
}

function createTimelineClip(item, type) {
    const clip = document.createElement("div");
    clip.className = `timeline-clip ${type}`;
    clip.style.left = (item.startTime || 0) * 20 + "px";
    clip.style.width = item.duration * 20 + "px";
    
    clip.innerHTML = `
        <div class="clip-content">
            <i class="fas fa-${getClipIcon(type)}"></i>
            <span>${getClipLabel(item, type)}</span>
        </div>
    `;
    
    clip.addEventListener("click", () => selectClip(item));
    
    return clip;
}

function getClipIcon(type) {
    const icons = {
        scene: "film",
        text: "font",
        image: "image",
        audio: "music"
    };
    return icons[type] || "layer-group";
}

function getClipLabel(item, type) {
    switch (type) {
        case "scene":
            return `Escena ${item.duration}s`;
        case "text":
            return item.content?.substring(0, 10) || "Texto";
        case "image":
            return "Imagen";
        default:
            return type;
    }
}

function selectClip(item) {
    selectedClip = item;
    document.querySelectorAll(".timeline-clip").forEach(clip => {
        clip.classList.remove("selected");
    });
    event.currentTarget.classList.add("selected");
}

// Pestañas de contenido
function switchContentTab(tab) {
    document.querySelectorAll(".panel-tab").forEach(t => t.classList.remove("active"));
    event.currentTarget.classList.add("active");
    
    loadContentTabs(tab);
}

function loadContentTabs(activeTab = "media") {
    const content = document.getElementById("panelContent");
    
    switch (activeTab) {
        case "media":
            content.innerHTML = `
                <div class="media-library">
                    <div class="upload-area" onclick="uploadMedia()">
                        <i class="fas fa-cloud-upload-alt fa-2x mb-2"></i>
                        <p>Arrastra archivos aquí o haz clic para subir</p>
                    </div>
                    <div class="media-grid" id="mediaGrid">
                        <!-- Media items -->
                    </div>
                </div>
            `;
            break;
        case "templates":
            content.innerHTML = `
                <div class="template-grid">
                    <div class="template-item" onclick="applyTemplate(\'intro\')">
                        <div class="template-preview">
                            <i class="fas fa-play-circle fa-2x"></i>
                        </div>
                        <span>Intro Animado</span>
                    </div>
                    <div class="template-item" onclick="applyTemplate(\'slideshow\')">
                        <div class="template-preview">
                            <i class="fas fa-images fa-2x"></i>
                        </div>
                        <span>Presentación</span>
                    </div>
                </div>
            `;
            break;
        case "effects":
            content.innerHTML = `
                <div class="effects-grid">
                    <div class="effect-item" onclick="applyEffect(\'blur\')">
                        <i class="fas fa-eye"></i>
                        <span>Desenfoque</span>
                    </div>
                    <div class="effect-item" onclick="applyEffect(\'glow\')">
                        <i class="fas fa-sun"></i>
                        <span>Brillo</span>
                    </div>
                </div>
            `;
            break;
    }
}

// Utilidades
function updateTimeDisplay() {
    document.getElementById("currentTime").textContent = formatTime(currentTime);
}

function updateProgressBar() {
    const progress = (currentTime / totalDuration) * 100;
    document.getElementById("progressFill").style.width = progress + "%";
    document.getElementById("progressHandle").style.left = progress + "%";
}

function formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
}

function updateDuration() {
    totalDuration = parseInt(document.getElementById("videoDuration").value);
    document.getElementById("totalTime").textContent = formatTime(totalDuration);
    setupTimeline();
}

function updateResolution() {
    const resolution = document.getElementById("videoResolution").value;
    switch (resolution) {
        case "720p":
            videoConfig.width = 1280;
            videoConfig.height = 720;
            break;
        case "1080p":
            videoConfig.width = 1920;
            videoConfig.height = 1080;
            break;
        case "4k":
            videoConfig.width = 3840;
            videoConfig.height = 2160;
            break;
    }
    
    setupVideoCanvas();
    renderCurrentFrame();
}

// Zoom del timeline
function zoomTimelineIn() {
    timelineZoom *= 1.5;
    updateTimelineScale();
}

function zoomTimelineOut() {
    timelineZoom /= 1.5;
    updateTimelineScale();
}

// Funciones globales requeridas por el template
function generateContent() {
    if (scenes.length === 0) {
        showAlert("Agrega escenas para generar el video", "warning");
        return;
    }
    
    showAlert("Generando video... Esto puede tomar unos minutos", "info");
    
    // Aquí iría la lógica de generación del video
    setTimeout(() => {
        showAlert("¡Video generado exitosamente!", "success");
    }, 3000);
}

function saveWork() {
    const projectData = {
        scenes: scenes,
        config: videoConfig,
        settings: {
            duration: totalDuration,
            resolution: document.getElementById("videoResolution").value,
            fps: document.getElementById("videoFPS").value
        },
        timestamp: new Date()
    };
    
    const blob = new Blob([JSON.stringify(projectData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement("a");
    a.href = url;
    a.download = `video_project_${Date.now()}.json`;
    a.click();
    
    URL.revokeObjectURL(url);
    showAlert("Proyecto guardado", "success");
}

function exportWork() {
    if (scenes.length === 0) {
        showAlert("No hay contenido para exportar", "warning");
        return;
    }
    
    showAlert("Exportando video... Esto puede tomar varios minutos", "info");
    
    // Aquí iría la lógica de exportación
    setTimeout(() => {
        showAlert("¡Video exportado exitosamente!", "success");
    }, 5000);
}

function showAlert(message, type = "info") {
    const alert = document.createElement("div");
    alert.className = `alert alert-${type} position-fixed top-0 end-0 m-3`;
    alert.style.zIndex = "9999";
    alert.innerHTML = `
        <i class="fas fa-${type === "success" ? "check" : type === "warning" ? "exclamation-triangle" : "info-circle"}"></i>
        ${message}
    `;
    
    document.body.appendChild(alert);
    setTimeout(() => alert.remove(), 4000);
}

// Inicializar cuando el DOM esté listo
document.addEventListener("DOMContentLoaded", function() {
    initializeVideoGenerator();
});
';

// Incluir el template base
include 'base_template.php';
