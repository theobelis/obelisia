<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generador de Paletas de Colores desde Imagen</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" xintegrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo \ObelisIA\Router\MainRouter::url('assets/css/tools/color-palette/style.css');?>">
    <link rel="stylesheet" href="<?php echo \ObelisIA\Router\MainRouter::url('assets/css/tools/color-palette/side-layout.css');?>">
<body class="bg-body-tertiary">



<div class="p-4 palette-tool-root">
    <div class="palette-side-layout">
        <!-- Opciones a la izquierda -->
        <div class="palette-options-col">
            <?php if (!empty($isPremium) && $isPremium): ?>
            <div class="card shadow-sm mb-4 premium-section">
                <div class="card-header bg-gradient-primary text-white border-0">
                    <h5 class="mb-0"><i class="fas fa-star me-1"></i> Opciones Premium</h5>
                </div>
                <div class="card-body">
                    <form id="palettePremiumOptionsForm">
                        <div class="mb-3">
                            <label for="premiumNumColors" class="form-label">Cantidad de colores:</label>
                            <input type="number" id="premiumNumColors" name="premiumNumColors" class="form-control" min="3" max="32" value="12">
                        </div>
                        <div class="mb-3">
                            <label for="colorFormat" class="form-label">Formato de color:</label>
                            <select id="colorFormat" name="colorFormat" class="form-select">
                                <option value="hex">HEX</option>
                                <option value="rgb">RGB</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="sortOrder" class="form-label">Ordenar por:</label>
                            <select id="sortOrder" name="sortOrder" class="form-select">
                                <option value="dominance">Dominancia</option>
                                <option value="hue">Matiz (Hue)</option>
                                <option value="lightness">Luminosidad</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="colorSpace" class="form-label">Espacio de color:</label>
                            <select id="colorSpace" name="colorSpace" class="form-select">
                                <option value="rgb">RGB</option>
                                <option value="lab">CIE LAB</option>
                                <option value="hsv">HSV</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="removeBackground" class="form-label">Eliminar fondo blanco/negro:</label>
                            <select id="removeBackground" name="removeBackground" class="form-select">
                                <option value="auto">Automático</option>
                                <option value="si">Sí</option>
                                <option value="no">No</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-warning w-100">Aplicar Opciones Premium</button>
                    </form>
                    <div class="text-center mt-2 small text-muted">Opciones avanzadas para usuarios <strong>Premium</strong></div>
                </div>
            </div>
            <?php else: ?>
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-white border-0">
                    <h5 class="mb-0">Opciones de Paleta</h5>
                </div>
                <div class="card-body">
                    <form id="paletteOptionsForm">
                        <div class="mb-3">
                            <label for="numColors" class="form-label">Cantidad de colores:</label>
                            <input type="number" id="numColors" name="numColors" class="form-control" min="3" max="16" value="6">
                        </div>
                        <div class="mb-3">
                            <label for="colorFormat" class="form-label">Formato de color:</label>
                            <select id="colorFormat" name="colorFormat" class="form-select">
                                <option value="hex">HEX</option>
                                <option value="rgb">RGB</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="sortOrder" class="form-label">Ordenar por:</label>
                            <select id="sortOrder" name="sortOrder" class="form-select">
                                <option value="dominance">Dominancia</option>
                                <option value="hue">Matiz (Hue)</option>
                                <option value="lightness">Luminosidad</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Aplicar Opciones</button>
                    </form>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <!-- Paleta y canvas en el centro -->
        <div class="palette-center-col">
            <div class="card shadow-sm mb-4">
                <div class="card-header text-center bg-white border-0 pb-0 pt-4">
                    <h1 class="display-5 fw-bold mb-1">Generador de Paletas desde Imagen</h1>
                    <p class="lead text-body-secondary mb-0">Extrae los colores dominantes de cualquier imagen</p>
                </div>
                <div class="card-body">
                    <div class="mb-4 mx-auto" style="max-width: 400px;">
                        <label for="image-upload" class="btn btn-violet-blue btn-lg btn-block w-100 text-white fw-bold mb-3 rounded-pill">
                            🖼️ Seleccionar Imagen
                        </label>
                        <input type="file" id="image-upload" class="d-none" accept="image/*">
                        <p id="loading-state" class="d-none text-body-secondary mt-3 mb-0">🎨 Analizando colores...</p>
                    </div>
                    <div class="mb-4">
                        <canvas id="image-canvas" class="d-none"></canvas>
                    </div>
                    <main id="palette-container" class="row row-cols-2 row-cols-sm-4 row-cols-md-6 row-cols-lg-8 row-cols-xl-10 g-3">
                        <!-- Las tarjetas de colores se insertarán aquí por JS -->
                    </main>
                    <div id="instructions" class="text-center text-muted mt-5 p-2 rounded-5">
                        <p class="fs-5">Sube una imagen para empezar.</p>
                        <p>Haz <strong>clic en un color</strong> para copiar su código HEX.</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Historial a la derecha -->
        <div class="palette-history-col">
            <div class="card shadow-sm">
                <div class="card-header d-flex justify-content-between align-items-center bg-white border-0">
                    <h5 class="mb-0">Historial de Paletas</h5>
                    <button id="clearPaletteHistoryButton" class="btn btn-outline-danger btn-sm" title="Limpiar historial">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
                <div id="paletteHistoryContainer" class="card-body">
                    <p class="text-muted text-center">No hay paletas en el historial.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
$premiumMessage = 'paletas avanzadas, más colores, extracción por LAB/HSV y opciones exclusivas solo para usuarios premium.';
include __DIR__ . '/../../../assets/banners/partials/premium_banner_for_tools.php'; 
?>

<script src="<?php echo \ObelisIA\Router\MainRouter::url('assets/js/tools/color-palette/app.js'); ?>"></script>
<script src="<?php echo \ObelisIA\Router\MainRouter::url('assets/js/tools/color-palette/palette-history.js'); ?>"></script>
<?php if (!empty($isPremium) && $isPremium): ?>
<script src="<?php echo \ObelisIA\Router\MainRouter::url('assets/js/tools/color-palette/premium-options.js'); ?>"></script>
<?php endif; ?>
