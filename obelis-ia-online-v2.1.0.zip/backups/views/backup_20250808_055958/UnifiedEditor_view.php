<?php
// Editor Unificado de Creaciones - Vista principal
// Permite combinar imágenes, paletas, textos y audio en una sola creación
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Creador de Creaciones - ObelisIA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo \ObelisIA\Router\MainRouter::url('assets/css/tools/unified-editor/style.css');?>">
    <style>
        body { font-family: 'Inter', sans-serif; background: #0f172a; color: #e2e8f0; }
        .unified-editor-container { min-height: 100vh; display: flex; flex-direction: column; }
        .editor-header { background: #1e293b; border-bottom: 1px solid #334155; padding: 1rem 0; }
        .editor-main { flex: 1; display: flex; overflow: hidden; }
        .editor-sidebar { width: 320px; background: #1e293b; border-right: 1px solid #334155; overflow-y: auto; }
        .editor-canvas-container { flex: 1; background: #0f172a; display: flex; flex-direction: column; }
        .editor-toolbar { background: #1e293b; border-bottom: 1px solid #334155; padding: 0.75rem; display: flex; align-items: center; gap: 0.5rem; }
        .canvas-area { flex: 1; padding: 1rem; display: flex; align-items: center; justify-content: center; position: relative; }
        .unified-canvas { border: 2px solid #334155; border-radius: 8px; background: white; box-shadow: 0 10px 25px rgba(0,0,0,0.3); }
        .sidebar-section { border-bottom: 1px solid #334155; }
        .sidebar-section:last-child { border-bottom: none; }
        .sidebar-header { padding: 1rem; background: #2d3748; font-weight: 600; }
        .sidebar-content { padding: 1rem; }
        .resource-item { padding: 0.75rem; border: 1px solid #334155; border-radius: 6px; margin-bottom: 0.5rem; cursor: pointer; transition: all 0.2s; }
        .resource-item:hover { background: #2d3748; border-color: #06b6d4; }
        .resource-item.selected { background: #0c4a6e; border-color: #0ea5e9; }
        .color-palette-preview { display: flex; gap: 2px; margin-top: 0.5rem; }
        .color-swatch { width: 20px; height: 20px; border-radius: 3px; border: 1px solid rgba(255,255,255,0.2); }
        .text-preview { font-size: 0.875rem; color: #94a3b8; margin-top: 0.5rem; max-height: 60px; overflow: hidden; }
        .image-preview { width: 60px; height: 60px; object-fit: cover; border-radius: 4px; border: 1px solid #334155; }
        .btn-primary { background: #0ea5e9; border-color: #0ea5e9; }
        .btn-primary:hover { background: #0284c7; border-color: #0284c7; }
        .btn-outline-primary { color: #0ea5e9; border-color: #0ea5e9; }
        .btn-outline-primary:hover { background: #0ea5e9; border-color: #0ea5e9; color: white; }
        .tool-btn { background: #374151; border: 1px solid #4b5563; color: #e5e7eb; padding: 0.5rem 1rem; border-radius: 6px; cursor: pointer; transition: all 0.2s; }
        .tool-btn:hover { background: #4b5563; }
        .tool-btn.active { background: #0ea5e9; border-color: #0ea5e9; }
        .layer-item { background: #2d3748; border: 1px solid #4a5568; border-radius: 6px; padding: 0.75rem; margin-bottom: 0.5rem; display: flex; align-items: center; justify-content: between; }
        .layer-preview { width: 40px; height: 40px; border-radius: 4px; margin-right: 0.75rem; border: 1px solid #4a5568; }
        .export-options { display: flex; gap: 0.5rem; }
    </style>
</head>
<body>
    <div class="unified-editor-container">
        <!-- Header -->
        <header class="editor-header">
            <div class="container-fluid">
                <div class="d-flex align-items-center justify-content-between">
                    <div class="d-flex align-items-center gap-3">
                        <h1 class="h4 mb-0">
                            <i class="fas fa-layer-group text-primary me-2"></i>
                            Creador de Creaciones
                        </h1>
                        <span class="badge bg-secondary">Beta</span>
                    </div>
                    <div class="d-flex align-items-center gap-2">
                        <button id="saveCreationBtn" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Guardar Creación
                        </button>
                        <button id="exportCreationBtn" class="btn btn-outline-primary">
                            <i class="fas fa-download me-2"></i>Exportar
                        </button>
                        <button id="previewCreationBtn" class="btn btn-outline-secondary">
                            <i class="fas fa-eye me-2"></i>Vista Previa
                        </button>
                    </div>
                </div>
            </div>
        </header>

        <!-- Main Content -->
        <main class="editor-main">
            <!-- Sidebar -->
            <aside class="editor-sidebar">
                <!-- Mis Recursos -->
                <div class="sidebar-section">
                    <div class="sidebar-header">
                        <i class="fas fa-folder-open me-2"></i>
                        Mis Recursos
                    </div>
                    <div class="sidebar-content">
                        <div class="mb-3">
                            <label class="form-label small">Filtrar por tipo:</label>
                            <select id="resourceFilter" class="form-select form-select-sm bg-dark text-light border-secondary">
                                <option value="all">Todos</option>
                                <option value="imagen">Imágenes</option>
                                <option value="paleta">Paletas de Colores</option>
                                <option value="texto">Textos</option>
                            </select>
                        </div>
                        <div id="resourcesList" class="resources-container">
                            <!-- Los recursos se cargarán aquí -->
                        </div>
                    </div>
                </div>

                <!-- Herramientas -->
                <div class="sidebar-section">
                    <div class="sidebar-header">
                        <i class="fas fa-tools me-2"></i>
                        Herramientas
                    </div>
                    <div class="sidebar-content">
                        <div class="d-grid gap-2 mb-3">
                            <button id="addTextTool" class="tool-btn">
                                <i class="fas fa-font me-2"></i>Agregar Texto
                            </button>
                            <button id="addShapeTool" class="tool-btn">
                                <i class="fas fa-shapes me-2"></i>Agregar Forma
                            </button>
                            <button id="drawTool" class="tool-btn">
                                <i class="fas fa-paint-brush me-2"></i>Pincel
                            </button>
                            <button id="eraseTool" class="tool-btn">
                                <i class="fas fa-eraser me-2"></i>Borrador
                            </button>
                        </div>
                        <div class="tool-options" id="toolOptions">
                            <!-- Opciones de herramientas aparecerán aquí -->
                        </div>
                    </div>
                </div>

                <!-- Capas -->
                <div class="sidebar-section">
                    <div class="sidebar-header">
                        <i class="fas fa-layer-group me-2"></i>
                        Capas
                    </div>
                    <div class="sidebar-content">
                        <div id="layersList" class="layers-container">
                            <!-- Las capas se mostrarán aquí -->
                        </div>
                        <div class="mt-3">
                            <button id="addLayerBtn" class="btn btn-outline-primary btn-sm w-100">
                                <i class="fas fa-plus me-2"></i>Nueva Capa
                            </button>
                        </div>
                    </div>
                </div>
            </aside>

            <!-- Canvas Container -->
            <div class="editor-canvas-container">
                <!-- Toolbar -->
                <div class="editor-toolbar">
                    <div class="d-flex align-items-center gap-2">
                        <button id="undoBtn" class="tool-btn" title="Deshacer">
                            <i class="fas fa-undo"></i>
                        </button>
                        <button id="redoBtn" class="tool-btn" title="Rehacer">
                            <i class="fas fa-redo"></i>
                        </button>
                        <div class="vr mx-2"></div>
                        <button id="zoomInBtn" class="tool-btn" title="Acercar">
                            <i class="fas fa-search-plus"></i>
                        </button>
                        <span id="zoomLevel" class="small text-muted">100%</span>
                        <button id="zoomOutBtn" class="tool-btn" title="Alejar">
                            <i class="fas fa-search-minus"></i>
                        </button>
                        <button id="fitToScreenBtn" class="tool-btn" title="Ajustar a pantalla">
                            <i class="fas fa-expand-arrows-alt"></i>
                        </button>
                        <div class="vr mx-2"></div>
                        <div class="d-flex align-items-center gap-2">
                            <label class="small mb-0">Tamaño:</label>
                            <input type="number" id="canvasWidth" class="form-control form-control-sm" style="width: 80px;" value="1024" min="100" max="4096">
                            <span class="small">×</span>
                            <input type="number" id="canvasHeight" class="form-control form-control-sm" style="width: 80px;" value="1024" min="100" max="4096">
                            <button id="resizeCanvasBtn" class="tool-btn" title="Aplicar tamaño">
                                <i class="fas fa-check"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Canvas Area -->
                <div class="canvas-area">
                    <div class="canvas-wrapper" id="canvasWrapper">
                        <canvas id="unifiedCanvas" class="unified-canvas" width="1024" height="1024"></canvas>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Modal para Agregar Texto -->
    <div class="modal fade" id="addTextModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content bg-dark">
                <div class="modal-header border-secondary">
                    <h5 class="modal-title">Agregar Texto</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Contenido del texto:</label>
                        <textarea id="textContent" class="form-control bg-dark text-light border-secondary" rows="3" placeholder="Escribe tu texto aquí..."></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Fuente:</label>
                            <select id="textFont" class="form-select bg-dark text-light border-secondary">
                                <option value="Arial">Arial</option>
                                <option value="Helvetica">Helvetica</option>
                                <option value="Times New Roman">Times New Roman</option>
                                <option value="Georgia">Georgia</option>
                                <option value="Verdana">Verdana</option>
                                <option value="Comic Sans MS">Comic Sans MS</option>
                                <option value="Impact">Impact</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tamaño:</label>
                            <input type="range" id="textSize" class="form-range" min="12" max="200" value="48">
                            <div class="text-center small"><span id="textSizeValue">48</span>px</div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Color:</label>
                            <input type="color" id="textColor" class="form-control form-control-color bg-dark" value="#ffffff">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Estilo:</label>
                            <div class="d-flex gap-2">
                                <button type="button" id="textBold" class="tool-btn">
                                    <i class="fas fa-bold"></i>
                                </button>
                                <button type="button" id="textItalic" class="tool-btn">
                                    <i class="fas fa-italic"></i>
                                </button>
                                <button type="button" id="textUnderline" class="tool-btn">
                                    <i class="fas fa-underline"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-secondary">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" id="addTextBtn" class="btn btn-primary">Agregar Texto</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para Exportar -->
    <div class="modal fade" id="exportModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content bg-dark">
                <div class="modal-header border-secondary">
                    <h5 class="modal-title">Exportar Creación</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Formato:</label>
                        <select id="exportFormat" class="form-select bg-dark text-light border-secondary">
                            <option value="png">PNG (Recomendado)</option>
                            <option value="jpeg">JPEG</option>
                            <option value="webp">WebP</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Calidad (solo JPEG):</label>
                        <input type="range" id="exportQuality" class="form-range" min="10" max="100" value="90">
                        <div class="text-center small"><span id="exportQualityValue">90</span>%</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Tamaño:</label>
                        <div class="d-flex gap-2 align-items-center">
                            <input type="number" id="exportWidth" class="form-control bg-dark text-light border-secondary" placeholder="Ancho">
                            <span>×</span>
                            <input type="number" id="exportHeight" class="form-control bg-dark text-light border-secondary" placeholder="Alto">
                            <button type="button" id="useCanvasSizeBtn" class="btn btn-outline-primary btn-sm">Usar tamaño actual</button>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-secondary">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" id="downloadBtn" class="btn btn-primary">
                        <i class="fas fa-download me-2"></i>Descargar
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo \ObelisIA\Router\MainRouter::url('assets/js/tools/unified-editor/main.js');?>"></script>
</body>
</html>
