<?php
/**
 * Configuración de seguridad centralizada
 * Este archivo contiene validaciones y configuraciones de seguridad
 */

class SecurityConfig {
    
    /**
     * Lista de dominios permitidos para operaciones externas
     */
    const ALLOWED_EXTERNAL_DOMAINS = [
        'picsum.photos',
        'via.placeholder.com',
        'placehold.co',
        'images.unsplash.com',
        'source.unsplash.com',
        'cdn.pixabay.com',
        'images.pexels.com',
        'generativelanguage.googleapis.com',
        'api.replicate.com'
    ];
    
    /**
     * Archivos de herramientas permitidos
     */
    const ALLOWED_TOOL_FILES = [
        'TextGenerator.php',
        'ImageGenerator.php', 
        'MusicComposer.php',
        'VideoGenerator.php',
        'WordCounter.php',
        'BackgroundRemover.php',
        'ColorPaletteGenerator.php',
        'ContentCreator.php',
        'NEW_TextGenerator.php',
        'NEW_ImageGenerator.php',
        'NEW_MusicComposer.php',
        'NEW_ColorPaletteGenerator.php'
    ];
    
    /**
     * Archivos de vista permitidos
     */
    const ALLOWED_VIEW_FILES = [
        'TextGenerator_view.php',
        'ImageGenerator_view.php', 
        'MusicComposer_view.php',
        'VideoGenerator_view.php',
        'WordCounter_view.php',
        'BackgroundRemover_view.php',
        'ColorPaletteGenerator_view.php',
        'ContentCreator_view.php',
        'NEW_TextGenerator_view.php',
        'NEW_ImageGenerator_view.php',
        'NEW_MusicComposer_view.php',
        'NEW_ColorPaletteGenerator_view.php'
    ];
    
    /**
     * Acciones permitidas en APIs
     */
    const ALLOWED_API_ACTIONS = [
        'check_access',
        'generate',
        'save',
        'delete',
        'publish',
        'update'
    ];
    
    /**
     * Tipos de búsqueda permitidos
     */
    const ALLOWED_SEARCH_TYPES = [
        'all',
        'creations', 
        'users',
        'tools',
        'content'
    ];
    
    /**
     * Valida si un dominio está en la lista de permitidos
     */
    public static function isAllowedDomain($url) {
        $parsed_url = parse_url($url);
        if (!$parsed_url || !isset($parsed_url['host'])) {
            return false;
        }
        
        $host = strtolower($parsed_url['host']);
        foreach (self::ALLOWED_EXTERNAL_DOMAINS as $allowed_domain) {
            if ($host === $allowed_domain || str_ends_with($host, '.' . $allowed_domain)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Sanitiza y valida entrada de usuario
     */
    public static function sanitizeInput($input, $type = 'string') {
        switch ($type) {
            case 'string':
                return filter_var(trim($input), FILTER_SANITIZE_STRING);
            case 'email':
                return filter_var(trim($input), FILTER_SANITIZE_EMAIL);
            case 'url':
                return filter_var(trim($input), FILTER_SANITIZE_URL);
            case 'int':
                return filter_var($input, FILTER_VALIDATE_INT);
            case 'float':
                return filter_var($input, FILTER_VALIDATE_FLOAT);
            default:
                return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
        }
    }
    
    /**
     * Valida que un archivo esté en un directorio permitido
     */
    public static function validateFilePath($file_path, $allowed_directory) {
        $real_path = realpath($file_path);
        $real_allowed_dir = realpath($allowed_directory);
        
        return $real_path && $real_allowed_dir && 
               str_starts_with($real_path, $real_allowed_dir) && 
               file_exists($file_path);
    }
    
    /**
     * Valida ID alfanumérico
     */
    public static function validateId($id) {
        return preg_match('/^[a-zA-Z0-9_-]+$/', $id);
    }
    
    /**
     * Detecta patrones sospechosos en texto
     */
    public static function detectSuspiciousPatterns($input) {
        $suspicious_patterns = [
            '/[<>"\']/',           // HTML/XSS básico
            '/javascript:/i',      // JavaScript URLs
            '/data:/i',           // Data URLs
            '/vbscript:/i',       // VBScript
            '/on\w+\s*=/i',       // Event handlers
            '/eval\s*\(/i',       // eval()
            '/exec\s*\(/i',       // exec()
            '/system\s*\(/i',     // system()
        ];
        
        foreach ($suspicious_patterns as $pattern) {
            if (preg_match($pattern, $input)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Registra eventos de seguridad
     */
    public static function logSecurityEvent($event_type, $details, $severity = 'medium') {
        $log_entry = [
            'timestamp' => date('Y-m-d H:i:s'),
            'event_type' => $event_type,
            'details' => $details,
            'severity' => $severity,
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
        ];
        
        error_log("SECURITY_EVENT: " . json_encode($log_entry));
    }
}
